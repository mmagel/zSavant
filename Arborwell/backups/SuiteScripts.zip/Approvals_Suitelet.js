/*

 */


function empSearch(request, response) {

    var employ = request.getParameter('employ');

    var filters = new Array();
    filters[0] = new nlobjSearchFilter('internalid', null, 'is', employ);
    var columns = new Array();
    columns[0] = new nlobjSearchColumn('supervisor');
    columns[1] = new nlobjSearchColumn('custentity_aw_employee_estimate_limit');

    var results = nlapiSearchRecord('employee', null, filters, columns);
    var boss = results[0].getValue(columns[0]);
    var limit = results[0].getValue(columns[1]);

    response.write(boss + ':' + limit);

}