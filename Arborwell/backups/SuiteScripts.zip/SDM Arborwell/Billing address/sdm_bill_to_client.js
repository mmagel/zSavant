/**
 * Module Description
 *
 * Validates that only project names can be in the label field
 * 
 * Version    Date            Author           Remarks
 * 1.00       28 Oct 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord customer
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){
	// property verification
	
	var address_label = nlapiGetCurrentLineItemValue('addressbook', 'label');
	
	if(type == 'addressbook' && name == 'label' && address_label.length > 0 && linenum > 0){
		//See if property match
							
		var filters = new Array();
		filters[0] = new nlobjSearchFilter('name', null, 'is', address_label);
		var columns = new Array();
		columns[0] = new nlobjSearchColumn('name');
		var name_ray = nlapiSearchRecord('customrecord_aw_property', null, filters, columns);
		
		if(name_ray == null){
			nlapiSetCurrentLineItemValue('addressbook', 'label', '', false);
			alert('No property Found. Please enter the Property Name as it apperars on the property record');
						
		}
	}
}
