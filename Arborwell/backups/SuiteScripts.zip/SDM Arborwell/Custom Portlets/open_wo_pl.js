function PortletFunction(portlet, column)
{
    portlet.setTitle("Open Work Orders");
    portlet.setScript('customscript190');
    var fld = portlet.addField("custpage_google", "inlinehtml").setLayoutType('startrow');
    fld.setDefaultValue('<style>'+
    		  '#legend {'+
    			    'background: white;'+
    			    'padding: 10px;'+
    			  '}'+
    			'</style><script type="text/javascript" async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyANeqMrmHFy3VXAEC76i_nC8VJWqIylMEo&callback=draw_chart"></script><div id="map_div" style="width: 900px; height: 500px;"></div><div id="legend"></div>');
}  
function draw_chart()
{

	var mapi = new google.maps.Map(document.getElementById('map_div'),{
	    zoom: 8,
	    center: {lat:37.646537, lng:-122.125015},
	mapTypeId: google.maps.MapTypeId.ROADMAP
	  });
	mapi.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(
			  document.getElementById('legend'));
		var icons= {
          1:   'https://system.na1.netsuite.com/core/media/media.nl?id=687879&c=3685407&h=b37990f13c8eb807ebb0',

          2:   'https://system.na1.netsuite.com/core/media/media.nl?id=687871&c=3685407&h=b31acb55bf8dde887a66',

          3:'https://system.na1.netsuite.com/core/media/media.nl?id=687872&c=3685407&h=f151c0f2e630cb16a4e6',

          4: 'https://system.na1.netsuite.com/core/media/media.nl?id=687878&c=3685407&h=fb30a5e69de8c2229742',

            5:  'https://system.na1.netsuite.com/core/media/media.nl?id=687874&c=3685407&h=b2c275ce7b15872f2de0',

            6:  'https://system.na1.netsuite.com/core/media/media.nl?id=687877&c=3685407&h=7bb3c841734304487aac',

            7: 'https://system.na1.netsuite.com/core/media/media.nl?id=687873&c=3685407&h=1ad3bc33eced611e3bc1',

            8:  'https://system.na1.netsuite.com/core/media/media.nl?id=687876&c=3685407&h=64769a5b4222a76c5268',

            10:   'https://system.na1.netsuite.com/core/media/media.nl?id=687875&c=3685407&h=3606ee51ed938de230e9'
            };
		var legend = document.getElementById('legend');
		for (var i in icons) {
		  if (i==1){
			  name='Corporate'
		  }
		  else if (i==2){
			  name='East Bay';
		  }
		  else if (i==3){
			  name='Peninsula';
		  }
		  else if (i==4){
			  name='San Jose';
		  }
		  else if (i==5){
			  name='Sacramento';
		  }
		  else if (i==6){
			  name='Orange County';
		  }
		  else if (i==7){
			  name='San Diego';
		  }
		  else if (i==8){
			  name='Tree Moving';
		  }
		  else if (i==10){
			  name='Seattle';
		  }
		  var div = document.createElement('div');
		  div.innerHTML = '<img src="' + icons[i] + '"> ' + name;
		  legend.appendChild(div);
		}

     //alert(2);
	var wo_search=nlapiLoadSearch('customrecord_aw_work_order','customsearch842');
	var allresults=wo_search.runSearch();
	var j=0;

	do {

			var thisresults = allresults.getResults(j*1000,j*1000+1000);

		for (var i=0; i<thisresults.length; i++){
			var addressstring='';

			var addr1=thisresults[i].getValue('custrecord_aw_address_1','custrecord_aw_wo_property');

			var addr2=thisresults[i].getValue('custrecord_aw_address_2','custrecord_aw_wo_property');

			var addr3=thisresults[i].getValue('custrecord_aw_address_3','custrecord_aw_wo_property');

			var city=thisresults[i].getValue('custrecord_aw_city','custrecord_aw_wo_property');
			var state=thisresults[i].getText('custrecord_aw_state','custrecord_aw_wo_property');
			var zip=thisresults[i].getValue('custrecord_aw_zip','custrecord_aw_wo_property');
			var county=thisresults[i].getText('custrecord_aw_county','custrecord_aw_wo_property');
			var lati=thisresults[i].getValue('custrecord_lat','custrecord_aw_wo_property');
			var long=thisresults[i].getValue('custrecord_long','custrecord_aw_wo_property');

			if (addr1!=''&&addr1!=null){
				addressstring+=addr1+', ';
			}
			if (addr2!=''&&addr2!=null){
				addressstring+=addr2+', ';
			}
			if (addr3!=''&&addr3!=null){
				addressstring+=addr3+', ';
			}
			if (city!=''&&city!=null){
				addressstring+=city+', ';
			}
			if (state!=''&&state!=null){
				addressstring+=state+', ';
			}
			if (zip!=''&&zip!=null){
				addressstring+=zip;
			}
			var contentstring='<p>Property Address: '+addressstring+'<br/>';
			contentstring+='County: '+county+'<br/>';
			contentstring+='Date: '+thisresults[i].getValue('custrecord_aw_wo_date')+'<br/>';
			contentstring+='Client: '+thisresults[i].getText('custrecord_aw_wo_client')+'<br/>';
			contentstring+='Account Manager: '+thisresults[i].getText('custrecord_aw_wo_sales_rep')+'<br/>';
			contentstring+='Property: '+thisresults[i].getText('custrecord_aw_wo_property')+'<br/>';
			contentstring+='Sales Order: '+thisresults[i].getText('custrecord_aw_wo_so')+'<br/>';
			contentstring+='Sales Order Amount: '+thisresults[i].getValue('amount','custrecord_aw_wo_so')+'<br/>';
			contentstring+='Estimated Hours: '+thisresults[i].getValue('custrecord_sdm_est_hrs_wo')+'<br/>';
			contentstring+='Region: '+thisresults[i].getText('custrecord_aw_salesorder_region')+'<br/>';
			contentstring+='Prevailing Wage: '+thisresults[i].getValue('custrecord4')+'</p><br/>';
			contentstring+='<a href="https://system.na1.netsuite.com/app/common/custom/custrecordentry.nl?rectype=10&id='+thisresults[i].getValue('internalid')+'">Record Link</a>';
				var marker=new google.maps.Marker({
				    position: new google.maps.LatLng(lati, long),
				    icon:icons[thisresults[i].getValue('custrecord_aw_salesorder_region')],
				    title: thisresults[i].getValue('name','custrecord_aw_wo_property'),
				    visible: true,
				    map:mapi,
				    county:county,
				    addrstring:addressstring
				  });
				 var infowindow = new google.maps.InfoWindow();
				 
				 google.maps.event.addListener(marker,'click', (function(marker,contentstring,infowindow){ 
					    return function() {
					        infowindow.setContent(contentstring);
					        infowindow.open(mapi,marker);
					    };
					})(marker,contentstring,infowindow));  
		}
		j++;
	} while(allresults.getResults(j*1000,j*1000+1000).length==1000);
	
}
function geocodeprops (){
	var  geocoder = new google.maps.Geocoder();
	var wo_search=nlapiLoadSearch('customrecord_aw_work_order','customsearch841');
	var allresults=wo_search.runSearch();
	var j=0;
	do {

			var thisresults = allresults.getResults(j*1000,j*1000+1000);

for (var i=0; i<thisresults.length; i++){
	var addressstring='';

	var addr1=thisresults[i].getValue('custrecord_aw_address_1','custrecord_aw_wo_property');

	var addr2=thisresults[i].getValue('custrecord_aw_address_2','custrecord_aw_wo_property');

	var addr3=thisresults[i].getValue('custrecord_aw_address_3','custrecord_aw_wo_property');
	var prop=thisresults[i].getValue('custrecord_aw_wo_property');
	var city=thisresults[i].getValue('custrecord_aw_city','custrecord_aw_wo_property');
	var state=thisresults[i].getText('custrecord_aw_state','custrecord_aw_wo_property');
	var zip=thisresults[i].getValue('custrecord_aw_zip','custrecord_aw_wo_property');
	var county=thisresults[i].getText('custrecord_aw_county','custrecord_aw_wo_property');

	var add=true;
	if (addr1!=''&&addr1!=null){
		addressstring+=addr1+', ';
	}
	else {
		add=false;
	}
	if (addr2!=''&&addr2!=null){
		addressstring+=addr2+', ';
	}
	if (addr3!=''&&addr3!=null){
		addressstring+=addr3+', ';
	}
	if (city!=''&&city!=null){
		addressstring+=city+', ';
	}
	else {
		add=false;
	}
	if (state!=''&&state!=null){
		addressstring+=state+', ';
	}
	else {
		add=false;
	}
	if (zip!=''&&zip!=null){
		addressstring+=zip;
	}
	else {
		add=false;
	}
	if (county!=''&&county!=null){
		//addressstring+=county;
	}
	if (add&&addressstring!=''){
		//alert('here1');
		Geocode(addressstring,prop,geocoder);

		if (nlapiGetContext().getRemainingUsage()<50){
			alert('usage limit reached');
			return;
		}
	}
	
}
j++;
} while(allresults.getResults(j*1000,j*1000+1000).length==1000);
}
function Geocode(address,id,geocoder) {
	//alert('here '+address);
    geocoder.geocode({
        'address': address
    }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
            //var result = results[0].geometry.location;
        	var lat=results[0].geometry.location.lat();
        	var long=results[0].geometry.location.lng();
        	nlapiSubmitField('customrecord_aw_property',id,['custrecord_lat','custrecord_long'],[lat,long]);
        } else if (status === google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {    
            setTimeout(function() {
                Geocode(address,id);
            }, 200);
        } else {
            alert("Geocode was not successful for the following reason:" 
                  + status);
        }
    });
}
function chart_field_changed(){
	draw_chart();
}