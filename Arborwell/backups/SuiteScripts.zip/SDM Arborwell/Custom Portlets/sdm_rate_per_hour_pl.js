/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       29 Apr 2014     AHalbleib
 *
 */

/**
 * @param {nlobjPortlet} portletObj Current portlet object
 * @param {Number} column Column position index: 1 = left, 2 = middle, 3 = right
 * @returns {Void}
 */
function rate_per_hour(portletObj, column) {
	portletObj.setTitle('Rate Per Hour by Region');
	portletObj.setScript('customscript_sdm_rph_field_changed');
	
	//first day of month
	var start='';
	var end='';
	var month_date=new Date().getDate();
	if (get_last_day(new Date().getMonth()+1,new Date().getFullYear())==month_date){
		//this month is a full month
		var year=new Date().getFullYear();
		var month=new Date().getMonth();
		if (month==1){
			year-=1;
			month=12;
		}
		else if (month==0){
			month=11;
			year-=1;
		}
		else {
			month-=1;
		}
		start=month+'/1/'+year;
		 end=(new Date().getMonth()+1)+'/'+get_last_day(new Date().getMonth()+1,new Date().getFullYear())+'/'+new Date().getFullYear();
	}
	else {
			var start_year=new Date().getFullYear();
			var end_year=new Date().getFullYear();
			var start_month=new Date().getMonth();
			var end_month=new Date().getMonth();
			if (start_month==1){
				start_year-=1;
				start_month=11;
			}
			else if (start_month==0){
				start_month=10;
				end_month=12;
				start_year-=1;
				end_year-=1;
			}
			else if (start_month==2){
				start_month=12;
				start_year-=1;
			}
			else {
				start_month-=2;
			}
		 
		 start=start_month+'/1/'+start_year
		 end=end_month+'/'+get_last_day(end_month,end_year)+'/'+end_year;
	}
	
	portletObj.addField('custpage_start','date','Start Date').setLayoutType('startrow','startcol').setDefaultValue(start);
	//last day of month
	
	portletObj.addField('custpage_end','date','End Date').setLayoutType('startrow').setDefaultValue(end);
	portletObj.addField('custpage_region','select','Region','location').setLayoutType('startrow').setDefaultValue(2);
	portletObj.addField('custpage_html','inlinehtml','').setLayoutType('startrow').setDefaultValue(get_rph(2,start,end));
	//portletObj.addButton('custpage_refresh','Refresh','nlapiSetFieldValue(\'custpage_html\','+
		//	'get_rph(nlapiGetFieldValue(\'custpage_region\'),new Date(nlapiGetFieldValue(\'custpage_start\')),new Date(nlapiGetFieldValue(\'custpage_end\'))))');
}
function get_rph(region,start,end){
	
	var tb_filters=new Array();
	tb_filters.push(new nlobjSearchFilter('date',null,'within',start,end));
	if (region!='All'){
		tb_filters.push(new nlobjSearchFilter('custrecord_aw_salesorder_region','custcol_aw_time_work_order','anyof',region));
	}
	var tb_columns=new Array();
	tb_columns.push(new nlobjSearchColumn('durationdecimal',null,'sum'));
	var tsheets=nlapiSearchRecord('timebill',null,tb_filters,tb_columns);
	
	var in_filters=new Array();

	in_filters.push(new nlobjSearchFilter('trandate',null,'within',start,end));
	in_filters.push(new nlobjSearchFilter('location',null,'is',region));

	var in_columns=new Array();
	in_columns.push(new nlobjSearchColumn('amount',null,'sum'));
	var invoices=nlapiSearchRecord('transaction','customsearch778',in_filters,in_columns);
	var revenue=0;
	var hours=0;
	for (var i=0; invoices!=null&&i<invoices.length; i++){
		if (invoices[i].getValue('amount',null,'sum').length>0){
			revenue+=parseFloat(invoices[i].getValue('amount',null,'sum'));
		}
	}
	for (var i=0; tsheets!=null&&i<tsheets.length; i++){
			//hours+=parseFloat(tsheets[i].getValue('durationdecimal'));	
		if (tsheets[i].getValue('durationdecimal',null,'sum').length>0){
			hours+=parseFloat(tsheets[i].getValue('durationdecimal',null,'sum'));
		}
	}
	var html=get_table(region,start,end,revenue,hours);
	return html;
}
function get_table(region,start,end,revenue,hours){
	var html='';
	var div='<div style="background-color:rgb(42,103,162); color:white; width:300px;  border-radius:5px; font-size:14px; padding:2px;"><b>';
	if (region!='All'){
		div+=nlapiLookupField('location',region,'name')+': '+start+'-'+end;
	}
	else {
		div+='All Regions'+': '+start+'-'+end;
	}
	div+='</b></div>';
	html+='<table border="0"style="background-color:rgb(185,199,212); width:300px; height:100px;border-radius:10px; padding:2px;">';
	var row='';
	row+=td('Revenue','background-color:beige;');
	row+=td('$'+nwc(revenue.toFixed(2)),'background-color:mintcream;');
	html+=tr(row);
	row='';
	row+=td('Hours','background-color:beige;');
	if (hours>0){
		row+=td(nwc(hours.toFixed(2)),'background-color:mintcream;');
	}
	else {
		row+=td(0,'background-color:mintcream;');
	}
	html+=tr(row);
	row='';
	row+=td('Per Hour','background-color:beige;');
	if (revenue>0&&hours>0){
		row+=td('$'+nwc((revenue.toFixed(2)/hours.toFixed(2)).toFixed(2)),'background-color:mintcream;');
	}
	else {
		row+=td('$'+0,'background-color:mintcream;');
	}
	html+=tr(row);
	html+='</table>';
	html=div+html;
	return html;
}
function field_changed(type,name,linenum){
	var region=parseInt(nlapiGetFieldValue('custpage_region'));
	var start=nlapiGetFieldValue('custpage_start');
	var end=nlapiGetFieldValue('custpage_end');
	if (region>0){
		var html=get_rph(region,start,end);
	}
	else {
		var html=get_rph('All',start,end);
	}
	if (name=='custpage_region'){
		
		nlapiSetFieldValue('custpage_html',html);
	}
	if (name=='custpage_start'){
		//var html=get_rph(region,start,end);
		nlapiSetFieldValue('custpage_html',html);
	}
	if (name=='custpage_end'){
		//var html=get_rph(region,start,end);
		nlapiSetFieldValue('custpage_html',html);
	}
}
function get_last_day(month,year){
	if (month=='1'||month=='3'||month=='5'||month=='7'||month=='8'||month=='10'||month=='12'){
		return 31;
	}
	else if(month=='4'||month=='6'||month=='9'||month=='11'){
		return 30;
	}
	else if (month=='2'){
		if (year%4==0){
			return 29;
		}
		else {
			return 28;
		}
	}
}
function nwc(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function tr(value,style){
	if (style!=null){
		return '<tr style="'+style+'">'+value+'</tr>';
	}
	return '<tr>'+value+'</tr>';
}
function td(value,style){
	if (style!=null){
		return '<td style="'+style+'">'+value+'</td>';
	}
	return '<td>'+value+'</td>';
}