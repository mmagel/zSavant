/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       05 Nov 2014     AHalbleib
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
//648,649,650,651,652
function contains(a, obj) {
    for (var i = 0; i < a.length; i++) {
        if (a[i] === obj) {
            return true;
        }
    }
    return false;
}
function download_searches(request,response) {
	var attachment=nlapiRequestURL('https://system.na1.netsuite.com/app/common/custom/custrecordentry.nl?rectype=10&id=22&print=T');
	var file=nlapiCreateFile('wo.html','HTMLDOC',attachment.getBody());
	nlapiSendEmail(nlapiGetUser(),nlapiGetUser(),'h',attachment.getBody(),null,null,null,file);

	var contents=''; 
	var temp=new Array();
	temp.push('Ovation Time Upload');
	contents+=temp.toString() + '\n';
	
	temp=new Array();
	temp.push('Emp #');
	temp.push('Code');
	temp.push('Time');
	contents+=temp.toString() + '\n';
	temp=new Array();
	var resultsst=nlapiSearchRecord('timebill',652);//st
	var resultsot=nlapiSearchRecord('timebill',649);//ot
	var resultspto=nlapiSearchRecord('timebill',651);//pto
	var resultshol=nlapiSearchRecord('timebill',650);//holiday
	var resultsdot=nlapiSearchRecord('timebill',648);//dot
	var emps=new Array();
	for (var i=0;resultsst!=null&&i<resultsst.length;i++){
		var val=resultsst[i].getValue('custentity5','employee','group');
		if (!contains(emps,val))
			emps.push(val);
	}	
	for (var i=0;resultspto!=null&&i<resultspto.length;i++){
		var val=resultspto[i].getValue('custentity5','employee','group');
		if (!contains(emps,val))
			emps.push(val);
	}	
	for (var i=0;resultshol!=null&&i<resultshol.length;i++){
		var val=resultshol[i].getValue('custentity5','employee','group');
		if (!contains(emps,val))
			emps.push(val);
	}	
	emps.sort(function(a, b){return a-b;});
		var content = new Array(); 
		for (var i=0;emps!=null&&i<emps.length;i++){
			add_array(resultsst,652,emps[i],content);
			add_array(resultsot,649,emps[i],content);
			add_array(resultspto,651,emps[i],content);
			add_array(resultshol,650,emps[i],content);
			add_array(resultsdot,648,emps[i],content);
		}
		for (var z = 0; z < content.length; z++) { 
			contents += content[z].toString() + '\n'; 
		}
	
	// Creating a csv file and passing the contents string variable. 
	var d=new Date();
	var day=d.getDay();
	var sunday='';
	var monday='';
	if (day==0){
		sunday=nlapiAddDays(d,-7);
		monday=nlapiAddDays(d,-13);
	}
	else if (day==1){
		sunday=nlapiAddDays(d,-1);
		monday=nlapiAddDays(d,-7);
	}
	else if (day==2){
		sunday=nlapiAddDays(d,-2);
		monday=nlapiAddDays(d,-8);
	}
	else if (day==3){
		sunday=nlapiAddDays(d,-3);
		monday=nlapiAddDays(d,-9);
	}
	else if (day==4){
		sunday=nlapiAddDays(d,-4);
		monday=nlapiAddDays(d,-10);
	}
	else if (day==5){
		sunday=nlapiAddDays(d,-5);
		monday=nlapiAddDays(d,-11);
	}
	else if (day==6){
		sunday=nlapiAddDays(d,-6);
		monday=nlapiAddDays(d,-12);
	}
	var file = nlapiCreateFile('lastweektime'+nlapiDateToString(monday).replace(/\//g, '.')+nlapiDateToString(sunday).replace(/\//g, '.')+'.csv', 'CSV', contents);
	file.setFolder(419831);
	var file_id=nlapiSubmitFile(file);
	file=nlapiLoadFile(file_id);
	response.setContentType('CSV',file.getName());
	response.write(file.getValue());
}
function add_array(results,t,emp,content){
	for (var i=0; results!=null&&i<results.length; i++){
		
		if (emp==results[i].getValue('custentity5','employee','group')){
		var val='';
		var temp=new Array();
		val=results[i].getValue('custentity5','employee','group');
		temp.push("\""+val.replace(/"/g,'\"\"')+'\"');
		val=results[i].getValue('formulatext',null,'group');
		temp.push("\""+val.replace(/"/g,'\"\"')+'\"');
		if (t==648){
			val=results[i].getValue('custcol_aw_time_hours_double_overtime',null,'sum');
		}
		else if (t==649){
			val=results[i].getValue('custcol_aw_time_hours_overtime',null,'sum');
		}
		else if (t==650||t==651){
			val=results[i].getValue('durationdecimal',null,'sum');
		}
		else {
			val=results[i].getValue('custcol_aw_time_hours_standard',null,'sum');
		}
		temp.push("\""+val.replace(/"/g,'\"\"')+'\"');
		content.push(temp);
		}
}
}
