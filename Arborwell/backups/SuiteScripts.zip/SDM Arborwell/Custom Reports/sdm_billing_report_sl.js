function get_last_day(month, year) {
	if (month == '1' || month == '3' || month == '5' || month == '7'
			|| month == '8' || month == '10' || month == '12') {
		return 31;
	} else if (month == '4' || month == '6' || month == '9' || month == '11') {
		return 30;
	} else if (month == '2') {
		if (year % 4 == 0) {
			return 29;
		} else {
			return 28;
		}
	}
}
function commish_report(request, response) {
	if (request.getMethod()=='GET') {
		var form=nlapiCreateForm('Commissions Report');
		var employees=form.addField('custpage_employee','select','Employee','employee').setLayoutType('startrow','startcol').setPadding(1);
		var year=form.addField('custpage_year','select','Year').setLayoutType('startrow');
		year.addSelectOption(2014,2014,false);
		var month=form.addField('custpage_month','select','Month').setLayoutType('startrow');
		month.addSelectOption(1,'January',false);
		month.addSelectOption(2,'February',false);
		month.addSelectOption(3,'March',false);
		month.addSelectOption(4,'April',false);
		month.addSelectOption(5,'May',false);
		month.addSelectOption(6,'June',false);
		month.addSelectOption(7,'July',false);
		month.addSelectOption(8,'August',false);
		month.addSelectOption(9,'September',false);
		month.addSelectOption(10,'October',false);
		month.addSelectOption(11,'November',false);
		month.addSelectOption(12,'December',false);
form.addField('custpage_hint','inlinehtml','').setDisplayType('inline').setLayoutType('outsideabove').setDefaultValue('<div style="border-radius:5px; padding-left:3px;'
				+'padding-top:3px; padding-right:3px; padding-bottom:3px; width:200px; height:100%; border:dotted 1px; background-color:aliceblue; border:dotted' 
				+'1px;">Enter the employee, month and year to see his or her commission report.</div>');
		form.addSubmitButton('Run Report');
response.writePage(form);
	}
	else {
		//var no_gp=0;
		var rec_id=0;
var html='';
		var employee = request.getParameter('custpage_employee');

		var month = request.getParameter('custpage_month');
		var year = request.getParameter('custpage_year');
		var last_day = get_last_day(month, year);

		date_filters = new Array();
		date_filters[0] = new nlobjSearchFilter('trandate', null, 'onorafter',
				new Date(month + '/1/' + year));
		date_filters[1] = new nlobjSearchFilter('trandate', null, 'onorbefore',
				new Date(month + '/' + last_day + '/' + year));
		date_filters[2] = new nlobjSearchFilter('mainline', null, 'is',
		'F');
		date_filters[3] = new nlobjSearchFilter('type', 'appliedtotransaction',
				'is', 'CustInvc');
		var payment_columns = new Array();
		payment_columns[0] = new nlobjSearchColumn('internalid');
		payment_columns[1] = new nlobjSearchColumn('trandate');
		payment_columns[2] = new nlobjSearchColumn('amount');
		payment_columns[3] = new nlobjSearchColumn('appliedtotransaction');
		payment_columns[4] = new nlobjSearchColumn('amount',
				'appliedtotransaction');
		payment_columns[5] = new nlobjSearchColumn('amountpaid',
				'appliedtotransaction');
		payment_columns[6] = new nlobjSearchColumn('amountremaining',
				'appliedtotransaction');
		payment_columns[7] = new nlobjSearchColumn('tranid',
				'appliedtotransaction');
		payment_columns[8] = new nlobjSearchColumn('internalid',
				'appliedtotransaction');
		var payments = nlapiSearchRecord('customerpayment', null, date_filters,
				payment_columns);
		var invoices = new Array();
		var message=false;
		if (payments != null) {
			// make list of invoices with payments applied for the chosen month
			for ( var i = 0; i < payments.length; i++) {
				var id = payments[i].getValue('internalid',
						'appliedtotransaction');
				if (invoices.indexOf(id) < 0) {
					invoices.push(id);
				}
			}
			var invoice_filters = new Array();
			invoice_filters[0] = new nlobjSearchFilter('internalid', null,
					'anyof', invoices);
			invoice_filters[1] = new nlobjSearchFilter('salesrep', null,
					'anyof', employee);
			invoice_filters[2] = new nlobjSearchFilter('mainline', null, 'is',
					'F');

			var columns = new Array();
			columns[0] = new nlobjSearchColumn('internalid');
			columns[1] = new nlobjSearchColumn('entity');
			columns[2] = new nlobjSearchColumn('salesrep');
			columns[3] = new nlobjSearchColumn('amount');
			columns[4] = new nlobjSearchColumn('tranestgrossprofit');
			columns[5] = new nlobjSearchColumn('rate');
			columns[6] = new nlobjSearchColumn('discountamount');
			columns[7] = new nlobjSearchColumn('effectiverate');
			columns[8] = new nlobjSearchColumn(
					'custbody_aw_invoice_margin_percent');
			columns[9] = new nlobjSearchColumn('custbody_aw_invoice_profit');
			columns[10] = new nlobjSearchColumn('tranid');
			columns[11] = new nlobjSearchColumn('estgrossprofit');
			columns[12] = new nlobjSearchColumn('estgrossprofitpct');
			columns[13] = new nlobjSearchColumn('memo');
			columns[14] = new nlobjSearchColumn('createdfrom');
			columns[15] = new nlobjSearchColumn('class');
			columns[16] = new nlobjSearchColumn('item');
			columns[17] = new nlobjSearchColumn('itemid', 'item');
			columns[18] = new nlobjSearchColumn('type', 'item');
			columns[19] = new nlobjSearchColumn('itemid', 'item');
			columns[20] = new nlobjSearchColumn('class', 'item');
			var s = nlapiCreateSearch('invoice', invoice_filters, columns);
			var employee_invoices = s.runSearch();
			var cols = employee_invoices.getColumns();
			var results = employee_invoices.getResults(0, 1000);
			var sales_orders = new Array();
			var patt = new RegExp('[0-9]+');

			for ( var i = 0; results!=null&&i < results.length; i++) {
				if (sales_orders.indexOf(results[i].getValue('createdfrom')) < 0) {
					if (patt.test(results[i].getValue('createdfrom'))) {
						sales_orders.push(results[i].getValue('createdfrom'));
					}

				}
			}
			
			var so_filters = new Array();
			so_filters[0] = new nlobjSearchFilter('internalid', null, 'anyof',
					sales_orders);
			var so_columns = new Array();
			so_columns[0] = new nlobjSearchColumn('tranid');
			so_columns[1] = new nlobjSearchColumn('internalid');
			so_columns[2] = new nlobjSearchColumn('custbody_aw_work_order');
			so_columns[3] = new nlobjSearchColumn('custbody_aw_invoice_margin_percent');
			var so_wo = null;
			if (sales_orders.length > 0) {
				so_wo = nlapiSearchRecord('salesorder', null, so_filters,
						so_columns);
			}
			// get commish %
			var name = nlapiLookupField('employee', employee, 'entityid', null);
			var gtc = convert_percent_to_decimal(nlapiLookupField('employee',
					employee, 'custentity_aw_gtc_commission', null));
			var phc = convert_percent_to_decimal(nlapiLookupField('employee',
					employee, 'custentity_aw_phc_comm', null));
			var consult = convert_percent_to_decimal(nlapiLookupField(
					'employee', employee, 'custentity_aw_cnslt_comm', null));
			var gis = convert_percent_to_decimal(nlapiLookupField('employee',
					employee, 'custentity_aw_gis_comm', null));
			var stump = convert_percent_to_decimal(nlapiLookupField('employee',
					employee, 'custentity_aw_stump_comm', null));
			var move = convert_percent_to_decimal(nlapiLookupField('employee',
					employee, 'custentity_aw_tree_moving_comm', null));
			var warranty = convert_percent_to_decimal(nlapiLookupField(
					'employee', employee, 'custentity_aw_warranty_comm', null));

			// set up header
			var report = new Array();
			var report_csv = new Array();
			report
					.push('<table border=".5 dotted darkslategray" cellborder=".5 dotted darkslategray" style="text-align:center; font-size:12px;  background-color:aliceblue;">');
			report.push('<tr>');
			report.push('<td><b>Invoice ID</b></td>');
			report.push('<td><b>Sales Order</b></td>');
			report.push('<td><b>Work Order</b></td>');
			report.push('<td><b>Client Name</b></td>');
			report.push('<td><b>GP%</b></td>');
			report.push('<td><b>Payment ID(s)</b></td>');
			report.push('<td><b>Payment Date(s)</b></td>');
			report.push('<td><b>Payment Amount(s)</b></td>');
			report.push('<td><b>PHC</b></td>');
			report.push('<td><b>GTC</b></td>');
			report.push('<td><b>Consulting</b></td>');
			report.push('<td><b>Moving</b></td>');
			report.push('<td><b>GIS</b></td>');
			report.push('<td><b>Warranty</b></td>');
			report.push('<td><b>Stumps</b></td>');
			report.push('<td><b>Adjustments</b></td>');
			report.push('<td><b>Invoice Total</b></td>');
			report.push('<td><b>Payment Total for Month</b></td>');
			report.push('<td><b>Total Invoice Commissions</b></td>');
			report.push('</tr>');
			report_csv.push(',Invoice ID');
			report_csv.push('Sales Order');
			report_csv.push('Work Order');
			report_csv.push('Client Name');
			report_csv.push('GP%');
			report_csv.push('Payment ID(s)');
			report_csv.push('Payment Date(s)');
			report_csv.push('Payment Amount(s)');
			report_csv.push('PHC');
			report_csv.push('GTC');
			report_csv.push('Consulting');
			report_csv.push('Moving');
			report_csv.push('GIS');
			report_csv.push('Warranty');
			report_csv.push('Stumps');
			report_csv.push('Adjustments');
			report_csv.push('Invoice Total');
			report_csv.push('Payment Total for Month');
			report_csv.push('Total Invoice Commissions');
			report_csv.push('\n');
			var line_commish = 0;
			var invoice_commish = 0;
			var invoice_count = 0;
			var total_gp = 0;
			var total_commish = 0;
			var low_commish = 0;
			var discount = 0;
			var adjust_display = '';
			// invoice subtotall=0
			// plant health care=1
			// general tree care=2
			// consulting=3
			// moving=4
			// invoice total=5
			// gis=6
			// warranty=7
			// stump=8
			var work_type;
			// indexes 0 and 5 are free for other uses, other indexes hold
			// running totals for work type amounts
			var amounts = [ 0, 0, 0, 0, 0, 0, 0, 0, 0 ];
			var disc_rate = 0;
			var current_invoice = -1;
			var paid = 0;
			var adjustment = 0;
			var gp = 0;

			var line_invoice = -1;
			
			for ( var i = 0; results.length>0&&i < results.length + 1; i++) {
				if (i < results.length) {
					line_invoice = results[i].getValue(cols[0].getName(),
							cols[0].getJoin());
					
				}

				// new invoice line
				//get the amoint paid on the invoice for the month from payment line level rather than doing math
				//change invoice total to reflect discount
				//calculate discount off total rather than subtotal so percentages match
				if (current_invoice != line_invoice || i == results.length) {

					if (current_invoice != -1) {
						// sum up payments made on this invoice for the month
						for ( var j = 0; j < inv_payments.length; j++) {
							//if (j == 0) {
							//	remaining = inv_payments[0].getValue(
							//			'amountremaining',
							//			'appliedtotransaction');
							//}
							if (inv_payments[j].getValue('internalid','appliedtotransaction')==current_invoice){
								paid += inv_payments[j].getValue('amount','appliedtotransaction')*1;
								remaining = inv_payments[j].getValue(
										'amountremaining',
										'appliedtotransaction');
								if (remaining.length<1){
									remaining = inv_payments[0].getValue('amountremaining');
								}
							}
						}
						// calculate amount paid this month/over invoice total
						discount = parseFloat(results[i - 1]
						.getValue('discountamount')
						* -1);
				// get payments applied from line level of customer of payment
				//var subtotal = parseFloat(amounts[0] + discount);
				var subtotal = parseFloat(amounts[0]);
				disc_rate = discount / subtotal;
						if (paid > amounts[5]) {
							// if payment amount>invoice amount, 1 payment was
							// made for multiple invoices
							adjustment = 1;
						} else {
							adjustment = parseFloat(paid / (amounts[5]-(disc_rate*amounts[5])));
							if (remaining>0){
								adjustment-=remaining/amounts[5];
							}
						}

						// calculate commision taking into account the actual
						// amount paid on this invoice for the month
						amounts[1] *= phc * adjustment;
						amounts[2] *= gtc * adjustment;
						amounts[3] *= consult * adjustment;
						amounts[4] *= move * adjustment;
						amounts[6] *= gis * adjustment;
						amounts[7] *= warranty * adjustment;
						amounts[8] *= stump * adjustment;
						// we now have the total commisions for the month for
						// each category
						report.push('<td>' + parseFloat(amounts[1]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[1]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[2]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[2]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[3]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[3]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[4]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[4]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[6]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[6]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[7]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[7]).toFixed(2));
						report.push('<td>' + parseFloat(amounts[8]).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[8]).toFixed(2));

						if (paid > amounts[5]) {
							paid = amounts[5];
						}
						if (parseFloat(remaining) > 0 && paid == amounts[5]) {
							paid -= parseFloat(remaining);
						}
						
						//remaing = inv_payments[0].getValue('amountremaining');
						invoice_commish += parseFloat(amounts[1] + amounts[2]
								+ amounts[3] + amounts[4] + amounts[6]
								+ amounts[7] + amounts[8]);
						report.push('<td>Discount: ' + disc_rate.toFixed(2)
								* 100 + '%<br/>' + 'Remaining:' + remaining
								+ '</td>');
						report_csv.push('Discount: ' + disc_rate.toFixed(2)
								* 100 + '%' + 'Remaining:' + remaining);
						report.push('<td>' + parseFloat(amounts[5]-(amounts[5]*disc_rate)).toFixed(2)
								+ '</td>');
						report_csv.push(parseFloat(amounts[5]-(amounts[5]*disc_rate)).toFixed(2));
						report.push('<td>' + paid.toFixed(2) + '</td>');
						report_csv.push(paid.toFixed(2));
						report.push('<td>' + invoice_commish.toFixed(2)
								+ '</td>');
						report_csv.push(invoice_commish.toFixed(2));
						report.push('</tr>');
						report_csv.push('\n');
						total_commish += invoice_commish;
						// gp=index 0, commish=index 1
						if (gp >= .60) {
							low_commish += invoice_commish;
						}
						if (i == results.length) {
							break;
						}
					}
					report.push('<tr>');
					invoice_commish = 0;
					paid = 0;
					adjustment = 0;

					disc_rate = 0;
					var pay_amounts = new Array();
					amounts = [ 0, 0, 0, 0, 0, 0, 0, 0, 0 ];
					current_invoice = line_invoice;
					discount = 0;
					invoice_count += 1;
					
					inv_payments = get_payments(current_invoice, payments);
					var ids = new Array();
					var dates = new Array();
					
					for ( var j = 0; j < inv_payments.length; j++) {
						ids.push(inv_payments[j].getValue('internalid'));
						dates.push(inv_payments[j].getValue('trandate'));
						pay_amounts.push(inv_payments[j].getValue('amount')
								* -1);
					}
					report.push('<td>' + results[i].getValue('tranid')
							+ '</td>');
					report_csv.push(results[i].getValue('tranid'));
					var so_index;
					if (so_wo != null) {
						so_index = get_index(so_wo, results[i]
								.getValue('createdfrom'));
					} else {
						so_index = -1;
					}

					// report.push('<td>'+so_wo.length+'</td>');
					if (so_index > -1) {
						report.push('<td>' + so_wo[so_index].getValue('tranid')
								+ '</td>');
						report_csv.push(so_wo[so_index].getValue('tranid'));
						// report_csv.push(so_wo[so_index].getValue('tranid'));
						// report.push('<td>'+so_index+'</td>');
						report.push('<td>'
								+ so_wo[so_index]
										.getValue('custbody_aw_work_order')
								+ '</td>');
						report_csv.push(so_wo[so_index]
								.getValue('custbody_aw_work_order'));
					} else {
						var inv_memo = nlapiLookupField('invoice', results[i]
								.getValue('internalid'), 'memo');
						if (inv_memo.length > 0) {
							report.push('<td>CSV</td>');
							report_csv.push('CSV');
							// report_csv.push(so_wo[so_index].getValue('tranid'));
							// report.push('<td>'+so_index+'</td>');
							report.push('<td>' + inv_memo + '</td>');
							report_csv.push(inv_memo);
						} else {
							report.push('<td>Not Found</td>');
							report.push('<td>Not Found</td>');
							report_csv.push('Not Found');
							report_csv.push('Not Found');
						}
					}
					// report_csv.push(so_wo[so_index].getValue('custbody_aw_work_order'));

					// customer name
					report
							.push('<td>' + results[i].getText('entity')
									+ '</td>');
					report_csv.push(results[i].getText('entity').replace(/,/g,
							' '));
					// gp%
					if (so_index>-1 && so_wo[so_index]
						.getValue('custbody_aw_invoice_margin_percent')!=null && so_wo[so_index]
						.getValue('custbody_aw_invoice_margin_percent').length>0){
							gp = convert_percent_to_decimal(so_wo[so_index]
							.getValue('custbody_aw_invoice_margin_percent'));
							total_gp += gp;
							report.push('<td>' + so_wo[so_index].getValue('custbody_aw_invoice_margin_percent')
								+ '</td>');
							report_csv.push(so_wo[so_index].getValue('custbody_aw_invoice_margin_percent'));
					}
					else {
						total_gp += .70;
						report
							.push('<td>70.0%</td>');
						report_csv.push('70%');
					}
					// payment number
					report.push('<td>' + ids.toString() + '</td>');
					report_csv.push(ids.toString().replace(/,/g, ' '));
					// payment date
					report.push('<td>' + dates.toString() + '</td>');
					report_csv.push(dates.toString().replace(/,/g, ' '));
					// payment amount
					report.push('<td>' + pay_amounts.toString() + '</td>');
					report_csv.push(pay_amounts.toString().replace(/,/g, ' '));
					// invoice amount
					// report.push('<td>'+inv_payments[0].getValue('amount','appliedtotransaction')+'</td>');
					//
				}
				work_type = results[i].getValue('class', 'item');
				if (work_type == 1 || work_type == 2 || work_type == 3
						|| work_type == 4 || work_type == 6 || work_type == 7
						|| work_type == 8) {
					amounts[work_type] += (results[i].getValue('amount') - results[i]
							.getValue('discountamount'));
					// update subtotal
			if (work_type.length>0){
				amounts[0] += results[i].getValue('amount') - 0;
					// update total
				amounts[5] += results[i].getValue('amount') - 0;
			}
			if (current_invoice==9182){						
					nlapiLogExecution('ERROR',current_invoice,results[i].getValue('amount')+' '+work_type);
			}
			} else {
				work_type = results[i].getValue('class');
				amounts[work_type] += (results[i].getValue('amount') - results[i]
					.getValue('discountamount'));
					// update subtotal
			if (work_type.length>0){
				amounts[0] += results[i].getValue('amount') - 0;
				// update total
				amounts[5] += results[i].getValue('amount') - 0;
			}
			if (current_invoice==9182){						
				nlapiLogExecution('ERROR',current_invoice,results[i].getValue('amount')+' '+work_type);
			}
				}
			}
			if (results.length<1){
				message=true;
			}
			report.push('</table>');
			var avg_gp = parseFloat(total_gp / invoice_count);
			var span='<span style="font-size:18px;">'
			var head = '<div style="width:250px; height:100%; background-color:lavender; border-style:dotted; font-size:18px;">';
			head+=nlapiLookupField('employee',employee,'entityid')+'<br/>';
			head += 'Average GP: ' + (avg_gp * 100).toFixed(2) + '%<br/>';
			span += 'Average GP: ' + (avg_gp * 100).toFixed(2) + '%<br/>';
			report_csv.push('Average GP: ' + (avg_gp * 100).toFixed(2) + '%');
			if (avg_gp >= .60) {
				// get all commissions
				head += 'Total Commissions: ' + total_commish.toFixed(2);
				span += 'Total Commissions: ' + total_commish.toFixed(2);
				report_csv.push('Total Commissions: '
						+ total_commish.toFixed(2));
			} else {
				head += 'Total Commissions: ' + low_commish.toFixed(2);
				span += 'Total Commissions: ' + low_commish.toFixed(2);
				report_csv.push('Total Commissions: ' + low_commish.toFixed(2));
			}
			span+='</span>'
			head += '</div>';
			sendbody = report.toString();
			sendbody = sendbody.replace(/,/g, ' ');
			var mm = nlapiCreateRecord('customrecord_sdm_mm');
			rec_id = nlapiSubmitRecord(mm, false, false);
			var xml = "<?xml version=\"1.0\"?>" +
			'<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">'+
			'<pdf><head><meta name="title" value="Commissions Report"/><macrolist><macro id="myheader"><p align="center" font-size="18"><b> Commissions Report: '+nlapiLookupField('employee',employee,'entityid')+' '+month+'-'+year+'</b></p></macro></macrolist></head><body text-align="justify" size="A3" header="myheader" header-height="20mm">';
			nlapiSubmitField('customrecord_sdm_mm', rec_id,
					'custrecord_sdm_mm_report_html', xml+span+sendbody, false);
			nlapiSubmitField('customrecord_sdm_mm', rec_id,
					'custrecord_sdm_report_csv', report_csv.toString(), false);
html=head+sendbody;
		} else {
			message=true;
		}
		if (message){
			var xml = "<?xml version=\"1.0\"?>" +
			'<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">'+
			'<pdf><head><meta name="title" value="Commissions Report"/></head><body text-align="justify" size="A3-landscape">';
			var head = '<div style="width:200px; height:100%; background-color:lavender; border-style:dotted; padding:5px;  font-size:18px;">';
			head += 'no data returned for '
					+ request.getParameter('custpage_month')
					+ '-'
					+ request.getParameter('custpage_year')+'.';
			head += '</div>';
			var mm = nlapiCreateRecord('customrecord_sdm_mm');
			rec_id = nlapiSubmitRecord(mm, false, false);
			nlapiSubmitField('customrecord_sdm_mm', rec_id,
					'custrecord_sdm_mm_report_html', xml+head, false);
			nlapiSubmitField('customrecord_sdm_mm', rec_id,
					'custrecord_sdm_report_csv', 'No Data Returned', false);
html=head;
		}
		// report.push('<div style="width:200px; height:150px;
		// background-color:ghostwhite; border:dotted 1px; font-size:14px;">');
		// report.push( 'Name: ' + name + '<br>');
		// report.push(month + '&nbsp' + year + '<br><br>');
		// report.push( 'Commission %<br>');
		// report.push( 'GTC: ' + (gtc * 100) + '%<br>');
		// report.push( 'PHC: ' + (phc * 100) + '%<br>');
		// report.push( 'Consulting: ' + (consult * 100) + '%<br>');
		// report.push( 'GIS: ' + (gis * 100) + '%<br>');
		// report.push( 'STUMPS: ' + (stump * 100) + '%<br>');
		// report.push( 'Move:' + (move * 100) + '%<br>');
		// report.push( 'Warranty:' + (warranty * 100) + '%<br><br>');
		// report.push('</div>');



		var form=nlapiCreateForm('Commissions Report');
		var employee1=nlapiLookupField('employee',employee,'entityid');
		form.addField('custpage_html1','longtext','asdf').setDisplayType('hidden').setDefaultValue(html);
		form.addField('custpage_mm_id','text','asdf').setDisplayType('hidden').setDefaultValue(rec_id);
		var employees=form.addField('custpage_employee','select','Employee','employee').setPadding(1).setLayoutType('startrow','startcol').setDefaultValue(employee);
		form.addField('custpage_date1','text','asdf').setDisplayType('hidden').setDefaultValue(employee1+': '+month+'-'+year);
		var year_field=form.addField('custpage_year','select','Year').setLayoutType('startrow');
		year_field.addSelectOption(2014,2014,true);
		var month_field=form.addField('custpage_month','select','Month').setLayoutType('startrow');
		month_field.addSelectOption(1,'January',false);
		month_field.addSelectOption(2,'February',false);
		month_field.addSelectOption(3,'March',false);
		month_field.addSelectOption(4,'April',false);
		month_field.addSelectOption(5,'May',false);
		month_field.addSelectOption(6,'June',false);
		month_field.addSelectOption(7,'July',false);
		month_field.addSelectOption(8,'August',false);
		month_field.addSelectOption(9,'September',false);
		month_field.addSelectOption(10,'October',false);
		month_field.addSelectOption(11,'November',false);
		month_field.addSelectOption(12,'December',false);
		month_field.setDefaultValue(month);		
		if (message==false){
			form.addButton('custpage_email_button','Email Report','var email=window.prompt(\'Please enter the address you would like to email this report to.\',\'blank@blank.com\');if (email!=null){nlapiSendEmail(nlapiGetContext().getUser(),email,\'Commissions Report: \'+nlapiGetFieldValue(\'custpage_date1\'),nlapiGetFieldValue(\'custpage_html1\'));}');
			form.addButton('custpage_csv_button','Export to CSV','var csv_url=nlapiResolveURL(\'SUITELET\', \'customscript_sdm_export_csv\', \'customdeploy_sdm_export_csv\');csv_url += \'&custpage_mm_id=\'+nlapiGetFieldValue(\'custpage_mm_id\');window.open(csv_url);');
			form.addButton('custpage_pdf_button','Export to PDF','var pdf_url=nlapiResolveURL(\'SUITELET\', \'customscript_sdm_export_pdf\', \'customdeploy_sdm_export_pdf\');pdf_url += \'&custpage_mm_id=\'+nlapiGetFieldValue(\'custpage_mm_id\');window.open(pdf_url);');
		}
form.addField('custpage_hint','inlinehtml','').setDisplayType('inline').setLayoutType('outsideabove').setDefaultValue('<div style="border-radius:5px; padding-left:3px;'
				+'padding-top:3px; padding-right:3px; padding-bottom:3px; width:200px; height:100%; border:dotted 1px; background-color:aliceblue; border:dotted' 
				+'1px;">Enter the employee, month and year to see his or her commission report.</div>');
		form.addSubmitButton('Run Report');
form.addField('custpage_html','inlinehtml','').setPadding(1).setDefaultValue(html);
response.writePage(form);
	} 
}
// get array of invoice relevant results from the larger array of payments
// returned
function get_payments(invoice_id, payments) {
	var inv_payments = new Array();
	for ( var i = 0; i < payments.length; i++) {
		if (payments[i].getValue('internalid', 'appliedtotransaction') == invoice_id) {
			inv_payments.push(payments[i]);
		}
	}
	return inv_payments;
}
function convert_percent_to_decimal(Value) {

	var val_return = ((Value.split("%"))[0]) / 100;
	return val_return;

}
function get_index(so_wo, id) {
	for ( var i = 0; i < so_wo.length; i++) {
		if (id == so_wo[i].getValue('internalid')) {
			return i;
		}
	}
	return -1;
}