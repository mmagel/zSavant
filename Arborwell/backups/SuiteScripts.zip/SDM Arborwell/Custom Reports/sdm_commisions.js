/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       10 Feb 2014     cblaisure
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function commissions(request, response){

	if (request.getMethod() == 'GET' ){
		
		var form = nlapiCreateForm('Arborwell Commisions');
		
		var employee = form.addField('aw_employee', 'select', 'Employee', 'employee');
			employee.setLayoutType('normal', 'startcol');
			employee.setMandatory( true );
		
		var select_month = form.addField('this_month', 'select', 'Month', null, null);	
			select_month.addSelectOption(0, 'January');
			select_month.addSelectOption(1, 'February');
			select_month.addSelectOption(2, 'March');
			select_month.addSelectOption(3, 'April');
			select_month.addSelectOption(4, 'May');
			select_month.addSelectOption(5, 'June');
			select_month.addSelectOption(6, 'July');
			select_month.addSelectOption(7, 'August');
			select_month.addSelectOption(8, 'September');
			select_month.addSelectOption(9, 'October');
			select_month.addSelectOption(10, 'November');
			select_month.addSelectOption(11, 'December');
			
		var select_year = form.addField('this_year', 'select', 'Year', null, null);
			select_year.addSelectOption(2013, 2013);
			select_year.addSelectOption(2014, 2014);
			select_year.addSelectOption(2015, 2015);
			select_year.addSelectOption(2016, 2016);
		
		var html_field = form.addField('html_report', 'inlinehtml', null, null, null);
		
			form.addSubmitButton('Report');
			response.writePage( form );
				
	} else {
	//post

		//var employee_id = nlapiGetFieldValue('aw_employee');
		//var for_month = nlapiGetFieldValue('this_month');
		//var for_year = nlapiGetFieldValue('this_year');
		var employee_id = request.getParameter('aw_employee');
		
		
		var filters = new Array();
		filters[0] = new nlobjSearchFilter('salesrep', null, 'is', employee_id);
		results = nlapiSearchRecord(null, 'customsearch_commish_data', filters, null);

		the_html = search_to_html(results);
				
		response.write(the_html);
				
	}
}


function search_to_html(item_results){
	// function used to convert search results into a simple HTML Table
	// Column headers on results can be edited by changing the saved search custom label field on the search results tab
		
		if(item_results == null){
			var null_search = 'No search results found';
			return null_search;
		}
		var body = '<table border="1"><tr>';
		//Set Column Headers
		var result = item_results[0];
		var columns = result.getAllColumns();
		var columnLen = columns.length;
		for (var i = 0; i < columnLen; i++)
		{
		    var column = columns[i];
		    var label = column.getLabel();
		    if(label == null){label = column.getName();}
		    body = body + '<th>' + label + '</th>';
		}
		body = body + '</tr>';
		
		//Set line details
		var line_count = item_results.length;
		for (var lines = 0; lines < line_count; lines++){
			var item_line = item_results[lines];
			var item_columns = item_line.getAllColumns();
			var col_count = item_columns.length;
			body = body + '<tr>';
			for (var col = 0; col < col_count; col++){
				//if text
				var data = item_line.getText(item_columns[col]);
				//if number value
				if(data == null){data = item_line.getValue(item_columns[col]);}
				body = body + '<td>' + data + '</td>';
				}
			}
			body = body + '</tr></table>';
		return body;
	}