/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       11 Mar 2014     AHalbleib
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function export_to_csv(request, response){
	        

	        var mm=nlapiLoadRecord('customrecord_sdm_mm',parseInt(request.getParameter('custpage_mm_id')));
	        
	        var file = nlapiCreateFile('results.csv', 'CSV',mm.getFieldValue('custrecord_sdm_report_csv'));
	        response.setContentType(file.getType(), 'results.csv');
	        response.write(file.getValue());  
}