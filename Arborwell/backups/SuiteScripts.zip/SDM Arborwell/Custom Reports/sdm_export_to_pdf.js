/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       23 Apr 2014     AHalbleib
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function export_to_pdf(request, response){
	var mm=nlapiLoadRecord('customrecord_sdm_mm',parseInt(request.getParameter('custpage_mm_id')));
    var file = nlapiXMLToPDF(mm.getFieldValue('custrecord_sdm_mm_report_html').replace(/&/g,'&amp;').replace(/&amp;nbsp;/g,'&nbsp;')+'</body></pdf>' );
	response.setContentType('PDF','reportpdf.pdf');
	response.write( file.getValue() );
}
