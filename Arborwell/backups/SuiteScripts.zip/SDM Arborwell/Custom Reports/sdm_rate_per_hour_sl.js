/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       01 May 2014     AHalbleib
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function rate_per_hour(request, response) {
    if (request.getMethod() == 'GET') {
        var form = nlapiCreateForm('Rate Per Hour By Month By Region');
        var year = form.addField('custpage_year', 'select', 'Year');
        year.addSelectOption(2014, 2014, false);
        year.addSelectOption(2015, 2015, false);
        year.addSelectOption(2016, 2016, false);
        year.addSelectOption(2017, 2017, true);
        year.addSelectOption(2018, 2018, false);
        year.addSelectOption(2019, 2019, false);
        year.addSelectOption(2020, 2020, false);

        form.addSubmitButton('Run Report');
        response.writePage(form);
    }
    else {
        var year = parseInt(request.getParameter('custpage_year'));
        nlapiLogExecution('DEBUG', 'year', year);
        var yearselect = year;
        if (year == new Date().getFullYear()) {
            var month = new Date().getMonth();
        }
        else {
            month = 11;
        }
        var columns = new Array();
        columns.push(new nlobjSearchColumn('internalid'));
        columns.push(new nlobjSearchColumn('name'));
        var regions = nlapiSearchRecord('location', null, null, columns);
        var region_tables = new Array();
        var html = '';
        var xml = "<?xml version=\"1.0\"?>" +
            '<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">' +
            '<pdf><head><meta name="title" value="Rate Per Hour By Region"/><macrolist><macro id="myheader"><p align="center" font-size="28"><b> Rate Per Hour By Region: ' + yearselect + '</b></p></macro></macrolist></head><body text-align="justify" header="myheader" header-height="30mm" size="A3">';
        for (var i = 0; i < regions.length; i++) {
            var id = parseInt(regions[i].getValue('internalid'));
            if (id != 1) {
                var table = setup_table(regions[i].getValue('name'));
                var totals = [0, 0];

                var start = 1 + '/' + '1' + '/' + year;
                var end = 12 + '/' + 31 + '/' + year;
                table += get_rph(id, start, end, totals, year);

                table += get_row('Branch Total', totals[0], totals[1]) + '</table>';
                html += table + '<br>';
                if (i < regions.length - 1) {
                    xml += table + '<pbr/>';
                }
                else {
                    xml += table;
                }
            }
        }
        var form = nlapiCreateForm('Rate Per Hour By Month');
        var year = form.addField('custpage_year', 'select', 'Year').setLayoutType('startrow', 'startcol');
        year.addSelectOption(2014, 2014, (yearselect == 2014) ? true : false);
        year.addSelectOption(2015, 2015, (yearselect == 2015) ? true : false);
        year.addSelectOption(2016, 2016, (yearselect == 2016) ? true : false);
        year.addSelectOption(2017, 2017, (yearselect == 2017) ? true : false);
        year.addSelectOption(2018, 2018, (yearselect == 2018) ? true : false);
        year.addSelectOption(2019, 2019, (yearselect == 2019) ? true : false);
        year.addSelectOption(2020, 2020, (yearselect == 2020) ? true : false);

        form.addField('custpage_html', 'inlinehtml', '').setDefaultValue(html);
        form.addField('custpage_html1', 'longtext', 'asdf').setDisplayType('hidden').setDefaultValue(html);

        var mm = nlapiCreateRecord('customrecord_sdm_mm');
        var rec_id = nlapiSubmitRecord(mm);
        nlapiSubmitField('customrecord_sdm_mm', rec_id,
            'custrecord_sdm_mm_report_html', xml, false);
        form.addField('custpage_mm_id', 'text', 'asdf').setDisplayType('hidden').setDefaultValue(rec_id);
        //nlapiSubmitField('customrecord_sdm_mm', rec_id,
        //		'custrecord_sdm_report_csv', report_csv.toString(), false);
        form.addSubmitButton('Run Report');
        form.addButton('custpage_email_button', 'Email Report', 'var email=window.prompt(\'Please enter the address you would like to email this report to.\',\'blank@blank.com\');if (email!=null){nlapiSendEmail(nlapiGetContext().getUser(),email,\'Rate Per Hour By Region: \'+nlapiGetFieldValue(\'custpage_year\'),nlapiGetFieldValue(\'custpage_html1\'));}');
        //form.addButton('custpage_csv_button','Export to CSV','var csv_url=nlapiResolveURL(\'SUITELET\', \'customscript_sdm_export_csv\', \'customdeploy_sdm_export_csv\');csv_url += \'&custpage_mm_id=\'+nlapiGetFieldValue(\'custpage_mm_id\');window.open(csv_url);');
        form.addButton('custpage_pdf_button', 'Export to PDF', 'var pdf_url=nlapiResolveURL(\'SUITELET\', \'customscript_sdm_export_pdf\', \'customdeploy_sdm_export_pdf\');pdf_url += \'&custpage_mm_id=\'+nlapiGetFieldValue(\'custpage_mm_id\');window.open(pdf_url);');
        response.writePage(form);
    }
}

function get_rph(region, start, end, totals, year) {
    var tb_filters = new Array();
    tb_filters.push(new nlobjSearchFilter('date', null, 'within', start, end));
    tb_filters.push(new nlobjSearchFilter('custrecord_aw_salesorder_region', 'custcol_aw_time_work_order', 'anyof', region));
    var tb_columns = new Array();
    tb_columns.push(new nlobjSearchColumn('durationdecimal', null, 'sum'));
    tb_columns.push(new nlobjSearchColumn('formulatext', null, 'group').setFormula('TO_CHAR({date},\'MM\')').setSort(false));
    var tsheets = nlapiSearchRecord('timebill', null, tb_filters, tb_columns);

    var in_filters = new Array();

    in_filters.push(new nlobjSearchFilter('trandate', null, 'within', start, end));
    in_filters.push(new nlobjSearchFilter('location', null, 'is', region));

    var in_columns = new Array();
    in_columns.push(new nlobjSearchColumn('amount', null, 'sum'));
    in_columns.push(new nlobjSearchColumn('formulatext', null, 'group').setFormula('TO_CHAR({trandate},\'MM\')').setSort(false));
    var invoices = nlapiSearchRecord('transaction', 'customsearch778', in_filters, in_columns);
    var revenue = 0;
    var hours = 0;
    var html = '';
    if (region == 10 && year == 2015) {
        for (var i = 0; tsheets != null && i < 6; i++) {
            var hours = 0;
            var revenue = 0;

            html += get_row(month_to_text(i), revenue, hours);
        }
        for (var i = 0; tsheets != null && i < 6; i++) {
            var hours = 0;
            var revenue = 0;

            if (tsheets[i] != undefined && tsheets[i].getValue('durationdecimal', null, 'sum').length > 0) {

                hours += parseFloat(tsheets[i].getValue('durationdecimal', null, 'sum'));
                totals[1] += hours;
            }
            if (invoices[i] != undefined && invoices[i].getValue('amount', null, 'sum').length > 0) {

                revenue += parseFloat(invoices[i].getValue('amount', null, 'sum'));
                totals[0] += revenue;
            }
            var mon = parseFloat(i) + parseFloat(6);
            html += get_row(month_to_text(mon), revenue, hours);
        }

    }
    else {
        for (var i = 0; tsheets != null && i < 12; i++) {
            var hours = 0;
            var revenue = 0;
            if (tsheets[i] != undefined && tsheets[i].getValue('durationdecimal', null, 'sum').length > 0) {

                hours += parseFloat(tsheets[i].getValue('durationdecimal', null, 'sum'));
                totals[1] += hours;
            }
            if (invoices[i] != undefined && invoices[i].getValue('amount', null, 'sum').length > 0) {

                revenue += parseFloat(invoices[i].getValue('amount', null, 'sum'));
                totals[0] += revenue;
            }
            html += get_row(month_to_text(i), revenue, hours);
        }
    }
    return html;
}
function setup_table(region) {
    var html = '';

    html += '<table border="0" cellborder="1 solid lightsteelblue" font-size="24" style="background-color:lightsteelblue; width:100%; padding:2px;">';
    var row = '';
    row += td(region, 'background-color:steelblue; color:mintcream; font-weight:bold;');
    row += td('Region Hours', 'background-color:darkslategray; color:mintcream; font-weight:bold;');
    row += td('Amount Invoiced', 'background-color:darkslategray; color:mintcream; font-weight:bold;');
    row += td('Effective Rate', 'background-color:darkslategray; color:mintcream; font-weight:bold;');
    html += tr(row);
    return html;
}
function get_row(month, revenue, hours) {
    var row = '';
    row += td(month, 'background-color:beige;');
    row += td(nwc(hours.toFixed(2)), 'background-color:mintcream;');
    row += td('$' + nwc(revenue.toFixed(2)), 'background-color:mintcream;');
    if (revenue > 0 && hours > 0) {
        row += td('$' + nwc((revenue.toFixed(2) / hours.toFixed(2)).toFixed(2)), 'background-color:mintcream;');
    }
    else {
        row += td('$' + 0, 'background-color:mintcream;');
    }
    return tr(row);
}
function get_last_day(month, year) {
    if (month == '1' || month == '3' || month == '5' || month == '7' || month == '8' || month == '10' || month == '12') {
        return 31;
    }
    else if (month == '4' || month == '6' || month == '9' || month == '11') {
        return 30;
    }
    else if (month == '2') {
        if (year % 4 == 0) {
            return 29;
        }
        else {
            return 28;
        }
    }
}
function nwc(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function tr(value, style) {
    if (style != null) {
        return '<tr style="' + style + '">' + value + '</tr>';
    }
    return '<tr>' + value + '</tr>';
}
function td(value, style) {
    if (style != null) {
        return '<td style="' + style + '">' + value + '</td>';
    }
    return '<td>' + value + '</td>';
}
function month_to_text(month) {
    nlapiLogExecution('AUDIT', 'month', month);
    if (month == 0) {
        return 'January';
    }
    if (month == 1) {
        return 'February';
    }
    if (month == 2) {
        return 'March';
    }
    if (month == 3) {
        return 'April';
    }
    if (month == 4) {
        return 'May';
    }
    if (month == 5) {
        return 'June';
    }
    if (month == 6) {
        return 'July';
    }
    if (month == 7) {
        return 'August';
    }
    if (month == 8) {
        return 'September';
    }
    if (month == 9) {
        return 'October';
    }
    if (month == 10) {
        return 'November';
    }
    if (month == 11) {
        return 'December';
    }
    return '';
}