/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Feb 2014     AHalbleib
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function run_report()

{ 
	//set second arg to scriptid of selected script
	var script=nlapiLoadRecord('suitelet',nlapiGetFieldValue('custpage_report_menu'));
	//var	dep_id=script.getLineItemValue('scriptdeployments','scriptid', 1);
	//set deployment so its a get call. suitelet scripts in the custom report folder should only have 1 deployment, a get call
    var url = nlapiResolveURL('SUITELET', script.getFieldValue('scriptid'),script.getFieldValue('scriptid').replace('customscript','customdeploy'));

    
    var params=script.getFieldValue('description');
	var params_array=params.split(',');
    
    for (var i=0; i<params_array.length; i+=2){
    var type=params_array[i+1];
	if (type.indexOf('.')>-1){
		var elements_array=type.split('.');
		//this should be the word 'multiselect'
		for (var k=1;k<elements_array.length;k+=2){
			var l=k+1;
			url+='&custpage_param'+i+'_listval'+k+'='+elements_array[k];
			url+='&custpage_param'+i+'_listtext'+k+'='+elements_array[l];
		}
	}
    
    }
    
    
    
    var i=0;
    //add parameters to report suitelet url
    url+='&custpage_report='+nlapiGetFieldValue('custpage_report_menu');
	while (nlapiGetField('custpage_param'+i)!=null){
		url += '&custpage_param'+i+'=' + nlapiGetFieldValue('custpage_param'+i);
		i+=2;
	}
    
	//run script, get args from request object, submit a middleman with the report results,
	//and reopen the original suitelet, passing the id of the middleman record in a get request
    document.location=url;
}
function set_script(type, name, linenum){
	//alert(name);
	if (name=='custpage_report_menu'){
		if (nlapiGetFieldValue('custpage_report_menu')==0){
			document.location=nlapiResolveURL('SUITELET', 'customscript_sdm_custom_report', 'customdeploy_custom_report_get');
		}
		else {
		var script=nlapiLoadRecord('suitelet',nlapiGetFieldValue('custpage_report_menu'));
		var params=script.getFieldValue('description');
		var params_array=params.split(',');
		var url = nlapiResolveURL('SUITELET', 'customscript_sdm_custom_report', 'customdeploy_custom_report_get');
		url+='&custpage_report='+nlapiGetFieldValue('custpage_report_menu');
		for (var i=0; i<params_array.length;i+=2){
			var j=i+1;
			//alert(params_array[i]);
			//alert(params_array[j]);
			//type=even
			var type=params_array[i+1];
			if (type.indexOf('.')>-1){
				var elements_array=type.split('.');
				//this should be the word 'multiselect'
				url += '&custpage_param'+i+'='+elements_array[0];
				for (var k=1;k<elements_array.length;k+=2){
					var l=k+1;
					url+='&custpage_param'+i+'_listval'+k+'='+elements_array[k];
					url+='&custpage_param'+i+'_listtext'+k+'='+elements_array[l];
				}
			}
			else {
			url += '&custpage_param'+i+'='+type;
			}
			//name=odd
			url += '&custpage_param'+j+'='+params_array[i];
			//alert(url);
		}
		   document.location=url;
		}
	}
}
function email_report(){
	if (nlapiGetFieldValue('custpage_mm_id')==null){
		alert('You must select and run a report from the report menu before emailing the report.');
	}
	else {
		var email=window.prompt('Please enter the address you would like to email this report to.','blank@blank.com');
		if (email!=null){
			mm=nlapiLoadRecord('customrecord_sdm_mm',nlapiGetFieldValue('custpage_mm_id'));
			nlapiSendEmail(nlapiGetContext().getUser(),email,'Commissions Report-'+nlapiGetFieldText('custpage_param0'),mm.getFieldValue('custrecord_sdm_mm_report_html'));
		}
	}
}
function export_to_csv(){
	if (nlapiGetFieldValue('custpage_mm_id')==null){
		alert('You must select and run a report from the report menu before exporting to csv.');
	}
	else {
	//redirect to suitelet
	//send filename and id of middleman
	var url=nlapiResolveURL('SUITELET', 'customscript_sdm_custom_report', 'customdeploy_custom_report_get');
	url += '&custpage_mm_id='+nlapiGetFieldValue('custpage_mm_id');
	url+='&custpage_report='+nlapiGetFieldValue('custpage_report_menu');
	var i=0;
	while (nlapiGetField('custpage_param'+i)){
		var field=nlapiGetField('custpage_param'+i);
		var j=i+1;
		if (field.getType()=='select'){
			var script=nlapiLoadRecord('suitelet',nlapiGetFieldValue('custpage_report_menu'));
			  var params=script.getFieldValue('description');
				var params_array=params.split(',');
			    
			    for (var n=0; n<params_array.length; n+=2){
			    var type=params_array[n+1];
				if (type.indexOf('.')>-1){
					var elements_array=type.split('.');
					//this should be the word 'multiselect'
					for (var k=1;k<elements_array.length;k+=2){
						var l=k+1;
						url+='&custpage_param'+n+'_listval'+k+'='+elements_array[k];
						url+='&custpage_param'+n+'_listtext'+k+'='+elements_array[l];
					}
				}
			    
			    }
		}
		//type
		url += '&custpage_param'+i+'='+field.getType();
		//value
		url += '&custpage_param_value'+i+'=' + nlapiGetFieldValue('custpage_param'+i);
		//label
		url += '&custpage_param'+j+'=' + field.getLabel();
		i+=2;
	}
	var csv_url=nlapiResolveURL('SUITELET', 'customscript_sdm_export_csv', 'customdeploy_sdm_export_csv');
	csv_url += '&custpage_mm_id='+nlapiGetFieldValue('custpage_mm_id');
	window.open(csv_url);
	document.location=url;
	}
}
