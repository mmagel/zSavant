function employee_check_payroll_items(type){
	var lines=nlapiGetLineItemCount('earning');
	var paytype=nlapiGetFieldText('usetimedata');
	var region=nlapiGetFieldValue('location');
	var region_text=nlapiGetFieldText('location');
	if (paytype=='Wage'){
		var labor=nlapiSearchRecord('customrecord_labor_rules',null,
		new nlobjSearchFilter('custrecord_lr_region',null,'anyof',region),
		[new nlobjSearchColumn('name'),new nlobjSearchColumn('internalid'),new nlobjSearchColumn('custrecord_employee_wage_item_multiplier')]);
		var multipliers;
	
		if (labor!=null){
			multipliers=labor[0].getText('custrecord_employee_wage_item_multiplier');
			//alert (multipliers+' '+labor[0].getValue('custrecord_employee_wage_item_multiplier')+' '+labor.length+' '+labor[0].getValue('internalid'));
			
			var multipliers=multipliers.split(',');
			//alert (multipliers);
			var found=new Array();
			var curfound;
			var allfound=true;
			for (var i=0; i<multipliers.length; i++){
				curfound=false;
				if (multipliers[i]==1){
					for (var j=1; j<=lines; j++){
						var pid=nlapiGetLineItemValue('earning','payrollitem',j);
						var multiplier=nlapiGetLineItemValue('earning','derivedratemultiplier',j);
						var pri=nlapiGetLineItemValue('earning','primaryearning',j);
						//alert('a '+multiplier+' : '+multipliers[i]);
						if ((multiplier==''||multiplier==null)&&pri=='T'){
							found.push(multipliers[i]);
							curfound=true;
						}
					}
				}
				else{
					
					for (var j=1; j<=lines; j++){
						var pid=nlapiGetLineItemValue('earning','payrollitem',j);
						var multiplier=nlapiGetLineItemValue('earning','derivedratemultiplier',j);
						var pri=nlapiGetLineItemValue('earning','primaryearning',j);
						
						if (multiplier==multipliers[i]){
							found.push(multipliers[i]);
							curfound=true;
						}					
						//alert(typeof multipliers+ ' '+'b '+multiplier+' : '+multipliers[i]);
					}
				}
				if (!curfound){
					allfound=false;
				}
			}
			if (!allfound){
				alert('  Employee does not have the required payroll items assigned. Wage employees in region '+region_text+ ' are required to have items of multipliers '+multipliers+ ' assigned to them in the earnings sublist. This employee currently has the following multipliers: '+found );
				return false;
			}
		}
	}
	return true;
}
//aaron halbleib, tyler engelmann
