/**
 * Module Description
 * 
 * 
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord employee
 * 
 * 
 */
function commish_report(){
	
	//task build discount multiplier
	//build payment multiplier
	//build to skip payments in previous periods (done)
		
	var employ_id = nlapiGetRecordId();
	
	//get date label
	var today = new Date();
	var year = today.getFullYear();
	var month_num = (today.getMonth()) - 1;
	var month = month_name(month_num);	

	
	//get commish %
	var name = nlapiLookupField('employee', employ_id, 'entityid', null);
	var gtc = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_gtc_commission', null));
	var phc = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_phc_comm', null));
	var consult = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_cnslt_comm', null));
	var gis = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_gis_comm', null));
	var stump = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_stump_comm', null));
	var move = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_tree_moving_comm', null));
	var warranty = convert_percent_to_decimal(nlapiLookupField('employee', employ_id, 'custentity_aw_warranty_comm', null));
	
		
	//get data by sales rep
	var filters = new Array();
	filters[0] = new nlobjSearchFilter('salesrep', null, 'is', employ_id);
	results = nlapiSearchRecord(null, 'customsearch_commish_data', filters, null);
	
	body2 = search_to_html(results);
	
	//set up header
	var body = 'Name: ' + name + '<br>';
		body += month + '&nbsp;' + year + '<br><br>';
		body += 'Commission %<br>';
		body += 'GTC: ' + (gtc * 100) + '%<br>';
		body += 'PHC: ' + (phc * 100) + '%<br>';
		body += 'Consulting: ' + (consult * 100) + '%<br>';
		body += 'GIS: ' + (gis * 100) + '%<br>';
		body += 'STUMPS: ' + (stump * 100) + '%<br>';
		body += 'Warranty:' + (warranty * 100) + '%<br><br>';
	
	//set up table
	var	table_body = '<table border="1"><tr><th>Invoice #</th><th>Customer</th><th>GP%</th><th>Payment #</th><th>Payment Date</th><th>Invoice Amount</th>';
		table_body += '<th>Payment Amount</th><th>GTC</th><th>PHC</th><th>Consulting</th><th>GIS</th><th>Stumps</th><th>Tree Moving</th>';
		table_body += '<th>Warranty</th><th>Adjustment</th><th>Commission</th></tr>';
	
	//set var
	var amt_gtc = 0;
	var amt_phc = 0;
	var amt_consult = 0;
	var amt_gis = 0;
	var amt_stump = 0;
	var amt_move = 0;
	var amt_warranty = 0;
	var line_commish = 0;
	var invoice_count = 0;
	var total_gp = 0;
	var total_commish = 0;
	var low_commish = 0;
	var discount = 0;
	var adjust_display = '';

	//start parse through search results
	var line_count = results.length;
	for (var lines = 0; lines < line_count; lines++){
	
		var amt = 0; //Default amt 0
		var item_line = results[lines];
		var item_columns = item_line.getAllColumns();
		var line_id = item_line.getValue(item_columns[1]);
	
		if(line_id == 0 && line_commish == 0){ //sort out main line, set main line values
			var id = item_line.getValue(item_columns[0]);
			var invoice = item_line.getValue(item_columns[2]);
			var customer = item_line.getText(item_columns[3]);
			var gp = item_line.getValue(item_columns[4]);
			var payment = item_line.getValue(item_columns[5]);
			var pay_date = item_line.getValue(item_columns[6]);
			var inv_amt = item_line.getValue(item_columns[7]);
			var pay_amt = item_line.getValue(item_columns[8]);
						
			invoice_count += 1; //how many unique invoices
			total_gp += parseFloat(gp);//total GP%
		
		
		} else { // sort out non-main line items and group by work type (class)
				
			var type = item_line.getValue(item_columns[9]);
			var amt = parseFloat(item_line.getValue(item_columns[10]));
				
				//multiply the line amount * commission rate to get commission by item, add to total by work type
				if(type == 2){
					amt_gtc = amt_gtc + (amt * gtc);
					}
				if(type == 1){
					amt_phc = amt_gtc + (amt * phc);
					}
				if(type == 3){
					amt_consult = amt_consult + (amt * consult);
					}
				if(type == 6){
					amt_gis = amt_gis + (amt * gis);
					}
				if(type == 8){
					amt_stump = amt_stump + (amt * stump);
					}
				if(type == 4){
					amt_move = amt_move + (amt * move);
					}
				if(type == 7){
					amt_warranty = amt_warranty + (amt * warranty);
					}
				
				//store line discounts by invoice to adjust commissions
				if(amt < 0) {
					discount += amt;
				}
				
				//add all rolling values to keep line commish total by invoice as loop.
				line_commish = amt_gtc + amt_phc + amt_consult + amt_gis + amt_stump + amt_move + amt_warranty;
							
			}
			
			// commit current row, start new, or commit last line in the report
			if((line_id == 0 && lines > 1) || lines == line_count){ 
				
				//Check for discounted payment from Customer
				if(inv_amt > pay_amt){
					var adjust = (parseFloat(pay_amt) / parseFloat(inv_amt)).toFixed(3);
					adjust_display += 'Less Payment: ' + (adjust * 100).toFixed(1) + '%';//For report display only
				
				} else {
					var adjust = 1;
				}
				
				//check for discounts on the Invoice
				if(discount < 0) {
					var subtotal = (discount * -1) + parseFloat(inv_amt);
					var adjust2 = parseFloat((parseFloat(inv_amt) / subtotal).toFixed(3));
					
					adjust_display += 'Less Discount: ' + ((1 - adjust2)*100).toFixed(1) + '%';	//for report display only		
				} else {
					var adjust2 = 1;
				}
				
							
				//round 2 decimals for all amounts
				amt_gtc = (amt_gtc).toFixed(2);
				amt_phc = (amt_phc).toFixed(2);
				amt_consult = (amt_consult).toFixed(2);
				amt_gis = (amt_gis).toFixed(2);
				amt_stump = (amt_stump).toFixed(2);
				amt_move = (amt_move).toFixed(2);
				amt_warranty = (amt_warranty).toFixed(2);
				
				line_commish = (line_commish * adjust * adjust2).toFixed(2);				
				
				var pay_date_date = nlapiStringToDate(pay_date);
				var pay_month = pay_date_date.getMonth(); //Payments in previous months should not be included
				
				if(pay_month == month_num){
														
					total_commish += parseFloat(line_commish); // rolling commission total
					
					if(parseFloat(gp) > 59.9999){low_commish += parseFloat(line_commish);} //track commision only if greater than 60% GM
					
					//add data row
					table_body += '<tr>'; //start new row
					table_body += '<td>' + invoice + '</td>';
					table_body += '<td>' + customer + '</td>';
					table_body += '<td>' + gp + '</td>';
					table_body += '<td>' + payment + '</td>';
					table_body += '<td>' + pay_date + '</td>';
					table_body += '<td>' + inv_amt + '</td>';
					table_body += '<td>' + pay_amt + '</td>';
					table_body += '<td>' + amt_gtc + '</td>';
					table_body += '<td>' + amt_phc + '</td>';
					table_body += '<td>' + amt_consult + '</td>';
					table_body += '<td>' + amt_gis + '</td>';
					table_body += '<td>' + amt_stump + '</td>';
					table_body += '<td>' + amt_move + '</td>';
					table_body += '<td>' + amt_warranty + '</td>';
					table_body += '<td>' + adjust_display + '</td>'
					table_body += '<td>' + line_commish + '</td>';
					table_body += '</tr>';
				}
				
				//reset var
				var amt_gtc = 0;
				var amt_phc = 0;
				var amt_consult = 0;
				var amt_gis = 0;
				var amt_stump = 0;
				var amt_move = 0;
				var amt_warranty = 0;
				var line_commish = 0;
				var discount = 0;
				var adjust_display = '';
				
				//add main line fields
				var id = item_line.getValue(item_columns[0]);
				var invoice = item_line.getValue(item_columns[2]);
				var customer = item_line.getText(item_columns[3]);
				var gp = item_line.getValue(item_columns[4]);
				var payment = item_line.getValue(item_columns[5]);
				var pay_date = item_line.getValue(item_columns[6]);
				var inv_amt = item_line.getValue(item_columns[7]);
				var pay_amt = item_line.getValue(item_columns[8]);
												
			}
	}
	table_body += '</table>';
	
	ave_gp = (parseFloat(total_gp) / parseFloat(invoice_count)).toFixed(2); //calculate average Gross Profit
	
	//display totals
	body += 'Average GP: ' + '&nbsp;' + ave_gp + '<br>';
	body += 'Commission > 60%: ' + '&nbsp;' + low_commish.toFixed(2) + '<br>'; 
	body += 'Total Commisions: ' + '&nbsp;' + total_commish.toFixed(2) + '<br><br>';
	
	//only pay total commision if GP > 60
	if(ave_gp > 59.99999){
		var to_pay = total_commish;
	} else {
		var to_pay = low_commish;
	}

	body += '<b>Comissions to be paid:' + '&nbsp;'  + to_pay.toFixed(2) + '</b><br><br>';

	body += table_body + '<br>' + body2;
	
	var current_user = nlapiGetUser();
	
	nlapiSendEmail(current_user, current_user, ('Commission Report ' + name), body, null, null, null, null);
	alert('Report Sent');
}


function convert_percent_to_decimal(Value){
	
	var val_return = ((Value.split("%"))[0])/100;
	return val_return;
		
}

function search_to_html(item_results){
	// function used to convert search results into a simple HTML Table
	// Column headers on results can be edited by changing the saved search custom label field on the search results tab
		
		if(item_results == null){
			var null_search = 'No search results found';
			return null_search;
		}
		var body = '<table border="1"><tr>';
		//Set Column Headers
		var result = item_results[0];
		var columns = result.getAllColumns();
		var columnLen = columns.length;
		for (var i = 0; i < columnLen; i++)
		{
		    var column = columns[i];
		    var label = column.getLabel();
		    if(label == null){label = column.getName();}
		    body = body + '<th>' + label + '</th>';
		}
		body = body + '</tr>';
		
		//Set line details
		var line_count = item_results.length;
		for (var lines = 0; lines < line_count; lines++){
			var item_line = item_results[lines];
			var item_columns = item_line.getAllColumns();
			var col_count = item_columns.length;
			body = body + '<tr>';
			for (var col = 0; col < col_count; col++){
				//if text
				var data = item_line.getText(item_columns[col]);
				//if number value
				if(data == null){data = item_line.getValue(item_columns[col]);}
				body = body + '<td>' + data + '</td>';
				}
			}
			body = body + '</tr></table>';
		return body;
	}

function month_name(month_number){
	
	var month=new Array();
	month[0]="January";
	month[1]="February";
	month[2]="March";
	month[3]="April";
	month[4]="May";
	month[5]="June";
	month[6]="July";
	month[7]="August";
	month[8]="September";
	month[9]="October";
	month[10]="November";
	month[11]="December";
	var n = month[month_number];
	return n;
}