/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       06 Dec 2013     cblaisure
 *
 *
 *	Used to set the external ID, used by NovaTime Upload, equal to a unique arborwell ID
 *
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord employee
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */
function set_labor_rate(){
//function used to calculate and set burdended cost and labor rate	
	var wage = nlapiGetFieldValue('custentity_aw_employee_wage_rate');
	
	if(isEmpty(wage) || wage == 0){
		nlapiSetFieldValue('custentity_aw_burdended_per_hour', 0);
		nlapiSetFieldValue('custentity_aw_employee_wage_rate', 0);
		nlapiSetFieldValue('laborcost', 0);	
		} else {
			nlapiSetFieldValue('custentity_aw_burdended_per_hour', (wage * .46));
			nlapiSetFieldValue('laborcost', (wage * 1.46));
			}
}


function isEmpty(stValue) {
	//used to identify blank fields
		if ((stValue == '') || (stValue == null) ||(stValue == undefined))
	    {
	    return true;
	    }
	    return false;
	}



//Old functions removed 12/19
function verify_unique_id(type){
 
	var aw_id = nlapiGetFieldValue('custentity5');
	var currentid = nlapiGetRecordId();
	
	if(aw_id > 0){
		
		var filters = new Array();
		filters[0] = new nlobjSearchFilter('custentity5', null,'is', aw_id);
		var columns = new Array();
		columns[0] = new nlobjSearchColumn('internalid');
		var result = nlapiSearchRecord('employee', null, filters, columns );
		
		if(result != null){
			var emp_id = result[0].getValue('internalid');	
			if(emp_id != currentid){
				throw nlapiCreateError('DUPLICATE_ID', 'You have selected an "Arborwell Employee ID" already in use. Please create a unique ID.');			
			}
		}
			
	}
}

function set_id_after(){
	var aw_id = nlapiGetFieldValue('custentity5');
	var currentid = nlapiGetRecordId();
	emp_rec = nlapiLoadRecord('employee', currentid);
		emp_rec.setFieldValue('externalid', aw_id);
		nlapiSubmitRecord(emp_rec);
}

function add_buttons(type, form, request){

	var gtc = nlapiGetFieldValue('custentity_aw_gtc_commission');
	
	if(type == 'view' && gtc != null){
		
		form.setScript('customscript_commish_report');
		form.addButton('custpage_sdm_commish', 'Email Commish Report', 'commish_report()');
	}
}