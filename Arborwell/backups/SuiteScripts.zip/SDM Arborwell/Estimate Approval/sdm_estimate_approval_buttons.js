/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       10 Oct 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord estimate
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */

function create_approval_buttons(type, form, request){
	//add approval or create order buttons
		
		var approval_status = nlapiGetFieldValue('custbody_aw_est_approval_status');
		var tran_status = nlapiGetFieldValue('status');
		var viewer = nlapiGetUser();
		var role = nlapiGetRole();
		var next_approver = nlapiGetFieldValue('custbody_aw_est_approver');
		
		//set Script for buttons to function
		form.setScript('customscript_sdm_est_approval_functions');
		
		if(type == 'view' && tran_status == 'Open' && approval_status == 1 && (next_approver == viewer || role == 3)) {
		
			form.addButton('custpage_sdm_approval', 'Approve', 'set_approved()');
			form.addButton('custpage_sdm_reject', 'Reject', 'set_reject()');
		
		} else if(type == 'view' && tran_status == 'Open' && approval_status == 2){
			
			form.addButton('custpage_sdm_create_sale', 'Create Order', 'create_so()');
		}
	}