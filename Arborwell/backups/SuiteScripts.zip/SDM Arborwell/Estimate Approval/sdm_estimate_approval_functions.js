/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       10 Oct 2013     cblaisure
 *
 *
 *
 *
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord estimate
 *
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */

function set_approved() {
    // Approval button script for estimate approval
    // 1 = pending
    // 2 = approved
    // 3 = rejected

    var id = nlapiGetRecordId();
    var record = nlapiLoadRecord('estimate', id);

    record.setFieldValue('custbody_aw_est_approval_status', 2);
    record.setFieldValue('custbody_aw_est_approver', '');
    if (record.getFieldValue('customform') == 129 || record.getFieldValue('customform') == 135) {
        record.setFieldValue('customform', 129);
    }
    else {
        record.setFieldValue('customform', 106);
    }
    nlapiSubmitRecord(record);
    location.reload();
}

function set_reject() {
    //Reject Button script for estimate rejection
    var id = nlapiGetRecordId();
    var record = nlapiLoadRecord('estimate', id);

    record.setFieldValue('custbody_aw_est_approval_status', 3);
    record.setFieldValue('custbody_aw_est_approver', '');

    nlapiSubmitRecord(record);
    location.reload();
}


function create_so() {
//used as a button to create a Sales Order from Estimate
    var get_id = nlapiGetRecordId();
    var new_so = nlapiTransformRecord('estimate', get_id, 'salesorder');
    nlapiSubmitField('estimate', get_id, 'custbody_op_close_date', nlapiDateToString(new Date()));
    var new_id = nlapiSubmitRecord(new_so, true);
    var url = nlapiResolveURL('RECORD', 'salesorder', new_id, 'VIEW');
    window.location = url;
}

function set_next_approver(type) {

    // get previous amount

    if (type == 'create') {
        var old_total = 0;
    } else {
        var est_id = nlapiGetRecordId();
        var filters = new Array();
        filters[0] = new nlobjSearchFilter('internalid', null, 'is', est_id);
        var columns = new Array();
        columns[0] = new nlobjSearchColumn('total');
        var est_total_ray = nlapiSearchRecord('estimate', null, filters, columns);
        var old_total = est_total_ray[0].getValue(columns[0]);
        old_total = parseFloat(old_total);
    }

    //get current amount
    var total = nlapiGetFieldValue('total');
    total = parseFloat(total);

    //get current status
    var approval_status = nlapiGetFieldValue('custbody_aw_est_approval_status');

    //set new approval if pending, edited to higher than previous total, or new estimate
    if (type == 'edit' && approval_status == 2) {
        if (nlapiGetFieldValue('customform') == 129 || nlapiGetFieldValue('customform') == 135) {
            nlapiSetFieldValue('customform', 129);
        }
        else if (nlapiGetFieldValue('customform') == 128) {
            nlapiSetFieldValue('customform', 106);
        }
    }
    if (type == 'create' || type == 'edit' && (approval_status == 1 || total > old_total || total == 0)) {

        employ = nlapiGetFieldValue('salesrep');

        var filters = new Array();
        filters[0] = new nlobjSearchFilter('internalid', null, 'is', employ);
        var columns = new Array();
        columns[0] = new nlobjSearchColumn('supervisor');
        columns[1] = new nlobjSearchColumn('custentity_aw_employee_estimate_limit');

        var results = nlapiSearchRecord('employee', null, filters, columns);
        var boss = results[0].getValue(columns[0]);
        var limit = results[0].getValue(columns[1]);

        total = nlapiGetFieldValue('total');

        if (boss == null || boss.length < 1) {
            boss = 11; //default to andy when no supervisor
        }
        if (limit == null || limit.length < 1) {
            limit = 100000; //default if no limit
        }

        total = parseFloat(total);
        limit = parseFloat(limit);

        // 1 = pending
        // 2 = approved
        // 3 = rejected

        if (total > limit) {
            if (total > 100000) {
                if (nlapiGetFieldValue('customform') == 129 || nlapiGetFieldValue('customform') == 135) {
                    nlapiSetFieldValue('customform', 135);
                }
                else {
                    nlapiSetFieldValue('customform', 128);
                }
                var loc = nlapiGetFieldValue('location');

                if (loc == 7 || loc == 6 || loc == 10) {  // San Diego, Orange County, Seattle,
                    nlapiSetFieldValue('custbody_aw_est_approver', 1852);
                }
                else {
                    nlapiSetFieldValue('custbody_aw_est_approver', 11); //andy defaults
                }
                nlapiSetFieldValue('custbody_aw_est_approval_status', 1);
            } else {
                if (nlapiGetFieldValue('customform') == 129 || nlapiGetFieldValue('customform') == 135) {
                    nlapiSetFieldValue('customform', 135);
                }
                else {
                    nlapiSetFieldValue('customform', 128);
                }
                nlapiSetFieldValue('custbody_aw_est_approver', boss);
                nlapiSetFieldValue('custbody_aw_est_approval_status', 1);
            }

        } else {
            if (nlapiGetFieldValue('customform') == 129 || nlapiGetFieldValue('customform') == 135) {
                nlapiSetFieldValue('customform', 129);
            }
            else if (nlapiGetFieldValue('customform') != 138) {
                nlapiSetFieldValue('customform', 106);
            }
            nlapiSetFieldValue('custbody_aw_est_approver', '');
            nlapiSetFieldValue('custbody_aw_est_approval_status', 2);

        }
    }

}
function set_date_closed(type) {
    if (type == 'create' || type == 'edit') {
        var notes = nlapiSearchRecord('transaction', 'customsearch891', [new nlobjSearchFilter('internalid', null, 'anyof', nlapiGetRecordId()), new nlobjSearchFilter('mainline', null, 'is', 'F')]);
        var cols = '';
        if (notes != null) {
            cols = notes[0].getAllColumns();
            var date = notes[0].getValue(cols[2]);
            date = date.split(' ');
            date = date[0];
            nlapiSubmitField('estimate', nlapiGetRecordId(), 'custbody_op_close_date', date);
        }
    }
}