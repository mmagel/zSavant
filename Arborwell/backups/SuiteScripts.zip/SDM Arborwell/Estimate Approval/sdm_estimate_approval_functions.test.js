/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       10 Oct 2013     cblaisure
 *
 *
 *
 *
 *
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord estimate
 *
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */


function set_approved() {

    var context = nlapiGetContext();
    var role = nlapiGetRole();
    console.log('role: ' + role);
    var user = nlapiGetUser();
    console.log('user: ' + user);

    var recId = nlapiGetRecordId();
    var recordType = nlapiGetRecordType();

    nlapiSubmitField(recordType, recId, 'custbody_context', 'UI');
    var rec = nlapiLoadRecord(recordType, recId);

    var custbody_aw_est_approver = nlapiGetFieldValue('custbody_aw_est_approver');
    console.log('custbody_aw_est_approver: ' + custbody_aw_est_approver);

    var filters = new Array();
    filters[0] = new nlobjSearchFilter('internalid', null, 'is', recId);
    var columns = new Array();
    columns[0] = new nlobjSearchColumn('total');
    var est_total_ray = nlapiSearchRecord(recordType, null, filters, columns);
    var total = est_total_ray[0].getValue(columns[0]);
    total = parseFloat(total);

    total = parseFloat(total);
    console.log('Total: ' + total);

    var employ = rec.getFieldValue('salesrep');
    console.log('employ: ' + employ);

    var url = 'https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=478&deploy=1&employ=' + employ;

    var resp = nlapiRequestURL(url);
    var respBody = resp.getBody();
    respBody = respBody.split(':');
    var boss = respBody[0];
    var limit = parseFloat(respBody[1]);
    if (isNaN(limit))
        limit = null;

    /*
    if (!boss) {
        boss = 11; // default to Andy when no supervisor
    }

    if (boss == 11) { // Andy
        boss = 36558 // Huzaifa
    }

    console.log('boss: ' + boss);
    */

    if (!limit) {
        limit = 25000; //default if no limit  // RB-changing this to 25k as default if no limit
    }

    limit = parseFloat(limit);
    console.log('limit: ' + limit);

    if (role == 3 || user == custbody_aw_est_approver) {

        console.log('role == 3 || user == custbody_aw_est_approver');

        rec.setFieldValue('custbody_aw_est_approval_status', 2); // Approved
        rec.setFieldValue('custbody_aw_est_approver', '');

        if (recordType == 'estimate') {
            if (rec.getFieldValue('customform') == 129
                || rec.getFieldValue('customform') == 135) {
                rec.setFieldValue('customform', 129);
            }
            else if (rec.getFieldValue('customform') == 128 ||
                rec.getFieldValue('customform') == 134) {
                rec.setFieldValue('customform', 106);
            }
        }
    }

    if (total > limit
        && (role != 3
            && (custbody_aw_est_approver == 11 || custbody_aw_est_approver == 36558
                || custbody_aw_est_approver == 1852
            ))) {

        console.log('total > limit: true');

        if (total > 100000) {

            if (rec.getFieldValue('customform') == 129
                || rec.getFieldValue('customform') == 135) {
                rec.setFieldValue('customform', 135);
            }
            else {
                rec.setFieldValue('customform', 128);
            }
            var loc = rec.getFieldValue('location');

            if (loc == 7 || loc == 6 || loc == 10) {  // San Diego, Orange County, Seattle,
                rec.setFieldValue('custbody_aw_est_approver', 1852);
            }
            else {
                rec.setFieldValue('custbody_aw_est_approver', 11); // Andy defaults
                if (parseInt(employ) == 39010) { // Robert
                    rec.setFieldValue('custbody_aw_est_approver', 36558); // Huzaifa
                }
            }
            rec.setFieldValue('custbody_aw_est_approval_status', 1);
        }
        else {
            rec.setFieldValue('custbody_aw_est_approver', boss);
            rec.setFieldValue('custbody_aw_est_approval_status', 1);
        }

        if (recordType == 'estimate') {

            if (rec.getFieldValue('customform') == 129
                || rec.getFieldValue('customform') == 135) {
                rec.setFieldValue('customform', 135);
            }
            else {
                rec.setFieldValue('customform', 128);
            }
        }
    }

    if (custbody_aw_est_approver == rec.getFieldValue('custbody_aw_est_approver')) {

        rec.setFieldValue('custbody_aw_est_approval_status', 2); // Approved
        rec.setFieldValue('custbody_aw_est_approver', '');

        if (recordType == 'estimate') {
            if (rec.getFieldValue('customform') == 129
                || rec.getFieldValue('customform') == 135) {
                rec.setFieldValue('customform', 129);
            }
            else if (rec.getFieldValue('customform') == 128 ||
                rec.getFieldValue('customform') == 134) {
                rec.setFieldValue('customform', 106);
            }
        }
    }

    nlapiSubmitRecord(rec, false, true);

    nlapiSubmitField(recordType, recId, 'custbody_context', '');
    location.reload();
}

function set_reject() {

    //Reject Button script for estimate rejection
    var id = nlapiGetRecordId();
    var type = nlapiGetRecordType();

    var record = nlapiLoadRecord(type, id);

    record.setFieldValue('custbody_aw_est_approval_status', 3);
    record.setFieldValue('custbody_aw_est_approver', '');

    nlapiSubmitRecord(record, false, true);
    location.reload();
}

function create_so() {
//used as a button to create a Sales Order from Estimate
    var get_id = nlapiGetRecordId();
    var new_so = nlapiTransformRecord('estimate', get_id, 'salesorder');
    nlapiSubmitField('estimate', get_id, 'custbody_op_close_date', nlapiDateToString(new Date()));
    var new_id = nlapiSubmitRecord(new_so, true);
    var url = nlapiResolveURL('RECORD', 'salesorder', new_id, 'VIEW');
    window.location = url;
}

function set_next_approver(type) {

    var context = nlapiGetContext();

    nlapiLogExecution('DEBUG', 'context.getExecutionContext()', context.getExecutionContext());
    nlapiLogExecution('DEBUG', 'type', type);

    var custbody_waive_disposal_old = null, old_approval_status = null, oldRecord;

    oldRecord = nlapiGetOldRecord();
    if (oldRecord) {
        custbody_waive_disposal_old = oldRecord.getFieldValue('custbody_waive_disposal');
        old_approval_status = oldRecord.getFieldValue('custbody_aw_est_approval_status');
    }

    var custbody_waive_disposal = nlapiGetFieldValue('custbody_waive_disposal');
    var custbody_aw_est_approver = nlapiGetFieldValue('custbody_aw_est_approver');
    var recordType = nlapiGetRecordType();

    var old_total = parseFloat(0);
    // get previous amount
    if (type == 'create') {
    } else {
        var est_id = nlapiGetRecordId();
        var filters = new Array();
        filters[0] = new nlobjSearchFilter('internalid', null, 'is', est_id);
        var columns = new Array();
        columns[0] = new nlobjSearchColumn('total');
        var est_total_ray = nlapiSearchRecord(recordType, null, filters, columns);
        old_total = est_total_ray[0].getValue(columns[0]);
        old_total = parseFloat(old_total);
    }

    //get current amount
    var total = nlapiGetFieldValue('total');
    total = parseFloat(total);

    //get current status
    var approval_status = nlapiGetFieldValue('custbody_aw_est_approval_status');

    var custbody_context = nlapiGetFieldValue('custbody_context');
    if (type == 'create' || type == 'copy')
        custbody_context = '';

    if (custbody_context != 'UI') {

        if (type == 'create' || type == 'edit' || type == 'copy') {

            // 1 = Pending Approval // 2 = Approved // 3 = Rejected

            if ((approval_status == 1 || total > old_total)
                || (custbody_waive_disposal != custbody_waive_disposal_old
                    && (approval_status == 2 || approval_status == 3))) {

                var employ = nlapiGetFieldValue('salesrep');

                var filters = new Array();
                filters[0] = new nlobjSearchFilter('internalid', null, 'is', employ);
                var columns = new Array();
                columns[0] = new nlobjSearchColumn('supervisor');
                columns[1] = new nlobjSearchColumn('custentity_aw_employee_estimate_limit');

                var results = nlapiSearchRecord('employee', null, filters, columns);

                var boss = results[0].getValue(columns[0]);
                nlapiLogExecution('DEBUG', 'boss', boss);

                var limit = results[0].getValue(columns[1]);
                nlapiLogExecution('DEBUG', 'limit', limit);

                total = nlapiGetFieldValue('total');
                nlapiLogExecution('DEBUG', 'total', total);

                if (boss == null || boss.length < 1) {
                    boss = 11; // default to Andy when no supervisor
                }

                if (employ == 39010) { // Robert
                    boss = 36558 // Huzaifa
                }

                if (limit == null || limit.length < 1) {
                    limit = 25000; //default if no limit //RB-changing this to 25k as default if no limit
                }

                total = parseFloat(total);
                limit = parseFloat(limit);

                if (custbody_waive_disposal == 'T'
                    && custbody_waive_disposal != custbody_waive_disposal_old) {

                    nlapiLogExecution('DEBUG', 'custbody_waive_disposal', 'T');

                    nlapiSetFieldValue('custbody_aw_est_approver', 11); // 11 Andy LaVelle

                    if (employ == 39010) { // Robert
                        nlapiSetFieldValue('custbody_aw_est_approver', 36558); // Huzaifa
                    }

                    nlapiSetFieldValue('custbody_aw_est_approval_status', 1);

                    if (recordType == 'estimate') {
                        if (nlapiGetFieldValue('customform') == 129
                            || nlapiGetFieldValue('customform') == 135) {
                            nlapiSetFieldValue('customform', 135);
                        }
                        else {
                            nlapiSetFieldValue('customform', 128);
                        }
                    }

                }
                else if (total > limit && total > old_total) {

                    nlapiLogExecution('DEBUG', 'total > limit', 'T');

                    if (total > 100000) {

                        var loc = nlapiGetFieldValue('location');

                        if (loc == 7 || loc == 6 || loc == 10) {  // San Diego, Orange County, Seattle,
                            nlapiSetFieldValue('custbody_aw_est_approver', 1852);
                        }
                        else {
                            nlapiSetFieldValue('custbody_aw_est_approver', 11); //andy defaults

                            if (employ == 39010) { // Robert
                                nlapiSetFieldValue('custbody_aw_est_approver', 36558); // Huzaifa
                            }

                        }
                        nlapiSetFieldValue('custbody_aw_est_approval_status', 1);
                    }
                    else {
                        nlapiSetFieldValue('custbody_aw_est_approver', boss);
                        nlapiSetFieldValue('custbody_aw_est_approval_status', 1);
                    }

                    if (recordType == 'estimate') {

                        if (nlapiGetFieldValue('customform') == 129
                            || nlapiGetFieldValue('customform') == 135) {
                            nlapiSetFieldValue('customform', 135);
                        }
                        else {
                            nlapiSetFieldValue('customform', 128);
                        }
                    }
                }
                else if (!custbody_aw_est_approver) {
                    nlapiSetFieldValue('custbody_aw_est_approver', '');
                    nlapiSetFieldValue('custbody_aw_est_approval_status', 2);

                    if (recordType == 'estimate') {

                        if (nlapiGetFieldValue('customform') == 129
                            || nlapiGetFieldValue('customform') == 135) {
                            nlapiSetFieldValue('customform', 129);
                        }
                        else if (nlapiGetFieldValue('customform') == 128
                            || nlapiGetFieldValue('customform') == 134) {
                            nlapiSetFieldValue('customform', 106);
                        }
                    }
                }
            }
        }
    }
}

function set_date_closed(type) {

    var recordType = nlapiGetRecordType();

    if (type == 'create' || type == 'edit') {

        if (recordType == 'estimate') {

            var notes = nlapiSearchRecord('transaction', 'customsearch891',
                [new nlobjSearchFilter('internalid', null, 'anyof', nlapiGetRecordId()),
                    new nlobjSearchFilter('mainline', null, 'is', 'F')]);
            var cols = '';
            if (notes != null) {
                cols = notes[0].getAllColumns();
                var date = notes[0].getValue(cols[2]);
                date = date.split(' ');
                date = date[0];
                nlapiSubmitField('estimate', nlapiGetRecordId(), 'custbody_op_close_date', date);
            }
        }
    }
}