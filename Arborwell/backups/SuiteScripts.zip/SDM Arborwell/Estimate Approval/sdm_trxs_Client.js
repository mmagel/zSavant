var id = nlapiGetRecordId();
var recordType = nlapiGetRecordType();

var custbody_aw_est_approval_status = nlapiLookupField(recordType, id, 'custbody_aw_est_approval_status', true);
console.log(custbody_aw_est_approval_status);

if (custbody_aw_est_approval_status == 'Pending Approval') {

    // hide print buttons top & bottom
    jQuery(jQuery('.pgBntG')[14]).hide();
    jQuery(jQuery('.pgBntG')[32]).hide();
}