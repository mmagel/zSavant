function get_supe_sl(request,response){
	var rec=request.getParameter('empid');
	var supe=nlapiLookupField('employee',rec,'supervisor');
	var name=nlapiLookupField('employee',rec,'entityid');
	var limit=nlapiLookupField('employee',rec,'approvallimit');
	var app=nlapiLookupField('employee',rec,'approver');
	var mail=nlapiLookupField('employee',rec,'email');
	response.write(JSON.stringify({'supe':supe,'name':name,'applim':limit,'app':app,'mail':mail}));
}
function sdm_set_approved(){
	// 1 = pending
	// 2 = approved
	// 3 = rejected
		var context = nlapiGetContext();
		var acc_approver = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_acct_approver'));
		var executive = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_exe_approver'));
		var backup_supe = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_last_supervisor_client'));
		var records=new Object();
		records['transaction']=''+nlapiGetRecordId()+'';
		var id = nlapiGetRecordId();
		var record = nlapiLoadRecord('expensereport', id);
		var employee=record.getFieldValue('entity');
		var name='';
		var supervisor='';
		
		var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','expensereport',nlapiGetRecordId());
		//alert(record.getFieldValue('nextapprover'));
		
		if (record.getFieldValue('nextapprover')==executive){
			var field=nlapiRequestURL('/app/site/hosting/scriptlet.nl?script=394&deploy=1'+'&empid='+record.getFieldValue('entity'));
			//alert('s');
			var json=JSON.parse(field.getBody());
			name=json['name'];
			record.setFieldValue('accountingapproval','T');
			record.setFieldValue('supervisorapproval','T');
			record.setFieldValue('custbody_sdm_er_supervisor','T');
			record.setFieldValue('custbody_sdm_er_executive','T');
			record.setFieldValue('approvalstatus', 2);
			record.setFieldValue('nextapprover', '');
			
		}
		else if (record.getFieldValue('nextapprover')==acc_approver &&record.getFieldValue('custbody_sdm_er_accounting')=='F'){
			//alert('s');
			supervisor=nlapiRequestURL('/app/site/hosting/scriptlet.nl?script=394&deploy=1'+'&empid='+record.getFieldValue('entity'));
			//alert('s');
			var json=JSON.parse(supervisor.getBody());
			name=json['name'];
			//alert('s');
			supervisor=json['supe'];
			//alert(name+' '+supervisor);
			//return;
			//alert('elif '+acc_approver);
			//alert('elif '+supervisor);
			record.setFieldValue('accountingapproval','T');
			record.setFieldValue('custbody_sdm_er_accounting','T');
			var total=parseFloat(record.getFieldValue('total'));
			//alert(total);
			while (supervisor.length>0 && json['applim'].length>0&&(parseFloat(json['applim'])<total)){
				//alert('total '+total);
				//alert('limit '+nlapiLookupField('employee',supervisor,'approvallimit'));
				json=nlapiRequestURL('/app/site/hosting/scriptlet.nl?script=394&deploy=1'+'&empid='+supervisor);
				supervisor=json['app'];
				//if there is no approver or the final approver has an approval limit < expense report amount, set next approver to brad
				if (supervisor.length<1&&employee!=backup_supe){
					
					supervisor=backup_supe;
					break;
				}
				else if (supervisor.length<1&&employee==backup_supe){
					//employee is brad, pass on to andy
					supervisor=executive;
					break;
				}
			}
			//alert('elif1');
			if (supervisor.length<1&&employee!=backup_supe){
				//alert('elif2');
				supervisor=backup_supe;
			}
			else if (supervisor.length<1&&employee==backup_supe){
				//employee is brad, pass on to andy
				supervisor=executive;
			}
			
			record.setFieldValue('nextapprover', supervisor);
			//alert(supervisor);
			
			nlapiSendEmail(nlapiGetUser(),supervisor,'Expense Report # '+record.getFieldValue('tranid'),'An expense report from user '+name+' is Awaiting Your Approval: '+url,null,null,records);
		}
		else if (record.getFieldValue('custbody_sdm_er_supervisor')=='F') {

			record.setFieldValue('custbody_sdm_er_supervisor','T');
			record.setFieldValue('nextapprover',executive);
			nlapiSendEmail(nlapiGetUser(),executive,'Expense Report # '+record.getFieldValue('tranid'),'An expense report is Awaiting Your Approval: '+url,null,null,records);
		}
		//alert('here');
		nlapiSubmitRecord(record);
		
		
		location.reload();
	}

	function sdm_set_reject(){
		var context = nlapiGetContext();
		var acc_approver = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_acct_approver'));
		var executive = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_exe_approver'));
		var backup_supe = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_last_supervisor_client'));
		var id = nlapiGetRecordId();
		var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','expensereport',id);
		var record = nlapiLoadRecord('expensereport', id);
		var approver=record.getFieldValue('nextapprover');
		var json=JSON.parse(nlapiRequestURL('/app/site/hosting/scriptlet.nl?script=394&deploy=1'+'&empid='+approver).getBody());
		var app_name=json['name'];
		var employee=record.getFieldValue('entity');
		var json=JSON.parse(nlapiRequestURL('/app/site/hosting/scriptlet.nl?script=394&deploy=1'+'&empid='+employee).getBody());
		var emp_name=json['name'];

			//emlpoyee
			var records=new Object();
			records['transaction']=''+nlapiGetRecordId()+'';
			var reason=window.prompt('Please enter your reason for rejecting this expense report.');
			var bodystring=app_name+ ' has rejected your expense report at the following url: '+url+'\n\n';
			if (reason!=null && reason.length>0){
				bodystring+='Comments: ';
				bodystring+=reason;
			}
			else {
				bodystring+='Comments: no reason was given.';
			}
			var email=json['mail'];
			if (email.length>0){
				nlapiSendEmail(nlapiGetUser(),employee,'Expense Report # '+record.getFieldValue('tranid')+' Rejected',bodystring,null,null,records);
			}
			else {
				alert('This employee has no email on file. They will not be notified.');
				nlapiSendEmail(nlapiGetUser(),nlapiGetUser(),'Expense Report # '+record.getFieldValue('tranid')+' Rejected: No employee email on file',bodystring,null,null,records);
			}
			record.setFieldValue('approvalstatus', 3);
			record.setFieldValue('custbody_sdm_er_supervisor','F');
			record.setFieldValue('custbody_sdm_er_accounting','F');
			record.setFieldValue('custbody_sdm_er_executive','F');
			record.setFieldValue('custbody_sdm_er_complete','F');
			record.setFieldValue('nextapprover', '');
			nlapiSubmitRecord(record);
			location.reload();
	}

	function expense_report_before_load(type, form, request){
		//18=full access role id
		if (nlapiGetFieldValue('custbody_sdm_jc')=='T'){
			var rec=nlapiLoadRecord('expensereport',nlapiGetRecordId());
			rec.setFieldValue('custbody_sdm_jc','F');
			nlapiSubmitRecord(rec);
			var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','expensereport',nlapiGetRecordId());
			var employee=nlapiGetFieldValue('entity');
			var name=nlapiLookupField('employee',employee,'entityid');
			var approver_em=nlapiGetFieldValue('nextapprover');
			var records=new Object();
			records['transaction']=''+nlapiGetRecordId()+'';
			nlapiSendEmail(nlapiGetUser(),approver_em,'Expense Report # '+nlapiGetFieldValue('tranid'),'A New expense report from user '+name+' is Awaiting Your Approval: '+url,null,null,records);
			
		}
		form.getField('approvalstatus').setDisplayType('inline');
		form.getField('nextapprover').setDisplayType('inline');
		if (nlapiGetFieldValue('custbody_sdm_er_complete')=='T'){
			if (((type=='edit' && parseInt(nlapiGetFieldValue('approvalstatus'))!=3 && nlapiGetFieldValue('custbody_sdm_er_accounting')=='T')||(parseInt(nlapiGetFieldValue('approvalstatus'))==3&&nlapiGetUser()!=nlapiGetFieldValue('entity')&&nlapiGetUser()!=11947&&nlapiGetUser()!=6)) && nlapiGetRole()!=3 &&nlapiGetRole()!=1008){
				nlapiSetRedirectURL('RECORD','expensereport',nlapiGetRecordId(),false);
			}

			if(type == 'view'){
				var status = nlapiGetFieldValue('approvalstatus');
				var approver = nlapiGetFieldValue('nextapprover');
				var current = nlapiGetUser();
				if(status == 1 && (approver == current||current==11947||current==6||nlapiGetRole()==3)	){
					form.setScript('customscript_sdm_expense_buttons');
					form.addButton('custpage_sdm_approve', 'Approve', 'sdm_set_approved()');
					form.addButton('custpage_sdm_reject', 'Reject', 'sdm_set_reject()');
					
				}
			}
		}
	}

	function expense_report_before_submit(type){
		var context = nlapiGetContext();
		var acc_approver = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_acct_approve'));
		var executive = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_exe_approve'));
		var backup_supe = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_er_last_supervisor'));
		var employee=nlapiGetFieldValue('entity');
		var name=nlapiLookupField('employee',employee,'entityid');
		var records=new Object();
		records['transaction']=''+nlapiGetRecordId()+'';
		var approver_em=nlapiGetUser();
		
			var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','expensereport',nlapiGetRecordId());
			var app='';
			app=nlapiGetFieldValue('nextapprover');
			nlapiLogExecution('ERROR','app','asdfasdf '+app);
			if (type=='edit'&&nlapiGetFieldValue('custbody_sdm_er_complete')=='T'&&nlapiGetFieldValue('approvalstatus')==3 && (employee==nlapiGetUser()||nlapiGetUser()==11947||nlapiGetUser()==3||nlapiGetUser()==11963)){
				nlapiSetFieldValue('approvalstatus',1);
				if (employee!=acc_approver&&nlapiGetFieldValue('custbody_sdm_er_accounting')=='F'&&nlapiGetFieldValue('custbody_sdm_er_supervisor')=='F'&&nlapiGetFieldValue('custbody_sdm_er_executive')=='F'){
					nlapiSetFieldValue('nextapprover',acc_approver);
					approver_em=acc_approver;
				}
				else if (employee==acc_approver){
					var approver=nlapiLookupField('employee',employee,'approver');
					nlapiSetFieldValue('custbody_sdm_er_accounting','T');
					nlapiSetFieldValue('nextapprover',approver);
					approver_em=approver;
				}
				
				nlapiSendEmail(nlapiGetUser(),approver_em,'Expense Report # '+nlapiGetFieldValue('tranid'),'A revised expense report from user '+name+' is Awaiting Your Approval: '+url,null,null,records);
			}	
			else if ((nlapiGetFieldValue('custbody_sdm_er_complete')=='T' && type=='create') ||(nlapiGetFieldValue('custbody_sdm_er_complete')=='T'&&app==-1&&type=='edit'&&nlapiGetFieldValue('approvalstatus')!=2)){
				if (employee!=acc_approver){
					nlapiSetFieldValue('nextapprover',acc_approver);
					approver_em=acc_approver;
					
				}
				else if (employee==acc_approver){
					nlapiSetFieldValue('custbody_sdm_er_accounting','T');
					nlapiSetFieldValue('nextapprover',backup_supe);
					approver_em=backup_supe;
				}
				if (type!='create'){
					nlapiSendEmail(nlapiGetUser(),approver_em,'Expense Report # '+nlapiGetFieldValue('tranid'),'A new expense report from user '+name+' is Awaiting Your Approval: '+url,null,null,records);
				}
				else if (type=='create'&&nlapiGetFieldValue('custbody_sdm_er_complete')=='T'){
					nlapiSetFieldValue('custbody_sdm_jc','T');
				}
			}
	}
	function expense_report_after_submit(type){
		if (type=='create'){
			if (nlapiGetFieldValue('custbody_sdm_er_complete')=='T'){
				//nlapiSubmitField('expensereport',nlapiGetRecordId(),'custbody_sdm_jc','T');
			}
		}
	}