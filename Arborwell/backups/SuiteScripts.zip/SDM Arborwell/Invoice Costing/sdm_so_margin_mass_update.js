/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       28 May 2014     cblaisure
 *
 */

/**
 * @param {String} recType Record type internal id
 * @param {Number} recId Record internal id
 * @returns {Void}
 */
function update_so_margin(recType, recId) {
	//load record
try{
	var so = nlapiLoadRecord(recType, recId); 

	var so_amt = parseFloat(so.getFieldValue('total'));
	var bill_sch = so.getFieldValue('billingschedule');
	var so_num = so.getFieldValue('tranid');

	//Check for billing schedule, if yes, default to 70%
	//if (bill_sch == null || bill_sch.length < 1) {
	//Labor cost
		var wo_id = so.getFieldValue('custbody_aw_work_order'); 

		if(wo_id == null || wo_id.length < 1){
			
			var labor_cost = Number(0);
			
			} else {
			
			var filters = new Array();
			filters[0] = new nlobjSearchFilter( 'custcol_aw_time_work_order', null, 'is', wo_id );
			var columns = new Array();
			columns[0] = new nlobjSearchColumn('custcol_aw_time_labor_cost', null, 'sum');
			var searchresults = nlapiSearchRecord( 'timebill', null, filters, columns );
			//error catch
			if(searchresults == null || searchresults.length < 1){
				var labor_cost = Number(0);
				} else {
				var labor_cost = Number(searchresults[0].getValue(columns[0]));
				}
			}
		
		so.setFieldValue('custbody_aw_invoice_labor_cost', labor_cost);	
		
	//PO Cost coming from Bill line items where sales order is entered
		
		var error_so = parseInt(so_num.replace(/[^0-9.]/g,'')); //remove the begining letter on SO's
		
		var po_filters = new Array();
		po_filters[0] = new nlobjSearchFilter('mainline', null, 'is', 'F');
		po_filters[1] = new nlobjSearchFilter('custcolaw_sales_order_cl', null, 'equalto', error_so);
		po_filters[2] = new nlobjSearchFilter('custcol_aw_exclude_gp', null, 'is', 'F');	
		var po_columns = new Array();
		po_columns[0] = new nlobjSearchColumn('amount', null, 'sum');
		
		var po_searchresults = nlapiSearchRecord( 'vendorbill', null, po_filters, po_columns );
		var ch_searchresults = nlapiSearchRecord( 'check', null, po_filters, po_columns );
		//error catch
		
		if(po_searchresults == null || po_searchresults.length < 1){
			var po_cost = Number(0);
			} else {
			var po_cost = (Number((po_searchresults[0].getValue(po_columns[0]))));
			}	

			if(ch_searchresults == null || ch_searchresults.length < 1){
			var ch_cost = Number(0);
			} else {
			var ch_cost = (Number((ch_searchresults[0].getValue(po_columns[0]))));
			}	
			
		so.setFieldValue('custbody_aw_invoice_po_cost', po_cost+ch_cost);	
		po_cost+=ch_cost;
	//SO Cost from fullfilment records

		var so_filters = new Array();
		so_filters[0] = new nlobjSearchFilter('createdfrom', null, 'is', recId);
		var so_columns = new Array();
		so_columns[0] = new nlobjSearchColumn('debitamount', null, 'sum');
		var so_searchresults = nlapiSearchRecord('itemfulfillment', null, so_filters, so_columns );

		if(so_searchresults == null || so_searchresults.length < 1){
			var so_cost = Number(0);
			} else {
			var so_cost = Number(so_searchresults[0].getValue(so_columns[0]));
			}	

		so.setFieldValue('custbody_aw_invoice_so_cost', so_cost);	

//changes to add JE Adjustment 3/5/2015
		var je_filters = new Array();
		je_filters[0] = new nlobjSearchFilter('custcol_aw_je_so', null, 'is', recId);
		var je_columns = new Array();
		je_columns[0] = new nlobjSearchColumn('debitamount', null, 'sum');
		je_columns[1] = new nlobjSearchColumn('creditamount', null, 'sum');
		var je_searchresults = nlapiSearchRecord('journalentry', null, je_filters, je_columns );
		if(je_searchresults == null || je_searchresults.length < 1){
			var je_adjust = Number(0);
			} else {
			var je_credit = Number(je_searchresults[0].getValue(je_columns[0]));
			var je_debit  = Number(je_searchresults[0].getValue(je_columns[1]));
			var je_adjust = je_credit-je_debit; //Create a single adjustment number
			nlapiLogExecution('ERROR', 'Credit', je_credit);
			nlapiLogExecution('ERROR', 'Debit', je_debit);
			}	
		so.setFieldValue('custbody_aw_invoice_adjustment', je_adjust);
		
	//Profit, invoice amount - all costs
		
		var inv_total = amount_billed(recId);
		
		var all_cost = Number(labor_cost) + Number(po_cost) + Number(so_cost) + Number(je_adjust);
		nlapiLogExecution('error', 'allcosts', all_cost+' '+po_cost+' '+so_cost+' '+je_adjust+' '+labor_cost);
		if(all_cost > 0){

			//if there are costs, calulate GM and GM%
			var profit = inv_total - all_cost;
			so.setFieldValue('custbody_aw_invoice_profit', profit);
			//set GM%
			nlapiLogExecution('ERROR','numbers',inv_total+' '+all_cost+' '+profit+' '+so_cost+' '+je_adjust+' '+po_cost+' '+labor_cost);
			var gm_percent = (profit / inv_total) * 100;
			if (String(gm_percent)=='-Infinity'){
				gm_percent=-999.99;
			}
			nlapiLogExecution('ERROR','numbers1',gm_percent);
			so.setFieldValue('custbody_aw_invoice_margin_percent', gm_percent);
			so.setFieldValue('custbody_aw_invoice_amount_billed', inv_total);	
			
			} else {
				
				//If no costs are found...

				var profit = inv_total * .54;
				so.setFieldValue('custbody_aw_invoice_profit', profit);	
				so.setFieldValue('custbody_aw_invoice_margin_percent', 54);	
				so.setFieldValue('custbody_aw_invoice_amount_billed', inv_total);	

			}
		if (labor_cost==0){
			so.setFieldValue('custbody_aw_invoice_margin_percent', 54);	
		}
	nlapiSubmitRecord(so,false,true);
}
catch (error) {
	var string= recId+' '+error.message;
	nlapiLogExecution('ERROR',recId,error.message);
	//throw string;
}
}


function isEmpty(stValue) {
	//used to identify blank fields
	if ((stValue == '') || (stValue == null) ||(stValue == undefined))
	    {
	    return true;
	    }
	    return false;
	}

function amount_billed (recId){
	var bill_filters = new Array();
	bill_filters[0] = new nlobjSearchFilter('createdfrom', null, 'is', recId);
	bill_filters[1] = new nlobjSearchFilter('mainline', null, 'is', 'F');
	bill_filters[2] = new nlobjSearchFilter('item',null,'noneof',[1250,1219,1526,-2]);
	
	var bill_columns = new Array();
	bill_columns[0] = new nlobjSearchColumn('amount', null, 'sum');
	
	var bill_searchresults = nlapiSearchRecord('invoice', null, bill_filters, bill_columns );
	//error catch
	
	if(bill_searchresults == null || bill_searchresults.length < 1){
		var bill_amount = Number(0);
		} else {
		var bill_amount = Number(bill_searchresults[0].getValue(bill_columns[0]));
		}
	
	return bill_amount;
	
}
function sales_orders_set_field(type, id)
	
{
var rec=nlapiLoadRecord(type,id);
var filters=new Array();
var date=rec.getFieldValue('trandate');
filters.push(new nlobjSearchFilter('custbody_aw_property',null,'is',rec.getFieldValue('custbody_aw_property')));
filters.push(new nlobjSearchFilter('trandate',null,'before',date));
filters.push(new nlobjSearchFilter('internalid',null,'noneof',id));
var columns=new Array();
columns.push(new nlobjSearchColumn('internalid'));
var results=nlapiSearchRecord('salesorder',null,filters,columns);
if (results==null||results.length==0){
	rec.setFieldValue('custbody_biz_type',1);
}
else {
	rec.setFieldValue('custbody_biz_type',2);
}
nlapiSubmitRecord(rec,false,true);
}



	
	