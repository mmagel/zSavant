/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       02 Jan 2014     cblaisure
 *
 */

/**
 * @param {String} recType Record type internal id
 * @param {Number} recId Record internal id
 * @returns {Void}
 */
function update_invoice_cost(recType, recId) {

	//load invoice	
var invoice = nlapiLoadRecord(recType, recId);
var so_id = invoice.getFieldValue('createdfrom'); 

//if no SO, then set to 70%
if(so_id == null || so_id.length < 1){
	invoice.setFieldValue('custbody_aw_invoice_labor_cost', 0);	
	invoice.setFieldValue('custbody_aw_invoice_so_cost', 0);	
	invoice.setFieldValue('custbody_aw_invoice_po_cost', 0);	
	var total = Number(invoice.getFieldValue('total')); 
	var profit = total * .70;
	invoice.setFieldValue('custbody_aw_invoice_profit', profit);	
	invoice.setFieldValue('custbody_aw_invoice_margin_percent', 70);	
	nlapiSubmitRecord(invoice);
	return;
}

//load Sales Order
var so = nlapiLoadRecord('salesorder', so_id);
var bill_sch = so.getFieldValue('billingschedule');
var so_num = so.getFieldValue('tranid');

//Check for billing schedule, if yes, default to 70%
if (bill_sch == null || bill_sch.length < 1) {
	
//Labor cost
	var wo_id = so.getFieldValue('custbody_aw_work_order'); 

	if(wo_id == null || wo_id.length < 1){
		
		var labor_cost = Number(0);
		
	} else {
		
		var filters = new Array();
		filters[0] = new nlobjSearchFilter( 'custcol_aw_time_work_order', null, 'is', wo_id );
		var columns = new Array();
		columns[0] = new nlobjSearchColumn('custcol_aw_time_labor_cost', null, 'sum');
		var searchresults = nlapiSearchRecord( 'timebill', null, filters, columns );
		//error catch
		if(searchresults == null || searchresults.length < 1){
			var labor_cost = Number(0);
			} else {
			var labor_cost = Number(searchresults[0].getValue(columns[0]));
			}
	}
	
	invoice.setFieldValue('custbody_aw_invoice_labor_cost', labor_cost);	
	
//PO Cost coming from Bill line items where sales order is entered
	
	
	//update 3.28 error check to remove letters in front of sales orders started early feb 2014.
	var num_only_so_id = parseInt(so_num.replace(/[^0-9.]/g,''));

	var po_filters = new Array();
	po_filters[0] = new nlobjSearchFilter('mainline', null, 'is', false);
	po_filters[1] = new nlobjSearchFilter('custcolaw_sales_order_cl', null, 'equalto', num_only_so_id);
	
	//end update 3.28	
	
	var po_columns = new Array();
	po_columns[0] = new nlobjSearchColumn('amount', null, 'sum');
	
	var po_searchresults = nlapiSearchRecord( 'vendorbill', null, po_filters, po_columns );

	if(po_searchresults == null || po_searchresults.length < 1){
		var po_cost = Number(0);
		} else {
		var po_cost = Number(-1 * (po_searchresults[0].getValue(po_columns[0])));
		}	
		
	invoice.setFieldValue('custbody_aw_invoice_po_cost', po_cost);	
	
//SO Cost from fullfilment records

	var so_filters = new Array();
	so_filters[0] = new nlobjSearchFilter('createdfrom', null, 'is', so_id);
		
	var so_columns = new Array();
	so_columns[0] = new nlobjSearchColumn('debitamount', null, 'sum');
	
	var so_searchresults = nlapiSearchRecord('itemfulfillment', null, so_filters, so_columns );

	if(so_searchresults == null || so_searchresults.length < 1){
		var so_cost = Number(0);
		} else {
		var so_cost = Number(so_searchresults[0].getValue(so_columns[0]));
		}	

	invoice.setFieldValue('custbody_aw_invoice_so_cost', so_cost);	

	
//Profit, invoice amount - all costs

	var inv_total = Number(invoice.getFieldValue('total'));
	var all_cost = Number(labor_cost) + Number(po_cost) + Number(so_cost);

	if(all_cost > 0){

		//if there are costs, calulate GM and GM%
		var profit = inv_total - all_cost;
		invoice.setFieldValue('custbody_aw_invoice_profit', profit);
		//set GM%
		var gm_percent = (profit / inv_total) * 100;
		invoice.setFieldValue('custbody_aw_invoice_margin_percent', gm_percent);
		
		} else {
			
			//If no costs are found, set = to 70%
			var profit = inv_total * .70;
			invoice.setFieldValue('custbody_aw_invoice_profit', profit);	
			invoice.setFieldValue('custbody_aw_invoice_margin_percent', 70);	
		}
			
	} else {
	
	//set default to 70% on billing schedule	
	invoice.setFieldValue('custbody_aw_invoice_labor_cost', 0);	
	invoice.setFieldValue('custbody_aw_invoice_so_cost', 0);	
	invoice.setFieldValue('custbody_aw_invoice_po_cost', 0);	
	
	var total = Number(invoice.getFieldValue('total')); 
	var profit = total * .70;
	
	invoice.setFieldValue('custbody_aw_invoice_profit', profit);	
	invoice.setFieldValue('custbody_aw_invoice_margin_percent', 70);	

}

// update invoice
nlapiSubmitRecord(invoice);


}


