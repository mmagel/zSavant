/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       04 Oct 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 *   
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
function line_price_validate(type){
 // used on line validation to do tree pricing (qty * labor * Trees)
	if(type == 'item'){
		
		var subtype = nlapiGetCurrentLineItemValue('item', 'itemtype');
		
		if(subtype == 'Service'){
		
			var ns_qty = nlapiGetCurrentLineItemValue('item', 'quantity');
			var aw_rate_per_item_hour = nlapiGetCurrentLineItemValue('item', 'custcol_actual_labor_rate');
			var aw_labor_per_tree = nlapiGetCurrentLineItemValue('item', 'custcol_aw_hr_per_tree');
			
			if (aw_rate_per_item_hour == null || aw_rate_per_item_hour.length < 1 || aw_labor_per_tree == null || aw_labor_per_tree.length < 1){
				throw alert('Service must have a defined Labor Rate and a per tree rate. Please check you rates and try again.');
			}
									
			var amt = aw_rate_per_item_hour * aw_labor_per_tree * ns_qty ;
			var new_rate = amt / ns_qty;
					
		nlapiSetCurrentLineItemValue('item', 'price', -1);
		nlapiSetCurrentLineItemValue('item', 'rate', new_rate);
		
		//set defined cost
	
		nlapiSetCurrentLineItemValue('item', 'costestimatetype', 'ITEMDEFINED', null, true);
		var cost_rate = nlapiGetCurrentLineItemValue('item', 'costestimaterate');
				
		var per_quantity_cost = ((ns_qty * aw_labor_per_tree) * cost_rate);
		
		nlapiSetCurrentLineItemValue('item', 'costestimatetype', 'CUSTOM');
		nlapiSetCurrentLineItemValue('item', 'costestimate', per_quantity_cost);
			
		}
	}
	return true;
  }

function set_std_price(type, name){
	//used to have a column field with Standard pricing available for reference	
		if(type == 'item' && name == 'item'){
			
			rate = nlapiGetCurrentLineItemValue('item', 'rate');
				
			nlapiSetCurrentLineItemValue('item', 'custcol_std_rate', rate);
			nlapiSetCurrentLineItemValue('item', 'custcol_actual_labor_rate', rate);
		}
		
	}