/**
* Module Description
* 
* Version Date Author Remarks
* 1.00 25 Aug 2014 AHalbleib
*
*/

/**
* The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
* @appliedtorecord recordType
* 
* @param {String} type Operation types: create, edit, view, copy, print, email
* @param {nlobjForm} form Current form
* @param {nlobjRequest} request Request object
* @returns {Void}
*/
function purchase_order_before_load(type, form, request){
	if (type=='copy'){nlapiSetFieldValue('custbody_sdm_po_num','');}
		form.getField('tranid').setDisplayType('hidden');
		if (type=='edit'||type=='create'){
			form.getField('approvalstatus').setDisplayType('inline');
			form.getField('nextapprover').setDisplayType('inline');
		}
		
		if (type=='view'){
			if (nlapiGetFieldValue('approvalstatus')==2&&(nlapiGetFieldValue('custbody_check')=='F'||nlapiGetFieldValue('custbody_check')==null)){
				
				rec=nlapiLoadRecord('purchaseorder',nlapiGetRecordId());
				rec.setFieldValue('custbody_sdm_po_num',nlapiGetFieldValue('tranid'));
				rec.setFieldValue('custbody_check','T');
				nlapiSubmitRecord(rec,false,true);
				nlapiSetRedirectURL('RECORD','purchaseorder',nlapiGetRecordId(),false);
				
			}
			var context = nlapiGetContext();
			var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president'));

			var status=nlapiGetFieldValue('approvalstatus');
			var next_approver=nlapiGetFieldValue('nextapprover');
			if (status==1 && (next_approver==nlapiGetUser()||nlapiGetRole()==3||nlapiGetUser()==president)){
				form.setScript('customscript_sdm_po_app_buttons');
				form.addButton('custpage_approve','Approve','approve()');
				form.addButton('custpage_reject','Reject','reject()');
			}
		}
}

function purchase_order_before_submit(type){
	var context = nlapiGetContext();
	var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president'));
	if (nlapiGetFieldValue('custbody_sdm_rejected')=='T'){
		nlapiSetFieldValue('custbody_sdm_rejected','F');
		return;
	}
	if (nlapiGetFieldValue('employee')!=null&&nlapiGetFieldValue('employee').length>0){
		limit=nlapiLookupField('employee',nlapiGetFieldValue('employee'),'purchaseorderlimit');
		if (limit==null||limit.length<1){
			limit=0;
		}
	}
	if (type=='create' || (type=='edit' && nlapiGetFieldValue('approvalstatus')==3)){
		var total=parseFloat(nlapiGetFieldValue('total'));
		if (total>=500&&total>limit){
			nlapiSetFieldValue('approvalstatus',1);
			var approver='';
			if (nlapiGetFieldValue('employee')!=null&&nlapiGetFieldValue('employee').length>0){
				approver=nlapiLookupField('employee',nlapiGetFieldValue('employee'),'purchaseorderapprover');
			}
			if (approver!=null && approver.length>0 && approver!=0){
				nlapiSetFieldValue('nextapprover',approver);
				if (type!='create'){
					var records=new Object();
					records['transaction']=''+nlapiGetRecordId()+'';
					var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
					nlapiSendEmail(nlapiGetUser(),approver,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
							'is awaiting your approval. It can be found at the following URL: '+url,null,null,records);
				}
			}
			else {
				nlapiSetFieldValue('nextapprover',president);
				if (type!='create'){
					var records=new Object();
					records['transaction']=''+nlapiGetRecordId()+'';
					var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
					nlapiSendEmail(nlapiGetUser(),president,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
							'is awaiting your approval. It can be found at the following URL: '+url,null,null,records);
				}
			}
		}
		else {
			nlapiSetFieldValue('approvalstatus',2);
			nlapiSetFieldValue('nextapprover','');
		}
	}
	if (nlapiGetFieldValue('approvalstatus')==2){
		nlapiSetFieldValue('custbody_sdm_po_num',nlapiGetFieldValue('tranid'));
	}
}
function approve(){
	var context = nlapiGetContext();
	var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president1'));
	var record=nlapiLoadRecord('purchaseorder',nlapiGetRecordId());
	if (record.getFieldValue('nextapprover')==president){
		var employee=record.getFieldValue('employee');
		var tranno=record.getFieldValue('tranid');
		var records=new Object();
		records['transaction']=''+nlapiGetRecordId()+'';
		var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
		nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Approved','Your purchase order '+
				'has been approved. It can be found at the following URL: '+url+' . The transaction number is '+tranno+'.',null,null,records);
		record.setFieldValue('approvalstatus',2);
		record.setFieldValue('nextapprover','');
	}
	else if (parseFloat(record.getFieldValue('total'))>=5000 && record.getFieldValue('nextapprover')!=president){
		var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
		var records=new Object();
		records['transaction']=''+nlapiGetRecordId()+'';
		nlapiSendEmail(nlapiGetUser(),president,'A Purchase Order is Awaiting Your Approval.','A new Purchase Order '+
				'is awaiting your approval. It can be found at the following URL: '+url,null,null,records);
		record.setFieldValue('nextapprover',president);
	}
	else {
		var employee=record.getFieldValue('employee');
		var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
		var tranno=record.getFieldValue('tranid');
		var records=new Object();
		records['transaction']=''+nlapiGetRecordId()+'';
		nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Approved','Your purchase order '+
				'has been approved. It can be found at the following URL: '+url+' . The transaction number is '+tranno+'.',null,null,records);
		record.setFieldValue('approvalstatus',2);
		record.setFieldValue('nextapprover','');
	}
	nlapiSubmitRecord(record,true,false);
	location.reload();
}
function reject(){
	var record=nlapiLoadRecord('purchaseorder',nlapiGetRecordId());
	var employee=record.getFieldValue('employee');
	var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
	var records=new Object();
	records['transaction']=''+nlapiGetRecordId()+'';
	nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Rejected','Your purchase order '+
		'has been rejected. It can be found at the following URL: '+url,null,null,records);
	record.setFieldValue('approvalstatus',3);
	record.setFieldValue('nextapprover','');
	record.setFieldValue('custbody_sdm_rejected','T');
	nlapiSubmitRecord(record,true,false);

	location.reload();
}
function purchase_order_after_submit(type){
	if (type=='create'){
		var total=parseFloat(nlapiGetFieldValue('total'));
		var limit=0;
		if (nlapiGetFieldValue('employee')!=null&&nlapiGetFieldValue('employee').length>0){
			limit=nlapiLookupField('employee',nlapiGetFieldValue('employee'),'purchaseorderlimit');
			if (limit==null||limit.length<1){
				limit=0;
			}
		}
		nlapiLogExecution('ERROR','adf',limit);
		if (total>=500&&total>limit){
			var app=nlapiGetFieldValue('nextapprover');
			var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
			var records=new Object();
			records['transaction']=''+nlapiGetRecordId()+'';
			nlapiSendEmail(nlapiGetUser(),app,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
					'is awaiting your approval. It can be found at the following URL: '+url,null,null,records);
		}
	}
	else if (type!='delete'&&nlapiGetFieldValue('approvalstatus')=='2'&&nlapiGetFieldValue('nextapprover').length>0){
		nlapiSubmitField('purchaseorder',nlapiGetRecordId(),'nextapprover','');
	}
}
function massUpdate(recType, recId) {
	var record=nlapiLoadRecord(recType,recId);
	record.setFieldValue('custbody_sdm_po_num',record.getFieldValue('tranid'));
	nlapiSubmitRecord(record,true,true);
}
