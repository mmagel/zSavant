/**
* Module Description
* 
* Version Date Author Remarks
* 1.00 25 Aug 2014 AHalbleib
*
*/

/**
* The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
* @appliedtorecord recordType
* 
* @param {String} type Operation types: create, edit, view, copy, print, email
* @param {nlobjForm} form Current form
* @param {nlobjRequest} request Request object
* @returns {Void}
*/
function purchase_order_before_load(type, form, request){
if (type=='copy'){nlapiSetFieldValue('custbody_sdm_po_num','');}
form.getField('tranid').setDisplayType('hidden');
if (type=='edit'||type=='create'){
form.getField('approvalstatus').setDisplayType('inline');
form.getField('nextapprover').setDisplayType('inline');
}
if (type=='view'){
var context = nlapiGetContext();
var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president'));

var status=nlapiGetFieldValue('approvalstatus');
var next_approver=nlapiGetFieldValue('nextapprover');
if (status==1 && (next_approver==nlapiGetUser()||nlapiGetRole()==3||nlapiGetUser()==president)){
form.setScript('customscript_sdm_po_app_buttons');
form.addButton('custpage_approve','Approve','approve()');
form.addButton('custpage_reject','Reject','reject()');
}
}
}

function purchase_order_before_submit(type){
var context = nlapiGetContext();
var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president'));
if (nlapiGetFieldValue('custrecord_sdm_rejected')=='T'){
nlapiSetFieldValue('custrecord_sdm_rejected','F');
return;
}

if (type=='create' || (type=='edit' && nlapiGetFieldValue('approvalstatus')==3)){
if (parseFloat(nlapiGetFieldValue('total'))>=500){
nlapiSetFieldValue('approvalstatus',1);
var approver=nlapiLookupField('employee',nlapiGetFieldValue('employee'),'purchaseorderapprover');
if (approver!=null&&approver.length>0){
nlapiSetFieldValue('nextapprover',approver);
if (type!='create'){
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),approver,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
'is awaiting your approval. It can be found at the following URL: '+url+'.');
}
}
else {
nlapiSetFieldValue('nextapprover',president);
if (type!='create'){
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),president,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
'is awaiting your approval. It can be found at the following URL: '+url+'.');
}
}
}
else {
nlapiSetFieldValue('approvalstatus',2);
nlapiSetFieldValue('nextapprover','');
}
}
if (nlapiGetFieldValue('approvalstatus')==2){
nlapiSetFieldValue('custbody_sdm_po_num',nlapiGetFieldValue('tranid'));
}
}
function approve(){
var context = nlapiGetContext();
var president = parseInt(context.getSetting('SCRIPT', 'custscript_sdm_po_president1'));
var record=nlapiLoadRecord('purchaseorder',nlapiGetRecordId());
if (record.getFieldValue('nextapprover')==president){
var employee=record.getFieldValue('employee');
var tranno=record.getFieldValue('tranid');
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Approved','Your purchase order '+
'has been approved. It can be found at the following URL: '+url+'. The transaction number is '+tranno+'.');
record.setFieldValue('approvalstatus',2);
record.setFieldValue('nextapprover','');
}
else if (parseFloat(record.getFieldValue('total'))>=5000 && record.getFieldValue('nextapprover')!=president){
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),president,'A Purchase Order is Awaiting Your Approval.','A new Purchase Order '+
'is awaiting your approval. It can be found at the following URL: '+url+'.');
record.setFieldValue('nextapprover',president);
}
else {
var employee=record.getFieldValue('employee');
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
var tranno=record.getFieldValue('tranid');
nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Approved','Your purchase order '+
'has been approved. It can be found at the following URL: '+url+'. The transaction number is '+tranno+'.');
record.setFieldValue('approvalstatus',2);
record.setFieldValue('nextapprover','');
}
nlapiSubmitRecord(record,true,false);
location.reload();
}
function reject(){
var record=nlapiLoadRecord('purchaseorder',nlapiGetRecordId());
var employee=record.getFieldValue('employee');
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),employee,'Your Purchase Order Has Been Rejected','Your purchase order '+
'has been rejected. It can be found at the following URL: '+url+'.');
record.setFieldValue('approvalstatus',3);
record.setFieldValue('nextapprover','');
record.setFieldValue('custrecord_sdm_rejected','T');
nlapiSubmitRecord(record,true,false);

location.reload();
}
function purchase_order_after_submit(type){
if (type=='create'){
if (parseFloat(nlapiGetFieldValue('total'))>=500){
var app=nlapiGetFieldValue('nextapprover');
var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD','purchaseorder',nlapiGetRecordId());
nlapiSendEmail(nlapiGetUser(),app,'A Purchase Order is Awaiting Your Approval.','A Purchase Order '+
'is awaiting your approval. It can be found at the following URL: '+url+'.');
}
}
}
