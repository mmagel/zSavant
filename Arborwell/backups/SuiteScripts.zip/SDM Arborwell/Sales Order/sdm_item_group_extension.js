/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Mar 2014     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 *   
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
function replace_item_group(type){

	if(type == 'item'){
		
		is_group = nlapiGetCurrentLineItemValue('item', 'itemtype');
		
		if(is_group == 'Group'){
			group_id = nlapiGetCurrentLineItemValue('item', 'item');
			//get items
			var species=nlapiGetCurrentLineItemValue('item','custcol1');
			var hpt=nlapiGetCurrentLineItemValue('item','custcol_aw_hr_per_tree');
			var quantity=nlapiGetCurrentLineItemValue('item','quantity');
			var location=nlapiGetCurrentLineItemValue('item','custcol2');
			var filters = new Array();
			filters[0] = new nlobjSearchFilter('internalid', null, 'is', group_id);
			var columns = new Array();
			columns[0] = new nlobjSearchColumn('memberitem');
			var search_results = nlapiSearchRecord('item', null, filters, columns);
			
			for (var x = 0; search_results != null && x < search_results.length; x++){
				
				var result = search_results[x];
				var item = result.getValue('memberitem');

				nlapiSetCurrentLineItemValue('item', 'item', item, true, true);
				
				if (item!=-2&&item!=-3){
					if (location!=null&&location.length>0){
						nlapiSetCurrentLineItemValue('item', 'custcol2', location, true, true);
					}
					if (quantity!=null&&quantity.length>0){
						nlapiSetCurrentLineItemValue('item', 'quantity', quantity, true, true);
					}
					else {
						nlapiSetCurrentLineItemValue('item', 'quantity', 1, true, true);
					}
					if (hpt!=null&&hpt.length>0){
						nlapiSetCurrentLineItemValue('item', 'custcol_aw_hr_per_tree', hpt, true, true);
					}
					else {
						nlapiSetCurrentLineItemValue('item', 'custcol_aw_hr_per_tree', 0, true, true);
					}
					if (species!=null&&species.length>0){
						nlapiSetCurrentLineItemValue('item', 'custcol1', species, true, true);
					}
				}
					if(x != search_results.length-1){ //last commit not needed.
						nlapiCommitLineItem('item'); 
					}
				
			}
		}
	}
	
	return true;

}

