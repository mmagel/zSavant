/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       19 Sep 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function sales_order_before_load(type, form, request){

	var status = nlapiGetFieldValue('status');
	var wo_id = nlapiGetFieldValue('custbody_aw_work_order');
		
	if(type == 'view' && (status != 'Pending Approval')){
		
		form.setScript('customscript_sdm_so_button_functions');
		
		
		form.addButton('custpage_sdm_create_case', 'Report Incident', 'create_incident()');
		
		
		if(wo_id == null || wo_id.length < 1){
			
			form.addButton('custpage_sdm_create_wo', 'Create Work Order', 'create_wo()');
			
			
		} else {
			//If update work order needed, insert here.
			
		}
				
	}
	if (type=='view'||type=='edit'){
		
		var tran=nlapiGetFieldValue('tranid');
		nlapiLogExecution('ERROR','so',tran.substring(1,tran.length));
		var bills=nlapiSearchRecord('transaction','customsearch726',
				[new nlobjSearchFilter('custcolaw_sales_order_cl',null,'equalto',tran.substring(1,tran.length)),
		                                                             new nlobjSearchFilter('type',null,'anyof',['VendBill','VendCred','Check']),new nlobjSearchFilter('mainline',null,'is','F')]);
		if (bills!=null){
			var columns;
			var sublist=form.addSubList('custpage_bills','staticlist','Vendor Bills','accntingtab');
			sublist.addField('custpage_vbtype','text','Type');
			sublist.addField('custpage_vbmln','text','Main Line Name');
			sublist.addField('custpage_vbdate','date','Date');
			sublist.addField('custpage_vbamount','currency','Amount');
			sublist.addField('custpage_vbmemo','text','Memo');
			
			for (var i=0;i<bills.length; i++){
				columns=bills[i].getAllColumns();
				sublist.setLineItemValue('custpage_vbtype',i+1,bills[i].getText(columns[0]));
				sublist.setLineItemValue('custpage_vbmln',i+1,bills[i].getText(columns[1]));
				sublist.setLineItemValue('custpage_vbdate',i+1,bills[i].getValue(columns[2]));
				sublist.setLineItemValue('custpage_vbamount',i+1,bills[i].getValue(columns[3]));
				sublist.setLineItemValue('custpage_vbmemo',i+1,bills[i].getValue(columns[4]));
			}
		}
		
		var journals=nlapiSearchRecord('transaction','customsearch725',[new nlobjSearchFilter('custcol_aw_je_so',null,'anyof',nlapiGetRecordId())]);
		if (journals!=null){
			nlapiLogExecution('ERROR','asdf',journals.length);
			var columns;
			var sublist1=form.addSubList('custpage_journals','staticlist','Journals','accntingtab');
			sublist1.addField('custpage_jdate','date','Date');
			sublist1.addField('custpage_jnum','text','Transaction Number');
			sublist1.addField('custpage_deb','currency','Debits');
			sublist1.addField('custpage_cred','currency','Credits');
			sublist1.addField('custpage_jmem','text','Memo');
			sublist1.addField('custpage_jso','select','Sales Order','transaction').setDisplayType('inline');
			
			for (var i=0;i<journals.length; i++){
				columns=journals[i].getAllColumns();
				sublist1.setLineItemValue('custpage_jdate',i+1,journals[i].getValue(columns[0]));
				sublist1.setLineItemValue('custpage_jnum',i+1,journals[i].getValue(columns[1]));
				sublist1.setLineItemValue('custpage_deb',i+1,journals[i].getValue(columns[2]));
				sublist1.setLineItemValue('custpage_cred',i+1,journals[i].getValue(columns[3]));
				sublist1.setLineItemValue('custpage_jmem',i+1,journals[i].getValue(columns[4]));
				sublist1.setLineItemValue('custpage_jso',i+1,journals[i].getValue(columns[5]));
			}
		}
	}
}


function est_hours (type){
	if (type=='xedit')
return;
	var item_count = nlapiGetLineItemCount('item');
	var total = 0;
	
	for (var x = 1; x <= item_count; x++){
		est_hour = nlapiGetLineItemValue('item', 'custcol_aw_hr_per_tree', x);
		qty = nlapiGetLineItemValue('item', 'quantity', x);
		
			if(isEmpty(est_hour)){
				est_hour = 0;
			}
			
			if(isEmpty(qty)){
				qty = 0;
			}
			
		line_hours = est_hour * qty;
		
		total += line_hours;
				
	}
	
	nlapiSetFieldValue('custbody_sdm_estimated_hours', total);
if (type=='create'||type=='edit'){
var filters=new Array();
var date=nlapiGetFieldValue('trandate');
filters.push(new nlobjSearchFilter('custbody_aw_property',null,'is',nlapiGetFieldValue('custbody_aw_property')));
filters.push(new nlobjSearchFilter('trandate',null,'before',date));
//filters.push(new nlobjSearchFilter('internalid',null,'noneof',id));
var columns=new Array();
columns.push(new nlobjSearchColumn('internalid'));
var results=nlapiSearchRecord('salesorder',null,filters,columns);
if (results==null||results.length==0){
	nlapiSetFieldValue('custbody_biz_type',1);
}
else {
	nlapiSetFieldValue('custbody_biz_type',2);
}
}
}

function isEmpty(stValue) {
	//used to identify blank fields
		if ((stValue == '') || (stValue == null) ||(stValue == undefined))
	    {
	    return true;
	    }
	    return false;
}
