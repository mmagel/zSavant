/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       19 Sep 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord salesorder
 *   
 */

function create_wo(){
 	
	var so_id = nlapiGetRecordId();
	var so_record = nlapiLoadRecord('salesorder', so_id);
	
	// variables to add to wo
	var date = so_record.getFieldValue('trandate');
	var client = so_record.getFieldValue('entity');
	var rep = so_record.getFieldValue('salesrep');
	var property = so_record.getFieldValue('custbody_aw_property');
	
	new_wo = nlapiCreateRecord('customrecord_aw_work_order');
		new_wo.setFieldValue('custrecord_aw_wo_date', date);
		new_wo.setFieldValue('custrecord_aw_wo_client', client);
		new_wo.setFieldValue('custrecord_aw_wo_sales_rep', rep);
		new_wo.setFieldValue('custrecord_aw_wo_property', property);
		new_wo.setFieldValue('custrecord_aw_wo_so', so_id);
		//set additional fields on the WO
		
	var wo_id = nlapiSubmitRecord(new_wo); //returns ID	
		
		//Set any fields on SO
	so_record.setFieldValue('custbody_aw_work_order', wo_id);
	nlapiSubmitRecord(so_record); //Submit the so to update work order number
	
		//Reload record
	location.reload();			
}

function update_wo(){
 	
	// if update WO function needed, insert here
	
}

function create_incident(){
try {
	var user = nlapiGetUser();
	
	var safety_person = 3; //Set to alison, Update
	
	var so_id = nlapiGetRecordId();

	//new_case = nlapiCreateRecord('supportcase');
	//new_case.setFieldValue('title', 'Report Incident');
	//new_case.setFieldValue('company', user);
	//new_case.setFieldValue('assigned', safety_person);
	//new_case.setFieldValue('custevent_aw_created_from', so_id);
	//new_case.setFieldValue('emailform', 'F');

	//var case_id = nlapiSubmitRecord(new_case,false,true);
	
	var args='?title=New Incident&company='+user+'&assigned='+safety_person+'&custevent_aw_created_from='+so_id+'&emailform=F&so=T';
	url = nlapiResolveURL('RECORD', 'supportcase', null);

	document.location=url+args;
}
catch(e){
	
	alert(e.message);
}
}
