/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       27 Aug 2014     AHalbleib
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function record_before_load(type, form, request){
        if (type=='create'&&nlapiGetContext().getExecutionContext()!='webservices'&&request!=undefined&&request.getParameter('cf')!=43){
                 nlapiSetRedirectURL('RECORD','timebill',null,null,{cf:'43'});
         }
	if (type!='create'&&type!='delete'){
		var filters=new Array();
		nlapiLogExecution('ERROR','asdf',nlapiGetRecordId());
		
		filters.push(new nlobjSearchFilter('custrecord_sdm_rec_id',null,'is',nlapiGetRecordId()));
		filters.push(new nlobjSearchFilter('custrecord_sdm_rec_type',null,'is',nlapiGetRecordType()));
		var columns=new Array();
		columns.push(new nlobjSearchColumn('internalid'));
		columns[0].setSort(true);
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_date'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_set_by'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_type'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_context'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_field'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_old'));
		columns.push(new nlobjSearchColumn('custrecord_sdm_cust_sys_new'));
		var results=nlapiSearchRecord('customrecord_sdm_cust_sys',null,filters,columns);
		//form.addTab('custpage_notestab','System Information');
		var sl=form.addSubList('custpage_noteslist','list','System Notes');
		sl.addField('custpage_date','datetimetz','Date').setDisplayType('inline');
		sl.addField('custpage_employee','text','Set By').setDisplayType('inline');
		sl.addField('custpage_type','text','Type').setDisplayType('inline');
		sl.addField('custpage_field','text','Field').setDisplayType('inline');
		sl.addField('custpage_old_val','text','Old Value').setDisplayType('inline');
		sl.addField('custpage_new_val','text','New Value').setDisplayType('inline');
		sl.addField('custpage_context','text','Execution Context').setDisplayType('inline');
		for (var i=0; results!=null&&i<results.length; i++){
			sl.setLineItemValue('custpage_date',i+1,results[i].getValue('custrecord_sdm_cust_sys_date'));
			sl.setLineItemValue('custpage_employee',i+1,results[i].getText('custrecord_sdm_cust_sys_set_by'));
			sl.setLineItemValue('custpage_type',i+1,results[i].getValue('custrecord_sdm_cust_sys_type'));
			sl.setLineItemValue('custpage_field',i+1,results[i].getValue('custrecord_sdm_cust_sys_field'));
			sl.setLineItemValue('custpage_old_val',i+1,results[i].getValue('custrecord_sdm_cust_sys_old'));
			sl.setLineItemValue('custpage_new_val',i+1,results[i].getValue('custrecord_sdm_cust_sys_new'));
			sl.setLineItemValue('custpage_context',i+1,results[i].getValue('custrecord_sdm_cust_sys_context'));
		}
	}
}


function record_before_submit(type){
 if (type=='delete'&&nlapiGetRecordType()=='timebill'){
	 var recid=nlapiGetRecordId();
	 var csn=nlapiSearchRecord('customrecord_sdm_cust_sys',null,[new nlobjSearchFilter('custrecord_sdm_rec_id',null,'is',recid),new nlobjSearchFilter('custrecord_sdm_cust_sys_type',null,'is','Create')],new nlobjSearchColumn('internalid'));
	 if (csn!=null){
		 nlapiSubmitField('customrecord_sdm_cust_sys',csn[0].getValue('internalid'),'custrecord_time_link','')
	 }
 }
}

function record_after_submit(type){
	//nlapiLogExecution('ERROR','edasdf','asdfasdf');
	if (type=='edit'||type=='xedit'){
		var rec_id = nlapiGetRecordId();
		var user_id = nlapiGetUser();
		var context = nlapiGetContext().getExecutionContext();
		var rec_type = nlapiGetRecordType();
		var new_rec=nlapiGetNewRecord();
		var old_rec = nlapiGetOldRecord();
		var all_fields = old_rec.getAllFields(); //normal keyed array
		for (var i = 0; all_fields != null && i < all_fields.length; i++){	
			var old_val=old_rec.getFieldText(all_fields[i]);
			if (old_val==null){
				old_val=old_rec.getFieldValue(all_fields[i]);
			}
			
			var new_val=new_rec.getFieldText(all_fields[i]);
			if (new_val==null){
				new_val=new_rec.getFieldValue(all_fields[i]);
			}
			var name='';
			if (new_rec.getField(all_fields[i])!=null){
				 name=nlapiGetField(all_fields[i]).getLabel();
			}
			if (old_val!=new_val&&name.length>0&&new_val!=null&&name!='Email Login Key'&&((new_val.length>0) || (old_val!=null && old_val.length>0))){
				nlapiLogExecution('ERROR','new val',new_val+' '+all_fields[i]);
				var notes=nlapiCreateRecord('customrecord_sdm_cust_sys');
				notes.setFieldValue('custrecord_sdm_rec_id',rec_id);
				notes.setFieldValue('custrecord_sdm_rec_type',rec_type);
				if (old_val!=null && old_val.length>0){
					notes.setFieldValue('custrecord_sdm_cust_sys_type','Change');
				}
				else {
					notes.setFieldValue('custrecord_sdm_cust_sys_type','Set');
				}
				var string=nlapiDateToString(new Date(),'datetime');
				string=string.replace(" pm",":00 pm");
				string=string.replace(" am",":00 am");
				notes.setFieldValue('custrecord_sdm_cust_sys_date',string);
				if (user_id==-4){
					user_id=11947;
				}
				notes.setFieldValue('custrecord_sdm_cust_sys_set_by',user_id);
				notes.setFieldValue('custrecord_sdm_cust_sys_context',context);
				
				notes.setFieldValue('custrecord_sdm_cust_sys_field',name);
				notes.setFieldValue('custrecord_sdm_cust_sys_old',old_val);
				notes.setFieldValue('custrecord_sdm_cust_sys_new',new_val);
				nlapiSubmitRecord(notes);
			}
		}
	}
	if (type=='create'){
		var rec_id = nlapiGetRecordId();
		var user_id = nlapiGetUser();
		var context = nlapiGetContext().getExecutionContext();
		var rec_type = nlapiGetRecordType();
		var record=nlapiLoadRecord(rec_type,rec_id);
		var all_fields=record.getAllFields();
		var notes=nlapiCreateRecord('customrecord_sdm_cust_sys');
		notes.setFieldValue('custrecord_sdm_rec_id',rec_id);
		notes.setFieldValue('custrecord_sdm_rec_type',rec_type);
		notes.setFieldValue('custrecord_sdm_cust_sys_type','Create');
		if (rec_type=='timebill'){
			notes.setFieldValue('custrecord_time_link',rec_id)
		}
		var string=nlapiDateToString(new Date(),'datetime');
		string=string.replace(" pm",":00 pm");
		string=string.replace(" am",":00 am");
		notes.setFieldValue('custrecord_sdm_cust_sys_date',string);
		notes.setFieldValue('custrecord_sdm_cust_sys_set_by',user_id);
		notes.setFieldValue('custrecord_sdm_cust_sys_context',context);
		notes.setFieldValue('custrecord_sdm_cust_sys_field','Record');
		notes.setFieldValue('custrecord_sdm_cust_sys_new',rec_id);
		nlapiSubmitRecord(notes);
		//nlapiLogExecution('ERROR','here',1);
		//nlapiLogExecution('ERROR','number of fields',all_fields.length);
		for (var i = 0; all_fields != null && i < all_fields.length; i++){	
			var new_val=nlapiGetFieldText(all_fields[i]);
			if (new_val==null){
				new_val=nlapiGetFieldValue(all_fields[i]);
			}
			var name='';
			if (nlapiGetField(all_fields[i])!=null){
				 name=nlapiGetField(all_fields[i]).getLabel();
			}
			if (new_val!=null&&new_val.length>0&&name.length>0 && name!='Email Login Key'){
				var notes=nlapiCreateRecord('customrecord_sdm_cust_sys');
				notes.setFieldValue('custrecord_sdm_rec_id',rec_id);
				notes.setFieldValue('custrecord_sdm_rec_type',rec_type);
				notes.setFieldValue('custrecord_sdm_cust_sys_type','Set');
				var string=nlapiDateToString(new Date(),'datetime');
				string=string.replace(" pm",":00 pm");
				string=string.replace(" am",":00 am");
				notes.setFieldValue('custrecord_sdm_cust_sys_date',string);
				notes.setFieldValue('custrecord_sdm_cust_sys_set_by',user_id);
				notes.setFieldValue('custrecord_sdm_cust_sys_context',context);
				
				notes.setFieldValue('custrecord_sdm_cust_sys_field',name);
				notes.setFieldValue('custrecord_sdm_cust_sys_new',new_val);
				nlapiSubmitRecord(notes);
			}
		}
	}
	if (type=='delete'){
		var rec_id = nlapiGetRecordId();
		var user_id = nlapiGetUser();
		var context = nlapiGetContext().getExecutionContext();
		var rec_type = nlapiGetRecordType();
		var notes=nlapiCreateRecord('customrecord_sdm_cust_sys');
		notes.setFieldValue('custrecord_sdm_rec_id',rec_id);
		notes.setFieldValue('custrecord_sdm_rec_type',rec_type);
		notes.setFieldValue('custrecord_sdm_cust_sys_type','Delete');
		var string=nlapiDateToString(new Date(),'datetime');
		string=string.replace(" pm",":00 pm");
		string=string.replace(" am",":00 am");
		notes.setFieldValue('custrecord_sdm_cust_sys_date',string);
		notes.setFieldValue('custrecord_sdm_cust_sys_set_by',user_id);
		notes.setFieldValue('custrecord_sdm_cust_sys_context',context);
		notes.setFieldValue('custrecord_sdm_cust_sys_field','Record');
		notes.setFieldValue('custrecord_sdm_cust_sys_old',rec_id);
		nlapiSubmitRecord(notes);
	}
}
