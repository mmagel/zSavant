/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       05 Dec 2013     cblaisure
 *
 * * This script works when a time record is saved, the following actions occur:
 *	1) Correcting for Novatime upload region limitation
 *	2) Setting labor cost on the work order
 *
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord timebill
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */
function on_time_save(type){

	if(type != 'delete'){
	var employ = nlapiGetFieldValue('employee');
	
	//set correct region, upload limitation
	var region = nlapiLookupField('employee', employ, 'location');
	nlapiSetFieldValue('location', region);
	
	//get employee cost
	var wage = Number(nlapiLookupField('employee', employ, 'custentity_aw_employee_wage_rate'));
		if(wage == null){ var wage = 0;}
	var burden = Number(nlapiLookupField('employee', employ, 'custentity_aw_burdended_per_hour'));
		if(burden == null){ var burden = 0;}
	//get time entry
	var standard = nlapiGetFieldValue('custcol_aw_time_hours_standard');
		if(standard == null){ var standard = 0;}
	var overtime = nlapiGetFieldValue('custcol_aw_time_hours_overtime');
		if(overtime == null){ var overtime = 0;}
	var double = nlapiGetFieldValue('custcol_aw_time_hours_double_overtime');
		if(double == null){ var double = 0;}
		
		standard=convert(standard);
		overtime=convert(overtime);
		double=convert(double);
		
	var total = (standard + overtime + double);
	
	//Calculate Cost & set Field	
	//var labor_cost = ((standard * wage) + (overtime * wage * 1.5) + (double * wage * 2) + (total * burden));
	
	var labor_cost = ((standard * wage) + ((overtime * wage) * 1.5) + ((double * wage) * 2) + (total * burden));

	nlapiSetFieldValue('custcol_aw_time_labor_cost', labor_cost);
	
	}
}
function convert(standard){
	standard=String(standard);
	standard=standard.split('.');
	var search_hours=0;
	var search_min=0;
	if(standard[0]!=undefined && standard[0]!='')
		var search_hours=parseInt(standard[0])*60;
	if(standard[1]!=undefined && standard[1]!='')
		var search_min=parseInt(standard[1]);
	var min=search_hours+search_min;
	standard=min/60;
	nlapiLogExecution('ERROR','standard',standard)
	return standard;
}