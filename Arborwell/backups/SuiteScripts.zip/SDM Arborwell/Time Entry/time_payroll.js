function time_create_edit_children(type){
	if ((type=='create'||type=='edit')&&nlapiGetFieldValue('employee')==14282){
		var parent=nlapiGetFieldValue('custcol_pte');
		if(parent==null||parent==''||typeof parent=='undefined'){
			var st=nlapiLookupField('timebill',nlapiGetRecordId(),'custcol_aw_time_hours_standard');
			var ot=nlapiLookupField('timebill',nlapiGetRecordId(),'custcol_aw_time_hours_overtime');
			var dot=nlapiLookupField('timebill',nlapiGetRecordId(),'custcol_aw_time_hours_double_overtime');
			var stit;
			var otit;
			var dotit;
			var sten=-1;
			var doten=-1;
			var oten=-1;
			st=parseFloat(st);
			ot=parseFloat(ot);
			dot=parseFloat(dot);
			var employee=nlapiGetFieldValue('employee');
			if (typeof dot=='number' && !isNaN(dot) && typeof ot=='number' && !isNaN(ot) && typeof st=='number'&&!isNaN(st) ){
				//,new nlobjSearchFilter('employee',null,'anyof',employee)
				//var items=nlapiSearchRecord(null,'customsearch_at_emp_pi_search');
				//var search=nlapiLoadSearch(null,'customsearch_at_emp_pi_search');
				//var filts=search.getFilters();
				//for (var i=0;i<filts.length;i++){
				//	nlapiLogExecution('ERROR',i,filts[i].getName()+' '+filts[i].getJoin());
				//}
				//return;
				//var cols;
				//if (items!=null)
				//	cols=items[0].getAllColumns();
				
				var emp=nlapiLoadRecord('employee',employee);
				var items=emp.getLineItemCount('earning');
				
				for (var i=1; i<=items; i++){
					var pid=emp.getLineItemValue('earning','payrollitem',i);
					var item=nlapiLoadRecord('payrollitem',pid);
					var multiplier=item.getFieldValue('derivedratemultiplier');
					if (multiplier==2){
						dotit=pid;
					}
					else if(multiplier==1.5) {
						otit=pid;
					}
					else if (multiplier==''||multiplier==null) {
						stit=pid;
					}
				}
				var existing=nlapiSearchRecord('timebill',null,new nlobjSearchFilter('custcol_pte',null,'anyof',nlapiGetRecordId()),
				[new nlobjSearchColumn('internalid'), new nlobjSearchColumn('payitem'),new nlobjSearchColumn('durationdecimal')]);
				for (var i=0;existing!=null&&i<existing.length; i++){
					var payit=existing[i].getValue('payitem');
					if (payit==stit&&st>0){
						sten=existing[i].getValue('internalid');
					}
					else if (payit==otit&&ot>0){
						oten=existing[i].getValue('internalid');
					}
					else if (payit==dotit&&dot>0){
						doten=existing[i].getValue('internalid');
					}
					else {
						var tefields=nlapiLookupField('timebill',nlapiGetRecordId(),['custcol_st_te','custcol_ot_te','custcol_dot_te']);
						var entid=existing[i].getValue('internalid');
						if (entid==tefields.custcol_st_te){
							nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_st_te','')
						}
						if (entid==tefields.custcol_ot_te){
							nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_ot_te','')
						}
						if (entid==tefields.custcol_dot_te){
							nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_dot_te','')
						}
						nlapiDeleteRecord('timebill',entid);
					}
				}
				nlapiLogExecution('ERROR',st,stit+' '+sten);
				nlapiLogExecution('ERROR',ot,otit+' '+oten);
				nlapiLogExecution('ERROR',dot,dotit+' '+doten);
				nlapiLogExecution('ERROR',st,convert_hm(st));
				if (st>0){
					if (sten>-1){
						sten=nlapiLoadRecord('timebill',sten);
					}
					else {
						sten=nlapiCreateRecord('timebill');		
					}
					sten.setFieldValue('hours',st);
					sten.setFieldValue('employee',employee);
					sten.setFieldValue('trandate',nlapiGetFieldValue('trandate'));
					sten.setFieldValue('payrollitem',stit);
					sten.setFieldValue('location',nlapiGetFieldValue('location'));
					sten.setFieldValue('custcol_pte',nlapiGetRecordId());
					var id=nlapiSubmitRecord(sten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_st_te',id);
				}
				if (ot>0){
					if (oten>-1){
						oten=nlapiLoadRecord('timebill',oten);						
					}
					else {
						oten=nlapiCreateRecord('timebill');					
					}
					oten.setFieldValue('hours',ot);
					oten.setFieldValue('employee',employee);
					oten.setFieldValue('trandate',nlapiGetFieldValue('trandate'));
					oten.setFieldValue('payrollitem',otit);
					oten.setFieldValue('location',nlapiGetFieldValue('location'));
					oten.setFieldValue('custcol_pte',nlapiGetRecordId());
					var id=nlapiSubmitRecord(oten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_ot_te',id);
				}
				if (dot>0){
					if (doten>-1){
						doten=nlapiLoadRecord('timebill',doten);					
					}
					else {
						doten=nlapiCreateRecord('timebill');
					}
					doten.setFieldValue('hours',dot);
					doten.setFieldValue('employee',employee);
					doten.setFieldValue('trandate',nlapiGetFieldValue('trandate'));
					doten.setFieldValue('location',nlapiGetFieldValue('location'));
					doten.setFieldValue('payrollitem',dotit);
					doten.setFieldValue('custcol_pte',nlapiGetRecordId());
					
					var id=nlapiSubmitRecord(doten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_dot_te',id);
				}
			}
		}
	}
	
}
function te_cleanup_child_entries(type){
	if (type=='delete'){
				var entries=nlapiLookupField('timebill',nlapiGetRecordId(),['custcol_st_te','custcol_ot_te','custcol_dot_te','custcol_pto_entry','custcol_holiday_entry']);
     // nlapiSetFieldValue('custcol_aw_time_work_order',75754);
      try {
				nlapiSubmitField('timebill',nlapiGetRecordId(),['custcol_st_te','custcol_ot_te','custcol_dot_te','custcol_pto_entry','custcol_holiday_entry','custcol_aw_time_work_order'],['','','','','',75754])
      }
      catch(e){
        nlapiLogExecution('ERROR','e',e.message);
      }

					try {
						nlapiDeleteRecord('timebill',entries.custcol_st_te);
					}
					catch(e){
						nlapiLogExecution('ERROR','error st',e.message);
					}
					try {
						nlapiDeleteRecord('timebill',entries.custcol_ot_te);
					}
					catch(e){
						nlapiLogExecution('ERROR','error ot',e.message);
					}
					try {
						nlapiDeleteRecord('timebill',entries.custcol_dot_te);
					}
					catch(e){
						nlapiLogExecution('ERROR','error dot',e.message);
					}
     				 try {
						nlapiDeleteRecord('timebill',entries.custcol_holiday_entry);
					}
					catch(e){
						nlapiLogExecution('ERROR','error hol',e.message);
					}
					try {
						nlapiDeleteRecord('timebill',entries.custcol_pto_entry);
					}
					catch(e){
						nlapiLogExecution('ERROR','error pto',e.message);
					}
     var filterExpr2  = [ 
                              ['custcol_st_te', 'anyof', nlapiGetRecordId()],
                              'OR' ,
                              ['custcol_ot_te', 'anyof', nlapiGetRecordId()],
       'OR' ,
                              ['custcol_dot_te', 'anyof', nlapiGetRecordId()],
     'OR' ,
                              ['custcol_pto_entry', 'anyof', nlapiGetRecordId()],
     'OR' ,
                              ['custcol_holiday_entry', 'anyof', nlapiGetRecordId()]
];
			var bills=	nlapiSearchRecord('timebill',null,filterExpr2,[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('custcol_st_te'),new nlobjSearchColumn('custcol_ot_te')
                                                                                                                                                           ,new nlobjSearchColumn('custcol_dot_te')
                                                                                                                                                           ,new nlobjSearchColumn('custcol_pto_entry')
                                                                                                                                                           ,new nlobjSearchColumn('custcol_holiday_entry')]);
      // 'custcol_st_te','custcol_ot_te','custcol_dot_te','custcol_pto_entry','custcol_holiday_entry'
       for (var i=0;bills!=null&&i<bills.length;i++){
		   
         var id=bills[i].getValue('internalid');
         var arr1=new Array();
         var arr2=new Array();
         if (bills[i].getValue('custcol_st_te')!=''&&bills[i].getValue('custcol_st_te')!=null){
           arr1.push('custcol_st_te');
           arr2.push('');
         }
         if (bills[i].getValue('custcol_ot_te')!=''&&bills[i].getValue('custcol_ot_te')!=null){
           arr1.push('custcol_ot_te');
           arr2.push('');
         }
         if (bills[i].getValue('custcol_dot_te')!=''&&bills[i].getValue('custcol_dot_te')!=null){
           arr1.push('custcol_dot_te');
           arr2.push('');
         }
         if (bills[i].getValue('custcol_pto_entry')!=''&&bills[i].getValue('custcol_pto_entry')!=null){
           arr1.push('custcol_pto_entry');
           arr2.push('');
         }
        if (bills[i].getValue('custcol_holiday_entry')!=''&&bills[i].getValue('custcol_holiday_entry')!=null){
           arr1.push('custcol_holiday_entry');
           arr2.push('');
         }
		 nlapiLogExecution('ERROR',i,id+' '+arr1+' '+arr2);
         if (arr1.length>0){
           nlapiSubmitField('timebill',id,arr1,arr2);
         }
       }
	   var notes=nlapiSearchRecord('customrecord_sdm_cust_sys',null,
	   new nlobjSearchFilter('custrecord_time_link',null,'anyof',nlapiGetRecordId()),
	   new nlobjSearchColumn('internalid'));
	   for (var i=0; notes!=null&&i<notes.length;i++){
		   nlapiDeleteRecord('customrecord_sdm_cust_sys',notes[i].getValue('internalid'));
	   }
	}
}
//pull so amount to deposit
//subtotal amount on item receipt
function convert_to_minutes(hours){
	//nlapiLogExecution('ERROR','time',nlapiGetRecordId()+' '+hours)
	
	var arr_hour=hours.split(':');
	if(arr_hour[0]!=undefined && arr_hour[0]!='')
		var ho=parseInt(arr_hour[0]);
	if(arr_hour[1]!=undefined && arr_hour[1]!=''&&arr_hour[1]!='00'){
		var min=parseInt(arr_hour[1].replace(/\b0+/g, ''));
	}
	else {
		min=parseInt('0');
	}
	//nlapiLogExecution('ERROR','asdf',nlapiGetRecordId()+' '+ho+' '+arr_hour[1]);
	hours=parseInt(ho)*60+parseInt(min);
	return hours;
}
function convert_hm(hours,blank){
	if (blank==null){
		blank=true;
	}
	hours=hours*60;
	var ho_=hours/60;
	var min_=hours%60;
	ho_=parseInt(ho_);
	min_=parseInt(min_);
	hours=parseInt(ho_);
	if(min_<=9)
	{
		min_="0"+min_;
	}
	//hours=hours+parseFloat(min_/60);
	hours=hours+":"+min_;
	//hours=parseFloat(hours);
	//hours=hours.toFixed(2);
	if (hours=='0:00'&&blank){
		return '';
	}
	return hours;
}