function timesheet_before_load(type,form,request){
	if (type=='create'){
		var date=nlapiDateToString(new Date());
		nlapiSetFieldValue('custcol_timbill_start_date',date);
		nlapiSetFieldValue('custcol_time_bill_end_date',date);
	}
	
	if (type=='edit'||type=='xedit'){
		var pi=nlapiGetFieldValue('payrollitem');
		if (pi!=null&&pi!=''){
		try {
			form.getField('custcol_timbill_start_date').setMandatory(false);
			
			form.getField('custcol_time_bill_end_date').setMandatory(false);
			
			form.getField('custcol_time_bill_start_time').setMandatory(false);
			form.getField('custcol_time_bill_end_time').setMandatory(false);
			form.getField('custcol_aw_time_work_order').setMandatory(false).setDisplayType('hidden');
          //.
         // form.getField('custcol_aw_time_work_order');
		}
		catch(e){
			nlapiLogExecution('ERROR','beforeload',e.message);
		}
		}
	}
}
function uncheck_lba(recType,recId){
	var rec=nlapiLoadRecord(recType,recId);
	nlapiSubmitRecord(rec);
}
function mass_update(recType,recId){
	var result=nlapiSearchRecord('customrecord_sdm_cust_sys',null,[new nlobjSearchFilter('custrecord_sdm_rec_id',null,'is',recId),new nlobjSearchFilter('custrecord_sdm_cust_sys_type',null,'is','Create')],new nlobjSearchColumn('custrecord_sdm_cust_sys_context'));
	
	if (result!=null){
		var rec=nlapiLoadRecord(recType,recId);
		rec.setFieldValue('custcol_source',result[0].getValue('custrecord_sdm_cust_sys_context'));
		nlapiSubmitRecord(rec,false,true);
	}
else {
var rec=nlapiLoadRecord(recType,recId);
		rec.setFieldValue('custcol_source','csvimport');
		nlapiSubmitRecord(rec,false,true);
}
}
function timesheet_before_submit(type){
        if (type=='create'){
            nlapiSetFieldValue('custcol_source',nlapiGetContext().getExecutionContext());
        }
        if ((type=='create'||type=='edit')){
		
		nlapiSetFieldValue('custcol_timbill_start_date',nlapiGetFieldValue('trandate'));
		nlapiSetFieldValue('custcol_time_bill_end_date',nlapiGetFieldValue('trandate'));
		var employee=nlapiGetFieldValue('custcol_temp_app_employee');
		if (employee!=null&&employee.length!=0){
			nlapiSetFieldValue('custcol_emp_name',nlapiLookupField('employee',employee,'entityid'));
		}
	}
	if (type=='edit'&&nlapiGetFieldValue('custcol_source')!='csvimport'){
		var employee=nlapiGetFieldValue('custcol_temp_app_employee');
		if (employee!=''&&employee!=null&&employee!=0){
			nlapiSetFieldValue('employee',employee);
			nlapiSetFieldValue('custcol_temp_app_employee',0);
		}
		else {
			employee=nlapiGetFieldValue('employee');
		}
		var region=nlapiLookupField('employee',employee,'location');
		var region2=nlapiLookupField('employee',employee,'location',true);
		nlapiLogExecution('ERROR',region,region2);
		nlapiSetFieldValue('location',region);
		var end_time=nlapiGetFieldValue('custcol_time_bill_end_time');
		var start_time=nlapiGetFieldValue('custcol_time_bill_start_time');
		if(end_time!='' && start_time!=''){
			
			var hours=convert_to_minutes(nlapiGetFieldValue('hours'));
			var durations=nlapiSearchRecord('timebill','customsearch_time_no_payroll_item',
					[new nlobjSearchFilter('date',null,'on',nlapiGetFieldValue('trandate')),new nlobjSearchFilter('custcol_time_bill_start_time',null,'isnotempty'),new nlobjSearchFilter('custcol_time_bill_end_time',null,'isnotempty'),
			         new nlobjSearchFilter('internalid',null,'noneof',nlapiGetRecordId()),
			         new nlobjSearchFilter('employee',null,'anyof',nlapiGetFieldValue('employee'))],[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('durationdecimal'),new nlobjSearchColumn('custcol_lba')]);
			var lunch_applied=false;
			if (nlapiGetFieldValue('custcol_lba')=='T'){
				lunch_applied=true;
			}
			var total_minutes=parseFloat(0);
			total_minutes+=parseFloat(hours);
			var index=-1;
			var indexval=-1;
			var app_index=-1;
			var appval=-1;
			var rules =nlapiSearchRecord('customrecord_labor_rules','customsearch731',new nlobjSearchFilter('custrecord_lr_region',null,'anyof',nlapiLookupField('employee',nlapiGetFieldValue('employee'),'location')));
			var lunch_thres=0;
			var break_length=0;
			
			if (rules!=null){
				
				if (rules[0].getValue('custrecord_lr_lbdeductthreshold')!=''&&!isNaN(rules[0].getValue('custrecord_lr_lbdeductthreshold'))){
					lunch_thres=parseInt(rules[0].getValue('custrecord_lr_lbdeductthreshold')).toFixed(0);
				}
				if (rules[0].getValue('custrecord_lr_lbreq')!=''&&!isNaN(rules[0].getValue('custrecord_lr_lbrec'))){
					break_length=parseInt(rules[0].getValue('custrecord_lr_lbreq')).toFixed(0);
				}
				nlapiLogExecution('ERROR','labor rules not null',lunch_thres+' '+break_length);
			}
			else {
				nlapiLogExecution('ERROR','labor rules null','aaaa');
			}
			for (var i=0;durations!=null&&i<durations.length;i++){
				var value=parseFloat(durations[i].getValue('durationdecimal')*60).toFixed(0);
				if (value>=break_length){
					index=i;
					indexval=value;
				}
				if (durations[i].getValue('custcol_lba')=='T'){
					lunch_applied=true;
					app_index=i;
					appval=value;
				}
				total_minutes+=parseFloat(value);
			}
			//nlapiLogExecution('ERROR','minutes',total_minutes+' '+lunch_applied);
			if (lunch_thres>0&&break_length>0){
				if (total_minutes>=lunch_thres&&lunch_applied==false){
	
					if (total_minutes>=lunch_thres){
						if (hours>=break_length){
							if (hours==break_length){
								hours=0;
							}
							else {
								hours-=break_length;
							}
							nlapiSetFieldValue('hours',convert_hours(hours));
							nlapiSetFieldValue('custcol_lba','T');
						}
						else if (indexval>-1) {
							indexval-=break_length;
							var rec=nlapiLoadRecord('timebill',durations[index].getValue('internalid'));
							rec.setFieldValue('custcol_lba','T');
							rec.setFieldValue('hours',convert_hours(indexval));
							nlapiSubmitRecord(rec,false,true);
						}
					}
				}
				//unapply luch if total is less than 5.5 hours
				else if (total_minutes<(lunch_thres-break_length)&&lunch_applied==true){
					//nlapiLogExecution('ERROR','2',parseFloat(appval+30).toFixed(0));
					if (nlapiGetFieldValue('custcol_lba')=='T'){
						hours+=Number(break_length);
						nlapiSetFieldValue('hours',convert_hours(hours));
						nlapiSetFieldValue('custcol_lba','F');
					}
					else if (app_index>-1){
						appval=parseFloat(parseFloat(appval)+parseFloat(break_length)).toFixed(0);
						var rec=nlapiLoadRecord('timebill',durations[app_index].getValue('internalid'));
						rec.setFieldValue('custcol_lba','F');
						rec.setFieldValue('hours',convert_hours(appval));
						nlapiSubmitRecord(rec,false,true);
					}
				}
			}
		}
	}
	if (type=='delete'){
     // nlapiSetFieldValue('custcol_aw_time_work_order',75754)
			var children=nlapiLookupField('timebill',nlapiGetRecordId(),['custcol_holiday_entry','custcol_pto_entry','custcol_dot_te','custcol_ot_te','custcol_st_te']);
			try_delete(children,'custcol_holiday_entry');
			try_delete(children,'custcol_pto_entry');
			try_delete(children,'custcol_dot_te');
			try_delete(children,'custcol_ot_te');
			try_delete(children,'custcol_st_te');
		}
}
function mu(a,b){
	var t=nlapiLoadRecord(a,b);
	nlapiSubmitRecord(t);
}
function calculateTime(st,et)
{
	var time = st.split(' '); 
	var start = time[0].split(':');
	if (time[1]=='pm'&&start[0]!=12){
		start[0]=parseInt(start[0]);
		start[0]+=parseInt(12);
	}
	else if (time[1]=='am'&&start[0]==12){
		start[0]=0;
	}
	var time = et.split(' '); 
	var end = time[0].split(':');
	
	if (time[1]=='pm'&&end[0]!=12){
		end[0]=parseInt(end[0]);
		end[0]+=parseInt(12);
	}
	else if (time[1]=='am'&&end[0]==12){
		end[0]=0;
	}
	//alert(end[0]);
	//alert(start[0]);
	var hours=end[0]-start[0];
	//alert(hours);
	//difference in minutes
	hours*=60;
	if (end[1]=='00'){
		end[1]=0;
	}
	if (start[1]=='00'){
		start[1]=0;
	}
	hours+=parseInt(end[1].replace(/\b0+/g, ''));
	hours-=parseInt(start[1].replace(/\b0+/g, ''));
	//alert(hours);
	if (hours<0) return-1;
	
	var final_hours=Math.floor(hours/60);
	var minutes=hours%60;
	minutes=Math.round(minutes/15)*15;

	if (minutes==60){
		minutes=='00';
		//final_hours+=1;
		
	}
	return final_hours+':'+minutes;
}
//1753
function try_delete(object,field){
	var id=object[field];
	if (id!=null&&id!=''&&typeof id!='undefined'){
		nlapiSubmitField('timebill',nlapiGetRecordId(),field,'');
		nlapiDeleteRecord('timebill',id);
	}
}
function userEventAfterSubmit(type){
	
	if((type=='edit'|| type=='create'||type=='delete')){
		
		var date=nlapiGetFieldValue('trandate');
		var from=start_date(date);
		var to=end_date(date);
		
		var filters=new Array();
		var employeerec=nlapiLoadRecord('employee',nlapiGetFieldValue('employee'));
		var wage = Number(nlapiLookupField('employee', nlapiGetFieldValue('employee'), 'custentity_aw_employee_wage_rate'));
	var burden = Number(nlapiLookupField('employee', nlapiGetFieldValue('employee'), 'custentity_aw_burdended_per_hour'));
		filters.push(new nlobjSearchFilter('date',null,'within',from,to));
		filters.push(new nlobjSearchFilter('custcol_aw_time_work_order',null,'noneof',[73994,75753]));
		filters.push(new nlobjSearchFilter('employee',null,'anyof',nlapiGetFieldValue('employee')));
		filters.push(new nlobjSearchFilter('custcol_time_bill_start_time',null,'isnotempty'));
		filters.push(new nlobjSearchFilter('custcol_time_bill_end_time',null,'isnotempty'));
		var columns=new Array();
		columns.push(new nlobjSearchColumn('internalid'));
		columns.push(new nlobjSearchColumn('hours'));
		columns.push(new nlobjSearchColumn('date').setSort(false));
		columns.push(new nlobjSearchColumn('custcol_time_bill_start_time').setSort(false));
		columns.push(new nlobjSearchColumn('custcol_st_te'));
		columns.push(new nlobjSearchColumn('custcol_ot_te'));
		columns.push(new nlobjSearchColumn('custcol_dot_te'));
		columns.push(new nlobjSearchColumn('durationdecimal','custcol_st_te'));
		columns.push(new nlobjSearchColumn('durationdecimal','custcol_ot_te'));
		columns.push(new nlobjSearchColumn('durationdecimal','custcol_dot_te'));
		columns.push(new nlobjSearchColumn('location'));
		columns.push(new nlobjSearchColumn('payitem','custcol_st_te'));
		columns.push(new nlobjSearchColumn('payitem','custcol_ot_te'));
		columns.push(new nlobjSearchColumn('payitem','custcol_dot_te'));
		columns.push(new nlobjSearchColumn('custrecord4','custcol_aw_time_work_order'));
		columns.push(new nlobjSearchColumn('custcol_ow_pay_item','custcol_st_te'));
		columns.push(new nlobjSearchColumn('custcol_ow_pay_item','custcol_ot_te'));
		columns.push(new nlobjSearchColumn('custcol_ow_pay_item','custcol_dot_te'));
		columns.push(new nlobjSearchColumn('payrolldate','custcol_st_te'));
		columns.push(new nlobjSearchColumn('payrolldate','custcol_ot_te'));
		columns.push(new nlobjSearchColumn('payrolldate','custcol_dot_te'));
		var rules =nlapiSearchRecord('customrecord_labor_rules','customsearch731',new nlobjSearchFilter('custrecord_lr_region',null,'anyof',nlapiLookupField('employee',nlapiGetFieldValue('employee'),'location'))); 
		var tostringdate=nlapiDateToString(to);
      if (type!='delete')
		zero_holidays(new nlobjSearchFilter('custcol_aw_time_work_order',null,'anyof',[73994,75753]),new nlobjSearchFilter('date',null,'within',from,to),new nlobjSearchFilter('employee',null,'anyof',nlapiGetFieldValue('employee')),employeerec,tostringdate);
		var filters2=new Array();
		filters2.push(new nlobjSearchFilter('date',null,'within',from,to));
		filters2.push(new nlobjSearchFilter('custcol_aw_time_work_order',null,'noneof',[73994,75753]));
		filters2.push(new nlobjSearchFilter('employee',null,'anyof',nlapiGetFieldValue('employee')));
		filters2.push(new nlobjSearchFilter('custcol_time_bill_start_time',null,'isnotempty'));
		filters2.push(new nlobjSearchFilter('custcol_time_bill_end_time',null,'isnotempty'));
		var columns2=new Array();
		columns2.push(new nlobjSearchColumn('date',null,'group').setSort(false));
		var results2=nlapiSearchRecord('timebill','customsearch_time_no_payroll_item',filters2,columns2);
		var results=nlapiSearchRecord('timebill','customsearch_time_no_payroll_item',filters,columns);
		var days_worked=0;
		if (results2!=null){
			days_worked=results2.length;
		}
		var running=0; 
		var standard_week=0; 
		var standard_day=0;
		var ot_day=0;
		var curr_date=null;
		var date_obj=0;
		var entry_ot=0;
		var entry_st=0;
		var entry_dot=0;
		var ot_rules=get_ot_rules(rules);
		var st_pw=ot_rules[0];
		var st_pd=ot_rules[1];
		var ot_pw=ot_rules[2];
		var ot_pd=ot_rules[3];
		var has_dot=ot_rules[4];;
		var consec_days=ot_rules[5];
		var ot_after_thres=ot_rules[6];
		var rules_rec=ot_rules[7];
		var special_rules=nlapiSearchRecord('customrecord_lr_ot_hours_rule',null,new nlobjSearchFilter('custrecord_lr_par',null,'anyof',rules_rec),[new nlobjSearchColumn('custrecord_spec_ot_minutes'),new nlobjSearchColumn('custrecord_lr_dow')]);
		if (rules_rec>0){
			rules_rec=nlapiLoadRecord('customrecord_labor_rules',rules_rec);
		}
		for (var i=0; results!=null&&i<results.length; i++){
			if (curr_date==null||(curr_date.getDate()!=new Date(results[i].getValue('date')).getDate())){
				curr_date=new Date(results[i].getValue('date'));
				standard_day=0;
				ot_day=0;
			}
			var paydatest=results[i].getValue('payrolldate','custcol_st_te');
			var paydateot=results[i].getValue('payrolldate','custcol_ot_te');
			var paydatedot=results[i].getValue('payrolldate','custcol_dot_te');
			entry_ot=0;
			entry_st=0;
			entry_dot=0;
			//thres=distance between standard day and 8 or time val, whichevers less. 
			var thres;
			var time_val=results[i].getValue('hours');
			time_val=convert_to_minutes(time_val);
			var dist_to_40=st_pw-standard_week;
			
			if (standard_day+time_val>=st_pd&&st_pd>0){
				thres=st_pd-standard_day;
			}
			else {
				thres=time_val;
			}
	
			//nlapiLogExecution('ERROR','vals',i+' '+results[i].getValue('internalid')+' '+time_val+' '+standard_week+' '+standard_day+' '+thres);
			var day=curr_date.getDay();
			
			if (standard_week>=st_pw||(curr_date.getDay()==0&&days_worked>=consec_days&&consec_days>0)){

				vals=over_40(time_val,ot_day,day,rules_rec,ot_after_thres,has_dot,special_rules,standard_day);
				entry_ot=vals[0];
				entry_dot=vals[1];
			}
			//dont need to take weekly total of st time into account
			else if (thres<=dist_to_40){

				vals=under_40(time_val,ot_day,day,standard_day,st_pd,ot_pd,has_dot,special_rules,results[i].getValue('date'),nlapiGetFieldText('employee'));
				entry_ot=vals[1];
				entry_dot=vals[2];
				entry_st=vals[0];
			}
			//need to take weekly ot rules into account 
			//standard week+time>=40
			else {
				//nlapiLogExecution('ERROR','vals',results[i].getValue('internalid')+' '+time_val+' '+standard_week+' '+standard_day+' '+thres);
				vals=threshold(time_val,ot_day,day,standard_day,thres,st_pw-standard_week,rules_rec,ot_after_thres,has_dot,special_rules);
				entry_st=vals[0];
				entry_ot=vals[1];
				entry_dot=vals[2];
			}
			var labor_cost=get_labor_cost(nlapiGetFieldValue('employee'),entry_st/60,entry_ot/60,entry_dot/60,wage,burden);
			try {
				nlapiSubmitField('timebill',results[i].getValue('internalid'),['custcol_aw_time_hours_standard','custcol_aw_time_hours_overtime','custcol_aw_time_hours_double_overtime','custcol_aw_time_labor_cost','custcol_hours_st_rounded','custcol_hours_ot_rounded','custcol_hours_dot_rounded'],[parseFloat(entry_st/60).toFixed(10),parseFloat(entry_ot/60).toFixed(10),parseFloat(entry_dot/60).toFixed(10),labor_cost,parseFloat(entry_st/60).toFixed(2),parseFloat(entry_ot/60).toFixed(2),parseFloat(entry_dot/60).toFixed(2)]);
			}
			catch(e){
				nlapiLogExecution('ERROR','error',e.message);
			}
			
			//nlapiLogExecution('ERROR','to and paydate',tostringdate+' '+paydatest+' '+paydatedot+' '+paydateot);
			
		if (new Date(tostringdate)>new Date('12/25/2016')&&isempty(paydatest)&&isempty(paydateot)&&isempty(paydatedot)){
				//nlapiLogExecution('ERROR','test','inif'+' '+results[i].getValue('custrecord4','custcol_aw_time_work_order'));

				
				create_edit_delete_children(parseFloat(entry_st/60).toFixed(10),parseFloat(entry_ot/60).toFixed(10),parseFloat(entry_dot/60).toFixed(10),employeerec,
				results[i].getValue('custcol_st_te'),results[i].getValue('custcol_ot_te'),results[i].getValue('custcol_dot_te'),results[i].getValue('durationdecimal','custcol_st_te'),results[i].getValue('durationdecimal','custcol_ot_te'),
				results[i].getValue('durationdecimal','custcol_dot_te'),type,results[i].getValue('internalid'),results[i].getValue('date'),results[i].getValue('location'),
				results[i].getValue('payitem','custcol_st_te'),results[i].getValue('payitem','custcol_ot_te'),results[i].getValue('payitem','custcol_dot_te')
				,results[i].getValue('custcol_ow_pay_item','custcol_st_te')
				,results[i].getValue('custcol_ow_pay_item','custcol_ot_te')
				,results[i].getValue('custcol_ow_pay_item','custcol_dot_te')
				,results[i].getValue('custrecord4','custcol_aw_time_work_order'));
			}
			standard_day+=parseInt(entry_st);
			ot_day+=parseInt(entry_ot);
			standard_week+=parseInt(entry_st);
		}
	}
	
}
function isempty(str){
	if (str==null||str==''||typeof str=='undefined')
		return true;
	else
		return false;
}
function create_edit_delete_children(st,ot,dot,emp,stte,otte,dotte,curst,curot,curdot,type,entryid,date,loc,curstit,curotit,curdotit,st_ow,ot_ow,dot_ow,prevwage){
	nlapiLogExecution('ERROR','payroll function values ',type+' : '+st+' : '+ot+' : '+dot+' : '+dotte+ ' : '+stte+' : '+otte+' : '+date+' : '+ot_ow);
	if (type=='create'||type=='edit'){
				st=parseFloat(st);
				ot=parseFloat(ot);
				dot=parseFloat(dot);
			if (typeof dot=='number' && !isNaN(dot) && typeof ot=='number' && !isNaN(ot) && typeof st=='number'&&!isNaN(st) ){		
				var items=emp.getLineItemCount('earning');
				var stit;
				var otit;
				var dotit;
				var holit;
				var ptoit=2;
				for (var i=1; i<=items; i++){
					var pid=emp.getLineItemValue('earning','payrollitem',i);
					var pname=emp.getLineItemText('earning','payrollitem',i);
					var multiplier=emp.getLineItemValue('earning','derivedratemultiplier',i);
					var pri=emp.getLineItemValue('earning','primaryearning',i);
					if (pname.indexOf('Holiday')>-1){
						holit=pid;
					}
					if (prevwage=='T'&&multiplier==2&&pid==63){
						dotit=pid;
					}
					else if (multiplier==2&&prevwage!='T'&&pid!=63){
						dotit=pid;
					}
					else if(prevwage=='T'&&multiplier==1.5&&pid==62) {
						otit=pid;
					}
					else if(multiplier==1.5&&prevwage!='T'&&pid!=62) {
						otit=pid;
					}
					else if(prevwage=='T'&&pid==28) {
						stit=pid;
					}
					else if ((multiplier==''||multiplier==null)&&pri=='T'&&prevwage!='T') {
						stit=pid;
					}
					else if ((multiplier==''||multiplier==null)&&pri=='T'&&prevwage!='T') {
						stit=pid;
					}
				}
				if (st==0&&stte!=''&&stte!=null){
					nlapiSubmitField('timebill',entryid,'custcol_st_te','');
					nlapiDeleteRecord('timebill',stte);
				}
				if (ot==0&&otte!=''&&otte!=null){
					nlapiSubmitField('timebill',entryid,'custcol_ot_te','');
					nlapiDeleteRecord('timebill',otte);
				}
				if (dot==0&&dotte!=''&&dotte!=null){
					nlapiSubmitField('timebill',entryid,'custcol_dot_te','');
					nlapiDeleteRecord('timebill',dotte);
				}
				nlapiLogExecution('ERROR',st,stit+' '+stte);
				nlapiLogExecution('ERROR',ot,otit+' '+otte);
				nlapiLogExecution('ERROR',dot,dotit+' '+dotte);
				var subject=emp.getFieldValue('entityid')+' is missing payroll items';
				var message='Employee '+emp.getFieldValue('entityid')+' is missing the following payroll items needed to record time. Please assign the missing payroll items to their employee record: ';
				var send=false;
				if (st>0&&typeof stit=='undefined'){
					send=true;
					message+='\nStandard - Prevailing Wage: '+prevwage;
				}
				 if (ot>0&&typeof otit=='undefined'){
					send=true;
					message+='\nOvertime - Prevailing Wage: '+prevwage;
				}
				if (dot>0&&typeof dotit=='undefined'){
					send=true;
					message+='\nDouble Overtime - Prevailing Wage: '+prevwage;
				}
				if (send){
					nlapiSendEmail(emp.getId(),'mgerow@arborwell.com',subject,message,['yechenique@arborwell.com','tperry@arborwell.com'],null,{'entity':emp.getId()});
				}
				if (st>0){
					if (stte>-1&&stte!=''&&stte!=null){
						stte=nlapiLoadRecord('timebill',stte);				
					}
					else {
						stte=nlapiCreateRecord('timebill');							
					}
						stte.setFieldValue('hours',st.toFixed(4));
						stte.setFieldValue('employee',emp.getId());
						stte.setFieldValue('trandate',date);
						if (!(st_ow=='T')&&typeof stit!='undefined')
							stte.setFieldValue('payrollitem',stit);
						else {
							stte.setFieldValue('payrollitem',curstit);
							
						}
						stte.setFieldValue('location',loc);
						//stte.setFieldValue('custcol_pte',nlapiGetRecordId());
						if (!isempty(stit)||!isempty(curstit)){
							var id=nlapiSubmitRecord(stte,false,true);
							nlapiSubmitField('timebill',entryid,'custcol_st_te',id);
						}
				}
				if (ot>0){
					if (otte>-1&&otte!=''&&otte!=null){
						otte=nlapiLoadRecord('timebill',otte);						
					}
					else {
						otte=nlapiCreateRecord('timebill');					
					}
					otte.setFieldValue('hours',ot.toFixed(4));
					otte.setFieldValue('employee',emp.getId());
					otte.setFieldValue('trandate',date);
					if (!(ot_ow=='T')&&typeof otit!='undefined')
						otte.setFieldValue('payrollitem',otit);
					else {
						otte.setFieldValue('payrollitem',curotit);
						if (type=='create'){
							return;
						}
					}
					otte.setFieldValue('location',loc);
					
					//otte.setFieldValue('custcol_pte',entryid);
					if (!isempty(otit)||!isempty(curotit)){
						var id=nlapiSubmitRecord(otte,false,true);
						nlapiSubmitField('timebill',entryid,'custcol_ot_te',id);
					}
				}
				if (dot>0){
					if (dotte>-1&&dotte!=''&&dotte!=null){
						dotte=nlapiLoadRecord('timebill',dotte);					
					}
					else {
						dotte=nlapiCreateRecord('timebill');
					}
					dotte.setFieldValue('hours',dot.toFixed(4));
					dotte.setFieldValue('employee',emp.getId());
					dotte.setFieldValue('trandate',date);
					dotte.setFieldValue('location',loc);
					
					if (!(dot_ow=='T')&&typeof dotit!='undefined')
						dotte.setFieldValue('payrollitem',dotit);
					else {
						dotte.setFieldValue('payrollitem',curdotit);
						if (type=='create'){
							return;
						}
					}
					//dotte.setFieldValue('custcol_pte',entryid);	
					if (!isempty(dotit)||!isempty(curdotit)){
						var id=nlapiSubmitRecord(dotte,false,true);
						nlapiSubmitField('timebill',entryid,'custcol_dot_te',id);
					}
				}
			}
	}
}
function isempty(vari){
	if (vari==''||vari==null||typeof vari=='undefined'){
		return true;
	}
	return false;
}
function get_ot_rules(rules){
	//default to CA rules
	var st_pw=2400;
	var st_pd=480;
	var ot_pw=0;
	var ot_pd=240;
	var has_dot='T';
	var consec_days=7;
	var ot_after_consec=480;
	var rec=0;
	if (rules!=null){
		if (rules[0].getValue('custrecord_lr_stpd')!=''&&!isNaN(rules[0].getValue('custrecord_lr_stpd'))){
			st_pd=parseInt(rules[0].getValue('custrecord_lr_stpd')).toFixed(0);
		}
		if (rules[0].getValue('custrecord_lr_stpw')!=''&&!isNaN(rules[0].getValue('custrecord_lr_stpw'))){
			st_pw=parseInt(rules[0].getValue('custrecord_lr_stpw')).toFixed(0);
		}
		if (rules[0].getValue('custrecord_lr_otpd')!=''&&!isNaN(rules[0].getValue('custrecord_lr_otpd'))){
			ot_pd=parseInt(rules[0].getValue('custrecord_lr_otpd')).toFixed(0);
		}
		if (rules[0].getValue('custrecord_lr_otmpw')!=''&&!isNaN(rules[0].getValue('custrecord_lr_otmpw'))){
			ot_pw=parseInt(rules[0].getValue('custrecord_lr_otmpw')).toFixed(0);
		}
		if (rules[0].getValue('custrecord_lr_consec_ot_rule')!=''&&!isNaN(rules[0].getValue('custrecord_lr_consec_ot_rule'))){
			consec_days=parseInt(rules[0].getValue('custrecord_lr_consec_ot_rule')).toFixed(0);
		}
		if (rules[0].getValue('custrecord_lr_otconsecdays')!=''&&!isNaN(rules[0].getValue('custrecord_lr_otconsecdays'))){
			ot_after_consec=parseInt(rules[0].getValue('custrecord_lr_otconsecdays')).toFixed(0);
		}
		has_dot=rules[0].getValue('custrecord_lr_hasdot');
		rec=rules[0].getValue('internalid');
		nlapiLogExecution('ERROR','rec',rec);
	}
	return [st_pw,st_pd,ot_pw,ot_pd,has_dot,consec_days,ot_after_consec,rec];
}
function get_labor_cost(employ,standard,overtime,double,wage,burden){
	
	if(wage == null){ var wage = 0;}

	if(burden == null){ var burden = 0;}

var total = (standard + overtime + double);

//Calculate Cost & set Field	
//var labor_cost = ((standard * wage) + (overtime * wage * 1.5) + (double * wage * 2) + (total * burden));

var labor_cost = ((standard * wage) + ((overtime * wage) * 1.5) + ((double * wage) * 2) + (total * burden));

return labor_cost;

}
function convert_to_minutes(hours){
	//nlapiLogExecution('ERROR','time',nlapiGetRecordId()+' '+hours)
	
	var arr_hour=hours.split(':');
	if(arr_hour[0]!=undefined && arr_hour[0]!='')
		var ho=parseInt(arr_hour[0]);
	if(arr_hour[1]!=undefined && arr_hour[1]!=''&&arr_hour[1]!='00'){
		var min=parseInt(arr_hour[1].replace(/\b0+/g, ''));
	}
	else {
		min=parseInt('0');
	}
	//nlapiLogExecution('ERROR','asdf',nlapiGetRecordId()+' '+ho+' '+arr_hour[1]);
	hours=parseInt(ho)*60+parseInt(min);
	return hours;
}
//for threshold to be crossed, some time that day has to be put in regular
// thus, time will be either regular, regular and ot, or regular, ot, and double ot.
//dist_to_40 is the correct regular amount. after that, other rules apply
//we know that ot for the day and dot for the day have to be 0 at this point 
//for the event to occur
function threshold (old_time_val,ot_day,day,standard_day,thres,dist_to_40,rules_rec,st_ot_amt,has_dot,special_rules){
	var time_val;
	var entry_st;
	time_val=old_time_val-dist_to_40;
	entry_st=dist_to_40;
	entry_ot=0;
	entry_dot=0;
	var day1=day;
	if (day==0){
		day1=7;
	}
	var cust_amt=0;
	if (rules_rec!=0){
		
		for (var i=0; special_rules!=null&&i<special_rules.length;i++){
			if (special_rules[i].getValue('custrecord_lr_dow')==day1){
				cust_amt=parseInt(special_rules[i].getValue('custrecord_spec_ot_minutes')).toFixed(0);
			}
		}
	}
	if (cust_amt>0){
		if (time_val<=cust_amt||has_dot=='F'){
			return [entry_st,time_val,0];
		}
		else {
			return [entry_st,cust_amt,time_val-cust_amt];
		}
	}
	else {
		if (time_val<=st_ot_amt||has_dot=='F'){
			return [entry_st,time_val,0];
		}
		else {
			return [entry_st,st_ot_amt,time_val-st_ot_amt];
		}
	}
}
function under_40(time_val,ot_day,day,st_day,st_pd,ot_pd,has_dot,special_rules,date,emp){
	var entry_dot=0;
	var entry_ot=0;
	var entry_day=0;
	time_val=Number(time_val);
	ot_day=Number(ot_day);
	day=Number(day);
	st_day=Number(st_day);
	st_pd=Number(st_pd);
	ot_pd=Number(ot_pd);
	//all standard
	if ((st_day+parseFloat(time_val)<=st_pd)||st_pd==0){
		entry_day=time_val;
		return[entry_day,entry_ot,entry_dot];
	}
	//all dot
	else if (st_day>=st_pd&&ot_day>=ot_pd&&has_dot=='T'){
		entry_dot=time_val;
		return[entry_day,entry_ot,entry_dot];
	}
	//all ot
	else if (st_day>=st_pd&&((ot_day+time_val<=ot_pd)||has_dot=='F')){
		return[entry_day,time_val,entry_dot];
	}
	//standard and ot
	else if (st_day<st_pd&&(st_day+time_val)>=st_pd&&((st_day+time_val+ot_day)<=(st_pd+ot_pd)||has_dot=='F')){
		if (emp=='Matthew Rippey')
		nlapiLogExecution('ERROR','standard and ot',date+' '+emp+' '+(st_pd+ot_pd)+' '+st_pd+' '+ot_pd+' '+(st_day+time_val+ot_day)+' '+ot_pd +' '+time_val);
		return[st_pd-st_day,time_val-(st_pd-st_day) ,0];
	}
	//standard ot and dot
	else if (st_day<st_pd&&(st_day+time_val>=st_pd+ot_pd&&has_dot=='T')){
		return [st_pd-st_day,ot_pd,time_val-ot_pd-(st_pd-st_day)];
	}
	//ot and dot
	else if ((st_day>=st_pd&&ot_day<ot_pd&&(time_val+ot_day)>=ot_pd)&&has_dot=='T'){
		return[0,ot_pd-ot_day,time_val-(ot_pd-ot_day)];
	}
	//nlapiLogExecution("ERROR",'no cond met',time_val);
}
function over_40(time_val,ot_day,day,rules_rec,ot_thres,has_dot,special_rules,st_day){
	var entry_dot=0;
	var entry_ot=0;
	var day1=day;
	if (day==0){
		day1=7;
	}
	var cust_amt=0;
	if (rules_rec!=0){
	
		for (var i=0; special_rules!=null&&i<special_rules.length;i++){
			if (special_rules[i].getValue('custrecord_lr_dow')==day1){
				cust_amt=parseInt(special_rules[i].getValue('custrecord_spec_ot_minutes')).toFixed(0);
			}
		}
	}
	nlapiLogExecution('ERROR','has_dot',has_dot);
	if (cust_amt>0){
		if ((ot_day+st_day<cust_amt&&(ot_day+st_day+time_val>cust_amt))&&has_dot=='T'){
			entry_dot=(ot_day+st_day+time_val-cust_amt);
			entry_ot=time_val-entry_dot;
			nlapiLogExecution('ERROR','4','4');
		}
		else if ((ot_day<cust_amt&&(ot_day+time_val<cust_amt))||has_dot=='F'){
			entry_ot=time_val;
			nlapiLogExecution('ERROR','1','1');
		}
		else if ((ot_day<cust_amt)&&ot_day+time_val>=cust_amt){
			nlapiLogExecution('ERROR','2','2');
			entry_dot=(ot_day+time_val-cust_amt);
			entry_ot=time_val-entry_dot;
		}
		else {
			nlapiLogExecution('ERROR','3','3');
			entry_dot=time_val;
		}
	}
	else {
		if ((ot_day<ot_thres&&(ot_day+time_val<ot_thres))||has_dot=='F'){
			entry_ot=time_val;
			nlapiLogExecution('ERROR','in 4',ot_day+' '+ot_thres+' '+time_val);
		}
		else if ((ot_day<ot_thres)&&ot_day+time_val>=ot_thres){
			nlapiLogExecution('ERROR','5','5');
			entry_dot=(ot_day+time_val-ot_thres);
			entry_ot=time_val-entry_dot;
		}
		else {
			nlapiLogExecution('ERROR','6','6');
			entry_dot=time_val;
		}
	}
	return [entry_ot,entry_dot];
}
function convert_hours(hours){
	
	try{

	var ho_=hours/60;
	var min_=hours%60;
	ho_=parseInt(ho_);
	min_=parseInt(min_);
	//nlapiLogExecution('ERROR', 'Hours New Diffr', ho_+" : "+min_);
	hours=parseInt(ho_);
	//if(min_<=9)
	//{
	//	min_="0"+min_;
	//}
	hours=hours+parseFloat(min_/60);
	//hours=hours+"."+min_;
	hours=parseFloat(hours);
	hours=hours.toFixed(2);

	return hours;
	}catch(e){
		nlapiLogExecution('ERROR', 'sdssd', e.message+" "+e);
	}

}
function start_date(date)
{
	var today = new Date(date);
	if (today.getDay()==0){
		return nlapiAddDays(today,-6);
	}
	else if (today.getDay()==6){
		return nlapiAddDays(today,-5);
	}
	else if (today.getDay()==5){
		return nlapiAddDays(today,-4);
	}
	else if (today.getDay()==4){
		return nlapiAddDays(today,-3);
	}
	else if (today.getDay()==3){
		return nlapiAddDays(today,-2);
	}
	else if (today.getDay()==2){
		return nlapiAddDays(today,-1);
	}
	else {
		return today;
	}
}
function end_date(date)
{
	var today = new Date(date);
	if (today.getDay()==0){
		return today;
	}
	else if (today.getDay()==6){
		return nlapiAddDays(today,1);
	}
	else if (today.getDay()==5){
		return nlapiAddDays(today,2);
	}
	else if (today.getDay()==4){
		return nlapiAddDays(today,3);
	}
	else if (today.getDay()==3){
		return nlapiAddDays(today,4);
	}
	else if (today.getDay()==2){
		return nlapiAddDays(today,5);
	}
	else {
		return nlapiAddDays(today,6);
	}
}
function zero_holidays(f1,f2,f3,emp,tostringdate){
	var filters=[f1,f2,f3];
	var field='';
	var column=[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('custcol_aw_time_work_order'),new nlobjSearchColumn('durationdecimal'),
	new nlobjSearchColumn('location'),new nlobjSearchColumn('date'),new nlobjSearchColumn('custcol_pto_entry'),new nlobjSearchColumn('custcol_holiday_entry')];
	var results=nlapiSearchRecord('timebill','customsearch_time_no_payroll_item',filters,column);
	var items=emp.getLineItemCount('earning');
	var holit;
	var ptoit=2;
				
	for (var i=1; i<=items; i++){
		var pid=emp.getLineItemValue('earning','payrollitem',i);
		var pname=emp.getLineItemText('earning','payrollitem',i);
		var multiplier=emp.getLineItemValue('earning','derivedratemultiplier',i);
		var pri=emp.getLineItemValue('earning','primaryearning',i);
		if (pname.indexOf('Holiday')>-1){
			holit=pid;
		}
	}
	var acc=emp.getLineItemCount('accruedtime');
	var ptofound=false;
	for (var i=1; i<=acc; i++){
		var pid=emp.getLineItemValue('accruedtime','payrollitem',i);
		if (pid==2){
			ptofound=true;
		}
	}
				
				var sendpto=false;
				var sendhol=false;
	for (var i=0; results!=null&&i<results.length; i++){
		var duration=results[i].getValue('durationdecimal');
		var wo=results[i].getValue('custcol_aw_time_work_order');
		var date=results[i].getValue('date');
		var loc=results[i].getValue('location');
		if (wo==73994&&!ptofound){
			sendpto=true;
		}
		else if (typeof holit=='undefined'){
			sendhol=true;
		}			
		if (wo==73994&&ptofound){
			field='custcol_hours_pto';
			field2='custcol_hours_holiday';
			if (new Date(tostringdate)>new Date('12/25/2016')){
			var ptoentry=results[i].getValue('custcol_pto_entry');
			if (ptoentry!=null&&ptoentry!=''){
				ptoentry=nlapiLoadRecord('timebill',ptoentry);
			}
			else {
				ptoentry=nlapiCreateRecord('timebill');
			}
			ptoentry.setFieldValue('hours',parseFloat(duration).toFixed(2));
			ptoentry.setFieldValue('employee',emp.getId());
			ptoentry.setFieldValue('trandate',date);

			ptoentry.setFieldValue('payrollitem',ptoit);
			ptoentry.setFieldValue('location',loc);
					
			//otte.setFieldValue('custcol_pte',entryid);
			var id=nlapiSubmitRecord(ptoentry,false,true);
			nlapiSubmitField('timebill',results[i].getValue('internalid'),'custcol_pto_entry',id);
			}
			
		}
		else if (typeof holit!='undefined'){
			field='custcol_hours_holiday';
			field2='custcol_hours_pto';
			if (new Date(tostringdate)>new Date('12/25/2016')){
			var holentry=results[i].getValue('custcol_holiday_entry');
			if (holentry!=''&&holentry!=null){
				holentry=nlapiLoadRecord('timebill',holentry);
			}
			else {
				holentry=nlapiCreateRecord('timebill');
			}
			holentry.setFieldValue('hours',parseFloat(duration).toFixed(2));
			holentry.setFieldValue('employee',emp.getId());
			holentry.setFieldValue('trandate',date);
			holentry.setFieldValue('payrollitem',holit);	
			holentry.setFieldValue('location',loc);	
			//otte.setFieldValue('custcol_pte',entryid);
			var id=nlapiSubmitRecord(holentry,false,true);
			nlapiSubmitField('timebill',results[i].getValue('internalid'),'custcol_holiday_entry',id);

			}
		}
		try {
		nlapiSubmitField('timebill',results[i].getValue('internalid'),['custcol_aw_time_hours_standard','custcol_aw_time_hours_overtime','custcol_aw_time_hours_double_overtime',field,field2,'custcol_hours_st_rounded','custcol_hours_ot_rounded','custcol_hours_dot_rounded'],[0,0,0,parseFloat(duration).toFixed(2),0,0,0,0]);
		}
		catch (e){
			
		}
		
	}
	var subject=emp.getFieldValue('entityid')+' is missing holiday/pto payroll items';
				var message='Employee '+emp.getFieldValue('entityid')+' is missing the following payroll items needed to record pto/holiday time. Please assign the missing payroll items to their employee record: ';
				var send=false;
				if (sendhol){
					
					message+='\nHoliday';
				}
				 if (sendpto){
					
					message+='\nPTO';
				}

				if (sendpto||sendhol){
					nlapiSendEmail(emp.getId(),'mgerow@arborwell.com',subject,message,['yechenique@arborwell.com','tperry@arborwell.com'],null,{'entity':emp.getId()});
				}
}
