/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 May 2015     AHalbleib
 *
 */

/**
 * @param {nlobjPortlet} portletObj Current portlet object
 * @param {Number} column Column position index: 1 = left, 2 = middle, 3 = right
 * @returns {Void}
 */

function get_timecards(request,response) {
	if (request.getMethod()=='GET'){
		var form=nlapiCreateForm('Get Timecards');
		form.addField('custpage_date','date','Date (Set to within week to download)').setMandatory(true).setDefaultValue(get_week_dates(nlapiAddDays(new Date(),-7))[0]);
		form.addSubmitButton('Download Week');
		response.writePage(form);
	}
	else {
		var logo=nlapiLoadFile(14).getURL();
		var title='Arborwell Weekly Time Cards';
		 var time_table_head=tr(td('Date',['align','left','font-size','9'])+td('Start Time',['align','left','font-size','9'])+td('End Time',['align','left','font-size','9'])+td('Work Order',['align','left','font-size','9'])+td('Property',['align','left','font-size','9'])+td('Hrs. Std.',['align','left','font-size','9'])+td('Hrs. OT',['align','left','font-size','9'])+td('Hrs. DT',['align','left','font-size','9'])+td('Total',['align','left','font-size','9']));
		 var sig_line='<p font-size="9" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold">I acknowledge that the above information is true and correct, '+
			 'I have taken appropriate rest periods each day, and I '+
		 'am not aware of any unreported accidents on my job this week.</p>'+
		 '<p font-size="9" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold">'+
		 'Yo reconozco que la informacion de arriba es verdadera y correcta, yo he tomado los periodos apropriados de Descanso cada dia, y no estoy enterado de ningun accidente que no ha sido reportado en mis trabajos esta semana.</p>'+
		 '<p font-size="9" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold">'+
		 'I CERTIFY THE ABOVE INFORMATION TO BE CORRECT.<br/>'+
		 'YO CERTIFICO QUE LA INFORMACION ARRIBA ESTA CORRECTA.</p><br/><span font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold" font-size="9" float="left"  border-bottom="1">X &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold" font-size="9" float="right" width="40%" border-bottom="1">X &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span>'+
		 '<p font-size="9" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif" font-weight="bold">&nbsp; &nbsp; Employee Signature &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Date &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Supervisor Signature &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Date <br/>&nbsp; &nbsp; Firma del Empleado &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Fecha &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Firma del Supervisor &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Fecha </p>';
		 var dates=get_week_dates(new Date(request.getParameter('custpage_date')));
		 nlapiLogExecution('ERROR','date',dates[0]+' '+dates[1]);
		 var search=nlapiLoadSearch('timebill','customsearch1163');
		 search.addFilter(new nlobjSearchFilter('date',null,'within',dates[0],dates[1]));
		 var weekly_totals=nlapiSearchRecord('timebill','customsearch1164',new nlobjSearchFilter('date',null,'within',dates[0],dates[1]));
		 var daily_totals=nlapiSearchRecord('timebill','customsearch1165',new nlobjSearchFilter('date',null,'within',dates[0],dates[1]));
		 //nlapiLogExecution('ERROR','date',weekly_totals);
		 var results=search.runSearch();
		 var index=0;
		 var string='';
		 var header='';
		 var employee=null;
		 var employeetext=null;
		 var pdf_string='';
		 var date=null;
		 //custcol_st_te
		 //custcol_ot_te
		 //custcol_dot_te
		 //custcol_aw_time_hours_standard
		 //custcol_aw_time_hours_overtime
		 //custcol_aw_time_hours_double_overtime	
		 do {
			 var temp=results.getResults(index*1000,(index+1)*1000);
			 for (var i=0; i<temp.length; i++){
				 if (temp[i].getValue('employee')!=employee){
					 if (employee!=null){
						 string+=get_day_totals(daily_totals,employee,date);
						 string+=get_totals(weekly_totals,employee);
						 pdf_string+=header+table(string,['border','.3','cellborder','.3','margin-bottom','.6cm','border-collapse','collapse'])+sig_line+'<pbr/>';
					 }
					 date=null;
					 employee=temp[i].getValue('employee');
					 employeetext=temp[i].getText('employee');
					 header=get_header_table(employeetext,temp[i].getValue('custentity5','employee'),temp[i].getText('location','employee'));
					 string=time_table_head;
				 }
				 if (temp[i].getValue('date')!=date){
					 if (date!=null){
						 string+=get_day_totals(daily_totals,employee,date);
					 }
					 date=temp[i].getValue('date');
				 }
				 nlapiLogExecution('ERROR','sdf',temp[i].getValue('durationdecimal','custcol_st_te'));
				 string+=tr(td(temp[i].getValue('date'),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(temp[i].getValue('custcol_time_bill_start_time'),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(temp[i].getValue('custcol_time_bill_end_time'),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
						 +td(temp[i].getText('custcol_aw_time_work_order'),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
						 +td(temp[i].getText('custrecord_aw_wo_property','custcol_aw_time_work_order').replace(/&/g,'&amp;').replace(/&amp;nbsp;/g,'&nbsp;'),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
						 +td((temp[i].getValue('durationdecimal','custcol_st_te')!='' ? parseFloat(temp[i].getValue('durationdecimal','custcol_st_te')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td((temp[i].getValue('durationdecimal','custcol_ot_te')!='' ? parseFloat(temp[i].getValue('durationdecimal','custcol_ot_te')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
						 +td((temp[i].getValue('durationdecimal','custcol_dot_te')!='' ? parseFloat(temp[i].getValue('durationdecimal','custcol_dot_te')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(parseFloat(temp[i].getValue('durationdecimal')).toFixed(2),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
			 } 
			 index++;
		 }while (temp.length==1000);
		 string+=get_day_totals(daily_totals,employee,date);
		 string+=get_totals(weekly_totals,employee);
		 pdf_string+=header+table(string,['border','.3','cellborder','.3','border-collapse','collapse'])+'<br/>'+sig_line;
		 var pdf=nlapiXMLToPDF(add_container(pdf_string,logo,title,dates));
		 response.setContentType('PDF');
		 response.write(pdf);
	}
}//report is pulling information from bills and the pos hve no bills 35093 suiteanswers id
function get_day_totals(daily_totals,employee,date){
	for (var i=0;daily_totals!=null&&i<daily_totals.length; i++){
		if (daily_totals[i].getValue('employee',null,'group')==employee&&daily_totals[i].getValue('date',null,'group')==date){
			return tr(td(date+' Total',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td('&nbsp;')+td('&nbsp;')+td('&nbsp;')+td('&nbsp;')
					+td((daily_totals[i].getValue('durationdecimal','custcol_st_te','sum')!='' ? parseFloat(daily_totals[i].getValue('durationdecimal','custcol_st_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td((daily_totals[i].getValue('durationdecimal','custcol_ot_te','sum')!='' ? parseFloat(daily_totals[i].getValue('durationdecimal','custcol_ot_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td((daily_totals[i].getValue('durationdecimal','custcol_dot_te','sum')!='' ? parseFloat(daily_totals[i].getValue('durationdecimal','custcol_dot_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td(parseFloat(daily_totals[i].getValue('durationdecimal',null,'sum')).toFixed(2),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
		}
	}
}
function get_totals(weekly_totals,employee){
	for (var i=0;weekly_totals!=null&&i<weekly_totals.length; i++){
		if (weekly_totals[i].getValue('employee',null,'group')==employee){
			return tr(td('Total',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td('&nbsp;')+td('&nbsp;')+td('&nbsp;')+td('&nbsp;')
					+td((weekly_totals[i].getValue('durationdecimal','custcol_st_te','sum')!='' ? parseFloat(weekly_totals[i].getValue('durationdecimal','custcol_st_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td((weekly_totals[i].getValue('durationdecimal','custcol_ot_te','sum')!='' ? parseFloat(weekly_totals[i].getValue('durationdecimal','custcol_ot_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td((weekly_totals[i].getValue('durationdecimal','custcol_dot_te','sum')!='' ? parseFloat(weekly_totals[i].getValue('durationdecimal','custcol_dot_te','sum')).toFixed(2):0.00),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])
					+td(parseFloat(weekly_totals[i].getValue('durationdecimal',null,'sum')).toFixed(2),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
		}
	}
}
function get_week_dates(date){
	var day=date.getDay();
	//nlapiLogExecution('ERROR','asdf',date+' '+day);
	var add=0;
	var first;
	if (day==6){
		add=-5;
	}
	else if (day==5){
		add=-4;
	}
	else if (day==4){
		add=-3;
	}
	else if (day==3){
		add=-2;
	}
	else if (day==2){
		add=-1;
	}
	else if (day==1){
		add=0;
	}
	else {
		add=1;
	}
	//nlapiLogExecution('ERROR','asdf',add+' '+day);
	if (add!=0){
		first=nlapiAddDays(date,add);
	}
	else {
		first=date;
	}
	//nlapiLogExecution('ERROR','asdf',first);
	dates=[nlapiDateToString(first),nlapiDateToString(nlapiAddDays(first,6))];
	return dates;
}
function add_container(bodystring,logo,title,dates){
	var xmlbase=get_xml();
	nlapiLogExecution('ERROR','vals',logo+' '+title);
	
	xmlbase+='<macro id="myHeader"><img float="left" src="'+logo.replace(/&/g,'&amp;').replace(/&amp;nbsp;/g,'&nbsp;')+'"/> <p float="left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>'+
	'<p font-size="11" align="center" float="right" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif">'+title+' - '+dates[0]+' - '+dates[1]+'</p></macro>';
	xmlbase+='</macrolist></head><body header="myHeader" header-height="2cm" footer="myFooter" footer-height=".6cm" size="letter">';
	return xmlbase+bodystring+'</body></pdf>';
}
function get_xml(){
	var xml = "<?xml version=\"1.0\"?>" +
	'<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">'+
	'<pdf><head><meta name="title" value="Timecards"/><macrolist><macro id="myFooter">'+
	'<p align="center" font-size="9">'+nlapiDateToString(new Date(),'datetime')+'     Page <pagenumber/> of <totalpages/> </p></macro>';
	
	return xml;
}
function get_header_table(employee,id,region){
	var string='';
	string+=tr(td('Employee: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(employee,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Arborwell Employee ID: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(id,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Region: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(region,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	return table(string,['border','.3','cellborder','.3','margin-bottom','.6cm']);
}
function table(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<style.length; i+=2){
			attr_string+=+style[i]+':'+style[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<table'+attr_string+'>'+value+'</table>';
}
function tr(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=+style[i]+':'+bfo_attr[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<tr'+attr_string+'>'+value+'</tr>';
}
function td(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<style.length; i+=2){
			attr_string+=+style[i]+':'+style[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<td'+attr_string+'><p'+attr_string+ '>'+value+'</p></td>';
}