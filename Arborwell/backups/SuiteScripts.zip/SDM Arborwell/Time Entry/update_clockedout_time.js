function update_time(recType,recId){
	try {
		var rec=nlapiLoadRecord(recType,recId);
		nlapiSubmitRecord(rec);
	}
catch (e){
}
}