function convert_hours(hours){
	
	try{

	var ho_=hours/60;
	var min_=hours%60;
	ho_=parseInt(ho_);
	min_=parseInt(min_);
	//nlapiLogExecution('ERROR', 'Hours New Diffr', ho_+" : "+min_);
	hours=parseInt(ho_);
	//if(min_<=9)
	//{
	//	min_="0"+min_;
	//}
	hours=hours+parseFloat(min_/60);
	//hours=hours+"."+min_;
	hours=parseFloat(hours);
	hours=hours.toFixed(2);

	return hours;
	}catch(e){
		nlapiLogExecution('ERROR', 'sdssd', e.message+" "+e);
	}

}
function update_time(){
	
	var results=nlapiSearchRecord('timebill','customsearch592');
	for (var i=0; results!=null&&i<results.length; i++){
		rec=nlapiLoadRecord('timebill',results[i].getValue('internalid'));
		rec.setFieldValue('custcol_time_bill_status','clockedout');
		rec.setFieldValue('custcol_time_bill_end_time','11:59 pm');
		if (rec.getFieldValue('custcol_source')!='csvimport'){
			var employee=rec.getFieldValue('custcol_temp_app_employee');
			if (employee!=''&&employee!=null&&employee!=0){
				rec.setFieldValue('employee',employee);
				rec.setFieldValue('custcol_temp_app_employee',0);
				
			}
			else {
				employee=rec.getFieldValue('employee');
			}
				}
			
		
try{
		rec.setFieldValue('hours',calculateTime(rec.getFieldValue('custcol_time_bill_start_time'),'11:59 pm'));
		nlapiSubmitRecord(rec);
}
catch (e){
nlapiLogExecution('ERROR',results[i].getValue('internalid'),calculateTime(rec.getFieldValue('custcol_time_bill_start_time'),'11:59 pm')+' '+rec.getFieldValue('custcol_time_bill_start_time'));
}
	}
}
function set_region(recType,recId){
	var ts=nlapiLoadRecord(recType,recId);
	var location=ts.getFieldValue('location');
	var emp_loc=nlapiLookupField('employee',ts.getFieldValue('employee'),'location');
	if (location!=emp_loc){
		ts.setFieldValue('location',emp_loc);
		nlapiSubmitRecord(ts);
	}
}

function calculateTime(st,et)
{
	var time = st.split(' '); 
	var start = time[0].split(':');
	if (time[1]=='pm'&&start[0]!=12){
		start[0]=parseInt(start[0]);
		start[0]+=parseInt(12);
	}
	else if (time[1]=='am'&&start[0]==12){
		start[0]=0;
	}
	var time = et.split(' '); 
	var end = time[0].split(':');
	
	if (time[1]=='pm'&&end[0]!=12){
		end[0]=parseInt(end[0]);
		end[0]+=parseInt(12);
	}
	else if (time[1]=='am'&&end[0]==12){
		end[0]=0;
	}
	//alert(end[0]);
	//alert(start[0]);
	var hours=end[0]-start[0];
	//alert(hours);
	//difference in minutes
	hours*=60;
	if (end[1].length==2&&end[1].charAt(0)=='0'){
		end[1]=end[1].charAt(1);
	}
	hours+=parseInt(end[1]);
	if (start[1].length==2&&start[1].charAt(0)=='0'){
		start[1]=start[1].charAt(1);
	}
	hours-=parseInt(start[1]);
	//alert(hours);
	if (hours<0) return-1;
	
	var final_hours=Math.floor(hours/60);
	var minutes=hours%60;
	//minutes=Math.round(minutes/15)*15;

	//if (minutes==60){
	//	minutes=='00';
	//	//final_hours+=1;
		
	//}
	return final_hours+':'+minutes;
}
function convert_to_minutes(hours){
	//nlapiLogExecution('ERROR','time',rec.getId()+' '+hours)
	
	var arr_hour=hours.split(':');
	if(arr_hour[0]!=undefined && arr_hour[0]!='')
		var ho=parseInt(arr_hour[0]);
	if(arr_hour[1]!=undefined && arr_hour[1]!=''&&arr_hour[1]!='00'){
		var min=parseInt(arr_hour[1].replace(/\b0+/g, ''));
	}
	else {
		min=parseInt('0');
	}
	//nlapiLogExecution('ERROR','asdf',rec.getId()+' '+ho+' '+arr_hour[1]);
	hours=parseInt(ho)*60+parseInt(min);
	return hours;
}