function update_so(recType,recId){
	var wo=nlapiLoadRecord(recType,recId);
	var time=nlapiSearchRecord('timebill',null,new nlobjSearchFilter('custcol_aw_time_work_order',null,'anyof',recId),new nlobjSearchColumn('durationdecimal',null,'sum'));
	var hours=0;
	if (time!=null){
		
		hours=time[0].getValue('durationdecimal',null,'sum');
	}
	nlapiSubmitField('salesorder',wo.getFieldValue('custrecord_aw_wo_so'),'custbody_num_hours',hours);
	//if (hours==0){
	//	nlapiSubmitField('salesorder',wo.getFieldValue('custrecord_aw_wo_so'),'custbody_aw_invoice_margin_percent',54);
	//	nlapiLogExecution('ERROR',recType,recId);
	//}
}