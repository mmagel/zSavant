function get_time(dataIn){
var empId=dataIn.empId;
var job_id = new Array();
	var job_name = new Array();
	var job_rec_int_id = new Array();
var wo_srch = nlapiLoadSearch('timebill', 'customsearch_ssst_time_entry_for_emp');
	
	
	
	wo_srch.addFilter(new nlobjSearchFilter('custcol_time_bill_end_time',null,'isempty'));
	wo_srch.addFilter(new nlobjSearchFilter('custcol_timbill_start_date',null,'within','thismonth'));
nlapiLogExecution('ERROR','empid',empId);
	nlapiLogExecution('ERROR', 'empid wo activity', empId);
	var clockedInSearchNotRequired = false;
	if(empId!='null' && empId != null){
		
		wo_srch.addFilter(new nlobjSearchFilter('custcol_temp_app_employee',null,'equalto',empId));
	}else{
		clockedInSearchNotRequired = true;
	}
//	wo_fil.push(new nlobjSearchFilter('custrecord_advs_curr_job_status',null,'anyof',1));//1 for in-progress status



	wo_srch.addColumn(new nlobjSearchColumn('custcol_aw_time_work_order'));//0
	wo_srch.addColumn(new nlobjSearchColumn('internalid'));//1
	wo_srch.addColumn(new nlobjSearchColumn('custrecord_aw_wo_client','custcol_aw_time_work_order'));//2
	wo_srch.addColumn(new nlobjSearchColumn('custrecord_aw_wo_property','custcol_aw_time_work_order'));//3
	wo_srch.addColumn(new nlobjSearchColumn('name','custcol_aw_time_work_order'));//4
	var wo_res = wo_srch.runSearch();
	var wo_cols = wo_res.getColumns();//	
//	var wo_internal_id = new Array();
	var count =0;
	wo_res.forEachResult(function(recs){
		count++;
		nlapiLogExecution('ERROR', 'rec count for active jobs ', count);		
		job_id.push(recs.getValue(wo_cols[4]));
		job_name.push(recs.getText(wo_cols[3]));
		job_rec_int_id.push(recs.getValue(wo_cols[1]));
		
		if(count==3 && clockedInSearchNotRequired)
			return false;
			
		return true;
	}
	);
	var compile=new Array();
	compile.push(job_id);
	compile.push(job_name);
	compile.push(job_rec_int_id);
	return compile;
}
function get_hist(dataIn){
	var wk='';
	var hrs_per_day = 0;
	var history_data_wo = new Array();
	var history_data_sd = new Array();
	var history_data_ed = new Array();
	var history_data_st = new Array();
	var history_data_et = new Array();
	var history_data_hrs = new Array();
	var history_data_week = new Array();
	var total_hrs_for_day = new Array();
	var day_array = new Array();
	var date_array = new Array();
	var week_arr_for_preview = new Array();
	var dt_for_srch_str=dataIn.dt_for_srch_str;
	dt_for_srch=new Date(dt_for_srch_str);
	
	var empId=dataIn.empId;
	var hist_srch = nlapiLoadSearch('timebill', 'customsearch_ssst_time_entry_for_emp');
		
		hist_srch.addFilter(new nlobjSearchFilter('custcol_timbill_start_date',null,'on',dt_for_srch_str));
//		srch_fil.push(new nlobjSearchFilter('custcol_aw_time_hours_standard',null,'',dt_for_srch_str));
		if(empId!='null' && empId != null){
			hist_srch.addFilter(new nlobjSearchFilter('employee',null,'anyof',empId));
		}
		hist_srch.addFilter(new nlobjSearchFilter('custcol_time_bill_end_date',null,'isnotempty'));
		hist_srch.addFilter(new nlobjSearchFilter('custcol_aw_time_hours_standard',null,'isnotempty'));
		
		hist_srch.addColumn(new nlobjSearchColumn('custcol_aw_time_work_order'));//0
		hist_srch.addColumn(new nlobjSearchColumn('custcol_timbill_start_date'));//1
		hist_srch.addColumn(new nlobjSearchColumn('custcol_time_bill_start_time').setSort(true));//2
		hist_srch.addColumn(new nlobjSearchColumn('custcol_time_bill_end_date'));//3
		hist_srch.addColumn(new nlobjSearchColumn('custcol_time_bill_end_time'));//4
		hist_srch.addColumn(new nlobjSearchColumn('internalid'));//5
		hist_srch.addColumn(new nlobjSearchColumn('custrecord_aw_wo_client','custcol_aw_time_work_order'));//6
		hist_srch.addColumn(new nlobjSearchColumn('hours'));//7
		hist_srch.addColumn(new nlobjSearchColumn('custrecord_aw_wo_property','custcol_aw_time_work_order'));//8
		hist_srch.addColumn(new nlobjSearchColumn('internalid','custcol_aw_time_work_order'));//9
		hist_srch.addColumn(new nlobjSearchColumn('name','custcol_aw_time_work_order'));//10
		
//		var hist_srch = nlapiCreateSearch('timebill', srch_fil, srch_cols);
		var hist_res = hist_srch.runSearch();
		var hist_cols = hist_res.getColumns();


		hist_res.forEachResult(function(hist_recs){
			nlapiLogExecution('ERROR', 'hrs time bill', hist_recs.getValue(hist_cols[7]));
			var sd = hist_recs.getValue(hist_cols[1]);
			var ed = hist_recs.getValue(hist_cols[3]);
			var st = hist_recs.getValue(hist_cols[2]);
			var et = hist_recs.getValue(hist_cols[4]);
			var wo = hist_recs.getValue(hist_cols[10])+"("+hist_recs.getText(hist_cols[8])+")";


			var startDte = sd;
			startDte = nlapiStringToDate(startDte);



			var yearStart = new Date(dt_for_srch.getFullYear(),0,1);
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil(( ( (dt_for_srch - yearStart) / 86400000)+1)/7);
			nlapiLogExecution('DEBUG', 'week no', weekNo);

			wk = weekNo;


			var time = st.split(' '); 
			var stimeval = time[0].split(':');
			if(time[1]=='am' && stimeval[0]== 12){
				stHour = 0;// stimeval[1]);
			}else{
				if(time[1]=='pm' && stimeval[0]!= 12){
					stHour = parseInt(stimeval[0])+12;// stimeval[1]);
				}else{
					stHour = stimeval[0];// stimeval[1]);
				}	    
			}
			var etime = et.split(' '); 
			var etimeval = etime[0].split(':');
			if(etime[1]=='am' && etimeval[0] == 12){
				enHour = 0;
			}else{
				if(etime[1]=='pm' && etimeval[0] != 12){
					enHour = parseInt(etimeval[0])+12;
				}else{
					enHour = etimeval[0];// etimeval[1]); 
				}	    	 
			}


			//pending lines for dates

//			var sd_ar = sd.split('/');
//			var ed_ar = ed.split('/');


//			var date1 = new Date(sd_ar[2],(parseInt(sd_ar[1])-1) , 1,  9, 0); 
//			var date2 = new Date(2000, 0, 1, 17, 0);
//			var diff_dats = date2 - date1;
//			var msec = diff_dats;
//			var hh = Math.floor(msec / 1000 / 60 / 60);
//			msec -= hh * 1000 * 60 * 60;
//			var mm = Math.floor(msec / 1000 / 60);
//			msec -= mm * 1000 * 60;



//			nlapiLogExecution('ERROR', 'end hour', enHour);
//			nlapiLogExecution('ERROR', 'start hour', stHour);
//			nlapiLogExecution('DEBUG', 'diff hr and min', hh+' and '+mm);
			var diffHour = enHour - stHour;
			var diffMinute = (etimeval[1] - stimeval[1])/60;
			var h = diffHour*1 + diffMinute*1;
			if(isNaN(h))
				{
				
				}else{
					hrs_per_day+= h*1;		
				}
			
			//time duration calculation

wo = wo.replace(/,/g, " ");

			history_data_sd.push(sd);
			history_data_ed.push(ed);
			history_data_st.push(st);
			history_data_et.push(et);
			history_data_wo.push(wo);
			history_data_hrs.push(hist_recs.getValue(hist_cols[7]));
			history_data_week.push(weekNo);


			return true;
		});
	var compile=new Array();
	compile.push(history_data_sd);
	compile.push(history_data_ed);
	compile.push(history_data_st);
	compile.push(history_data_et);
	compile.push(history_data_wo);
	compile.push(history_data_hrs);
	compile.push(history_data_week);
	compile.push(wk);
	compile.push(hrs_per_day);
	return compile;
}