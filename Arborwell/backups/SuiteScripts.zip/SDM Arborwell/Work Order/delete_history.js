function delete_history(recType,recId){
	nlapiDeleteRecord(recType,recId);
}