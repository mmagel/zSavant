function get_employee_search(request,response){
	var filters=new Array();
	for (var i=1; request.getParameter('f'+i)!=null; i++){
		var filter=request.getParameter('f'+i);
		var f=filter.split('-');
		filter=new nlobjSearchFilter(f[0],f[1],f[2],f[3]);
		filters.push(filter);
	}
	var columns=new Array();
	var columnstring=new Array();
	for (var i=1; request.getParameter('c'+i)!=null; i++){
		var column=request.getParameter('c'+i);
		columnstring.push(column);
		column=new nlobjSearchColumn(column);
		columns.push(column);
	}
	var results=nlapiSearchRecord(null,'customsearch983',filters,columns);
	var array=new Array();
	for (var i=0; results!=null && i<results.length; i++){
		var object=new Object();
		for (var j=0;j<columns.length; j++){
			object[columnstring[j]]=results[i].getValue(columns[j]);
		}
		array.push(object);
	}
	response.write(JSON.stringify(array));
}