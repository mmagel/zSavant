function estimate_add_markup(type) {

    //nlapiLogExecution('DEBUG', 'DEBUG', type);
    //if (nlapiGetFieldValue('customform')==138){

    var markUpItem = 1621; // 3% markup // 2% markup 1612
    var user = nlapiGetUser();

    var recordType = nlapiGetRecordType();
    var recordStatus = nlapiGetFieldValue('status');
    nlapiLogExecution('DEBUG', 'recordStatus', recordStatus);

    if (recordType == 'salesorder') {

        //var createdFrom = nlapiGetFieldValue('createdfrom');
        //if (createdFrom)
        //return;

        if (recordStatus == 'Pending Approval'
            || recordStatus == 'Pending Fulfillment'
            || !recordStatus) {
        }
        else
            return;
    }

    var disp = nlapiGetFieldValue('custbody_waive_disposal');
    var markupindex = -1;
    var markupamt = parseFloat(0);
    var rate = nlapiLookupField('otherchargeitem', markUpItem, 'custitem_markup_multiplier');

    if (type == 'create' || type == 'edit' || type == 'copy') {

        var markuplines = 0;

        var lines = nlapiGetLineItemCount('item');
        for (var i = 1; i <= lines; i++) {

            nlapiSelectLineItem('item', i);
            var sched = nlapiGetCurrentLineItemValue('item', 'custcol_tax_schedule');
            var amount = parseFloat(nlapiGetCurrentLineItemValue('item', 'amount'));
            var item = nlapiGetCurrentLineItemValue('item', 'item');
            var wt = nlapiLookupField('item', item, 'class');
            var markline = nlapiGetCurrentLineItemValue('item', 'custcol_markline');

            if (item != markUpItem && disp != 'T' && (wt == 2 || wt == 8)) {
                markupamt = parseFloat(parseFloat(markupamt) + parseFloat(amount * rate)).toFixed(2);
                //nlapiLogExecution('DEBUG', i, parseFloat(amount * rate));
            }

            //nlapiLogExecution('DEBUG', i, markline + ' ' + item + ' ' + amount);
            if (item == markUpItem && markline == 'T') {
                markupindex = i;
            }
        }

        nlapiLogExecution('DEBUG', 'markupindex', markupindex);
        nlapiLogExecution('DEBUG', 'markupamt', markupamt);

        if (markupamt > 0) {
            if (markupindex == -1) {
                nlapiSelectNewLineItem('item');
            }
            else {
                nlapiSelectLineItem('item', markupindex);
            }
            nlapiSetCurrentLineItemValue('item', 'item', markUpItem); //partial use tax
            nlapiSetCurrentLineItemValue('item', 'quantity', 1);
            nlapiSetCurrentLineItemValue('item', 'rate', markupamt);
            nlapiSetCurrentLineItemValue('item', 'custcol_markline', 'T');
            nlapiSetCurrentLineItemValue ( 'item' , 'istaxable' , 'F'); //set to not be taxable -RB 2/26/18
            nlapiCommitLineItem('item');
        }

        else {
            if (markupindex != -1) {
                nlapiRemoveLineItem('item', markupindex);
            }
        }
    }

    //}
}