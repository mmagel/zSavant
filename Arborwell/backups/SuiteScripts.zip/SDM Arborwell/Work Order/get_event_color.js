function get_colors(request,response){
	if (request.getMethod()=='GET'){
		var colors=nlapiSearchRecord('classification',null,[new nlobjSearchFilter('isinactive',null,'is','F'),new nlobjSearchFilter('custrecord_colorid',null,'isnot','8')],[new nlobjSearchColumn('name'),new nlobjSearchColumn('custrecord_color').setSort(true)]);
		var table='<table border=\'1\'><tr><td>Work Type</td><td>Color</td></tr>';
		var tab=new Object();
		for (var i=0;colors!=null&&i<colors.length;i++){
			table+='<tr><td style=\'font-size:9px;\'>'+colors[i].getValue('name')+'</td>'+'<td style=\'background-color:'+colors[i].getValue('custrecord_color')+';\'>&nbsp;</td></tr>';
			tab[colors[i].getValue('name')]=colors[i].getValue('custrecord_color');
		}
		table+='</table>';
		response.setHeader('Custom-Header-Access-Control-Allow-Origin','*');
		response.write('document.body.innerHTML+="'+table+'";');
	}
}