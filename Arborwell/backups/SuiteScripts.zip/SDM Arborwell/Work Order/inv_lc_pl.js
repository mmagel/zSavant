function invoice_search(portlet,column){
	var lastmonthstart=firstDayInPreviousMonth(new Date());
	var lastday=new Date(lastmonthstart.getFullYear(),lastmonthstart.getMonth()+1,0);
	portlet.setScript('customscript206')
	portlet.setTitle('Labor Cost/Invoice Search');
	portlet.addField('custpage_startdate','date','Start Date').setLayoutType('startrow','startcol').setDefaultValue(nlapiDateToString(lastmonthstart));
	portlet.addField('custpage_enddate','date','End Date').setLayoutType('startrow').setDefaultValue(nlapiDateToString(lastday));
	portlet.addField('custpage_region','select','Region','location').setLayoutType('startrow');
	var fld = portlet.addField("custpage_google", "inlinehtml").setLayoutType('startrow');
    fld.setDefaultValue('<script type="text/javascript" src="https://www.google.com/jsapi"></script> <script type="text/javascript">google.load("visualization", "1", { packages: ["table"] });google.setOnLoadCallback(drawTable);</script><div id="table_div" style="height:400px;"></div>');
}
function firstDayInPreviousMonth(yourDate) {
    var d = new Date(yourDate);
    d.setDate(1);
    d.setMonth(d.getMonth() - 1);
    return d;
}
function format_money(int){
    var n = int, 
        c = isNaN(c = Math.abs(c)) ? 2 : c, 
        d = d == undefined ? "." : d, 
        t = t == undefined ? "," : t, 
        s = n < 0 ? "-" : "", 
        i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
        j = (j = i.length) > 3 ? j % 3 : 0;
       return '$'+s+(j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
    }
function drawTable() {

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Client');
    data.addColumn('string', 'Work Order');
    data.addColumn('string', 'Property');
    data.addColumn('string', 'Sales Order');
    data.addColumn('string', 'SO Status');
    data.addColumn('string', 'Invoice');
    data.addColumn('number', 'Time');
    data.addColumn('number', 'Invoice Value');
    data.addColumn('number', 'Labor Cost');
    var sd=nlapiGetFieldValue('custpage_startdate');
    var ed=nlapiGetFieldValue('custpage_enddate');
    var region=nlapiGetFieldValue('custpage_region');
    if (region==''||region==''){
    	region=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
    }
    var totaltime=parseFloat(0);
    var totalval=parseFloat(0);
    var totallabor=parseFloat(0);

    var time_results=nlapiSearchRecord('timebill',null,[new nlobjSearchFilter('date',null,'within',sd,ed),new nlobjSearchFilter('custrecord_aw_salesorder_region','custcol_aw_time_work_order','anyof',region)],
    		[new nlobjSearchColumn('custcol_aw_time_work_order',null,'group').setSort(true),
             new nlobjSearchColumn('durationdecimal',null,'sum'),
             new nlobjSearchColumn('custcol_aw_time_labor_cost',null,'sum'),
             new nlobjSearchColumn('custrecord_aw_wo_property','custcol_aw_time_work_order','group'),
             new nlobjSearchColumn('custrecord_aw_wo_client','custcol_aw_time_work_order','group'),
             new nlobjSearchColumn('custrecord_aw_wo_so','custcol_aw_time_work_order','max')]);

    var invresults=nlapiSearchRecord('invoice',null,[new nlobjSearchFilter('location',null,'anyof',region),new nlobjSearchFilter('trandate',null,'within',sd,ed),new nlobjSearchFilter('mainline',null,'is','T')],
    		[new nlobjSearchColumn('createdfrom',null,'group'),
    		 new nlobjSearchColumn('statusref','createdfrom','group'),
             new nlobjSearchColumn('amount',null,'sum'),
             new nlobjSearchColumn('entity',null,'group'),
             new nlobjSearchColumn('tranid',null,'group'),
             new nlobjSearchColumn('custbody_aw_property',null,'group'),
             new nlobjSearchColumn('custbody_aw_work_order','createdfrom','group')]);
    		 var labor_wo=new Array();

    	//alert(invresults.length); alert(time_results.length);
    		 var arr;
    	for (var i=0; invresults!=null&&i<invresults.length; i++){
    		arr=new Array();
    		
    		arr.push(invresults[i].getText('entity',null,'group'));
    		arr.push(invresults[i].getText('custbody_aw_work_order','createdfrom','group'));
    		arr.push(invresults[i].getText('custbody_aw_property',null,'group'));
    		arr.push(invresults[i].getText('createdfrom',null,'group'));
    		arr.push(invresults[i].getText('statusref','createdfrom','group'));
    		arr.push(invresults[i].getValue('tranid',null,'group'));
    		var found=false;
    		for (var j=0; j<time_results.length; j++){
    			if (time_results[j].getValue('custcol_aw_time_work_order',null,'group')==invresults[i].getText('custbody_aw_work_order','createdfrom','group')){
    				arr.push({v:parseFloat(time_results[j].getValue('durationdecimal',null,'sum'))});
    				arr.push({v:parseFloat(invresults[i].getValue('amount',null,'sum')),f:format_money(invresults[i].getValue('amount',null,'sum'))});
    				arr.push({v:parseFloat(time_results[j].getValue('custcol_aw_time_labor_cost',null,'sum')),f:format_money(time_results[j].getValue('custcol_aw_time_labor_cost',null,'sum'))});
    				 totaltime=parseFloat(parseFloat(totaltime)+parseFloat(time_results[j].getValue('durationdecimal',null,'sum')));
    				 totalval=parseFloat(parseFloat(totalval)+parseFloat(invresults[i].getValue('amount',null,'sum')));
    				 totallabor=parseFloat(parseFloat(totallabor)+parseFloat(time_results[j].getValue('custcol_aw_time_labor_cost',null,'sum')));
    				found=true;
    				break;
    			}
    		}
    		
    		if (found){
    			
    			data.addRow(arr);
    			labor_wo.push(invresults[i].getValue('custbody_aw_work_order','createdfrom','group'));
    		}    		
    	}
    	var arr=new Array();
    	//alert('1');
    	var wos=new Array();
    	var nobills=new Array();
    	for (var j=0; j<time_results.length; j++){
			if (labor_wo.indexOf((time_results[j].getValue('custcol_aw_time_work_order',null,'group')))<0){
				wos.push(time_results[j].getValue('custcol_aw_time_work_order',null,'group'));
				nobills.push(time_results[j]);
			}
    	}

    	var wossearch=nlapiSearchRecord('customrecord_aw_work_order',null,new nlobjSearchFilter('internalid',null,'anyof',wos),[new nlobjSearchColumn('internalid',null,'group').setSort(true),new nlobjSearchColumn('statusref','custrecord_aw_wo_so','group')]);

    	for (var j=0; j<nobills.length; j++){
    		
			//if (labor_wo.indexOf((time_results[j].getValue('custcol_aw_time_work_order',null,'group')))<0){
				arr.push(nobills[j].getText('custrecord_aw_wo_client','custcol_aw_time_work_order','group'));
	    		arr.push(nobills[j].getText('custcol_aw_time_work_order',null,'group'));
	    		arr.push(nobills[j].getText('custrecord_aw_wo_property','custcol_aw_time_work_order','group'));
	    		arr.push(nobills[j].getValue('custrecord_aw_wo_so','custcol_aw_time_work_order','max'));
	    		//alert(nobills[j].getValue('custcol_aw_time_work_order',null,'group')+' '+wossearch[j].getValue('internalid',null,'group'));
	    		arr.push(wossearch[j].getText('statusref','custrecord_aw_wo_so','group'));
	    		arr.push('');
				arr.push({v:parseFloat(nobills[j].getValue('durationdecimal',null,'sum'))});
				arr.push({v:0,f:format_money(0)});
				arr.push({v:parseFloat(nobills[j].getValue('custcol_aw_time_labor_cost',null,'sum')),f:format_money(nobills[j].getValue('custcol_aw_time_labor_cost',null,'sum'))});
				
				data.addRow(arr);

				totaltime=parseFloat(parseFloat(totaltime)+parseFloat(nobills[j].getValue('durationdecimal',null,'sum')));
				 totalval=parseFloat(parseFloat(totalval)+parseFloat(0));
				 totallabor=parseFloat(parseFloat(totallabor)+parseFloat(nobills[j].getValue('custcol_aw_time_labor_cost',null,'sum')));
				var arr=new Array();
			//}
		}
    	arr.push('Total');
		arr.push('');
		arr.push('');
		arr.push('');
		arr.push('');
		arr.push('');
		arr.push({v:totaltime,f:totaltime.toFixed(2)});
		arr.push({v:totalval,f:format_money(totalval)});
		arr.push({v:totallabor,f:format_money(totallabor)});
		data.addRow(arr);
    	//alert('2');
    //	alert('here1');
    var table = new google.visualization.Table(document.getElementById('table_div'));

    table.draw(data, {showRowNumber: true, allowHtml:true, width: '100%', height: '100%'});
 }
function table_field_changed(type,name,linenum){
	drawTable();
}
