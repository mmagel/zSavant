
function invoice_search(portlet,column){
	var lastmonthstart=firstDayInPreviousMonth(new Date());
	var lastday=new Date(lastmonthstart.getFullYear(),lastmonthstart.getMonth()+1,0);
	portlet.setScript('customscript277');
	portlet.setTitle('Invoice Geochart');
	portlet.addField('custpage_startdate','date','Start Date').setLayoutType('startrow','startcol').setDefaultValue(nlapiDateToString(lastmonthstart));
	portlet.addField('custpage_enddate','date','End Date').setLayoutType('startrow').setDefaultValue(nlapiDateToString(lastday));
	portlet.addField('custpage_region','select','Region','location').setLayoutType('startrow');
	var fld = portlet.addField("custpage_google", "inlinehtml").setLayoutType('startrow');
    fld.setDefaultValue('<script type="text/javascript" src="https://www.google.com/jsapi"></script> <script type="text/javascript">google.load("visualization", "1", { packages: ["geochart"] });google.setOnLoadCallback(drawChart);</script><div id="chart_div" style="height:400px;"></div>');
}
function firstDayInPreviousMonth(yourDate) {
    var d = new Date(yourDate);
    d.setDate(1);
    d.setMonth(d.getMonth() - 1);
    return d;
}
function format_money(int){
    var n = int, 
        c = isNaN(c = Math.abs(c)) ? 2 : c, 
        d = d == undefined ? "." : d, 
        t = t == undefined ? "," : t, 
        s = n < 0 ? "-" : "", 
        i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
        j = (j = i.length) > 3 ? j % 3 : 0;
       return '$'+s+(j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
    }
function drawChart() {
	var options = {
	        region: 'US-CA',
	        resolution: 'provinces',
	        displayMode: 'markers',
	        colorAxis: {colors: ['red', 'green']}
	      };
    var data = new google.visualization.DataTable();
    data.addColumn('number','Latitude');
    data.addColumn('number','Longitude');
    data.addColumn('number','Invoice Amount');
    //data.addColumn('string','Client');
    //data.addColumn('string','Work Order');
   // data.addColumn('string','Property');
   // data.addColumn('string','Sales Order');
    //data.addColumn('string','Invoice');
    ;

    var sd=nlapiGetFieldValue('custpage_startdate');
    var ed=nlapiGetFieldValue('custpage_enddate');
    var region=nlapiGetFieldValue('custpage_region');
    if (region==''||region==''){
    	region=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
    }



    var invresults=nlapiSearchRecord('invoice',null,[new nlobjSearchFilter('custrecord_long','custbody_aw_property','isnotempty'),new nlobjSearchFilter('custrecord_lat','custbody_aw_property','isnotempty'),new nlobjSearchFilter('location',null,'anyof',region),new nlobjSearchFilter('trandate',null,'within',sd,ed),new nlobjSearchFilter('mainline',null,'is','T')],
    		[new nlobjSearchColumn('createdfrom'),
             new nlobjSearchColumn('amount'),
             new nlobjSearchColumn('entity'),
             new nlobjSearchColumn('tranid'),
             new nlobjSearchColumn('custbody_aw_property'),
             new nlobjSearchColumn('custbody_aw_work_order','createdfrom'),
    		 new nlobjSearchColumn('custrecord_lat','custbody_aw_property'),
    		 new nlobjSearchColumn('custrecord_long','custbody_aw_property')]);
    		 var labor_wo=new Array();
    	//alert(invresults.length); alert(time_results.length);
    		 var arr;
    		 var arr=new Array();
    	for (var i=0; invresults!=null&&i<invresults.length; i++){
    		data.addRow([parseFloat(invresults[i].getValue('custrecord_lat','custbody_aw_property')),
    		             parseFloat(invresults[i].getValue('custrecord_long','custbody_aw_property')),
    		            		 parseFloat(invresults[i].getValue('amount')),
    				//invresults[i].getValue('entity'),
    				//invresults[i].getValue('custbody_aw_work_order'),
    				//invresults[i].getValue('custbody_aw_property'),
    				//invresults[i].getValue('createdfrom'),
    				//invresults[i].getValue('tranid')
    				]);
    	}
    	//alert('2');
    //	alert('here1');
    	 var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
         chart.draw(data, options);
 }
function chart_field_changed(type,name,linenum){
	drawChart();
}
