function prop_mu(r,id){
	var rec=nlapiLoadRecord(r,id,{recordmode:'dynamic'});
	nlapiSubmitRecord(rec);
}