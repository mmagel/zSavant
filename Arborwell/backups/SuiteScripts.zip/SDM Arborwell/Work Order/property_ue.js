function property_before_load(type)
{
	if (type=='create'||type=='edit'){
    	var fld = form.addField("custpage_google", "inlinehtml").setLayoutType('startrow');
    	fld.setDefaultValue('<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyANeqMrmHFy3VXAEC76i_nC8VJWqIylMEo"></script><div id="map_div" style="width: 900px; height: 500px;"></div>');
	}
}  
function property_field_changed(type,name,linenum){

	if (name!='custrecord_lat'&&name!='custrecord_long'&&nlapiGetUser()==11947)
		geocodeprop();

}
function geocodeprop (){
	var  geocoder = new google.maps.Geocoder();
	var addressstring='';

	var addr1=nlapiGetFieldValue('custrecord_aw_address_1');

	var addr2=nlapiGetFieldValue('custrecord_aw_address_2');

	var addr3=nlapiGetFieldValue('custrecord_aw_address_3');

	var city=nlapiGetFieldValue('custrecord_aw_city');
	var state=nlapiGetFieldText('custrecord_aw_state');
	var zip=nlapiGetFieldValue('custrecord_aw_zip');
	var county=nlapiGetFieldText('custrecord_aw_county');

	var add=true;
	if (addr1!=''&&addr1!=null){
		addressstring+=addr1+', ';
	}
	else {
		add=false;
	}
	if (addr2!=''&&addr2!=null){
		addressstring+=addr2+', ';
	}
	if (addr3!=''&&addr3!=null){
		addressstring+=addr3+', ';
	}
	if (city!=''&&city!=null){
		addressstring+=city+', ';
	}
	else {
		add=false;
	}
	if (state!=''&&state!=null){
		addressstring+=state+', ';
	}
	else {
		add=false;
	}
	if (zip!=''&&zip!=null){
		addressstring+=zip;
	}
	else {
		add=false;
	}
	if (add&&addressstring!=''){
		Geocode(addressstring,geocoder);
	}
}
function Geocode(address,geocoder) {
    geocoder.geocode({
        'address': address
    }, function(results, status) {
    	
        if (status === google.maps.GeocoderStatus.OK) {
        	var lat=results[0].geometry.location.lat();
        	var long=results[0].geometry.location.lng();
        	nlapiSetFieldValue('custrecord_lat',lat);
        	nlapiSetFieldValue('custrecord_long',long);
  
        } else if (status === google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {    
            setTimeout(function() {
                Geocode(address,id);
            }, 200);
        } else {
            nlapiLogExecution('ERROR','Geocode Error',"Geocode was not successful for the following reason:" + status);
        }
    });
}