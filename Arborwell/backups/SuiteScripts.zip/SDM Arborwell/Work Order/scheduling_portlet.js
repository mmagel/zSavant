function production_manager_portlet(portlet, column){

	
	    portlet.setTitle("Scheduling Portlet");
	    portlet.setScript('customscript349');
	    
	    portlet.addField('custpage_liness','inlinehtml','').setLayoutType('startrow','startcol').setDefaultValue('<div style="font-size:14px; width:950px;"><br/> Work Order Filters <hr> </div>');
	    var region =portlet.addField('custpage_region','select','Region','location').setLayoutType('startrow');
	    
	   // if (nlapiGetRole()==1017)
	    //	region.setDisplayType('inline');
	    nlapiLogExecution('ERROR','role',nlapiGetRole());
	    portlet.addField('custpage_role','text','Sales Rep').setDisplayType('hidden').setDefaultValue(nlapiGetRole());
	    region.setDefaultValue(nlapiLookupField('employee',nlapiGetUser(),'location'));
	    portlet.addField('custpage_rep','select','Sales Rep','employee').setLayoutType('endrow');
	    
	    portlet.addField('custpage_wonumtext','text','Search Work Order').setLayoutType('startrow');
		portlet.addField('custpage_proptext','text','Search Property').setLayoutType('midrow');
		portlet.addField('custpage_clienttext','text','Search Client').setLayoutType('endrow');
	    
	    portlet.addField('custpage_wonum','select','Work Order').setLayoutType('startrow');
	    portlet.addField('custpage_prop','select','Property').setLayoutType('midrow');
	    portlet.addField('custpage_client','select','Client').setLayoutType('endrow');
	    
	    portlet.addField('custpage_lines','inlinehtml','').setLayoutType('startrow').setDefaultValue('<div style="font-size:14px; width:950px;"><br/> Schedule <hr> </div>');
	    portlet.addField('custpage_colors','inlinehtml','').setLayoutType('startrow').setDefaultValue('&nbsp;');
	    var foremenfield=portlet.addField('custpage_foreman','select','Foreman').setLayoutType('startrow').setMandatory(true);
	   // customlist364
	    portlet.addField('custpage_authorized','checkbox','').setDisplayType('hidden');
	    portlet.addField('custpage_date','date','Date').setLayoutType('midrow').setMandatory(true);
	    portlet.addField('custpage_starttime','select','Start Time','customlist364').setLayoutType('midrow').setMandatory(true);
	    portlet.addField('custpage_endtime','select','End Time','customlist364').setLayoutType('midrow').setMandatory(true);
	    portlet.addField('custpage_rec','integer','Number Of Days').setLayoutType('midrow');
	    portlet.addField('custpage_numpeople','integer','Number Of People').setLayoutType('endrow');
		portlet.addField('custpage_myloc','text','').setDisplayType('hidden').setDefaultValue(nlapiLookupField('employee',nlapiGetUser(),'location'));
		var cals=nlapiSearchRecord('customrecord_calendar','customsearch_calssearch',
				null,[new nlobjSearchColumn('isinactive','custrecord_calendar_employee'),new nlobjSearchColumn('email','custrecord_calendar_employee'),new nlobjSearchColumn('entityid','custrecord_calendar_employee'),new nlobjSearchColumn('custrecord_calendar_id'),new nlobjSearchColumn('name'),new nlobjSearchColumn('custrecord_calendar_id','custrecord_parent_calendar'),new nlobjSearchColumn('name','custrecord_parent_calendar'),new nlobjSearchColumn('custrecord_calendar_employee'),new nlobjSearchColumn('title','custrecord_calendar_employee'),new nlobjSearchColumn('location','custrecord_calendar_employee')]);
				var array=new Array();
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				array.push(new Array());
				for (var i=0;i<cals.length;i++){
					array[0].push(cals[i].getValue('custrecord_calendar_id'));
					array[1].push(cals[i].getValue('name'));
					array[2].push(cals[i].getValue('custrecord_calendar_id','custrecord_parent_calendar'));
					array[3].push(cals[i].getValue('name','custrecord_parent_calendar'));
					array[4].push(cals[i].getValue('custrecord_calendar_employee'));
					array[5].push(cals[i].getValue('email','custrecord_calendar_employee'));
					
					array[6].push(cals[i].getValue('entityid','custrecord_calendar_employee'));
					var submails=nlapiSearchRecord('employee',null,new nlobjSearchFilter('supervisor',null,'anyof',cals[i].getValue('custrecord_calendar_employee')),[new nlobjSearchColumn('email'),new nlobjSearchColumn('internalid')]);
					var emails=new Array();
					for (var j=0; submails!=null&&j<submails.length; j++){
						emails.push(submails[j].getValue('email'));
					}
					
					nlapiLogExecution('ERROR','emails '+cals[i].getValue('custrecord_calendar_employee')+' ',emails);
					array[7].push(emails);
					array[8].push(cals[i].getValue('location','custrecord_calendar_employee'));
					array[9].push(cals[i].getValue('title','custrecord_calendar_employee'));
					array[10].push(cals[i].getValue('isinactive','custrecord_calendar_employee'));
				}
	    portlet.addField('custpage_cals','longtext','').setDisplayType('hidden').setDefaultValue(JSON.stringify(array));
	    portlet.addField('custpage_auth','inlinehtml','').setLayoutType('startrow').setDefaultValue('<script src="https://apis.google.com/js/client.js?onload=checkAuth"></script>');
	    portlet.addField("custpage_schedule", "inlinehtml",'').setLayoutType('startrow').setDefaultValue('<br/><div style="font-size:14px; width:950px;"><hr><br/><button style=" width:200px; height: 28px; font-size:14px;" onclick="get_selected(); return false;">Schedule Selected</button>'+
	    		' &nbsp; &nbsp; &nbsp; &nbsp; <button style=" width:200px; height: 28px; font-size:14px;" onclick="drawTable(); return false;">Refresh</button></div><br/>');
	    var fld = portlet.addField("custpage_google", "inlinehtml").setLayoutType('startrow');
	    fld.setDefaultValue('<script type="text/javascript" src="https://www.google.com/jsapi"></script> <script type="text/javascript">var table; var data; google.load("visualization", "1", { packages: ["table"] }); google.setOnLoadCallback(dum);</script><div id="table_div" style="height:600px; width:970px;"></div>');
	    
}
function pl_field_changed(type,name,linenum){
	if (name=='custpage_wonumtext'){
		nlapiRemoveSelectOption('custpage_wonum',null);
		//var results=nlapiLoadSearch('customrecord_aw_work_order','customsearch943');
		//var filters=results.getFilters();
		//var columns=results.getColumns();
		///for (var i=0;i<filters.length;i++){
		//	alert(filters[i].getName());
		//}
		//for (var i=0;i<columns.length;i++){
		//	alert(columns[i].getName());
		//}
		//return;
		nlapiInsertSelectOption('custpage_wonum',0,'',true);
		if (nlapiGetFieldValue(name)!=''){
			var results=nlapiSearchRecord('customrecord_aw_work_order',null,new nlobjSearchFilter('idtext',null,'contains',nlapiGetFieldValue(name)),[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('name').setSort(true)]);
		
			for (var i=0;results!=null&&i<results.length;i++){
				nlapiInsertSelectOption('custpage_wonum',results[i].getValue('internalid'),results[i].getValue('name'),false);
			}
		}
	}
	else if (name=='custpage_proptext'){
		nlapiRemoveSelectOption('custpage_prop',null);
		
		nlapiInsertSelectOption('custpage_prop',0,'',true);
		if (nlapiGetFieldValue(name)!=''){
			var results=nlapiSearchRecord('customrecord_aw_property',null,new nlobjSearchFilter('name',null,'contains',nlapiGetFieldValue(name)),[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('name').setSort(true)]);
			for (var i=0;results!=null&&i<results.length;i++){
				nlapiInsertSelectOption('custpage_prop',results[i].getValue('internalid'),results[i].getValue('name'),false);
			}
		}
	}
	else if (name=='custpage_clienttext'){
		nlapiRemoveSelectOption('custpage_client',null);
		
		nlapiInsertSelectOption('custpage_client',0,'',true);
		if (nlapiGetFieldValue(name)!=''){
			var results=nlapiSearchRecord('customer',null,new nlobjSearchFilter('entityid',null,'contains',nlapiGetFieldValue(name)),[new nlobjSearchColumn('internalid'),new nlobjSearchColumn('entityid').setSort(true)]);
			for (var i=0;results!=null&&i<results.length;i++){
				nlapiInsertSelectOption('custpage_client',results[i].getValue('internalid'),results[i].getValue('entityid'),false);
			}
		}
	}
}
//google.setOnLoadCallback(drawTable);
function drawTable() {
	
try {
	if (nlapiGetFieldValue('custpage_authorized')!='T'){
		alert('authorize access to google calendar to use scheduler.');
		return;
	}


    var employee=nlapiGetFieldValue('custpage_rep');
    var region=nlapiGetFieldValue('custpage_region');
    var prop=nlapiGetFieldValue('custpage_prop');
    var client=nlapiGetFieldValue('custpage_client');
    var wonum=nlapiGetFieldValue('custpage_wonum');

    var f1time='';
    var f1='';
    var f2time='';
    var f2='';
    var f3time='';
    var f3='';
    var f4time='';
    var f4='';
    var f5time='';
    var f5='';

	if (employee!=''&&employee!=null){
		f1=new nlobjSearchFilter('custrecord_aw_wo_sales_rep',null,'anyof',employee);
		f1time=new nlobjSearchFilter('custrecord_aw_wo_sales_rep','custcol_aw_time_work_order','anyof',employee);
	}
	if (region!=''&&region!=null&&region!=0){

		f2=new nlobjSearchFilter('custrecord_aw_salesorder_region',null,'anyof',region);
		f2time=new nlobjSearchFilter('custrecord_aw_salesorder_region','custcol_aw_time_work_order','anyof',region);
		nlapiRemoveSelectOption('custpage_foreman',null);
		var foremen;
		var stumps;
		var phc;
		var cals=JSON.parse(nlapiGetFieldValue('custpage_cals'));
		var ids=new Array();
		var names=new Array();
		if (nlapiGetFieldValue('custpage_role')==3){

			//var args='&f1=title-null-is-Foreman&f2=isinactive-null-is-F&c1=internalid&c2=entityid';
			//foremen=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');

			//var args='&f1=title-null-is-Stump Grinder&f2=isinactive-null-is-F&c1=internalid&c2=entityid';
			//stumps=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');

			//var args='&f1=title-null-is-PHC Technician&f2=isinactive-null-is-F&c1=internalid&c2=entityid';
			//phc=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');
			for (var i=0; i<cals[9].length; i++){
				//alert(cals[9][i]+' '+cals[10][i]);
				if ((cals[9][i]=='Foreman'||cals[9][i]=='Stump Grinder'||cals[9][i]=='PHC Technician')&&cals[10][i]!='T'){
					names.push(cals[6][i]);
					ids.push(cals[4][i]);
				}
			}
		}
		else {
			//var args='&f1=internalid-null-anyof-'+nlapiGetUser()+'&c1=location';
			//var myloc=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');
			var myloc=nlapiGetFieldValue('custpage_myloc');
			////var args='&f1=location-null-anyof-'+myloc[0]['location']+'&f2=isinactive-null-is-F&f3=title-null-is-Foreman&c1=internalid&c2=entityid';
			///var args='&f1=isinactive-null-is-F&f2=title-null-is-Foreman&c1=internalid&c2=entityid';
			//foremen=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');

			//var args='&f1=location-null-anyof-'+myloc[0]['location']+'&f2=isinactive-null-is-F&f3=title-null-is-Stump Grinder&c1=internalid&c2=entityid';
			//stumps=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');
			
			//var args='&f1=isinactive-null-is-F&f2=title-null-is-PHC Technician&c1=internalid&c2=entityid';
			//phc=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args,null,null,null,'GET');
			for (var i=0; i<cals[9].length; i++){
				if ((cals[9][i]=='PHC Technician')&&cals[10][i]!='T'){
					names.push(cals[6][i]);
					ids.push(cals[4][i]);
				}
				else if ((cals[9][i]=='Foreman'||cals[9][i]=='Stump Grinder')&&cals[10][i]!='T'&&cals[8][i]==myloc){
					names.push(cals[6][i]);
					ids.push(cals[4][i]);
				}
			}
		}

		nlapiInsertSelectOption('custpage_foreman',0,'',true);
		//alert(JSON.stringify(foremen));
		//foremen=JSON.parse(foremen.getBody());
		//stumps=JSON.parse(stumps.getBody());
		//phc=JSON.parse(phc.getBody());
		//fore
	    for (var i=0; names!=null && i<names.length; i++){
	    	nlapiInsertSelectOption('custpage_foreman',ids[i],names[i],false);
	    }
	  //  for (var i=0; stumps!=null && i<stumps.length; i++){
	  //  	nlapiInsertSelectOption('custpage_foreman',stumps[i]['internalid'],stumps[i]['entityid'],false);
	  //  }
	//	for (var i=0; phc!=null && i<phc.length; i++){
	  //  	nlapiInsertSelectOption('custpage_foreman',phc[i]['internalid'],phc[i]['entityid'],false);
	 //   }
	}
	if (prop!=''&&prop!=null&&prop!=0){
		f3=new nlobjSearchFilter('custrecord_aw_wo_property',null,'anyof',prop);
		f3time=new nlobjSearchFilter('custrecord_aw_wo_property','custcol_aw_time_work_order','anyof',prop);
	}
	if (client!=''&&client!=null&&client!=0){
		f4=new nlobjSearchFilter('custrecord_aw_wo_client',null,'anyof',client);
		f4time=new nlobjSearchFilter('custrecord_aw_wo_client','custcol_aw_time_work_order','anyof',client);
	}
	if (wonum!=''&&wonum!=null&&wonum!=0){
		f5=new nlobjSearchFilter('internalid',null,'anyof',wonum);
		f5time=new nlobjSearchFilter('internalid','custcol_aw_time_work_order','anyof',wonum);
	}
	
	var datarefreshed=false;

    var search= nlapiCreateSearch('timebill',
    		[new nlobjSearchFilter('custrecord_aw_wo_client','custcol_aw_time_work_order','noneof',[2216,2217]),new nlobjSearchFilter('custrecord_aw_wo_status','custcol_aw_time_work_order','noneof',3)],
    [new nlobjSearchColumn('durationdecimal',null,'sum'),
     new nlobjSearchColumn('custrecord_sdm_est_hrs_wo','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_status','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_date','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_client','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_sales_rep','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_property','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord_aw_wo_so','custcol_aw_time_work_order','max'),
     new nlobjSearchColumn('custrecord_aw_salesorder_region','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custrecord4','custcol_aw_time_work_order','group'),
     new nlobjSearchColumn('custcol_aw_time_work_order',null,'group'),
     new nlobjSearchColumn('internalid','custcol_aw_time_work_order','group').setSort(true)]);
	if (f1!=''){
		search.addFilter(f1time);
	}
	if (f2!=''){
		search.addFilter(f2time);
	}
	if (f3!=''){
		search.addFilter(f3time);
	}
	if (f4!=''){
		search.addFilter(f4time);
	}
	if (f5!=''){
		search.addFilter(f5time);
	}

    var allresults=search.runSearch();

	var j=0;
	var woarray=new Array();
	
	do {
		var thisresults = allresults.getResults(j*1000,j*1000+1000);
	for (var i=0; thisresults!=null&&i<thisresults.length; i++){
		woarray.push(thisresults[i].getValue('custcol_aw_time_work_order',null,'group'));
	}
	j++;
	} while(allresults.getResults(j*1000,j*1000+1000)!=null&&allresults.getResults(j*1000,j*1000+1000).length==1000);
	
	j=0;
//alert(woarray);
	//if (woarray.length==0){
	//	alert('no results found.');
	//	return;
	//}
	if (woarray.length==0){
		woarray.push(0);
	}

	var amtsearch= nlapiCreateSearch('customrecord_aw_work_order',
    		new nlobjSearchFilter('internalid',null,'anyof',woarray),
    [new nlobjSearchColumn('total','custrecord_aw_wo_so','max'),new nlobjSearchColumn('internalid',null,'group').setSort(true)]);

	var amtresults=amtsearch.runSearch();

	do {
		
			var thisamtresults = amtresults.getResults(j*1000,j*1000+1000);
			var thisresults = allresults.getResults(j*1000,j*1000+1000);
			//alert('ss');
		for (var i=0; thisresults!=null&&i<thisresults.length; i++){
			//ordersfound.push(thisresults[i].getValue('internalid','custcol_aw_time_work_order','group'));
			var prevwage='No';
			if (thisresults[i].getValue('custrecord4','custcol_aw_time_work_order','group')=='T'){
				prevwage='Yes';
			}
			if (!datarefreshed){
				datarefreshed=true;
				data = new google.visualization.DataTable();
				data.addColumn('string', 'WO #','wonum');
			    data.addColumn('string', 'Status','wostatus');
			    data.addColumn('date', 'Date','wodate');
			    data.addColumn('string', 'Client','woclient');
			    data.addColumn('string', 'Acct Manager','am');
			    data.addColumn('string', 'Property','property');
			    data.addColumn('string', 'SO','salesorder');
			    data.addColumn('number', 'SO Amt','salesorderamt');
			    data.addColumn('number', 'Est Hours','esthours');
			    data.addColumn('number', 'Actual Hours','acthours');
			    data.addColumn('number', '% Complete','perccomplete');
			    data.addColumn('string', 'Region','region');
			    data.addColumn('string', 'Prev Wage','prevwage');
			    data.addColumn('string', 'ID','woid');
			}
			//a//lert('asdf');
			//alert(thisamtresults[i].getValue('total','custrecord_aw_wo_so','max'));
			var percdone=Number((thisresults[i].getValue('durationdecimal',null,'sum')/thisresults[i].getValue('custrecord_sdm_est_hrs_wo','custcol_aw_time_work_order','group'))*100).toFixed(2);
			data.addRow([thisresults[i].getText('custcol_aw_time_work_order',null,'group'),
			             thisresults[i].getText('custrecord_aw_wo_status','custcol_aw_time_work_order','group'),
			             new Date(thisresults[i].getValue('custrecord_aw_wo_date','custcol_aw_time_work_order','group')),
			             thisresults[i].getText('custrecord_aw_wo_client','custcol_aw_time_work_order','group'),
			             thisresults[i].getText('custrecord_aw_wo_sales_rep','custcol_aw_time_work_order','group'),
			             thisresults[i].getText('custrecord_aw_wo_property','custcol_aw_time_work_order','group'),
			             thisresults[i].getValue('custrecord_aw_wo_so','custcol_aw_time_work_order','max').split('#')[1],
			             {v:Number(thisamtresults[i].getValue('total','custrecord_aw_wo_so','max')),f:String('$'+Number(thisamtresults[i].getValue('total','custrecord_aw_wo_so','max')).toFixed(2))},
			             {v:Number(thisresults[i].getValue('custrecord_sdm_est_hrs_wo','custcol_aw_time_work_order','group')),f:String(Number(thisresults[i].getValue('custrecord_sdm_est_hrs_wo','custcol_aw_time_work_order','group')).toFixed(2))},
						{v:Number(thisresults[i].getValue('durationdecimal',null,'sum')),f:String(Number(thisresults[i].getValue('durationdecimal',null,'sum')).toFixed(2))},
			             {v:Number(percdone),f:percdone+'%'},
			             thisresults[i].getText('custrecord_aw_salesorder_region','custcol_aw_time_work_order','group'),
			             prevwage,
			             thisresults[i].getValue('internalid','custcol_aw_time_work_order','group')]);
		}
		j++;
	} while(allresults.getResults(j*1000,j*1000+1000)!=null&&allresults.getResults(j*1000,j*1000+1000).length==1000);
	//alert(datarefreshed);
	search= nlapiCreateSearch('customrecord_aw_work_order',
    		[new nlobjSearchFilter('mainline','custrecord_aw_wo_so','is','T'),new nlobjSearchFilter('internalid',null,'noneof',woarray),new nlobjSearchFilter('custrecord_aw_wo_client',null,'noneof',[2216,2217]),new nlobjSearchFilter('custrecord_aw_wo_status',null,'anyof',[1,2,4])],
    [
     new nlobjSearchColumn('custrecord_sdm_est_hrs_wo'),
     new nlobjSearchColumn('custrecord_aw_wo_status'),
     new nlobjSearchColumn('custrecord_aw_wo_date'),
     new nlobjSearchColumn('custrecord_aw_wo_client'),
     new nlobjSearchColumn('custrecord_aw_wo_sales_rep'),
     new nlobjSearchColumn('custrecord_aw_wo_property'),
     new nlobjSearchColumn('custrecord_aw_wo_so'),
     new nlobjSearchColumn('total','custrecord_aw_wo_so'),
     new nlobjSearchColumn('name'),
     new nlobjSearchColumn('custrecord_aw_salesorder_region'),
     new nlobjSearchColumn('custrecord4'),
     new nlobjSearchColumn('internalid')]);
	if (f1!=''){
		search.addFilter(f1);
	}
	if (f2!=''){
		search.addFilter(f2);
	}
	if (f3!=''){
		search.addFilter(f3);
	}
	if (f4!=''){
		search.addFilter(f4);
	}
	if (f5!=''){
		search.addFilter(f5);
	}
	allresults=search.runSearch();
	//alert(ordersfound.length)
	var j=0;
	do {

		var thisresults = allresults.getResults(j*1000,j*1000+1000);


		for (var i=0; thisresults!=null&&i<thisresults.length; i++){
			var prevwage='No';
			if (thisresults[i].getValue('custrecord4')=='T'){
				prevwage='Yes';
			}
			var percdone=0;
			if (!datarefreshed){
				datarefreshed=true;
				data = new google.visualization.DataTable();
				data.addColumn('string', 'WO #','wonum');
			    data.addColumn('string', 'Status','wostatus');
			    data.addColumn('date', 'Date','wodate');
			    data.addColumn('string', 'Client','woclient');
			    data.addColumn('string', 'Acct Manager','am');
			    data.addColumn('string', 'Property','property');
			    data.addColumn('string', 'SO','salesorder');
			    data.addColumn('number', 'SO Amt','salesorderamt');
			    data.addColumn('number', 'Est Hours','esthours');
			    data.addColumn('number', 'Actual Hours','acthours');
			    data.addColumn('number', '% Complete','perccomplete');
			    data.addColumn('string', 'Region','region');
			    data.addColumn('string', 'Prev Wage','prevwage');
			    data.addColumn('string', 'ID','woid');
			}
			data.addRow([thisresults[i].getValue('name'),
			             thisresults[i].getText('custrecord_aw_wo_status'),
			             new Date(thisresults[i].getValue('custrecord_aw_wo_date')),
			             thisresults[i].getText('custrecord_aw_wo_client'),
			             thisresults[i].getText('custrecord_aw_wo_sales_rep'),
			             thisresults[i].getText('custrecord_aw_wo_property'),
			             thisresults[i].getText('custrecord_aw_wo_so').split('#')[1],
			             {v:Number(thisresults[i].getValue('total','custrecord_aw_wo_so')),f:String('$'+Number(thisresults[i].getValue('total','custrecord_aw_wo_so')).toFixed(2))},
			             {v:Number(thisresults[i].getValue('custrecord_sdm_est_hrs_wo')),f:String(Number(thisresults[i].getValue('custrecord_sdm_est_hrs_wo')).toFixed(2))},
			             {v:Number(0),f:'0'},
			             {v:Number(percdone),f:percdone+'%'},
			             thisresults[i].getText('custrecord_aw_salesorder_region'),
			             prevwage,
			             thisresults[i].getValue('internalid')]);
		}
		j++;
	} while(allresults.getResults(j*1000,j*1000+1000)!=null&&allresults.getResults(j*1000,j*1000+1000).length==1000);
	if (!datarefreshed){
		alert('no results found.');
		return;
	}
    table = new google.visualization.Table(document.getElementById('table_div'));
    data.sort([{column:11},{column:4}]);
    var view = new google.visualization.DataView(data);
    view.setColumns([0,1,2,3,4,5,6,7,8,9,10,11,12]);
    //google.visualization.events.addListener(table, 'select', selectHandler);
    
    table.draw(view, {showRowNumber: true, allowHtml:true, width: '100%', height: '100%'});
    //table.sort([{column: 2}, {column: 1}]);
}
catch(e){
	alert(e.message);
}
 }
function get_selected(){
	try {
		
	if (nlapiGetFieldValue('custpage_authorized')!='T'){
		alert('authorize access to google calendar to use scheduler.');
		return;
	}
    var numpeople=nlapiGetFieldValue('custpage_numpeople');
	var foreman=nlapiGetFieldValue('custpage_foreman');
	var date=nlapiGetFieldValue('custpage_date');
	var starttime=nlapiGetFieldText('custpage_starttime');
	var endtime=nlapiGetFieldText('custpage_endtime');
	var days=nlapiGetFieldValue('custpage_rec');
	var message='';
	if (foreman==0){
		message+='You must select a foreman to schedule work order(s).\n';
	}
	
	if (date==''){
		message+='You must enter a date to schedule work order(s).\n';
	}
	if (starttime==''){
		message+='You must enter a start time to schedule work order(s).\n';
	}
	if (endtime==''){
		message+='You must enter a end time to schedule work order(s).\n';
	}
	if (days==0||days==1||days==''){
		days=1;
	}
	var enddate=nlapiDateToString(nlapiAddDays(new Date(date),days-1));
	
		  var selection = table.getSelection();
		  var orders=new Array();
		  for (var i = 0; i < selection.length; i++) {
		    var item = selection[i];	
		      if (item.row != null) {
		    	  orders.push(data.getFormattedValue(item.row, 13));
		      }
		  }
		  
	if (orders.length==0){
		message+='No order selected.';
	}

	if (message.length>0){
		message='Schedule failed for the following reason(s):\n'+message;
		alert(message);
		return;
	}
	else {

		//date=date.split('/');

		//date=timeStringToUTC(date[0]+' '+date[1]+' '+date[2]+' '+starttime);
		//date2=timeStringToUTC(date[0]+' '+date[1]+' '+date[2]+' '+endtime);
		var hoursmins=convert_to_military(starttime);
		var date1=new Date(date);
		date1.setHours(parseInt(hoursmins[0]));
		date1.setMinutes(parseInt(hoursmins[1]));
		var date1s=ISODateString(date1);
		
		hoursmins=convert_to_military(endtime);
		var date2=new Date(date);
		date2.setHours(parseInt(hoursmins[0]));
		date2.setMinutes(parseInt(hoursmins[1]));
		var date2s=ISODateString(date2);
		
		//var region=nlapiGetFieldValue('custpage_region');
		//var master=nlapiLookupField('customrecord_calendar',1,'custrecord_calendar_id');
		//var cals=nlapiSearchRecord('customrecord_calendar',null,
		//		[new nlobjSearchFilter('custrecord_calendar_employee',null,'anyof',foreman)],[new nlobjSearchColumn('custrecord_calendar_id'),new nlobjSearchColumn('name'),new nlobjSearchColumn('custrecord_calendar_id','custrecord_parent_calendar'),new nlobjSearchColumn('name','custrecord_parent_calendar')]);
		var cals=JSON.parse(nlapiGetFieldValue('custpage_cals'));
		var calindex=cals[4].indexOf(foreman);
		var ids=new Array();
		//ids.push(master);
		//ids.push('Master Calendar');
		//for (var i=0; cals!=null&&i<cals.length; i++){}
		if (calindex==-1){
			alert('the foreman you selected does not have a google calendar set up. please contact an administrator.');
			return;
		}
					
		ids.push(cals[2][calindex]);
		ids.push(cals[3][calindex]);
		ids.push(cals[0][calindex]);
		ids.push(cals[1][calindex]);
		
		for (var j=0; j<orders.length; j++){
			//get event data
			
			
			var textvals=nlapiLookupField('customrecord_aw_work_order',orders[j],
					['custrecord_aw_wo_client','custrecord_aw_wo_property','custrecord_aw_wo_sales_rep','custrecord_aw_wo_so'],true);
			var vals=nlapiLookupField('customrecord_aw_work_order',orders[j],
					['custrecord_aw_wo_so','custrecord_sdm_est_hrs_wo','custrecord4','name','custrecord_aw_wo_property','custrecord_sdm_est_hrs_wo','internalid']);
			var prop=nlapiLookupField('customrecord_aw_property',vals.custrecord_aw_wo_property,
					['custrecord_aw_address_1','custrecord_aw_address_2','custrecord_aw_city','custrecord_aw_zip',
					 ]);
			var esthours=vals.custrecord_sdm_est_hrs_wo;
			var propstate=nlapiLookupField('customrecord_aw_property',vals.custrecord_aw_wo_property,'custrecord_aw_state',true);
			var sototal=nlapiLookupField('salesorder',vals.custrecord_aw_wo_so,
					'total');
			//var colors=nlapiSearchRecord('transaction','customsearch901',new nlobjSearchFilter('internalid',null,'anyof',vals.custrecord_aw_wo_so));
			//get address
			var address='';
			if (!isEmpty(prop.custrecord_aw_address_1))
				address+=prop.custrecord_aw_address_1;
			if (!isEmpty(prop.custrecord_aw_address_2))
				address+=', '+prop.custrecord_aw_address_2;
			if (!isEmpty(prop.custrecord_aw_city))
				address+=', '+prop.custrecord_aw_city;
			if (!isEmpty(propstate))
				address+=', '+propstate;
			if (!isEmpty(prop.custrecord_aw_zip))
				address+=', '+prop.custrecord_aw_zip;
			//get attendees

			//var args='&f1=internalid-null-anyof-'+foreman+'&c1=entityid&c2=email';
			//var fvals=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args);

			//var args='&f1=supervisor-null-anyof-'+foreman+'&c2=email';
					//5 email
					//6 name
					//7 emailarray
			//var subs=nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=371&deploy=1'+args);
			subs=cals[7][calindex];
		//	fvals=JSON.parse(fvals.getBody());
			var attendees=new Array();
			var emails=new Array();
			attendees.push({'email':cals[5][calindex],'responseStatus':'accepted'});
			emails.push(cals[5][calindex]);
			var num_attendees=parseFloat(1);
			for (var i=0; subs!=null&&i<subs.length; i++){
				if (subs[i]!=''&&subs[i]!=null)
				attendees.push({'email':subs[i],'responseStatus':'accepted'});
				if (subs[i]!=''&&subs[i]!=null)
				emails.push(subs[i]);
				num_attendees++;
			}

			//get description
			var sched_hours=(date2-date1)/60/60/1000;
			numpeople=parseInt(numpeople);
			if (!isNaN(numpeople))
				num_attendees=numpeople;
			
				sched_hours*=num_attendees;
			var sched_amount=get_sched_amount(sched_hours,vals.custrecord_sdm_est_hrs_wo,sototal);
			sototal=String(sototal).split('.');;
			sched_amount= String(sched_amount).split('.');
			var description='';
			description+='Client: '+textvals.custrecord_aw_wo_client+'\n';	
			description+='Sales Rep: '+textvals.custrecord_aw_wo_sales_rep+'\n';		
			description+='Total Estimated Hours: '+vals.custrecord_sdm_est_hrs_wo+'\n';		
			description+='SOT: '+String(convertFromBaseToBase(sototal[0],10,16))+sototal[1]+'\n';	
			description+='Scheduled Hours: '+sched_hours+'\n';
			description+='SA: '+String(convertFromBaseToBase(sched_amount[0],10,16))+String(sched_amount[1])+'\n';
			var colorid=19;
			//if (colors!=null && colors[0].getValue('custrecord_colorid',null,'group')!=''){
			//	colorid=colors[0].getValue('custrecord_colorid','class','group');
			//}

			//alert(colorid);
			var event = {
				  'summary': 'Work Order #'+vals.name+' : '+cals[6][calindex]+' : '+textvals.custrecord_aw_wo_property,
				  'location': address,
				  'description': description,
				  //'colorId':colorid,
				  'start': {
				    'dateTime': date1s,
				    'timeZone': 'America/Los_Angeles'
				  },
				  'end': {
				    'dateTime': date2s,
				    'timeZone': 'America/Los_Angeles'
				  },
				  'recurrence': [
				                 'RRULE:FREQ=DAILY;COUNT='+days,
				               ],
				  'attendees': attendees,
				  'reminders': {
				    'useDefault': false,
				    'overrides': [
				      {'method': 'email', 'minutes': 24 * 60},
				      {'method': 'popup', 'minutes': 10}
				    ]
				  }
			};
			  //'recurrence': [
			 //   'RRULE:FREQ=DAILY;COUNT=2'
			 // ],
			//var request = gapi.client.calendar.calendarList.list({});
			sentglob=false;
			objglob=orders[j];
			valsglob=vals;
			var fvals=new Array();
			fvals.push(cals[5][calindex]);
			fvals.push(cals[6][calindex]);
			fvalsglob=fvals;
			textvalsglob=textvals;
			emailsglob=emails;
			dateglob=date;
			enddateglob=enddate;
			starttimeglob=starttime;
			endtimeglob=endtime;
			addressglob=address;
			esthoursglob=esthours;
			woglob=orders[j];
			for (var i=0; i<ids.length; i+=2){
				var request = gapi.client.calendar.events.insert({
				  'calendarId': ids[i],
				  'resource': event
				});
				indexglob=i;
				arrayglob=ids;
				request.execute(function(event) {
				//	+' '+ JSON.stringify(event)
					//nlapiSendEmail(11947,11947,nlapiGetUser(),'Event created on calendar ' +emailsglob);
					if ((event['code']==400||event['code']==401)&&indexglob+2==arrayglob.length&&sentglob==false){
						sentglob=true;
						alert(event['data'][0]['message']);
					}
					else if (indexglob+2==arrayglob.length&&sentglob==false){
						sentglob=true;
						alert('Work Order #'+valsglob.name+' : '+fvalsglob[1]+' : '+textvalsglob.custrecord_aw_wo_property+ ' Successfully Scheduled.');
						var equipment=get_equipment(woglob);
						var data=new Object();
						data['subject']='Work Order #'+valsglob.name+' : '+fvalsglob[1]+' : '+textvalsglob.custrecord_aw_wo_property+ ' Scheduled';
						data['body']=dateglob+'-'+enddateglob+' '+starttimeglob+'-'+endtimeglob+'<br/>'+addressglob+'<br/>Estimated Hours: '+esthoursglob+'<br/>'+equipment;
						data['emails']=emailsglob;
						data['user']=nlapiGetUser();
						data['wo']=valsglob.name;
						var val=nlapiRequestURL('https://system.na1.netsuite.com/app/common/custom/custrecordentry.nl?rectype=10&id='+valsglob.internalid+'&whence=&print=T');
						data['htmldoc']=val.getBody();
						nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=372&deploy=1',JSON.stringify(data),{'Content-Type':'application/json'},null,'POST');

						//nlapiSendEmail(nlapiGetUser(),emailsglob,'Work Order #'+valsglob.name+' : '+fvalsglob[0]['entityid']+' : '+textvalsglob.custrecord_aw_wo_property+ ' Scheduled',
						//		dateglob+'-'+enddateglob+' '+starttimeglob+'-'+endtimeglob+'<br/>'+addressglob+'<br/>Estimated Hours: '+esthoursglob+'<br/>'+equipment);
						//nlapiSendEmail(nlapiGetUser(),nlapiGetUser(),'Work Order #'+valsglob.name+' : '+fvalsglob[0]['entityid']+' : '+textvalsglob.custrecord_aw_wo_property+ ' Scheduled',
						//		dateglob+'-'+enddateglob+' '+starttimeglob+'-'+endtimeglob+'<br/>'+addressglob+'<br/>Estimated Hours: '+esthoursglob+'<br/>'+equipment);
					}
				});
			}
			

	}
	}
	}
	catch(e){
		alert(e.message);
	}
}
function send_emails(request,response){
	
	var bod=request.getBody();
	bod=JSON.parse(bod);
	var subject=bod['subject'];
	var body=bod['body'];
	var emails=bod['emails'];
	var user=bod['user'];
	var file=nlapiCreateFile(bod['wo'],'HTMLDOC',bod['htmldoc']);
	file.setFolder(-14);
	file=nlapiSubmitFile(file);
	file=nlapiLoadFile(file);
	//nlapiLogExecution('ERROR',String(emails),'aa')
	nlapiSendEmail(user,String(emails).split(','),subject,body,null,null,null,file);
	//nlapiSendEmail(user,user,subject,body,null,null,null,file);
	
	nlapiLogExecution('ERROR',bod,subject+' '+body+' '+emails+' '+user);
}
var woglob;
var valsglob;
var fvalsglob;
var textvalsglob;
var emailsglob;
var dateglob;
var enddateglob;
var starttimeglob;
var endtimeglob;
var addressglob;
var esthoursglob;
var equipmentglob;
var objglob;
var sentglob;
var indexglob;
var arrayglob;
function convertFromBaseToBase(str, fromBase, toBase){
    var num = parseInt(str, fromBase);
    return num.toString(toBase);
}
function get_equipment(order){
	var ordersearch=nlapiSearchRecord('customrecord_aw_work_order','customsearch911',
			new nlobjSearchFilter('internalid',null,'anyof',order));
	var columns=ordersearch[0].getAllColumns();
	var html='<table border="0"><tr>';
	for (var i=0;i<columns.length; i++){
		if (i>0&&i%3==0){
			html+='</tr><tr>';
		}
		html+='<td>'+columns[i].getLabel()+': '+ordersearch[0].getValue(columns[i])+'</td>';
	}
	html+='</tr></table>';
	return html;
	
}
function isEmpty(stValue) {
	//used to identify blank fields
		if ((stValue == '') || (stValue == null) ||(stValue == undefined)) {
			return true;
	    	}
	    return false;
}
function get_sched_hours(start,end){
	
}
function get_sched_amount(sched_hours,est_hours,so_amt){
	var sched_rat=sched_hours/est_hours;
	return Number(sched_rat*so_amt).toFixed(2);
}
var dateToUTCString = (function () {

	  // Add leading zero to single digit numbers
	  function addZ(n) {
	    return (n<10)?'0'+n:''+n;
	  }

	  return function(d) {

	    // If d not supplied, use current date
	    var d = d || new Date();

	    return d.getUTCFullYear() + 
	           addZ(d.getUTCMonth() + 1) + 
	           addZ(d.getUTCDate()) +
	           'T' + 
	           addZ(d.getUTCHours()) + 
	           addZ(d.getUTCMinutes()) + 
	           addZ(d.getUTCSeconds()) +
	           'Z';
	  }
	}());
function timeStringToUTC(s) {

	  // Deal with trailing am/pm if present
	  // Probably should trim leading spaces here too
	  var isPM = /pm\s*$/i.test(s);
	  s = s.replace(/\s*pm\s*$/i,'')

	  // Split the string on any of -, space or :
	  var b = s.split(/[- :]/);

	  // Add 12 to hour if is pm
	  if (isPM) {
	    b[3] = +b[3] + 12;
	  } else {
	    // Add leading zero if hours less than 10
	    b[3] = (b[3] < 10)? '0' + +b[3] : b[3];
	  }

	  // Add leading zero to minutes if < 10
	  if (b[4] < 10) b[4] = '0' + +b[4];

	  // If seconds not supplied, set to 00
	  if ( !/^\d\d?$/.test(b[5])) {
	    b[5] = '00';
	  } else {
	    // Add leading zero if seconds less than 10
	    if (b[5] < 10) b[5] = '0' + +b[5];
	  }

	  // Generate date object, call dateToUTCString to return 
	  // UTC date string
	  return dateToUTCString(
	           new Date(b[2] + '/' +
	                    b[0] + '/' +
	                    b[1] + ' ' +
	                    b[3] + ':' +
	                    b[4] + ':' +
	                    b[5]
	               )
	         ); 
	}
function convert_to_military(time){
	var hours = Number(time.match(/^(\d+)/)[1]);
	var minutes = Number(time.match(/:(\d+)/)[1]);
	var AMPM = time.match(/\s(.*)$/)[1];
	if(AMPM.toLowerCase() == "pm" && hours<12) hours = hours+12;
	if(AMPM.toLowerCase() == "am" && hours==12) hours = hours-12;
	var sHours = hours.toString();
	var sMinutes = minutes.toString();
	if(hours<10) sHours = "0" + sHours;
	if(minutes<10) sMinutes = "0" + sMinutes;
	//alert(sHours + ":" + sMinutes);
	return [sHours,sMinutes];
}
function table_validate_field(type,name,linenum){
	if (nlapiGetFieldValue(name)=='')
		return true;
	
	if (name=='custpage_starttime'||name=='custpage_endtime'){
		var re = /^(((0?[1-9]|1[012])(:[0-5][0-9])?\sam)|((0?[0-9]|1[012])(:[0-5][0-9])?\spm))\b/;
		var field=nlapiGetFieldText(name);
		if (!re.test(field)){
			alert('time must be in hh:mm format followed by [space] am/pm.');
			return false;
		}
	}
	return true;
}
var CLIENT_ID = '32871394322-nmq65b763gubi41kuk9so2c6qooc1se8.apps.googleusercontent.com';

var SCOPES = ["https://www.googleapis.com/auth/calendar"];

/**
 * Check if current user has authorized this application.
 */
function checkAuth() {
  gapi.auth.authorize(
    {
      'client_id': CLIENT_ID,
      'scope': SCOPES.join(' '),
      'immediate': true
    }, handleAuthResult);
}

/**
 * Handle response from authorization server.
 *
 * @param {Object} authResult Authorization result.
 */
function handleAuthResult(authResult) {
  var authorizeDiv = document.getElementById('table_div');
  if (authResult && !authResult.error) {
    // Hide auth UI, then load client library.
	 // authorizeDiv.innerHTML = '<br/><br/><br/><span style="font-size:24px;">Loading Work Orders...</span>';
	  nlapiSetFieldValue('custpage_authorized','T');
	  //alert('sd');
    loadCalendarApi();
    //alert('sss');
    drawTable();
    
  } else {
    // Show auth UI, allowing the user to initiate authorization by
    // clicking authorize button.
	  authorizeDiv.innerHTML = '<br/><br/><br/><span style="font-size:24px;">Authorize access to Google Calendar API to use scheduler by clicking the button below.</span><br/>'+
	      '<button style=" width:200px; height: 28px; font-size:14px;" id="authorize-button" onclick="handleAuthClick(event); return false;">'+
	        'Authorize'+
	      '</button>';
  }
}

/**
 * Initiate auth flow in response to user clicking authorize button.
 *
 * @param {Event} event Button click event.
 */
function handleAuthClick(event) {
  gapi.auth.authorize(
    {client_id: CLIENT_ID, scope: SCOPES, immediate: false},
    handleAuthResult);
  return false;
}
function ISODateString(d){
	 function pad(n){return n<10 ? '0'+n : n}
	 return d.getUTCFullYear()+'-'
	      + pad(d.getUTCMonth()+1)+'-'
	      + pad(d.getUTCDate())+'T'
	      + pad(d.getUTCHours())+':'
	      + pad(d.getUTCMinutes())+':'
	      + pad(d.getUTCSeconds())+'Z'}

function loadCalendarApi() {
  gapi.client.load('calendar', 'v3', function(){
	    var request = gapi.client.calendar.calendarList.list({});
	    request.execute(function(resp){
	       // alert(JSON.stringify(resp));
	    });
	});

}

function dum() {

}
/**
 * Print the summary and start datetime/date of the next ten events in
 * the authorized user's calendar. If no events are found an
 * appropriate message is printed.
 */

function listUpcomingEvents() {
  var request = gapi.client.calendar.events.list({
    'calendarId': 'primary',
    'timeMin': (new Date()).toISOString(),
    'showDeleted': false,
    'singleEvents': true,
    'maxResults': 10,
    'orderBy': 'startTime'
});

  request.execute(function(resp) {
    var events = resp.items;
    appendPre('Upcoming events:');

    if (events.length > 0) {
      for (i = 0; i < events.length; i++) {
        var event = events[i];
        var when = event.start.dateTime;
        if (!when) {
          when = event.start.date;
        }
        appendPre(event.summary + ' (' + when + ')')
      }
    } else {
      appendPre('No upcoming events found.');
    }

  });
}
function populate_field(field,textid,search){
	var j=0;
	do {
		var thisresults = search.getResults(j*1000,j*1000+1000);
		//alert('ss');
	for (var i=0; thisresults!=null&&i<thisresults.length; i++){
		field.addSelectOption(thisresults[i].getValue('internalid'),thisresults[i].getValue(textid));
	}
	j++;
} while(search.getResults(j*1000,j*1000+1000)!=null&&search.getResults(j*1000,j*1000+1000).length==1000);
}
//Calendar ID: nua4snsuleo3e7c5561nbdkjg4@group.calendar.google.com
//32871394322-nmq65b763gubi41kuk9so2c6qooc1se8.apps.googleusercontent.com
//8rcr9w8g-dL-_dPU2hrP0xCx