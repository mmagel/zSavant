/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Nov 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord 
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */


function create_email_button(type, form, request){
 
	if(type == 'view') {
	
	form.setScript('customscript_sdm_wo_function');
	form.addButton('custpage_sdm_email', 'Email', 'run_wo_suitelet()');	
			
	}
		
}

