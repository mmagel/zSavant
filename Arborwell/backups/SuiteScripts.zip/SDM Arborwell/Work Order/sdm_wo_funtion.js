/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Nov 2013     cblaisure
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord  
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function run_wo_suitelet(type){
	
	var wo_id = nlapiGetRecordId();
	var order_id = nlapiGetFieldValue('custrecord_aw_wo_so');
	
	var url = nlapiResolveURL('SUITELET', 'customscript_sdm_wo_suitelet', 'customdeploy1', null);
	url += '&wo_id=' + wo_id +'&order=' + order_id;
	window.location = url;
	   
}

function update_email(type, name){
	
	if(name == 'employee'){
	
	var employee_id = nlapiGetFieldValue('employee');
	var employee_email = nlapiLookupField('employee', employee_id, 'email');
	
	nlapiSetFieldValue('recipient', employee_email);
		
	}
}