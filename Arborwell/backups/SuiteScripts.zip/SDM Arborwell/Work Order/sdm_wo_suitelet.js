/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       21 Nov 2013     cblaisure
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function email_suitelet(){
//UI interface for Emailing Work Orders

    if (request.getMethod() == 'GET' ){

        var wo_id = request.getParameter('wo_id');
        var order = request.getParameter('order');

        var form = nlapiCreateForm('Email Work Order');

        var employee = form.addField('employee', 'select', 'Send To', 'employee');
        employee.setLayoutType('normal', 'startcol');
        employee.setMandatory( true );

        var work_order = nlapiLoadRecord('customrecord_aw_work_order', wo_id);
        var work_number = work_order.getFieldValue('name'); //id field
        var property_name = work_order.getFieldText('custrecord_aw_wo_property'); //property name

        var subject = form.addField('subject','text', 'Subject');
        subject.setDefaultValue(property_name + '  WO#' + work_number);
        subject.setLayoutType('normal', 'none');
        subject.setMandatory( true );

        var message = form.addField('message','textarea', 'Message');
        message.setLayoutType('normal', 'none');
        message.setDisplaySize( 60, 10 );

        var work_order = form.addField('workorder', 'integer', 'Work Order');
        work_order.setDefaultValue(wo_id);
        work_order.setDisplayType('hidden');

        var sales_order = form.addField('order', 'integer', 'Sales Order');
        sales_order.setDefaultValue(order);
        sales_order.setDisplayType('hidden');

        var script_string = "var url = nlapiResolveURL('RECORD', 'customrecord_aw_work_order'," + wo_id + ", 'VIEW'); window.location = url;";
        form.addButton('custombutton_back', 'Back', script_string);

        form.addSubmitButton('Send Email');

        response.writePage( form );
    }
    else
    {
        var order = request.getParameter('order');
        var currentuser = nlapiGetUser();
        var wo_id = request.getParameter('workorder');
        var subject = request.getParameter('subject');
        var message = request.getParameter('message');
        var email_body = message + '<br><br>';

        var work_order = nlapiLoadRecord('customrecord_aw_work_order', wo_id);
        var work_number = work_order.getFieldValue('name'); //id field
        var wo_status = work_order.getFieldText('custrecord_aw_wo_status');
        var wo_date = work_order.getFieldValue('custrecord_aw_wo_date');
        var wo_client = work_order.getFieldText('custrecord_aw_wo_client');
        var wo_property = work_order.getFieldText('custrecord_aw_wo_property');
        var wo_rep = work_order.getFieldText('custrecord_aw_wo_sales_rep');
        var wo_prop_id = work_order.getFieldValue('custrecord_aw_wo_property');
        var esthours = work_order.getFieldValue('custrecord_sdm_est_hrs_wo');

        var wo_job_setup = work_order.getFieldValue('custrecord_aw_wo_job_notes');
        if(wo_job_setup ==null){wo_job_setup = 'None';}
        var wo_site_condition = work_order.getFieldValue('custrecord_aw_wo_existing_site');
        if(wo_site_condition ==null){wo_site_condition = 'None';}

        //set header fields

        email_body = email_body + '<b>Work Order: </b> ' + work_number + '<br>';
        email_body = email_body + '<b>Status: </b> ' + wo_status + '<br>';
        email_body = email_body + '<b>Date: </b> ' + wo_date + '<br>';
        email_body = email_body + '<b>Client: </b> ' + wo_client + '<br>';
        email_body = email_body + '<b>Property: </b> ' + wo_property + '<br>';
        email_body = email_body + '<b>Sales Rep: </b> ' + wo_rep + '<br>';
        email_body = email_body + '<b>Job Setup Notes: </b> ' + wo_job_setup + '<br>';
        email_body = email_body + '<b>Site Condition: </b> ' + wo_site_condition + '<br>';
        email_body = email_body + '<b>Estimated Hours: </b> ' + esthours + '<br>';
        //get email address
        var employee_id = request.getParameter('employee');
        var employee_email = nlapiLookupField('employee', employee_id, 'email');

        if(employee_email == null || employee_email.length <1){
            throw new nlobjError('DEBUG', 'Employee Email Address is not configured in NetSuite. Please contact your administrator');
        }

        //get item list
        var item_filters = new Array();
        item_filters[0] = new nlobjSearchFilter('internalid', null, 'is', order);
        item_results = nlapiSearchRecord(null, 'customsearch_aw_wo_sublist_items', item_filters, null);


        if(item_results != null){
            var item_table = search_to_html(item_results);
            email_body = email_body + '<br>' + item_table;
        }

        //get property info
        var prop_filters = new Array();
        prop_filters[0] = new nlobjSearchFilter('internalid', null, 'is', wo_prop_id);
        property_results = nlapiSearchRecord(null, 'customsearch_aw_wo_sublist_property', prop_filters, null);


        if(property_results != null){
            var prop_table = search_to_html(property_results);
            email_body = email_body + '<br>' + prop_table;
        }

        //get order info
        var order_filters = new Array();
        order_filters[0] = new nlobjSearchFilter('internalid', null, 'is', order);
        order_results = nlapiSearchRecord(null, 'customsearch_aw_wo_sublist_transactions', order_filters, null);

        if(order_results != null){
            var order_table = search_to_html(order_results);
            email_body = email_body + "<br>" + order_table;
        }

        // set equipment information
        email_body = email_body + '<br><b>Addition Equipment / Job Setup:</b><br>';

        var equip_ray = ['custrecord_aw_wo_eq2_small',
            'custrecord_aw_wo_eq2_personnel',
            'custrecord_aw_wo_eq2_safety',
            'custrecord_aw_wo_eq2_permits',
            'custrecord_aw_wo_eq2_equip',
            'custrecord_aw_wo_eq2_sched',
            'custrecord_aw_wo_eq2_elect_hazard'];

        var equip_count = equip_ray.length;

        for (var x = 0; x < equip_count; x++){
            var field_obj = work_order.getField(equip_ray[x]);
            var field_label = field_obj.getLabel();
            var field_value = work_order.getFieldValue(equip_ray[x]);

            //if you want to include equipment include
            //if(field_value == null){field_value = 'No';}

            if(field_value!=null&&field_value.length>0)	{
                email_body += '<SPAN style="BACKGROUND-COLOR: #ffff00"><b>' + field_label + ': </b> ' + field_value + '<br></SPAN>';
            }
        }

        // Attach the WO inspection document
        var newAttachment = nlapiLoadFile(15697);
        nlapiLogExecution('DEBUG','wo test',currentuser+' '+employee_email+' '+subject+' '+email_body);
        nlapiSendEmail(currentuser, employee_email, subject, email_body, null, null, {'entity':currentuser}, newAttachment);

        response.sendRedirect('record', 'customrecord_aw_work_order', wo_id);
    }
}

function search_to_html(item_results){
// function used to convert search results into an HTML Table
// Column headers on results can be edited by changing the saved seach custom label field on the search results tab

    if(item_results == null){
        var null_search = 'No search results found';
        return null_search;
    }
    var body = '<table border="1"><tr>';
    //Set Column Headers
    var result = item_results[0];
    var columns = result.getAllColumns();
    var columnLen = columns.length;
    for (var i = 0; i < columnLen; i++)
    {
        var column = columns[i];
        var label = column.getLabel();
        if(label == null){label = column.getName();}
        body = body + '<th>' + label + '</th>';
    }
    body = body + '</tr>';

    //Set line details
    var line_count = item_results.length;
    for (var lines = 0; lines < line_count; lines++){
        var item_line = item_results[lines];
        var item_columns = item_line.getAllColumns();
        var col_count = item_columns.length;
        body = body + '<tr>';
        for (var col = 0; col < col_count; col++){
            //if text
            var data = item_line.getText(item_columns[col]);
            //if number value
            if(data == null){data = item_line.getValue(item_columns[col]);}
            body = body + '<td>' + data + '</td>';
        }
    }
    body = body + '</tr></table>';
    return body;
}

