function time_create_edit_children(type){
	if (type=='create'||type=='edit'){
		var parent=nlapiGetFieldValue('custcol_pte');
		if(parent==null||parent==''||typeof parent=='undefined'){
			var st=nlapiGetFieldValue('custcol_aw_time_hours_standard');
			var ot=nlapiGetFieldValue('custcol_aw_time_hours_overtime');
			var dot=nlapiGetFieldValue('custcol_aw_time_hours_double_overtime');
			var stit;
			var otit;
			var dotit;
			var sten=-1;
			var doten=-1;
			var oten=-1;
			st=parseFloat(st);
			ot=parseFloat(ot);
			dot=parseFloat(dot);
			var employee=nlapiGetFieldValue('employee');
			if (typeof dot=='number' && !dot.isNaN() &&typeof ot=='number'&& !ot.isNaN() &&typeof st=='number'&&!st.isNaN() ){
				var items=nlapiSearchRecord(null,'customsearch_at_emp_pi_search',new nlobjSearchFilter('employee',null,'anyof',employee));
				var cols;
				if (items!=null)
					cols=items[0].getAllColumns();
				for (var i=0; items!=null&&i<items.length; i++){
					var item=nlapiLoadRecord('payrollitem',items[0].getValue(cols[0]));
					var multiplier=item.getFieldValue('derivedratemultiplier');
					if (multiplier==2){
						dotit=items[0].getValue(cols[0]);
					}
					else if(multiplier==1.5) {
						otit=items[0].getValue(cols[0]);
					}
					else if (multiplier==''||multiplier==null) (
						stit=items[0].getValue(cols[0]);
					)
				}
				var existing=nlapiSearchRecord('timebill',null,new nlobjSearchFilter('custcol_pte',null,'anyof',nlapiGetRecordId()),
				[new nlobjSearchColumn('internalid'), new nlobjSearchColumn('payitem'),new nlobjSearchColumn('durationdecimal')]);
				for (var i=0;existing!=nulli<existing.length; i++){
					var payit=existing[i].getValue('payitem');
					if (payit==stit&&st>0){
						sten=existing[i].getValue('internalid');
					}
					else if (payit==otit&&ot>0){
						oten=existing[i].getValue('internalid');
					}
					else if (payit==dotit&&dot>0){
						doten=existing[i].getValue('internalid');
					}
					else {
						nlapiDeleteRecord('timebill',existing[i].getValue('internalid'));
					}
				}
				if (st>0){
					if (sten>-1){
						sten=nlapiLoadRecord('timebill',sten);
					}
					else {
						sten=nlapiCreateRecord('timebill');		
					}
					sten.setFieldValue('duration',convert_hm(st));
					sten.setFieldValue('employee',employee);
					sten.setFieldValue('payrollitem',stit);
					sten.setFieldValue('custcol_pte',nlapiGetRecordId());
					var id=nlapiSubmitRecord(sten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_st_te',id);
				}
				if (ot>0){
					if (oten>-1){
						oten=nlapiLoadRecord('timebill',oten);						
					}
					else {
						oten=nlapiCreateRecord('timebill');					
					}
					oten.setFieldValue('duration',convert_hm(ot));
					oten.setFieldValue('employee',employee);
					oten.setFieldValue('payrollitem',otit);
					oten.setFieldValue('custcol_pte',nlapiGetRecordId());
					var id=nlapiSubmitRecord(oten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_ot_te',id);
				}
				if (dot>0){
					if (doten>-1){
						doten=nlapiLoadRecord('timebill',doten);					
					}
					else {
						doten=nlapiCreateRecord('timebill');
					}
					doten.setFieldValue('duration',convert_hm(dot));
					doten.setFieldValue('employee',employee);
					doten.setFieldValue('payrollitem',dotit);
					doten.setFieldValue('custcol_pte',nlapiGetRecordId());
					
					var id=nlapiSubmitRecord(doten,false,true);
					nlapiSubmitField('timebill',nlapiGetRecordId(),'custcol_dot_te',id);
				}
			}
		}
	}
	else if (type=='delete'){
				var existing=nlapiSearchRecord('timebill',null,new nlobjSearchFilter('custcol_pte',null,'anyof',nlapiGetRecordId()),
				[new nlobjSearchColumn('internalid'), new nlobjSearchColumn('payitem'),new nlobjSearchColumn('durationdecimal')]);
				for (var i=0;existing!=null&&i<existing.length; i++){
					try {
						nlapiDeleteRecord('timebill',existing[i].getValue('internalid'));
					}
					catch(e){
						nlapiLogExecution('ERROR','');
					}
				}
	}
}
//pull so amount to deposit
//subtotal amount on item receipt
function convert_to_minutes(hours){
	//nlapiLogExecution('ERROR','time',nlapiGetRecordId()+' '+hours)
	
	var arr_hour=hours.split(':');
	if(arr_hour[0]!=undefined && arr_hour[0]!='')
		var ho=parseInt(arr_hour[0]);
	if(arr_hour[1]!=undefined && arr_hour[1]!=''&&arr_hour[1]!='00'){
		var min=parseInt(arr_hour[1].replace(/\b0+/g, ''));
	}
	else {
		min=parseInt('0');
	}
	//nlapiLogExecution('ERROR','asdf',nlapiGetRecordId()+' '+ho+' '+arr_hour[1]);
	hours=parseInt(ho)*60+parseInt(min);
	return hours;
}
function convert_hm(hours,blank){
	if (blank==null){
		blank=true;
	}
	hours=hours*60;
	var ho_=hours/60;
	var min_=hours%60;
	ho_=parseInt(ho_);
	min_=parseInt(min_);
	hours=parseInt(ho_);
	if(min_<=9)
	{
		min_="0"+min_;
	}
	//hours=hours+parseFloat(min_/60);
	hours=hours+":"+min_;
	//hours=parseFloat(hours);
	//hours=hours.toFixed(2);
	if (hours=='0:00'&&blank){
		return '';
	}
	return hours;
}