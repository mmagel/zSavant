function time_ue_set_so(type){
	try {
	if (type=='create'||type=='edit'){
		var wo=nlapiGetFieldValue('custcol_aw_time_work_order');
		if (wo!=''&&wo!=null){
			var so=nlapiLookupField('customrecord_aw_work_order',wo,'custrecord_aw_wo_so');
			nlapiSetFieldValue('custcol3',so);
		}
	}
	}
	catch (e){
		nlapiLogExecution('ERROR','time set so error '+nlapiGetRecordId(),e.message);
	}
}