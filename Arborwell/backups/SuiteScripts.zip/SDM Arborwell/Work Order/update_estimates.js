function estimate_mass_update(recType,recId){
	var rec=nlapiLoadRecord(recType,recId);
	nlapiSubmitRecord(rec);
	
}