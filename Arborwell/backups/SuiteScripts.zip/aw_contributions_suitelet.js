function print_contributions(request,response){
	if (request.getMethod()=='GET'){
		var form=nlapiCreateForm('Print Contributions');
		form.addSubmitButton('Print');
		form.addField('custpage_employee','multiselect','Employee','employee');
		form.addField('custpage_sd','date','From').setMandatory(true);
		form.addField('custpage_ed','date','To').setMandatory(true);
		response.writePage(form);
	}
	else {
		var employees=request.getParameter('custpage_employee');
		var sd=request.getParameter('custpage_sd');
		var ed=request.getParameter('custpage_ed');
		var search=nlapiLoadSearch('paycheck','customsearch1225');
		if (employees!=''&&employees!=null){
			search.addFilter(new nlobjSearchFilter('employee',null,'anyof',employees));
		}
		
		var filters=search.getFilters();
		search.addFilter(new nlobjSearchFilter('checkdate',null,'within',sd,ed));
		var results=search.runSearch();
		var resultset;
		var columns=search.getColumns();
		var resobj=new Object();
		var i=0;
		do {
			resultset=results.getResults(i*1000,(i+1)*1000);
			
			for (var j=0;j<resultset.length;j++){
				var employee=resultset[j].getValue(columns[3]);
				var date=resultset[j].getValue(columns[2]);
				var batch=resultset[j].getValue(columns[0]);
				if (resobj[employee]==null|| typeof resobj[employee]=='undefined'){
					resobj[employee]=new Object();
					resobj[employee]['region']=resultset[j].getText(columns[12]);
					resobj[employee]['empid']=resultset[j].getValue(columns[13]);
					resobj[employee]['sub']=parseFloat(0);
				}
				var amt=parseFloat(resultset[j].getValue(columns[8]));
				if (amt<0)
				{
				if ((resobj[employee][batch]==null|| typeof resobj[employee][batch]=='undefined')){
					resobj[employee][resultset[j].getValue(columns[0])]=new Array();
				}
				resobj[employee][batch].push(date);
				resobj[employee][batch].push(resultset[j].getValue(columns[4]));
				resobj[employee][batch].push(resultset[j].getValue(columns[5]));
					amt*=-1;
					resobj[employee][batch].push(amt);
					resobj[employee]['sub']+=amt;
				}
			}
			i++
		}
		while (resultset.length==1000);
		var logo=nlapiLoadFile(14).getURL();
		var title='Employee/Employer Contributions';
		 var pdf_string='';
		for( x in resobj){
			var header=get_header_table(x,resobj[x]['empid'],resobj[x]['region']);
			 var time_table_head=tr(td('Payroll Batch',['align','left','font-size','9'])+td('Date',['align','left','font-size','9'])+td('Payroll Item',['align','left','font-size','9'])+td('Type',['align','left','font-size','9'])+td('Contribution',['align','left','font-size','9']));
			var body='';
			body+=time_table_head;
			for (y in resobj[x]){
				if (y!='region'&&y!='empid'&&y!='sub'){
					
					var amt=parseFloat(0);
					for (var i=0; i<resobj[x][y].length; i+=4){
						var rowstring=''
						var ittype=resobj[x][y][i+2];
						if (ittype=='Deduction')
							ittype='Employee Deduction';
						if (i==0){
							rowstring+=td(y,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i+1],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(ittype,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i+3],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
						}
						else {
							rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i+1],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(ittype,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
							rowstring+=td(resobj[x][y][i+3],['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
						}
						amt+=parseFloat(resobj[x][y][i+3]);
						rowstring=tr(rowstring);
						body+=rowstring;
					}
					var rowstring='';
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('Batch Total',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td(amt.toFixed(2),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring=tr(rowstring);
					body+=rowstring;
				}
			} 
			var rowstring='';
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('&nbsp;',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td('Total',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring+=td(resobj[x]['sub'].toFixed(2),['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']);
					rowstring=tr(rowstring);
					body+=rowstring;
			pdf_string+=header+table(body,['border','.3','cellborder','.3','margin-bottom','.6cm','border-collapse','collapse'])+'<pbr/>';
		}
		
		 response.setContentType('PDF');
		pdf_string=add_container(pdf_string,logo,title,[sd,ed])
		var pdf=nlapiXMLToPDF(pdf_string);
		response.write(pdf);
	}
}
function get_xml(){
	var xml = "<?xml version=\"1.0\"?>" +
	'<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">'+
	'<pdf><head><meta name="title" value="Deductions and Contributions"/><macrolist><macro id="myFooter">'+
	'<p align="center" font-size="9">'+nlapiDateToString(new Date(),'datetime')+'     Page <pagenumber/> of <totalpages/> </p></macro>';
	
	return xml;
}
function get_header_table(employee,id,region){
	var string='';
	string+=tr(td('Employee: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(employee,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Arborwell Employee ID: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(id,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Region: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(region,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	return table(string,['border','.3','cellborder','.3','margin-bottom','.6cm']);
}
function table(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<style.length; i+=2){
			attr_string+=+style[i]+':'+style[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<table'+attr_string+'>'+value+'</table>';
}
function tr(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=+style[i]+':'+bfo_attr[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<tr'+attr_string+'>'+value+'</tr>';
}
function td(value,bfo_attr,style){
	var attr_string='';
	if (bfo_attr!=null){
		for (var i=0; i<bfo_attr.length; i+=2){
			attr_string+=' '+bfo_attr[i]+'="'+bfo_attr[i+1]+'"';
		}
	}
	if (style!=null){
		attr_string+=' style="';
		for (var i=0; i<style.length; i+=2){
			attr_string+=+style[i]+':'+style[i+1]+'; ';
		}
		attr_string+='"';
	}
	return '<td'+attr_string+'><p'+attr_string+ '>'+value+'</p></td>';
}
function add_container(bodystring,logo,title,dates){
	var xmlbase=get_xml();
	nlapiLogExecution('ERROR','vals',logo+' '+title);
	
	xmlbase+='<macro id="myHeader"><img float="left" src="'+logo.replace(/&/g,'&amp;').replace(/&amp;nbsp;/g,'&nbsp;')+'"/> <p float="left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>'+
	'<p font-size="11" align="center" float="right" font-family="Calibri, Candara, Segoe, Optima, Arial, sans-serif">'+title+' - '+dates[0]+' - '+dates[1]+'</p></macro>';
	xmlbase+='</macrolist></head><body header="myHeader" header-height="2cm" footer="myFooter" footer-height=".6cm" size="letter">';
	return xmlbase+bodystring+'</body></pdf>';
}
function get_header_table(employee,id,region){
	var string='';
	string+=tr(td('Employee: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(employee,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Arborwell Employee ID: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(id,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	string+=tr(td('Region: ',['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif'])+td(region,['align','left','font-size','9','font-family','Calibri, Candara, Segoe, Optima, Arial, sans-serif']));
	return table(string,['border','.3','cellborder','.3','margin-bottom','.6cm']);
}