function afterSubmitEstimate(type)
{
	if(type=='delete') return;
	var primaryContactId = nlapiLookupField(nlapiGetRecordType(),nlapiGetRecordId(),'contactprimary.internalid');
	if(primaryContactId)
	{
		nlapiSubmitField(nlapiGetRecordType(),nlapiGetRecordId(),'custbody_estimate_primary_contact',primaryContactId);
	}
}
