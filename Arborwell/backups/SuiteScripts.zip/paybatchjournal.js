function paybatchjournal_sl(request,response){
	if (request.getMethod()=='GET'){
		var results=nlapiSearchRecord('paycheck','customsearch_paybatchsearch');
		var form=nlapiCreateForm('Create Payroll Adjustment Journal Entry');
		form.addSubmitButton('Save');
		var batchfield=form.addField('custpage_batch','select','Batch');
		var cols=results[0].getAllColumns();
		batchfield.addSelectOption(0,'---',true);
		for (var i=0;i<results.length; i++){
			var batch=results[i].getValue(cols[0]);
			var date=results[i].getValue(cols[1]);
				
				batchfield.addSelectOption(batch,batch+' '+date,false);
		}
		form.setScript('customscript_paybatchslcl');
		var list=form.addSubList('custpage_acc','list','Account Mapping');
		list.addField('custpage_from','select','From Account','account').setDisplayType('inline');
		list.addField('custpage_to','select','To Account','account').setDisplayType('inline');
		var results=nlapiSearchRecord('customrecord_je_allocation_mapping',null,null,[new nlobjSearchColumn('custrecord_from_account'),new nlobjSearchColumn('custrecord_to_account')]);
		for (var i=1;i<=results.length;i++){
			//nlapiLogExecution('ERROR',results[i].getValue('custrecord_from_account'),results[i-1].getValue('custrecord_to_account'));
			list.setLineItemValue('custpage_from',i,results[i-1].getValue('custrecord_from_account'));
			list.setLineItemValue('custpage_to',i,results[i-1].getValue('custrecord_to_account'));
		}
		response.writePage(form);
	}
	else {
		var batch=request.getParameter('custpage_batch');
		if (batch!=0){
			var toaccounts=new Array();
			var fromaccounts=new Array();
			var amounts=new Array();
			var results=nlapiSearchRecord('customrecord_je_allocation_mapping',null,null,[new nlobjSearchColumn('custrecord_from_account').setSort(true),new nlobjSearchColumn('custrecord_to_account')]);
			for (var i=0;i<results.length;i++){
				fromaccounts.push(results[i].getValue('custrecord_from_account'));
				toaccounts.push(results[i].getValue('custrecord_to_account'));
				amounts.push(parseFloat(0));
			}
			
			var search=nlapiSearchRecord('paycheck','customsearch_paybatchsearch_2',[new nlobjSearchFilter('batchnumber',null,'equalto',batch),new nlobjSearchFilter('account',null,'anyof',fromaccounts)]);
			var lines=0;
			var je=nlapiCreateRecord('journalentry');
			je.setFieldValue('custbody_paybatch',batch);
			for (var i=0; search!=null&&i<search.length; i++){
				var cols=search[i].getAllColumns();
				var account=search[i].getValue(cols[2]);
				var amount=search[i].getValue(cols[3]);
				
				var index=fromaccounts.indexOf(account);
				if (index>-1){
					je.selectNewLineItem('line');
					je.setCurrentLineItemValue('line','account',account);
					je.setCurrentLineItemValue('line','debit',amount);	
					je.setCurrentLineItemValue('line','location',1);
					je.commitLineItem('line');
					je.selectNewLineItem('line');
					je.setCurrentLineItemValue('line','account',toaccounts[index]);
					je.setCurrentLineItemValue('line','credit',amount);	
					je.setCurrentLineItemValue('line','location',1);
					je.commitLineItem('line');
					lines++;
				}
			}
			if (lines>0){
				var id=nlapiSubmitRecord(je);
				nlapiSetRedirectURL('RECORD','journalentry',id);
			}
			else {
				response.write('No je created - amount calculated was zero');
			}
		}
		else {
			nlapiSetRedirectURL('SUITELET','customscript_payjournalsl','customdeploy_payjournalsl');
		}
	}
}
function paybatchjournal_fc(type,name,linenum){
	if (name=='custpage_batch'){
		var batchid=nlapiGetFieldValue(name);
		if (batchid==0)
			return;
		var batch=nlapiGetFieldText(name);
		batch=batch.split(' ');
		//alert(batch);
		var nums=nlapiSearchRecord('journalentry',null,[new nlobjSearchFilter('custbody_paybatch',null,'is',batch[0]),new nlobjSearchFilter('mainline',null,'is','T')],new nlobjSearchColumn('tranid',null,'group'));
		var numsarr=new Array();
		if (nums!=null){
			for (var i=0; i<nums.length; i++){
				numsarr.push(nums[i].getValue('tranid',null,'group'));
			}
			alert('Warning: this payroll batch already associated with the following JEs: '+numsarr);
		}
	}
}