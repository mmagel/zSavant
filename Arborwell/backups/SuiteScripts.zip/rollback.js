/**
 * Created by Huzaifa on 6/23/2017.
 */

function onStart() {

    var search = nlapiLoadSearch('transaction', 'customsearch1345');
    var resultSet = search.runSearch();
    var rowCount = 999;
    var r = resultSet.getResults(0, rowCount);
    do {
        nlapiLogExecution('DEBUG', 'r.length', r.length);
        for (var i = 0; i < r.length; i++) {

            //try {
            var id = r[i].getId();
            nlapiLogExecution('DEBUG', 'id', id);

            var so = nlapiLoadRecord('salesorder', id);
            var lineItemCount = so.getLineItemCount('item');
            for (var j = 1; j <= lineItemCount; j++) {
                var item = so.getLineItemValue('item', 'item', j);
                if (item == 1612) {
                    so.removeLineItem('item', j);
                }
            }
            nlapiSubmitRecord(so, false, true);
            checkGovernance(50);
            //}
            //catch (ex) {
            //nlapiLogExecution('ERROR', 'id', id);
            //}
        }
        rowCount++;
        if (r.length < 999) break;
        r = resultSet.getResults(rowCount, (rowCount + 999));
    } while (r && r.length > 0);


}
