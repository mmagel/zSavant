//Estimate & SO - After Submit
//Emails when status & approver changes
/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       8 Mar 2018      rBender
 *
 */
/**
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @returns {Void}
 */

//email when pending approval to manager
//email when approved to sales rep AND/OR creator of record
//email when rejected to sales rep AND/OR creator of record

function email_on_as(type){
    nlapiLogExecution('DEBUG', 'type=', type);

    try{
            var recid = parseFloat( nlapiGetRecordId() );
            var rectype = nlapiGetRecordType();
            if(rectype == 'salesorder'){ var trantype = 'salesord'; var trantypeverbose='Sales Order';}
            if(rectype == 'estimate'){ var trantype = 'estimate'; var trantypeverbose='Estimate';}


            // Search to find the Created By to match with Sales Rep
            //search id = customsearch1672
            //estimate id = 556186
            var estimateSearch = nlapiSearchRecord("estimate",null,
            [
                ["type","anyof","Estimate"], 
                "AND", 
                ["mainline","is","T"],
                "AND", 
                ["internalidnumber","equalto",recid]
            ], 
            [
                new nlobjSearchColumn("internalid",null,null), 
                new nlobjSearchColumn("createdby",null,null), 
                new nlobjSearchColumn("salesrep",null,null)
            ]
            );
            
            if ( estimateSearch.length>0 ){
                var cols = estimateSearch[0].getAllColumns();
                
                var intid = estimateSearch[0].getValue(cols[0]);
                var createdby = parseInt( estimateSearch[0].getValue(cols[1]) );
                var createdbytext = estimateSearch[0].getText(cols[1]);
                var salesreptext = estimateSearch[0].getText(cols[2]); 
                var salesrep = parseInt( estimateSearch[0].getValue(cols[2]) );                    
            



                // SEARCH to find email addresses for sales rep
                var repsearch = nlapiSearchRecord("employee",null,
                [
                    ["internalidnumber","equalto",salesrep]
                ], 
                [
                    new nlobjSearchColumn("internalid",null,null), 
                    new nlobjSearchColumn("email",null,null)
                ]
                );
                
                if ( repsearch.length>0 ){
                    var cols = repsearch[0].getAllColumns();
                    var salesrepintid = repsearch[0].getValue(cols[0]);
                    var salesrepemail = repsearch[0].getValue(cols[1]);                 
                }



                // SEARCH to find email addresses for created by
                var createdbysearch = nlapiSearchRecord("employee",null,
                [
                    ["internalidnumber","equalto",createdby]
                ], 
                [
                    new nlobjSearchColumn("internalid",null,null), 
                    new nlobjSearchColumn("email",null,null)
                ]
                );
                
                if ( createdbysearch.length>0 ){
                    var cols = createdbysearch[0].getAllColumns();
                    var createdbyintid = createdbysearch[0].getValue(cols[0]);
                    var createdbyemail = createdbysearch[0].getValue(cols[1]);                 
                }

            }   // estimate matching int id found

  
    } catch(e){
        nlapiLogExecution('ERROR', 'CATCH', e.message);
    }



        //when created we must email the manager of SR 
        if (type == 'create' || type == 'copy'){
            //if create notify the manager
            //var oldrec = nlapiGetOldRecord();
            var newrec = nlapiGetNewRecord();
            var recid = parseFloat( nlapiGetRecordId() );
            var entityname = newrec.getFieldText('entity');
            //var tranid = newrec.getFieldValue('tranid');    //ex: E1234       //not working on create
            var tranid = nlapiLookupField(nlapiGetRecordType(), nlapiGetRecordId(), 'tranid');
            var tranname = newrec.getFieldText('entity');   //ex: Andrew LaVelle
            var trantotal = newrec.getFieldValue('total');
            var newstatus = newrec.getFieldValue('status');
            var newapprovalstatus = parseFloat( newrec.getFieldValue('custbody_aw_est_approval_status') );
            var newapprover = parseFloat(newrec.getFieldValue('custbody_aw_est_approver') );
            var newapprovertext = newrec.getFieldText('custbody_aw_est_approver');
            var tranproperty = newrec.getFieldText('custbody_aw_property');
            var wdm = newrec.getFieldValue('custbody_waive_disposal');

            nlapiLogExecution('DEBUG','tranid',tranid);

            // 1 = Pending Approval && NO waive disposal markup
            if(newapprovalstatus == 1 && wdm == 'F'){
                // 39010 = Robert Bender (support@sdmayer.com)
                var efrom = 3,  //alison=3, aw=39010  gt=9230         // from = salesrep
                    eto = newapprover,                             //   to = approver        
                    esubject = trantypeverbose+' #'+tranid+' for '+ tranproperty +' needs your approval.',
                    ebody = '<p>Please Approve: '+trantypeverbose+' #'+tranid+'  linked below.</p>'+
                            '<p>'+entityname+', '+tranproperty+', for $'+trantotal+'</p>'+
                            '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                    ecc = '',
                    ebcc = '',
                    erecords = oldrec,
                    efiles = '';

                    //if (salesrep != createdby){ ecc = createdbyemail; }  // ecc = createdbyemail;
                    //if(ecc != ''){
                    //    nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                    //} else {
                        nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                    //}    
                nlapiLogExecution('DEBUG','CREATE-Email Sent (pending)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                
            }

            //Waive Disposal Markup for Andy
            if(newapprovalstatus == 1 && wdm == 'T'){
                // 39010 = Robert Bender (support@sdmayer.com)
                var efrom = 3,  //aw=39010  gt=9230         // from = salesrep
                    eto = newapprover,                             //   to = approver        
                    esubject = trantypeverbose+' #'+tranid+' for '+ tranproperty +' needs your approval.',
                    ebody = '<p>You are receiving this email because an '+trantypeverbose+' was marked: "Waive Disposal Markup" and requires your approval.</p>'+
                            '<p>Please Approve: '+trantypeverbose+' #'+tranid+' linked below.</p>'+
                            '<p>'+entityname+', '+tranproperty+', for $'+trantotal+'</p>'+
                            '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                    ecc = '',
                    ebcc = '',
                    erecords = oldrec,
                    efiles = '';

                    //if (salesrep != createdby){ ecc = createdbyemail; }  // ecc = createdbyemail;
                    //if(ecc != ''){
                    //    nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                    //} else {
                        nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                    //}    
                nlapiLogExecution('DEBUG','CREATE-Email Sent (pending)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                
            }


        }


        if ( type == 'edit' || type== 'xedit' ){
            var oldrec = nlapiGetOldRecord();
            var newrec = nlapiGetNewRecord();

            if (oldrec){
                //nlapiLogExecution('DEBUG','oldrec',oldrec);
                var oldstatus = oldrec.getFieldValue('status');             
                var oldapprovalstatus = parseFloat( oldrec.getFieldValue('custbody_aw_est_approval_status') );    //gt = partner
                var oldapprover = parseFloat( oldrec.getFieldValue('custbody_aw_est_approver') );

                var newstatus = newrec.getFieldValue('status');
                var newapprovalstatus = parseFloat( newrec.getFieldValue('custbody_aw_est_approval_status') ); // 1=pending 2=approved 3=rejected
                var newapprover = parseFloat( newrec.getFieldValue('custbody_aw_est_approver') );
                var newapprovertext = newrec.getFieldText('custbody_aw_est_approver');

                //var salesrep = parseFloat(newrec.getFieldText('salesrep'));
                var recid = parseFloat( nlapiGetRecordId() );
                var tranname = newrec.getFieldText('entity');
                //var tranid = newrec.getFieldValue('tranid');
                var tranid = oldrec.getFieldValue('tranid');
                var trantotal = newrec.getFieldValue('total');
                var tranproperty = newrec.getFieldText('custbody_aw_property');
                var wdm = newrec.getFieldValue('custbody_waive_disposal');

                nlapiLogExecution('DEBUG','oldrec status',oldstatus);
                nlapiLogExecution('DEBUG','approver','new='+newapprover+' old='+oldapprover);





                //if approver has changed AND its pending then we fire off an email
                if ( (oldapprover != newapprover) && (newapprovalstatus == 1) && wdm == 'F' ){    //approver changed & PENDING APPROVAL
                    // 39010 = Robert Bender (support@sdmayer.com)
                    var efrom = 3,  //aw=39010  gt=9230     //should be from SR
                        eto = newapprover,                            //should be to Approver
                        esubject = trantypeverbose+' #'+tranid+' for '+ tranproperty +' needs your approval.',
                        ebody = '<p>Please Approve: '+trantypeverbose+' #'+tranid+'</p>'+
                                '<p>'+tranname+', '+tranproperty+', for $'+trantotal+'</p>'+
                                '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                        ecc = '',   //if SR != created by then CC the creator
                        ebcc = '',
                        erecords = oldrec,
                        efiles = '';

                        //if (salesrep != createdby){ ecc = createdbyemail; }  // ecc = createdbyemail;
                        //if(ecc != ''){
                        //    nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                        //} else {
                            nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                        //}    
                    nlapiLogExecution('DEBUG','EDIT-Email Sent (diff approver -pending)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                    
                }

                if ( (oldapprover != newapprover) && (newapprovalstatus == 1) && wdm == 'T' ){    //approver changed & PENDING APPROVAL
                    // 39010 = Robert Bender (support@sdmayer.com)
                    var efrom = 3,  //aw=39010  gt=9230     //should be from SR
                        eto = newapprover,                            //should be to Approver
                        esubject = trantypeverbose+' #'+tranid+' for '+ tranproperty +' needs your approval.',
                        ebody = '<p>You are receiving this email because an '+trantypeverbose+' was marked: "Waive Disposal Markup" and requires your approval.</p>'+
                                '<p>Please Approve: '+trantypeverbose+' #'+tranid+'</p>'+
                                '<p>'+tranname+', '+tranproperty+', for $'+trantotal+'</p>'+
                                '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                        ecc = '',   //if SR != created by then CC the creator
                        ebcc = '',
                        erecords = oldrec,
                        efiles = '';

                        //if (salesrep != createdby){ ecc = createdbyemail; }  // ecc = createdbyemail;
                        //if(ecc != ''){
                        //    nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                        //} else {
                            nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                        //}    
                    nlapiLogExecution('DEBUG','EDIT-Email Sent (diff approver -pending)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                    
                }



                if ( newapprovalstatus == 2 && ( isNaN(oldapprover) == false  ) ) {     // if oldapprover isnt then then dont send email        // APPROVED
                    // 39010 = Robert Bender (support@sdmayer.com)
                    var efrom = 3,  //aw=39010  gt=9230     //should be from Approver
                        eto = salesrep,                            //should be to SR/creator
                        esubject = 'Manager Approval of '+trantypeverbose+' #'+tranid+', '+tranproperty,
                        ebody = '<p>'+trantypeverbose+' #'+tranid+' has been Approved by your Manager</p>'+
                                '<p>'+tranname+', '+tranproperty+', for $'+trantotal+'</p>'+
                                '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                        ecc = '',
                        ebcc = '',
                        erecords = oldrec,
                        efiles = '';

                    if (salesrep != createdby){ var ecc = createdbyemail; } // createdbyemail

                    //nlapiLogExecution('DEBUG','EDIT-Emailing.. (APPROVED)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody+ '\n'+ ecc);  
                    if(ecc != ''){
                        nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                    } else {
                        nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                    }
                    
                    nlapiLogExecution('DEBUG','EDIT-Email Sent (APPROVED)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                    
                }


                if ( newapprovalstatus == 3 ) {                                                         // REJECTED
                    // 39010 = Robert Bender (support@sdmayer.com)
                    var efrom = oldapprover,  //aw=39010  gt=9230     //should be from Approver
                        eto = salesrep,                            //should be to SR/creator
                        esubject = trantypeverbose+' Rejected #'+tranid,
                        ebody = '<p>'+trantypeverbose+' #'+tranid+' has been Rejected.</p>'+
                        '<p>Please contact your Manager for more information</p>'+
                        '<p>'+tranname+', '+tranproperty+', for $'+trantotal+'</p>'+
                        '<p>link to Transaction: <a href="https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +'">'+ 'https://system.na1.netsuite.com/app/accounting/transactions/'+trantype+'.nl?id='+ recid +' </a></p>',
                        ecc = '',
                        ebcc = '',
                        erecords = oldrec,
                        efiles = '';

                    if (salesrep != createdby){ var ecc = createdbyemail }  //createdbyemail
                    if(ecc != ''){
                        nlapiSendEmail ( efrom , eto , esubject , ebody, ecc );   // , ecc , ebcc , erecords , efiles 
                    } else {
                        nlapiSendEmail ( efrom , eto , esubject , ebody ); 
                    }
                    nlapiLogExecution('DEBUG','EDIT-Email Sent (REJECTED)',efrom +'\n'+ eto +'\n'+ esubject +'\n'+ ebody);                    
                }



            } //if oldrec

        } //endif edit

      

}
