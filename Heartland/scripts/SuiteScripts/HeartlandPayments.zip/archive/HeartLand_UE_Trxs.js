/**
 * Created by Huzaifa on 9/10/2017.
 */

/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['/SuiteScripts/Heartland/globalpayments.api.js', 'N/record'], function (GP, record) {

    function beforeLoad(context) {

    }

    function beforeSubmit(context) {

    }

    function afterSubmit(context) {


    }

    return {
        //beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
});