/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Apr 2014     rgurram
 *
 */

/**
 * @param {Number} toversion
 * @returns {Void}
 */
function beforeInstall(toversion) {
  
}

/**
 * @param {Number} toversion
 * @returns {Void}
 */
function afterInstall(toversion) {
  
}

/**
 * @param {Number} fromversion
 * @param {Number} toversion
 * @returns {Void}
 */
function beforeUpdate(fromversion, toversion) {
 
}

/**
 * @param {Number} fromversion
 * @param {Number} toversion
 * @returns {Void}
 */
function afterUpdate(fromversion, toversion) {
  
}

/**
 * @returns {Void}
 */
function beforeUninstall() {
 
}