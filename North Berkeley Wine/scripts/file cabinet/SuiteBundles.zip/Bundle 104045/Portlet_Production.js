/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       10 Jul 2014     rgurram
 *
 */

/**
 * @param {nlobjPortlet} portletObj Current portlet object
 * @param {Number} column Column position index: 1 = left, 2 = middle, 3 = right
 * @returns {Void}
 */
function VirtualOffice(portletObj, column) {
	portlet.setTitle('8x8 Virtual Office');
	var url = nlapiOutboundSSO('customssovirtualofficesso');
	var content = '<iframe src="'+url+'" align="center" style="width: 100%; height: 100px; margin:0; border:0; padding:0"></iframe>';
	  
	portlet.setHtml( content );
}
