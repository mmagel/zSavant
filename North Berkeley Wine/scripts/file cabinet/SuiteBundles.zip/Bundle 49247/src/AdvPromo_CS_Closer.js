/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

function pageInit() {
	window.close();
	// Use this for ExtJs
	/*
	var theWindow = window.parent.Ext.WindowMgr.getActive();
	theWindow.close();
	*/
}