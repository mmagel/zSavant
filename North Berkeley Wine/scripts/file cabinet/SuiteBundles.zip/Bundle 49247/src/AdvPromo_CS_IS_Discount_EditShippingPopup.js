/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

/**
 * Module Description Here
 * You are using the default templates which should be customized to your needs.
 * You can change your user name under Preferences->NetSuite Plugin->Code Templates.
 *
 * Version    Date            Author           Remarks
 * 1.00       15 Feb 2012     dembuscado
 *
 */

/**
 * @param {String} type Access mode: create, copy, edit
 * @return {void}
 */

var TRANS_CS_IS_Discount_EditShippingPopup = {};
function init_CS_IS_Discount_EditShippingPopup() {
	var translates = [];
	translates.push(new TranslateMember('label.percentoff', 'LABEL_PERCENT_OFF', 'Percent Off'));
	translates.push(new TranslateMember('label.amount.set', 'LABEL_SET_AMOUNT', 'Set Amount'));
	translates.push(new TranslateMember('text.or', 'TEXT_OR', 'or'));
	translates.push(new TranslateMember('text.on', 'TEXT_ON', 'on'));
	translates.push(new TranslateMember('text.off', 'TEXT_OFF', 'Off'));
	translates.push(new TranslateMember('error.amount.enter', 'ERROR_AMOUNT_ENTER', 'Please enter value(s) for: amount'));
	translates.push(new TranslateMember('error.amount.nan', 'ERROR_AMOUNT_NAN', 'Invalid amount value. Values must be numbers'));
	translates.push(new TranslateMember('error.amount.range', 'ERROR_AMOUNT_RANGE', 'Invalid amount value. Values must be greater than zero.'));
	translates.push(new TranslateMember('error.percent.enter', 'ERROR_PERCENT_ENTER', 'Please enter value(s) for: percent'));
	translates.push(new TranslateMember('error.percent.nan', 'ERROR_PERCENT_NAN', 'Invalid percent value. Values must be numbers'));
	translates.push(new TranslateMember('error.percent.range', 'ERROR_PERCENT_RANGE', 'Invalid percent value. Values must be greater than zero and must not exceed 100.'));
	translates.push(new TranslateMember('error.shipping.select', 'ERROR_SHIPPING_SELC', 'Please select at least one method from the list'));
	translates.push(new TranslateMember('text.please.wait', 'TEXT_PLEASE_WAIT', 'Please wait'));
	translates.push(new TranslateMember('text.loading.page', 'TEXT_LOADING_PAGE', 'Loading page...'));
	translates.push(new TranslateMember('text.percent.completed', 'TEXT_PERCENT_COMPLETED', 'Completed'));
	TRANS_CS_IS_Discount_EditShippingPopup = new TranslateHelper(translates);
}
var TranslateInitFunctions;
var TranslateInit;
if (!TranslateInitFunctions) TranslateInitFunctions = [];
TranslateInitFunctions.push(init_CS_IS_Discount_EditShippingPopup);
if (TranslateInit) TranslateInit();

var Ext;
if(Ext && Ext.MessageBox) {
    Ext.MessageBox.show({
        title: TRANS_CS_IS_Discount_EditShippingPopup.TEXT_PLEASE_WAIT,
        msg: TRANS_CS_IS_Discount_EditShippingPopup.TEXT_LOADING_PAGE + '...',
        progressText: '0% ' + TRANS_CS_IS_Discount_EditShippingPopup.TEXT_PERCENT_COMPLETED,
        progress:true,
        closable:false,
        width:300
    });
}

var currencyList;
var methodIds;
var amountCurrIds;

function objectKeys(obj) {
	if (!obj) return [];
	if ((($.browser.msie) && ($.browser.version < 9)) ||
		(($.browser.safari) && ($.browser.version < 5))) {
		var a = [];
		$.each(obj, function(k){ a.push(k);});
		return a;
	} else {
		try {
			return (obj) ? Object.keys(obj) : [];
		} catch (e) { // fallback
			var a = [];
			$.each(obj, function(k){ a.push(k);});
			return a;
		}
	}
}


function pageInit(type){

		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			var cssTool = Ext.util.CSS;
			cssTool.updateRule('.x-window-mc', 'font-family', 'Open Sans');
		}

	methodIds = window.parent.AdvPromo.PromotionCs.globalParam['23_selShipMethodIds'];
	amountCurrIds = window.parent.AdvPromo.PromotionCs.globalParam['23_selAmountCurr'];

	currencyList = JSON.parse(nlapiGetFieldValue('custpage_currencies_shipping_edit'));

	currencyList.sort(function (a, b) {
		if ((a.value == 0) && (b.value != 0)) return -1;
		else if ((a.value != 0) && (b.value == 0)) return 1;
		else if (a.text.toLocaleUpperCase() < b.text.toLocaleUpperCase()) return -1;
		else if (a.text.toLocaleUpperCase() > b.text.toLocaleUpperCase()) return 1;
		else return 0;
	});

	var theLabel = '';

	var selectBoxPrefix='currencyUnit', valuePrefix='amount', containerId='custpage_all_items_list2';
	$('#' + containerId).css('border-collapse', 'collapse');

	var selectOptions = currencyList;

	var selectedValues = [];	// values of currency dropdown
	var inputBoxValues = [];	// values of amount
	var percentValue = ""; 		// value of amount in percent
	var defaultRadio = 0;

	var numOfAmCurr = objectKeys(amountCurrIds).length;

	if(numOfAmCurr == 1 && amountCurrIds[0].currency == ""){
		percentValue = amountCurrIds[0].amount;
		selectedValues = [""];
		inputBoxValues = [""];
	}else{
		for(var i=0; i<numOfAmCurr; i++){
			inputBoxValues.push(amountCurrIds[i].amount);
			selectedValues.push(amountCurrIds[i].currency);
		}
		defaultRadio = 1;
	}

	var theLabel = "";
	var selector = new ValueUnitObject(theLabel, 'currencyUnitt', 'amountt', containerId, selectOptions, selectedValues, inputBoxValues);

	var valueBox = new TextboxObject(theLabel, valuePrefix, containerId, percentValue);

	var theLabel1 = new LabelWithHelp(TRANS_CS_IS_Discount_EditShippingPopup.LABEL_PERCENT_OFF, 'custpage_advpromo_shipping');
	var theLabel2 = new LabelWithHelp(TRANS_CS_IS_Discount_EditShippingPopup.LABEL_SET_AMOUNT,  'custpage_advpromo_shipping');
	var labels = new ToggleLabels(theLabel1, theLabel2, '');

	var config = null;
	if(window.parent.AdvPromo.PromotionCs.isNewUi) config = {'labelFontSize': '14px', 'labelTextAlign': 'left'};
	$.shippingPriceForm = new Toggle(selectBoxPrefix, valuePrefix, containerId, labels, valueBox, selector, defaultRadio, config);
	$.selector = selector;

	var stopper = true;

	// beautify layout
	if(window.parent.AdvPromo.PromotionCs.isNewUi){
		moveButtonToBottom('tr_custpage_add_discount_shipping_price_edit');
	}

	hideProgressBar();
}

function hideProgressBar(){
	var f = function(v){
		return function(){
		    if(v == 12){
		    	Ext.MessageBox.hide.defer(100, Ext.MessageBox);
		    }
		    else{
		        var i = v/11;
		        Ext.MessageBox.updateProgress(i, Math.round(10*i)+'% ' + TRANS_CS_IS_Discount_EditShippingPopup.TEXT_PERCENT_COMPLETED);
		    }
		};
   	};

   	for(var i = 1; i < 13; i++){
   		setTimeout(f(i), i*100);
   	}

   	Ext.get("div__body").dom.style.visibility="visible";
}

/*
 *
 */
function cancelDiscountShipping(){
	var theWindow = window.parent.Ext.WindowMgr.getActive();
	theWindow.close();
}

function validateDiscountShipping(fields){
	if(fields instanceof Array){
		var size = fields.length;
		for(var i=0; i<size; i++){
			if(fields[i].value == "" || fields[i].value == null){
				alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_AMOUNT_ENTER);
				return false;
			}
			// input should be numeric
			if(isNaN(fields[i].value)){
				alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_AMOUNT_NAN);
				return false;
			}
			if(fields[i].value <= 0){
				alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_AMOUNT_RANGE);
				return false;
			}
		}
	}else{
		if(fields == "" || fields == null){
			alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_PERCENT_ENTER);
			return false;
		}
		// input should be numeric
		if(isNaN(fields)){
			alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_PERCENT_NAN);
			return false;
		}
		if(fields <= 0 || fields > 100){
			alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_PERCENT_RANGE);
			return false;
		}
	}
	return true;
}

function validateDiscountShipMethod(shipMethodIds){
	if(shipMethodIds.length == 0){
		alert(TRANS_CS_IS_Discount_EditShippingPopup.ERROR_SHIPPING_SELC);
		return false;
	}
	return true;
}


function editShippingPrice(){

	var shippingPriceList = [];
	var shippingMethod = [];

	var shipMethodIds = [];
	var shipMethodNames = [];
	var shippingObjArr = [];

	shipMethodNames = nlapiGetFieldTexts('custpage_advpromo_shipping_method_multiselect_edit');
	shipMethodIds = nlapiGetFieldValues('custpage_advpromo_shipping_method_multiselect_edit');

	var shipOr = "";
	var priceOr = "";
	var methodNum = shipMethodNames.length;

	shippingPriceList = $.shippingPriceForm.getValues();

	if(validateDiscountShipping(shippingPriceList) && validateDiscountShipMethod(shipMethodIds)){
		if(shippingPriceList instanceof Array){
			for (var i = 0; i < shippingPriceList.length; i++){
				var currency = shippingPriceList[i].key;

				shippingObjArr.push({"amount":shippingPriceList[i].value, "currency":currency, "isPercent":'F', "type":'3', "oper":'A'});		// shipping type is 3 in promotion discount

				var skey = parseInt(shippingPriceList[i].key);
				if(priceOr == "") {
					priceOr = shippingPriceList[i].value + " " + retrieveText(currencyList, skey);
				}else{
					priceOr = priceOr + " " + TRANS_CS_IS_Discount_EditShippingPopup.TEXT_OR + " " + shippingPriceList[i].value + " " + retrieveText(currencyList, skey);
				}
			}
		}else{
			priceOr = shippingPriceList + '% ' + TRANS_CS_IS_Discount_EditShippingPopup.TEXT_OFF + ' ';
			var currency = '';
			shippingObjArr.push({"amount":shippingPriceList, "currency":currency, "isPercent":'T', "type":'3', "oper":'A'});
		}

		//disjunct shipping methods into one line
		for (var j = 0; j < methodNum; j++){
			if(shipOr == "") {
				shipOr = " " + TRANS_CS_IS_Discount_EditShippingPopup.TEXT_ON + " " + shipMethodNames[j];
			}else{
				shipOr = shipOr + " / " + shipMethodNames[j];
			}
		}
		var textDisplay = priceOr + shipOr;

		window.parent.AdvPromo.PromotionCs.syncEditToListObject(23, shippingObjArr, [textDisplay, shipMethodIds]);// trigger adding of data to sublist
		var theWindow = window.parent.Ext.WindowMgr.getActive();
		theWindow.close();
	}

}
