/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

var TRANS_CS_OrderDiscountPopup = {};
function init_CS_IS_OrderDiscountPopup() {
	var translates = [];
	translates.push(new TranslateMember('label.promo.offer', 'LABEL_PROMO_OFFER', 'Promotional Offer'));
	translates.push(new TranslateMember('label.discount.upto', 'LABEL_DISCOUNT_UPTO', 'Discount Up To'));
	translates.push(new TranslateMember('text.off', 'TEXT_OFF', 'Off'));
	translates.push(new TranslateMember('text.or', 'TEXT_OR', 'or'));
	translates.push(new TranslateMember('text.nolimit', 'TEXT_NOLIMIT', 'No Limit'));
	translates.push(new TranslateMember('text.please.wait', 'TEXT_PLEASE_WAIT', 'Please wait'));
	translates.push(new TranslateMember('text.loading.page', 'TEXT_LOADING_PAGE', 'Loading page...'));
	translates.push(new TranslateMember('text.percent.completed', 'TEXT_PERCENT_COMPLETED', 'Completed'));
	TRANS_CS_OrderDiscountPopup = new TranslateHelper(translates);
}
var TranslateInitFunctions;
var TranslateInit;
if (!TranslateInitFunctions) TranslateInitFunctions = [];
TranslateInitFunctions.push(init_CS_IS_OrderDiscountPopup);
if (TranslateInit) TranslateInit();

Ext.MessageBox.show({
	title: TRANS_CS_OrderDiscountPopup.TEXT_PLEASE_WAIT,
	msg: TRANS_CS_OrderDiscountPopup.TEXT_LOADING_PAGE + '...',
	progressText: '0% ' + TRANS_CS_OrderDiscountPopup.TEXT_PERCENT_COMPLETED,
	progress:true,
	closable:false,
	width:300
});

AdvPromo.OrderDiscountCS = new function () {
	this.promoOfferList;
	this.limitList;
	
	this.pageInit = function(type){
	
		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			var cssTool = Ext.util.CSS;
			cssTool.updateRule('.x-window-mc', 'font-family', 'Open Sans');
		}
	
		this.promoOfferList = JSON.parse(nlapiGetFieldValue('custpage_promo_offer_currencies'));
		this.limitList = JSON.parse(nlapiGetFieldValue('custpage_limit_currencies'));
		
		var promoOfferCurrencies = [], promoOfferValues = [];
		var limitCurrencies = [], limitValues = [];
		var editMode = false;
		
		var dataModel = window.parent.AdvPromo.PromotionCs.mainModel;
		if(dataModel && dataModel.promotionalOffers.length > 0){
			editMode = true;
			
			for(var i = 0; i < dataModel.promotionalOffers.length; i++){
				promoOfferCurrencies.push(dataModel.promotionalOffers[i].currencyId);
				promoOfferValues.push(dataModel.promotionalOffers[i].amount);
			}
			
			for(var i = 0; i < dataModel.promotionalOfferLimits.length; i++){
				limitCurrencies.push(dataModel.promotionalOfferLimits[i].currencyId);
				limitValues.push(dataModel.promotionalOfferLimits[i].amount);
			}
		}
				
		// specify layout adjustments
		var layoutConfig = {'labelWidth': '120px', 'labelPadding': '0 3px 0 0', 'selectWidth': '67px'};
		
		// construct Promotional Offer
		var promoOfferLbl = new LabelWithHelp(TRANS_CS_OrderDiscountPopup.LABEL_PROMO_OFFER, 'custpage_promo_offer');
		var promoOfferValuePrefix = 'promoAmount';
		var promoOfferCurrencyPrefix = 'promoCurrencyUnit';
		var promoOfferContainer = 'custpage_promo_offers';
		if(editMode){
			$.allPromoForm = new ValueUnitObject(promoOfferLbl, promoOfferCurrencyPrefix, promoOfferValuePrefix, 
					promoOfferContainer, this.promoOfferList, promoOfferCurrencies, promoOfferValues, layoutConfig);	
		}
		else{
			$.allPromoForm = new ValueUnitObject(promoOfferLbl, promoOfferCurrencyPrefix, promoOfferValuePrefix, 
					promoOfferContainer, this.promoOfferList, null, null, layoutConfig);
		}
		
		
		// construct Discount Up To
		var limitLbl = new LabelWithHelp(TRANS_CS_OrderDiscountPopup.LABEL_DISCOUNT_UPTO, 'custpage_limit_label');
		var limitValuePrefix = 'limitAmount';
		var limitCurrencyPrefix = 'limitCurrencyUnit';
		var limitContainer = 'custpage_limits';
		layoutConfig = {'labelWidth': '120px', 'labelPadding': '0 3px 0 0', 'selectWidth': '67px'};
		if(editMode && dataModel.promotionalOfferLimits.length > 0){
			$.allLimitForm = new ValueUnitObject(limitLbl, limitCurrencyPrefix, limitValuePrefix, 
				limitContainer, this.limitList, limitCurrencies, limitValues, layoutConfig);
					
		}
		else{
			$.allLimitForm = new ValueUnitObject(limitLbl, limitCurrencyPrefix, limitValuePrefix, 
				limitContainer, this.limitList, null, null, layoutConfig);
		}
		
		var registerParams = {'popupType': 'orderDiscount'};
		$.allPromoForm.register($.allLimitForm, registerParams);	
		
		
		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			moveButtonToBottom('tr_custpage_save');	
			var header = '<table><tr><td class="fgroup_title"><div class="fgroup_title" style="color:#5A6F8F; border-bottom:1px solid #CCC; font-weight:600; white-space:nowrap; margin:0 0 2px 0; width: 260px;">Discount Limit</div></td></tr></table><br/>';        
		    $('#custpage_limits').prepend($(header));
		}
		else{
			$('#custpage_promo_offers').css('margin-top', '10px');
		}
		
		this.hideProgressBar();
	};
	
	this.hideProgressBar = function(){
		var f = function(v){
			return function(){
			    if(v == 12){
			    	Ext.MessageBox.hide.defer(100, Ext.MessageBox);
			    }
			    else{
			        var i = v/11;
			        Ext.MessageBox.updateProgress(i, Math.round(10*i)+'% ' + TRANS_CS_OrderDiscountPopup.TEXT_PERCENT_COMPLETED);
			    }
			};
	   	};
	   	
	   	for(var i = 1; i < 13; i++){
	   		setTimeout(f(i), i*100);
	   	}
	   	
	   	Ext.get("div__body").dom.style.visibility="visible";
	};
	
	this.getCurrencySymbol = function(currencyId, currencyList){
		
		if(currencyList && currencyList instanceof Array){
			for(var i = 0; i < currencyList.length; i++){
				if(currencyId == currencyList[i].value){
					if(currencyId == 0 && currencyList[i].text == '%'){
						return '% ' + TRANS_CS_OrderDiscountPopup.TEXT_OFF;
					}
					else{
						return currencyList[i].text;	
					}
				}
			}	
		}
			
		return '';
	};
	
	this.isOfferInPercent = function(promoOfferValues){
		
		if(promoOfferValues[0].key == 0) {
			return true;
		}
		
		return false;
	};

	this.cancel = function(){
		window.parent.Ext.WindowMgr.getActive().close();
	};

	this.save = function(){
		
		var promoOfferValues = $.allPromoForm.getValues();
		var limitValues = $.allLimitForm.getValues();
		
		if(validateDiscountItemFields(promoOfferValues) && validateLimitEntries(limitValues)){
			var mainModel = new MainModel();
			
			// populate promotionalOffers
			mainModel.promotionalOffers = [];
			var isPercent = this.isOfferInPercent(promoOfferValues);
			for(var i = 0; i < promoOfferValues.length; i++){
				var obj = {};
				
				obj.currencyId = promoOfferValues[i].key;
				obj.offerLabel = this.getCurrencySymbol(promoOfferValues[i].key, this.promoOfferList);
				obj.amount = promoOfferValues[i].value;
				obj.isPercent = isPercent;
				
				mainModel.promotionalOffers.push(obj);
			}
			
			// populate promotionalOfferLimits
			mainModel.promotionalOfferLimits = [];
			for(var i = 0; i < limitValues.length; i++){
				
				if(limitValues[i].value){
					var obj = {};
					
					obj.currencyId = limitValues[i].key;
					obj.limitLabel = this.getCurrencySymbol(limitValues[i].key, this.limitList);
					obj.amount = limitValues[i].value;
					obj.isUnit = false;
					
					mainModel.promotionalOfferLimits.push(obj);	
				}
			}

			window.parent.AdvPromo.PromotionCs.renderOrderSublist(mainModel);
			window.parent.AdvPromo.PromotionCs.flagChanged();

			window.parent.Ext.WindowMgr.getActive().close();
		}
		
		
	};
};
