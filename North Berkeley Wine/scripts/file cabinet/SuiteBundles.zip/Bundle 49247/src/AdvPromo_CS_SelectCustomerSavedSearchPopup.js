/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

var TRANS_CS_SelectCustomerSavedSearchPopup = {};

var SAVEDSEARCHDDL = 'custpage_advpromo_savedsearch'; //id for list of customer saved search
var DESCRIPTION = 'custpage_advpromo_description'; // id for description

function init_CS_AddCustomerSaveSearchPopup() {
	var translates = [];
	translates.push(new TranslateMember('error.customer.ss.exists', 'SEARCH_EXISTS', 'Customer Saved Search already exists in the sublist'));
	translates.push(new TranslateMember('error.customer.select', 'SELECT_CUSTOMER', 'Please select at least one customer from the list'));
	translates.push(new TranslateMember('text.please.wait', 'TEXT_PLEASE_WAIT', 'Please wait'));
	translates.push(new TranslateMember('text.loading.page', 'TEXT_LOADING_PAGE', 'Loading page...'));
	translates.push(new TranslateMember('text.percent.completed', 'TEXT_PERCENT_COMPLETED', 'Completed'));
	TRANS_CS_SelectCustomerSavedSearchPopup = new TranslateHelper(translates);
}



var TranslateInitFunctions;
var TranslateInit;
if (!TranslateInitFunctions) TranslateInitFunctions = [];
TranslateInitFunctions.push(init_CS_AddCustomerSaveSearchPopup);
if (TranslateInit) TranslateInit();

var Ext;
if(Ext && Ext.MessageBox) {
    Ext.MessageBox.show({
        title: TRANS_CS_SelectCustomerSavedSearchPopup.TEXT_PLEASE_WAIT,
        msg: TRANS_CS_SelectCustomerSavedSearchPopup.TEXT_LOADING_PAGE + '...',
        progressText: '0% ' + TRANS_CS_SelectCustomerSavedSearchPopup.TEXT_PERCENT_COMPLETED,
        progress:true,
        closable:false,
        width:300
    });
}

AdvPromo.SelectCustSrchCS = new function () {

	this.pageInit = function(){

		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			var cssTool = Ext.util.CSS;
			cssTool.updateRule('.x-window-mc', 'font-family', 'Open Sans');
		}

		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			$('#inpt_' + SAVEDSEARCHDDL + '1').width(300);
			$('#' + DESCRIPTION).width(300);
			//$('#tr_custpage_save').addClass('pgBntY pgBntB');
			moveButtonToBottom('tr_custpage_save');
		}

		this.hideProgressBar();
	};

	this.isNewRowUnique = function(savedSearchId, eligibleCustomersModel){

		if(!savedSearchId || !eligibleCustomersModel){
			return false;
		}

		if(eligibleCustomersModel){
			for(var i = 0; i < eligibleCustomersModel.length; i++){
				var mod = eligibleCustomersModel[i];

				if(parseInt(mod.type) === AdvPromo.GlobalConstants.CONST_ELIGIBILITY_CUSTOMER_TYPE_SAVED_SEARCH
					&& parseInt(mod.id) === parseInt(savedSearchId) && mod.op !== 'D'){
					return false;
				}
			}
		}

		return true;
	};

	this.save = function(){

		var savedSearchId = nlapiGetFieldValue(SAVEDSEARCHDDL);
		var savedSearchName = nlapiGetFieldText('custpage_advpromo_savedsearch');
		var description = nlapiGetFieldValue(DESCRIPTION);
		var modelIndex = nlapiGetFieldValue('custpage_advpromo_index');

		if(!savedSearchId){ // won't happen since there's always one selected
			alert(TRANS_CS_SelectCustomerSavedSearchPopup.SELECT_CUSTOMER);
			return;
		}

		if(modelIndex){
			var oldSavedSearchId = window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].id;
			if(oldSavedSearchId != savedSearchId){
				// check for duplicate entry in sublist
				if(!this.isNewRowUnique(savedSearchId, window.parent.AdvPromo.PromotionCs.eligibleCustomersObj)){
					alert(TRANS_CS_SelectCustomerSavedSearchPopup.SEARCH_EXISTS);
					return;
				}
			}

			// access the main model directly
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].op = 'E';
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].id = savedSearchId;
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].name = savedSearchName;
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].desc = description;

			window.parent.AdvPromo.PromotionCs.sublistMgr.renderEligibilityCustomerSublistEditMode(true);
		}
		else{
			// check for duplicate entry in sublist
			if(!this.isNewRowUnique(savedSearchId, window.parent.AdvPromo.PromotionCs.eligibleCustomersObj)){
				alert(TRANS_CS_SelectCustomerSavedSearchPopup.SEARCH_EXISTS);
				return;
			}

			var custObj = {};
			custObj.type = AdvPromo.GlobalConstants.CONST_ELIGIBILITY_CUSTOMER_TYPE_SAVED_SEARCH;
			custObj.op = 'A';
			custObj.id = savedSearchId;
			custObj.name = savedSearchName;
			custObj.desc = description;

			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj.push(custObj);
			window.parent.AdvPromo.PromotionCs.sublistMgr.renderEligibilityCustomerSublistEditMode(true);
		}

		window.parent.Ext.WindowMgr.getActive().close();
	};

	this.cancel = function() {
		window.parent.Ext.WindowMgr.getActive().close();
	};

	this.hideProgressBar = function(){
		var f = function(v){
			return function(){
			    if(v == 12){
			    	Ext.MessageBox.hide.defer(100, Ext.MessageBox);
			    }
			    else{
			        var i = v/11;
			        Ext.MessageBox.updateProgress(i, Math.round(10*i)+'% ' + TRANS_CS_SelectCustomerSavedSearchPopup.TEXT_PERCENT_COMPLETED);
			    }
			};
	   	};

	   	for(var i = 1; i < 13; i++){
	   		setTimeout(f(i), i*100);
	   	}

	   	Ext.get("div__body").dom.style.visibility="visible";
	};
};

