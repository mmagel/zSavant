/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

var TRANS_CS_AddCustomerSaveSearchPopup = {};
function init_CS_AddCustomerSaveSearchPopup() {
	var translates = [];
	translates.push(new TranslateMember('error.customer.select', 'SELECT_CUSTOMER', 'Please select at least one customer from the list'));
	translates.push(new TranslateMember('text.please.wait', 'TEXT_PLEASE_WAIT', 'Please wait'));
	translates.push(new TranslateMember('text.loading.page', 'TEXT_LOADING_PAGE', 'Loading page...'));
	translates.push(new TranslateMember('text.percent.completed', 'TEXT_PERCENT_COMPLETED', 'Completed'));
	TRANS_CS_AddCustomerSaveSearchPopup = new TranslateHelper(translates);
}

var TranslateInitFunctions;
var TranslateInit;
if (!TranslateInitFunctions) TranslateInitFunctions = [];
TranslateInitFunctions.push(init_CS_AddCustomerSaveSearchPopup);
if (TranslateInit) TranslateInit();

Ext.MessageBox.show({
	title: TRANS_CS_AddCustomerSaveSearchPopup.TEXT_PLEASE_WAIT,
	msg: TRANS_CS_AddCustomerSaveSearchPopup.TEXT_LOADING_PAGE + '...',
	progressText: '0% ' + TRANS_CS_AddCustomerSaveSearchPopup.TEXT_PERCENT_COMPLETED,
	progress:true,
	closable:false,
	width:300
});

AdvPromo.SelectCustomerCS = new function () {

	this.pageInit = function(){
	
		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			var cssTool = Ext.util.CSS;
			cssTool.updateRule('.x-window-mc', 'font-family', 'Open Sans');
		}
	
		if(window.parent.AdvPromo.PromotionCs.isNewUi){
			moveButtonToBottom('tr_custpage_save');
		}
		
		this.hideProgressBar();
	};
	
	
	this.save = function(){
		
		var customerIds = nlapiGetFieldValues('custpage_advpromo_customers');
		var customerNames = nlapiGetFieldTexts('custpage_advpromo_customers');
		var modelIndex = nlapiGetFieldValue('custpage_advpromo_index');
		
		if(!customerIds || (customerIds && customerIds.length == 0) || (customerIds && customerIds.length == 1 && !customerIds[0])){
			alert(TRANS_CS_AddCustomerSaveSearchPopup.SELECT_CUSTOMER);
			return;
		}
		
		if(modelIndex){
			// access the main model directly
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].op = 'E';
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].id = customerIds;
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj[modelIndex].name = customerNames;
			
		}
		else{
			var custObj = {}; 
			custObj.type = AdvPromo.GlobalConstants.CONST_ELIGIBILITY_CUSTOMER_TYPE_CUSTOMER;	
			custObj.op = 'A';
			custObj.id = customerIds;
			custObj.name = customerNames;
			
			window.parent.AdvPromo.PromotionCs.eligibleCustomersObj.push(custObj);
		}

		window.parent.AdvPromo.PromotionCs.sublistMgr.renderEligibilityCustomerSublistEditMode(true);
		window.parent.Ext.WindowMgr.getActive().close();
	};
	
	this.cancel = function() {
		window.parent.Ext.WindowMgr.getActive().close();
	};
	
	this.hideProgressBar = function(){
		var f = function(v){
			return function(){
			    if(v == 12){
			    	Ext.MessageBox.hide.defer(100, Ext.MessageBox);
			    }
			    else{
			        var i = v/11;
			        Ext.MessageBox.updateProgress(i, Math.round(10*i)+'% ' + TRANS_CS_AddCustomerSaveSearchPopup.TEXT_PERCENT_COMPLETED);
			    }
			};
	   	};
	   	
	   	for(var i = 1; i < 13; i++){
	   		setTimeout(f(i), i*100);
	   	}
	   	
	   	Ext.get("div__body").dom.style.visibility="visible";
	};
};
