/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

AdvPromo.FieldFormatter = new function FieldFormatter() {
	
	var REC_AUTOPOST = 'customrecord_advpromo_ssearch_select';
	var FLD_AUTOPOST_SEARCH = 'custrecord_advpromo_sssetup_saved_search';
	var FLD_AUTOPOST_SEARCHTYPE = 'custrecord_advpromo_sssetup_search_type';
	
	this.truncateText = function(inputText, maxLength) {
		if (!inputText) return null;
		
		var length = (isNaN(maxLength)) ? 300 : maxLength;
		if (inputText.length <= length) return inputText;
		
		return (inputText.substring(0, (length > 3) ? (length - 3) : length) + '...');
	};
	
	this.retrieveSavedSearchesOfScriptedRecord = function(recordType){
	    
		// simulate creating a new record in the client. To do so, recordmode needs to be set to dynamic
		var record = nlapiCreateRecord(REC_AUTOPOST, {
			recordmode: 'dynamic'
		});
		
		record.setFieldValue(FLD_AUTOPOST_SEARCHTYPE, recordType); //search type

		var fld = record.getField(FLD_AUTOPOST_SEARCH);	//saved search
		var selectOptions = fld.getSelectOptions();

		return selectOptions;
	};
};