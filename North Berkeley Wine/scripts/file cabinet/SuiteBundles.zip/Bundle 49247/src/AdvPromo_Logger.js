/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

AdvPromo.CustomLogger = new function CustomLogger()
{
	var showDebugMessages = false;
	var logTitle = 'AdvPromo Logger';

	this.debug = function(title, message) {
		if(showDebugMessages){
			if(arguments.length == 1){
				nlapiLogExecution('DEBUG', logTitle, title);
			}
			else if(arguments.length == 2){
				nlapiLogExecution('DEBUG', title || logTitle, message);
			}
		}
	};

	this.error = function(title, message) {
		if(showDebugMessages){
			if(arguments.length == 1){
				nlapiLogExecution('ERROR', logTitle, title);
			}
			else if(arguments.length == 2){
				nlapiLogExecution('ERROR', title || logTitle, message);
			}
		}
	};

	this.audit = function(title, message) {
		if(showDebugMessages){
			if(arguments.length == 1){
				nlapiLogExecution('AUDIT', logTitle, title);
			}
			else if(arguments.length == 2){
				nlapiLogExecution('AUDIT', title || logTitle, message);
			}
		}
	};

	this.debugVar = function(varName, varValue) {
		if(showDebugMessages){
			nlapiLogExecution('DEBUG', logTitle, varName + ': ' + varValue);
		}
	};
};