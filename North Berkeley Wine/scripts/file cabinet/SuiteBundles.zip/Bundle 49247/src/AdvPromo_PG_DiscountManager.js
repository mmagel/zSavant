/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

if (!AdvPromo.Plugin) { AdvPromo.Plugin = {}; }

AdvPromo.Plugin.ItemDiscountManager = new function ItemDiscountManager() {

	this.logger = AdvPromo.CustomLogger;
	
	this.promotionsApi;
	this.discountAmount;
	this.discountIsPercent;
	this.limit;
	this.limitIsUnit;
	this.isFixedPrice;
	this.discountableLineItems = []; // array of SortedLineItemModel
	
	this.init = function(mainModel, promotionsOutput){
		
		this.promotionsApi = promotionsOutput;
		
		// only get the discount details on the first entry of PromotionDiscountModel
		var discountInfo = mainModel.promotionDiscountModel[0];

		// if discountInfo is null or undefined, it means no discount to apply
		if(discountInfo){
			this.discountAmount = Number(discountInfo.amount) || 0;
			this.discountIsPercent = discountInfo.isPercent == 'T' ? true : false;
			this.limit = discountInfo.limit;
			this.limitIsUnit = discountInfo.isUnit == 'T' ? true : false;
			this.isFixedPrice = discountInfo.isFixedPrice || false;
			
			// on Buy X Get Y, if limit = -1, skip all logic and end discount application
			if(this.limit == -1){
				return;
			}
			
			// handle bad data in custom record (sometimes limitIsUnit = false). if No Limit, set limitIsUnit = true. 
			if(this.isLimitEmpty(this.limit)){
				this.limitIsUnit = true;	
				this.limit = 0;
			}
			else{
				this.limit = Number(this.limit) || 0;
			}
			
			if(discountInfo.type == CONST_DISCOUNT_ITEM_ADD_TYPE_SAVED_SEARCH){
				this.identifyDiscountableItems(mainModel.lineItemModel,
                    Number(discountInfo.id) || 0, mainModel.excludeItems);
			}
			else if (discountInfo.type == CONST_DISCOUNT_ITEM_ADD_TYPE_ITEM){
				var itemIds = [];
				
				// TODO: modifiy initialization of promotionDiscountModel outside this function if type is item. no need for several entries in array
				for(var i = 0; i < mainModel.promotionDiscountModel.length; i++){
					itemIds.push(Number(mainModel.promotionDiscountModel[i].id) || 0);
				}
				
				this.identifyDiscountableItems(mainModel.lineItemModel, itemIds,
                    mainModel.excludeItems);
			}	
		}
		else{
			this.logger.debug('No line level discount applied.');
		}
		
		this.logger.debug('Item Discount Manager', this.toString());
	},
	
	this.applyDiscount = function(){
		
		if(!this.discountableLineItems || !(this.discountableLineItems instanceof Array)){
			throw 'Invalid discountableLineItems. Make sure that it is an array or not empty.';	
		}
		
		// loop over discountableLineItems, already sorted by price, start at the top
		for(var i = 0; i < this.discountableLineItems.length; i++){
			var iter = this.discountableLineItems[i];
			
			if(this.limitIsUnit){
				if(this.discountIsPercent){
					this.applyDiscountInPercentAndLimitInUnit(iter);
				}	
				else{
					this.applyDiscountInCurrencyAndLimitInUnit(iter);
				}
			}
			else{
				if(this.discountIsPercent){
					this.applyDiscountInPercentAndLimitInCurrency(iter);
				}	
				else{
					// invalid case: discount is currency, limit is currency
				}
			}
		}
	};
	
	this.applyDiscountInPercentAndLimitInUnit = function(lineItem){
		var isPercent = true;
		var finalDiscount = 0;
		
		this.logger.debug('Applying Promotional Offer in Percent and Limit in Units');
		
		// 0 limit means No Limit. All undefined must be converted to 0 before this function. -1 limit means there's a limit initially set
		if(this.limit == 0){
			finalDiscount = this.discountAmount;
		}
		else if(this.limit > 0){
			if(lineItem.quantity > 0){ // additional checking if quantity = 0 to prevent division by 0 error
				if(this.limit > lineItem.quantity){
					// use quantity
					finalDiscount = (this.discountAmount / 100 * lineItem.rate) * lineItem.quantity;
					isPercent = false;
					
					// decrement limit
					this.limit -= lineItem.quantity;
					if(this.limit <= 0){
						this.limit = -1;
					}
				}
				else{
					// use limit
					finalDiscount = (this.discountAmount / 100 * lineItem.rate) * this.limit;
					isPercent = false;
					
					this.limit = -1;
				}
			}
		}
		
		// call Promotion API
		if(finalDiscount != 0){
			this.promotionsApi.addLineDiscount(lineItem.lineItemNum, isPercent, this.roundOff(finalDiscount));	
		}
	};
	
	this.applyDiscountInCurrencyAndLimitInUnit = function(lineItem){
		var isPercent = false;
		var finalDiscount = 0;
		
		this.logger.debug('Applying Promotional Offer in Currency and Limit in Units');
		
		// 0 limit means No Limit. All undefined must be converted to 0 before this function. -1 limit means there's a limit initially set
		if(this.limit == 0){
			if(this.isFixedPrice){
				var discAmount = this.computeFixedPriceAdjustment(lineItem.rate, this.discountAmount);
				finalDiscount = discAmount * lineItem.quantity;
			}
			else{
				// get minimum between rate and discountAmount
				finalDiscount = Math.min(lineItem.rate * lineItem.quantity, this.discountAmount);
			}
		}
		else if(this.limit > 0){
			if(lineItem.quantity > 0){ 
				if(this.limit > lineItem.quantity){
					// use quantity
					if(this.isFixedPrice){
						var discAmount = this.computeFixedPriceAdjustment(lineItem.rate, this.discountAmount);
						finalDiscount = discAmount * lineItem.quantity;
					}
					else{
						// get minimum between rate and discountAmount
						finalDiscount = Math.min(lineItem.rate, this.discountAmount) * lineItem.quantity;
					}					
					
					// decrement limit
					this.limit -= lineItem.quantity;
					if(this.limit <= 0){
						this.limit = -1;
					}
				}
				else{
					// use limit
					if(this.isFixedPrice){
						var discAmount = this.computeFixedPriceAdjustment(lineItem.rate, this.discountAmount);
						finalDiscount = discAmount * this.limit;
					}
					else{
						// get minimum between rate and discountAmount
						finalDiscount = Math.min(lineItem.rate, this.discountAmount) * this.limit;
					}
					
					this.limit = -1;
				}
			}
		}
		
		// call Promotion API
		if(finalDiscount != 0){
			this.promotionsApi.addLineDiscount(lineItem.lineItemNum, isPercent, this.roundOff(finalDiscount));	
		}
	};
	
	this.applyDiscountInPercentAndLimitInCurrency = function(lineItem){
		var isPercent = false;
		var finalDiscount = 0;
		
		this.logger.debug('Applying Promotional Offer in Percent and Limit in Currency');
		
		finalDiscount = this.discountAmount / 100 * lineItem.itemTotalAmount;
		finalDiscount = Math.min(finalDiscount, this.limit);
		
		// call Promotion API
		if(finalDiscount != 0){
			this.promotionsApi.addLineDiscount(lineItem.lineItemNum, isPercent, this.roundOff(finalDiscount));	
		}
	};
	
	this.isDiscountable = function(itemId){
		var ret = false;
		
		if(!this.discountableLineItems || !(this.discountableLineItems instanceof Array)){
			throw 'Invalid discountableLineItems. Make sure that it is an array or not empty.';	
		}		
		
		if(typeof itemId != 'number'){
			throw 'Invalid itemId. Make sure that it is a number or not empty.';	
		}
		
		for(var i = 0; i < this.discountableLineItems.length; i++){
			var iter = this.discountableLineItems[i];
			if(iter.itemId == itemId){
				return true;
			}
		}
		
		return ret;
	};
	
	this.identifyDiscountableItems = function(lineItems, discountCriteria, excludeItems){
        
	    // list of discountable line types
	    var discountableLineTypes = {
            'InvtPart': true,
            'Assembly': true,
            'Kit': true,
            'OthCharge': true,
            'Service': true,
            'DwnLdItem': true,
            'GiftCert': true,
            'NonInvtPart': true
	    };
	    
	    if(!lineItems || !(lineItems instanceof Array)){
			throw 'Invalid lineItems. Make sure that it is an array or not empty.';	
		}
		
		if(!discountCriteria || (typeof discountCriteria != 'number' && !(discountCriteria instanceof Array))){
			throw 'Invalid discountCriteria. Make sure that it is a number, array, or not empty.';	
		}

		// populate discountableItems by comparing lineItems (use itemId) and discountCriteria (can be an array of itemIds or a savedsearch)
		if(discountCriteria instanceof Array){
			// discountCriteria is an array of ints, which is the list of item ids
			for(var i = 0; i < lineItems.length; i++){
				var iter = lineItems[i];

				if ((discountCriteria.indexOf(iter.itemId) != -1 && !excludeItems) ||
                    (discountCriteria.indexOf(iter.itemId) == -1 && excludeItems)) {
                    
				    // prevent adding discounts on non discountable line types
			        if(discountableLineTypes[iter.type]){
                        this.discountableLineItems.push(iter);
                    }
				}
			}
		}
		else if(typeof discountCriteria == 'number'){
			// discountCriteria is a savedsearch id (int)
			
			// extract all itemIds from lineItems
			var itemIds = [];
			for(var i = 0; i < lineItems.length; i++){
				itemIds.push(Number(lineItems[i].itemId));
			}
			
			itemIds = this.eliminateDuplicates(itemIds);
						
			// discount type is savedsearch
			var filters = [new nlobjSearchFilter('internalid', null, 'anyof', itemIds)]; // filter by itemIds from lineItems
			var columns = [new nlobjSearchColumn('itemid')];

			var startIndex = 0;
			var batchCount = 1000;
			var searchObj = nlapiLoadSearch('item', discountCriteria);
			searchObj.addFilters(filters);
			searchObj.addColumns(columns);
			var searchResult = searchObj.runSearch();
			var res = searchResult.getResults(startIndex, startIndex + batchCount); 
			
			// handle case when search returns empty or 0
			if(!res || res.length == 0){
				if (excludeItems) {
					// just add all lineItems
					for(var j = 0; j < lineItems.length; j++){
					    
					    var iter = lineItems[j];
					    
					    // prevent adding discounts on non discountable line types
					    if(discountableLineTypes[iter.type]){
                            this.discountableLineItems.push(iter);
                        }
					}	
				}
			}
			else{
				
				// get the matching item ids from saved search. 
				var matchingIds = [];
				while(res && res.length > 0){
					for(var i = 0; i < res.length; i++){ 
						matchingIds.push(Number(res[i].getId()));
					}						
					
					startIndex += batchCount; 
					res = searchResult.getResults(startIndex, startIndex + batchCount);
				}
				
				if(excludeItems) {
					// get the non-intersecting values between the line items' item ids and matching ids from saved search
					matchingIds = this.diffArray(itemIds, matchingIds);
				}
				
				// loop on lineItems first to retain the order by rate
				for(var j = 0; j < lineItems.length; j++){
					var iter = lineItems[j];
					if(matchingIds.indexOf(Number(iter.itemId)) != -1){
					    
					    // prevent adding discounts on non discountable line types
					    if(discountableLineTypes[iter.type]){
					        this.discountableLineItems.push(iter);
					    }
					}
				}
			}
		}
	};
	
	this.computeFixedPriceAdjustment = function(oldRate, newRate){
		// get the amount that will make oldRate to newRate
		var ret = 0;
		
		if(typeof oldRate != 'number'){
			throw 'Invalid oldRate. Make sure that it is a number or not empty.';	
		}
		
		if(typeof newRate != 'number'){
			throw 'Invalid newRate. Make sure that it is a number or not empty.';	
		}
		
		ret = oldRate - newRate;
		
		return ret;
	};
	
	this.eliminateDuplicates = function (arr) {
		
		if(!arr || !(arr instanceof Array)){
			throw 'Invalid arr. Make sure that it is an array or not empty.';	
		}
		
		var i, len = arr.length, out = [], obj = {};

		for (i = 0; i < len; i++) {
			obj[arr[i]] = 0;
		}
		
		for (i in obj) {
			out.push(i);
		}
		
		return out;
	};
	
	this.toString = function() {
		var dbg = {};
		dbg.discountAmount = this.discountAmount;
		dbg.discountIsPercent = this.discountIsPercent;
		dbg.limit = this.limit;
		dbg.limitIsUnit = this.limitIsUnit;
		dbg.isFixedPrice = this.isFixedPrice;
		dbg.discountableLineItems = this.discountableLineItems;
		return JSON.stringify(dbg);
	};
	
	this.roundOff = function (inputNum) {
		
		if(typeof inputNum != 'number'){
			throw 'Invalid inputNum. Make sure that it is a number or not empty.';	
		}
		
		var decimalPrecisionFactor = Math.pow(10, AdvPromo.GlobalConstants.CONST_DECIMAL_PRECISION);
		
		return Math.round(inputNum * decimalPrecisionFactor) / decimalPrecisionFactor;
	};
	
	this.isLimitEmpty = function(limit) {
		
		if(limit == '' || limit == undefined || limit == null || limit == 0){
			return true;
		}
		
		return false;
	};
	
	/*
	 	Returns the non-intersecting items in the array of integers.
	 	
	 	Ex. 
	  	var array1 = [1, 2, 3, 4, 5];
		var array2 = [1, 5];
		
		array1 - array2 = [2, 3, 4]
	 */
	this.diffArray = function(inputArr1, inputArr2) {
	    var tempArr = [], diff = [];
	    
	    // need to remove duplicates in the array to make the remaining logic work
	    var arr1 = this.eliminateDuplicates(inputArr1);
	    var arr2 = this.eliminateDuplicates(inputArr2);
	    
	    for (var i = 0; i < arr1.length; i++) {
	        tempArr[arr1[i]] = true;
	    }
	    
	    for (var i = 0; i < arr2.length; i++) {
	        if (tempArr[arr2[i]]) delete tempArr[arr2[i]];
	        else tempArr[arr2[i]] = true;
	    }
	    
	    for (var k in tempArr) {
	        diff.push(Number(k));
	    }
	    
	    return diff;
	};
};

AdvPromo.Plugin.OrderDiscountManager = new function OrderDiscountManager() {
	
	this.promotionsApi;
	this.discountAmount;
	this.discountIsPercent;
	this.limit;
	this.limitIsUnit;
	
	this.applyDiscount = function(){
		
	};
};