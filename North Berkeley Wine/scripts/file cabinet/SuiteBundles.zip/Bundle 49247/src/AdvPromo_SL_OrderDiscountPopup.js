/**
 * "� 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. "
 */

var AdvPromo;
if (!AdvPromo) { AdvPromo = {}; }

AdvPromo.OrderDiscountSL = new function () {
	
	this.renderSuitelet = function(request, response) {
		
		var TRANS_LABEL_SAVE = 'Save';
		var TRANS_LABEL_CANCEL = 'Cancel';
//		var TRANS_LABEL_DISCOUNT_UP_TO = 'Discount Up to';
//		var TRANS_LABEL_PROMO_OFFER = 'Promotional Offer';
//		var TRANS_LABEL_NEW_ORDER = 'New Order Discount';
//		var TRANS_LABEL_EDIT_ORDER = 'Edit Order Discount';
		var TRANS_HELP_OFFER = '<html><p>Enter the percentage or currency amount discount for this promotion.</p></html>';
		var TRANS_HELP_DISCOUNT = '<html><p>Enter the maximum discount amount available for this promotion for a single order.</p></html>';

		try {
			var t = advPromoTranslateInit();

			TRANS_LABEL_SAVE = t.translate('label.save');
			TRANS_LABEL_CANCEL = t.translate('label.cancel');
			TRANS_HELP_OFFER = t.translate('help.popup.offer.percent');
			TRANS_HELP_DISCOUNT = t.translate('help.popup.offer.discount.max');
		}
		catch(e) {
			nlapiLogExecution('ERROR', 'Advanced Promotion', 'Error in translation. ' + e);
		}

		if(request.getMethod() == 'GET') {

			var promoId = request.getParameter('promoId');
			
			var form = nlapiCreateForm('', true);

			// promotional offer label
			var hiddenField = form.addField('custpage_promo_offer', 'text');
			hiddenField.setDisplayType('hidden');
			hiddenField.setHelpText(TRANS_HELP_OFFER, false);
			
			// discount up to label
			hiddenField = form.addField('custpage_limit_label', 'text');
			hiddenField.setDisplayType('hidden');
			hiddenField.setHelpText(TRANS_HELP_DISCOUNT, false);
			
			// container for promotional offer
			var inlineHtmlTable = form.addField('custpage_outer_table', 'inlinehtml');
			inlineHtmlTable.setDefaultValue(
				'<div id="custpage_promo_offers"></div>' +
				'<div id="custpage_limits"></div>'
			);
			
			// promotion ID
			hiddenField = form.addField('custpage_promo_id', 'text');
			hiddenField.setDisplayType('hidden');
			hiddenField.setDefaultValue(promoId);
			
			// promotional offer currencies
			hiddenField = form.addField('custpage_promo_offer_currencies', 'longtext');
			hiddenField.setDisplayType('hidden');
			hiddenField.setDefaultValue(JSON.stringify(this.getCurrencyList(false)));
			
			// discount up to currencies
			hiddenField = form.addField('custpage_limit_currencies', 'longtext');
			hiddenField.setDisplayType('hidden');
			hiddenField.setDefaultValue(JSON.stringify(this.getCurrencyList(true)));

			// to hide the whole form
			var fld = form.addField('custpage_inlinehtml', 'inlinehtml');
		    // div__body contains the nlobjForm UI
		    fld.setDefaultValue('<script type="text/javascript">Ext.get("div__body").dom.style.visibility="hidden"</script>');

			form.setScript('customscript_ap_order_discount_cs');
			
			form.addButton('custpage_save', TRANS_LABEL_SAVE, 'AdvPromo.OrderDiscountCS.save()');
			form.addButton('custpage_cancel', TRANS_LABEL_CANCEL, 'AdvPromo.OrderDiscountCS.cancel()');
			
			response.writePage(form);
		}
	};
	
	this.getCurrencyList = function(isLimit){

		var ret = [];
		
		if(!isLimit){
			ret.push({'value': '0', 'text': '%'});
		}
		
		if(this.isFeatureEnabled('MULTICURRENCY')){
			var i = 0;
			var columns = [new nlobjSearchColumn('symbol')];
			var filters = [new nlobjSearchFilter('isinactive', null, 'is', 'F')];
			var res = nlapiSearchRecord('currency', null, filters, columns);
			
			for ( i = 0; i < res.length; i++) {
				var id = res[i].getId();
				var name = res[i].getValue('symbol');
				ret.push({'value':id, 'text':name});
			}
		}
		else{
			var rec = nlapiLoadRecord('currency', 1);
			ret.push({'value':1, 'text':rec.getFieldValue('symbol')});
		}
		
		ret.sort(function (a, b) {
			if (a.value == 0) return -1;
			
			return a.text.toLocaleUpperCase() > b.text.toLocaleUpperCase();
		});
		
		return ret;
	};
	
	this.isFeatureEnabled = function(featureId){
		var ret = false;

		if(featureId){
			var objContext = nlapiGetContext();
			if(objContext.getSetting('FEATURE', featureId) == 'T'){
				ret = true;
			}	
		}

		return ret;
	};
};