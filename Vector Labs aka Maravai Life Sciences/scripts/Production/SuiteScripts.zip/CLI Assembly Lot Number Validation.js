// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI Assembly Lot Number Validation.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:16-Oct-2017
    Description: This script is used to validate if new Serial Number is entered on Work Order.

    
	Script Modification Log:
	-- Date --			-- Modified By --				--Requested By--				-- Description --
	23-10-2017          Vinod P                         Shekar                         Changed the saveRecord function f
	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================


// START GLOBAL VARIABLE BLOCK  =======================================
var s_G_mode_type = '';

// END GLOBAL VARIABLE BLOCK  =======================================

function pageInit_record_Mode(type)
{
	//Getting the type to store in global variable
	s_G_mode_type = type;
}


function fieldChange_getSerialNo(type,name,linenum)
{
	//Check if VALIDATE LOT NUMBER  is clicked
	if(name == 'custbody_cg_wocompl_validatelotnumber')
	{		
		//Getting the Validate Lot Number checkbox value from Work Order
		var b_validate_lot_no = nlapiGetFieldValue('custbody_cg_wocompl_validatelotnumber');
		//alert('b_validate_lot_no = '  + b_validate_lot_no);
		//If checkbox is true
		if(b_validate_lot_no == 'T')
		{
			//Get the Assembly Item id
			var i_assembly_item = nlapiGetFieldValue('item'); 
		 	//Lookup for Lot Number Validation field from assembly item 
		 	var b_item_lot_validation = nlapiLookupField('item',i_assembly_item,'custitem_cg_item_lotnumbervalidation');
			//alert('b_item_lot_validation = '  + b_item_lot_validation);
			//If LOT NUMBER VALIDATION checkbox is true on Item master 
			if(b_item_lot_validation == 'T')
			{ 	
				//var arr_component_texts = new Array(); 
				//Creating array of component ids,line lot numbers
				var arr_component_ids = new Array();
				var arr_line_lot_nos = new Array(); 
				//Getting the Component line count
				var i_component_count = nlapiGetLineItemCount('component');
				//Getting the Serial number
				var s_serial_no = nlapiGetFieldValue('serialnumbers');
				//Getting the trandate of work order
				var d_assembly_creation_dt = nlapiGetFieldValue('trandate');
				
				//Loop through the component line count
				for(var i=1; i<=i_component_count;i++)
				{
					//Get the item id
					var i_component_item = nlapiGetLineItemValue('component','item',i);
					//Push the item id into arr_component_ids array
					arr_component_ids.push(i_component_item);
					//Get line Lot number
					var s_line_lot_nos = nlapiGetLineItemValue('component','componentnumbers',i);
					//Push the line lot number into arr_line_lot_nos array
					arr_line_lot_nos.push(s_line_lot_nos);
				}
				//Convert array in to string
				var s_arr_component_ids = arr_component_ids.toString();

				//Removing all the preceding and succeding commas using regex 
				s_arr_component_ids = s_arr_component_ids.replace(/(^\s*,)|(,\s*$)/g, '');

				//Convert array in to string
				var s_arr_line_lot_nos = arr_line_lot_nos.toString();

				//Removing all the preceding and succeding commas using regex 
				s_arr_line_lot_nos = s_arr_line_lot_nos.replace(/(^\s*,)|(,\s*$)/g, '');
/*
				alert('i_assembly_item' + i_assembly_item);
				alert('s_arr_component_ids =' + s_arr_component_ids);
				alert('s_arr_line_lot_nos =' + s_arr_line_lot_nos);
				alert('s_serial_no =' + s_serial_no);*/

				//Getting the value from getLotNoHistory function for previous LOT NUMBERS with same combination if present.
				 var s_prev_serial_no =  getLotNoHistory(i_assembly_item,s_arr_component_ids,s_arr_line_lot_nos,s_serial_no);

				 if(_logValidation(s_prev_serial_no))
				 {
				 	//Set the returned serial number value on LOT NUMBERS field & disable the LOT NUMBERS field
				 	nlapiSetFieldValue('serialnumbers',s_prev_serial_no);
				 	nlapiDisableField('serialnumbers',true);
				 }
				 else
				 {
					alert('This combination never used for the lot number.');
				 	//alert('in else s_prev_serial_no = ' + s_prev_serial_no);
				 	//Set the LOT NUMBERS field to blank and enable the field
				 	nlapiSetFieldValue('serialnumbers','');
				 	nlapiDisableField('serialnumbers',false);
				 }
			}//End of 	if(b_item_lot_validation == 'T')
		}//End of if(b_validate_lot_no == 'T')
		//If  VALIDATE LOT NUMBER field is unchecked then set the serial number blank and enable the field
		else
		{
			nlapiSetFieldValue('serialnumbers','');
			nlapiDisableField('serialnumbers',false);
		}
	}// End of if(name == 'custbody_cg_wocompl_validatelotnumber')
}//End of function fieldChange_getSerialNo(type,name,linenum)


//***********************************START Supporting Function****************************************//

function getLotNoHistory(i_assembly_item,s_arr_component_ids,s_arr_line_lot_nos,s_serial_no)
{
	//Adding filters for assembly item , component ids string array and line lot number string array
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('custrecord_cg_lotnustor_assemblyitem',null,'is',i_assembly_item);
	filter[1] = new nlobjSearchFilter('custrecord_cg_lotnustor_componentidconca',null,'is',s_arr_component_ids);
	filter[2] = new nlobjSearchFilter('custrecord_cg_lotnustor_compolotnumconca',null,'is',s_arr_line_lot_nos);
	//filter[3] = new nlobjSearchFilter('custrecordcg_lotnustor_seriallotnumber',null,'is',s_serial_no);

//Add columns for parent Work order record link and  LOT NUMBERS
	var column = new Array();
	column[0] = new nlobjSearchColumn('custrecord_cg_lotnustor_parentlink');
	column[1] = new nlobjSearchColumn('custrecordcg_lotnustor_seriallotnumber');

	//Search on custom record Lot Number Storage-WO to get the result
	var searchResult = nlapiSearchRecord('customrecord_cg_lotnumberstorage',null,filter,column);
	//If searchResult present the get the first row from the result 
	if(searchResult)
	{
		//return the first search row's LOT NUMBERS from the searchResult
		return searchResult[0].getValue('custrecordcg_lotnustor_seriallotnumber');
	}
	//If search is null then return null
	else
	{
		return null;
	}
	
}//End of function getLotNoHistory(i_assembly_item,s_arr_component_ids,s_arr_line_lot_nos,s_serial_no)

//***********************************END Supporting Function****************************************//

function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}
