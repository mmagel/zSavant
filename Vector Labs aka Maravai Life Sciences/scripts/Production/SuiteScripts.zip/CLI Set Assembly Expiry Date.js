// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI_Set_Assembly_Expiry_Date.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:05-10-2017
	Description:This script is used set the earliest expiry date on Expiry date of Work order completion record.


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --
	23-10-2017          Vinod P                          Shekar                         Changed the earliest date calculation on checkbox change event instead of save record.
	03-11-2017          Vinod P                          Shekar                         Changed the split logic for expiry dates from , to $, for getting & setting the earliest expiration date.
	07-11-2017          Vinod P                          Shekar                        	After check of CALCULATE EXPIRATION DATE get date from TEMPORARY EXPIRATION DATE and set to expiration date. 																					Added try/catch block
Below is a summary of the process controls enforced by this script file.  The control logic is described
more fully, below, in the appropriate function headers and code blocks.


     BEFORE LOAD
		- beforeLoadRecord(type)



     BEFORE SUBMIT
		- beforeSubmitRecord(type)


     AFTER SUBMIT
		- afterSubmitRecord(type)



     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:

               - NOT USED

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{
	//  Initialize any Global Variables, in particular, debugging variables...
	var s_G_mode_type = '';

}
// END GLOBAL VARIABLE BLOCK  =======================================


function pageInit_DisableExpiryDate(type)
{	//Assign Globle variable to type
	s_G_mode_type = type;
	//While creating Work Order Completion from Work Order we will always get type = copy 
	if(s_G_mode_type == 'create' || s_G_mode_type == 'copy')
	{
		//alert('s_G_mode_type = ' + s_G_mode_type);
		//Getting the assembly Item
		var i_assembly_item = nlapiGetFieldValue('item');
		//var b_lookup_expiry = nlapiLookupField('item',i_assembly_item,'custitem_cg_assemblylot_autoexpdateupd');
		//Lookup for AUTO EXPIRY DATE UPDATE checkbox & item record type from item master.
		var item_fields = ['custitem_cg_assemblylot_autoexpdateupd','recordtype'] ;

      	var item_lookupObj = nlapiLookupField('item',i_assembly_item,item_fields);

	    var b_lookup_expiry = item_lookupObj.custitem_cg_assemblylot_autoexpdateupd;
	    var s_item_type= item_lookupObj.recordtype;
      	//If item type is lotnumberedassemblyitem 
      	if(s_item_type = 'lotnumberedassemblyitem')
      	{
			//If checkbox AUTO EXPIRY DATE UPDATE is true then disable the expiry date on Work Order completion record
			if(b_lookup_expiry == 'T')
			{		
				nlapiDisableField('expirationdate',true);
			}
      	}
	}
	
}//End of function pageInit_DisableExpiryDate(type)

//On field change of ALLOW EXPIRY DATE OVERRIDE field disable/enable expiration date
function fieldChange_overrideExpireDate(type,name)
{
	try
	{


	var date_array = new Array();

	//If field ALLOW EXPIRY DATE OVERRIDE is checked
	if(s_G_mode_type == 'copy' || s_G_mode_type == 'create')
	{
		var i_assembly_item = nlapiGetFieldValue('item');
		var s_item_type = nlapiLookupField('item',i_assembly_item,'recordtype');
		if(s_item_type == 'lotnumberedassemblyitem')
		{	
			if(name == 'custbody_cg_wocomple_allowexpdateoverr')
			{
				//Get the boolean value of field ALLOW EXPIRY DATE OVERRIDE
				var b_override_expire_dt = nlapiGetFieldValue('custbody_cg_wocomple_allowexpdateoverr');
				//If ALLOW EXPIRY DATE OVERRIDE is true then disable Expiration Date else enable it and set to blank.
				if(b_override_expire_dt == 'T')
				{	
					nlapiDisableField('expirationdate',false);
				}
				else 
				{
					nlapiDisableField('expirationdate',true);
					nlapiSetFieldValue('expirationdate','');
				}
			}
			//On check of  CALCULATE EXPIRATION DATE set the Earliest Expiration date on Expiration Date field 
			else if(name == 'custbody_cg_wocomple_calexpdate')
			{
				//Getting the value of  CALCULATE EXPIRATION DATE checkbox
				var b_calculat_exp_dt = nlapiGetFieldValue('custbody_cg_wocomple_calexpdate');
				//If checkbox is true
				if(b_calculat_exp_dt == 'T')
				{
/*					//Getting the expiration dates from custom field
					var s_expiry_dates = nlapiGetFieldValue('custbody_expiry_dates');
					//If expiration dates is not null.
					if(_logValidation(s_expiry_dates))
					{
						//Split the expiration dates by $,
					var d_split_date = s_expiry_dates.split('$,');

						//alert(d_split_date + ' Length = ' +d_split_date.length);
						//Loop through the split date 
						for(var i=0;i<d_split_date.length;i++)
						{
							//alert('d_split_date = ' + d_split_date[i]);
							//Checking after split is there $ present if present then replace by blank
							if(d_split_date[i].indexOf('$') != -1)
							{
								//alert('in if' + d_split_date[i]);
								//Replacing $ by blank in split date string
								d_split_date[i] = d_split_date[i].replace('$','');
								//alert('in if after split = ' + d_split_date[i]);

							}
							//Converting the split date string into date object
							var d_exp_date = nlapiStringToDate(d_split_date[i]);
							//Pushing the date object into date array
							date_array.push(d_exp_date);
						}
						//Getting the first expiration date from list of dates.
							var minDate=new Date(Math.min.apply(null,date_array));
							nlapiLogExecution('debug','minDate',minDate);
							//Converting date object to date string 
							minDate = nlapiDateToString(minDate,'date');
							//Assigning minimum date to companyDateTime object
							var companyDateTime = minDate;
							//alert('companyDateTime =' + companyDateTime);	
					}*/
		//return false;


						//Getting ALLOW EXPIRY DATE OVERRIDE  field value
						var is_override_exp_dt = nlapiGetFieldValue('custbody_cg_wocomple_allowexpdateoverr');
						//If ALLOW EXPIRY DATE OVERRIDE is false then set the Expiration date as earliest expiration date.
						if(is_override_exp_dt == 'F')
						{
							//nlapiSetFieldValue('expirationdate',companyDateTime);


							var temp_exp_dt = nlapiGetFieldValue('custbody_cg_temp_exp_dt');
							//alert('temp_exp_dt = ' + temp_exp_dt);
							//temp_exp_dt = nlapiDateToString(temp_exp_dt,'date');
							//alert('temp_exp_dt after nlapiDateToString= ' + temp_exp_dt);

							if(_logValidation(temp_exp_dt))
							{
								nlapiSetFieldValue('expirationdate',temp_exp_dt);
							}
						}
				}
				else 
				{	//Setting the value of expiration date to blank
					nlapiSetFieldValue('expirationdate','');

				}	
			}
		}
		}
	}
	catch(e)
	{
		nlapiLogExecution('debug','Error','in Catch');
	}	
}



function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}


function _nullValidation(val){
    if (val == null || val == undefined || val == '') {
        return true;
    }
    else {
        return false;
    }
    
}

