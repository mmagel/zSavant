// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI Update Expiry Date On WO.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:12-Oct-2017
    Description: This script is used to set the expiry date of LOT number on select of Lot number on Work Order.
	Script Modification Log:
	-- Date --			-- Modified By --				--Requested By--				-- Description --
	26-10-2017            Vinod P                        Shekar                          Added filter for item for searching inventorynumber record for the serial number.
	08-11-2017            Vinod P                         Shekar                          Added saveRecord_set_temp_ExpiryDate function to set earliest date on temporary expiry date field.
	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================

function fieldChange_setExpirationDate(type,name,linenum)
{
	//Check for type is item and Lot number is selected.
	if(type == 'item' && name == 'serialnumbers')
	{
		//Select line numbered item
		nlapiSelectLineItem('item',linenum);
		//Getting the lot number value
		var currentline_serial = nlapiGetCurrentLineItemValue('item','serialnumbers');
		var itemname = nlapiGetCurrentLineItemValue('item','item');
		//alert('currentline = ' + currentline);
		//Check for logValidation for selected lot number
		if(_logValidation(currentline_serial))
		{
			//Search on Inventory number to get expiration date for selected lot number which is passed as a filter 
		//	var searchExpdate=nlapiSearchRecord('inventorynumber',null,new nlobjSearchFilter('inventorynumber',null,'is',currentline_serial),new nlobjSearchColumn('expirationdate'));
			var filter = new Array();
			filter[0] = new nlobjSearchFilter('inventorynumber',null,'is',currentline_serial)
			filter[1] = new nlobjSearchFilter('item',null,'is',itemname);
			var column = new Array();
			column[0] = new nlobjSearchColumn('expirationdate');
			var searchExpdate= nlapiSearchRecord('inventorynumber',null,filter,column);


			//If script contains results then get the expiry date from result
			if(searchExpdate)
			{

				//Getting the first expiration Date value from search result
				var expdate = searchExpdate[0].getValue('expirationdate');
				//alert('expdate= '+ expdate) 
			//If returned expiry date is not null or not undefined or not blank then set it on custom column field
			if(expdate != '' || expdate != null)
			{
				//Set the returned expiration date custom column Expiration Date field. 
				nlapiSetCurrentLineItemValue('item','custcol_expdate',expdate)
				return true;
			}
			}//End of if(searchExpdate)
		}//End of if(_logValidation(currentline_serial))
	}//End of if(type == 'item' && name == 'serialnumbers')
}//End of function fieldChange_setExpirationDate(type,name,linenum)


function saveRecord_set_temp_ExpiryDate(){
	//Declare an Item Date array
	var item_dt_array = new Array();
	//Getting line count of items
	var line_count = nlapiGetLineItemCount('item');
	//Loop through the line items
	for(var i=1;i<=line_count;i++)
	{
		//Get the expiration date of lot number for line item
		var d_item_exp_dt = nlapiGetLineItemValue('item','custcol_expdate',i);
		//alert('d_item_exp_dt = ' + d_item_exp_dt);
		if(_logValidation(d_item_exp_dt))
		{
			if(d_item_exp_dt != null || d_item_exp_dt != undefined || d_item_exp_dt != '')
			{
				//Converting the line item date into date format
				d_item_exp_dt = nlapiStringToDate(d_item_exp_dt);
				//Push the line item date into item date array
				item_dt_array.push(d_item_exp_dt);
			}
		}
	}
	//alert(item_dt_array);
	if(_logValidation(item_dt_array))
	{
		if(item_dt_array!= null || item_dt_array != '' || item_dt_array != undefined)
		{
			//Getting the first expiration date from array of dates.
			var minDate=new Date(Math.min.apply(null,item_dt_array));
			//alert(minDate);
			//Converting minimum date to string
			minDate = nlapiDateToString(minDate,'date');
			nlapiSetFieldValue('custbody_cg_temp_exp_dt',minDate);
			//return true;
		}
	}
	return true;
	
}//End of function saveRecord_set_temp_ExpiryDate


function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}

