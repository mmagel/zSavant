// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI_CopyLocation_on_IA.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:05-10-2017
	Description:This script is used copy body level location to line level when Item is selected on Inventory adjustment


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --

Below is a summary of the process controls enforced by this script file.  The control logic is described
more fully, below, in the appropriate function headers and code blocks.


     BEFORE LOAD
		- beforeLoadRecord(type)



     BEFORE SUBMIT
		- beforeSubmitRecord(type)


     AFTER SUBMIT
		- afterSubmitRecord(type)



     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:

               - NOT USED

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{
	//  Initialize any Global Variables, in particular, debugging variables...




}
// END GLOBAL VARIABLE BLOCK  =======================================

var s_G_mode_type = '';
function pageInit_po_override(type)
{
	s_G_mode_type = type;
}


// BEGIN FILD CHANGE =============================================
function fieldChange_setLocation(type,name,linenum){
//Check type for inventory and item is selected 	
	if(type == 'inventory' && name == 'item')
	{	
		//Get the adjust location
		var i_adj_location = nlapiGetFieldValue('adjlocation');
		//Check for logValidation for adjustment location
		if(_logValidation(i_adj_location))
		{
			//Select the inventory item linenumber and set the body level location value on line level location column field 
			nlapiSelectLineItem('inventory',linenum);
			nlapiSetCurrentLineItemValue('inventory', 'location', i_adj_location, false,true);
			nlapiCommitLineItem('item');
			nlapiDisableLineItemField('inventory','location', true);
			return true;
		}
		// If location is blank then throw alert message to select the location and cancel the selected line 
		else
		{
			alert('Please select Body Level Adjustment Location !')
			//Cancel the selected line
			nlapiCancelLineItem('inventory');
			//return false;
		}
	}
	//If location field is selected
	if(name == 'adjlocation')
	{
		//Get the adjust location field value
		var i_adj_location = nlapiGetFieldValue('adjlocation');
		//Check for logValidation for adjustment location
		if(_logValidation(i_adj_location))
		{
			//Get count of line level inventory 
			var i_line_count = nlapiGetLineItemCount('inventory');
			//Loop through the line item count
			for(var i=1;i<=i_line_count;i++)
			{
				//Set the body level location to each line level location 
				nlapiSelectLineItem('inventory',i);
				nlapiSetCurrentLineItemValue('inventory', 'location', i_adj_location, false,true);
				nlapiCommitLineItem('item');
			}
		}
		//If location is blank then alert message to select the location
		else
		{
			alert('Please select Body Level Adjustment Location !');
			return false;
		}
	}
return true;
}

// END FILD CHANGE =============================================

//////////////LOGVALIDATION FUNCTION
function _logValidation(value){
    if (value != null && value != '' && value != undefined && value != 'undefined' && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}

/////////////////NULLVALIDATION FUNCTION//////////////////////////

function _nullValidation(value)
{
	if (value == null || value == 'NaN' || value == '' || value == undefined || value == '&nbsp;')
	{
		return true;
	}
	else
	{
		return false;
	}
}
