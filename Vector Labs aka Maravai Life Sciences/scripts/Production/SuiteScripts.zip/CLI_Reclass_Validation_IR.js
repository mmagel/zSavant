// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI_Reclass_Validation_IR.js
	Author:Shweta Acharya
	Company:Inspirria Cloudtech Pvt Ltd
	Date:30 August 2017
    Description:This script is use to validate Item Receipt lines of type R_&_D


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --




	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

     PAGE INIT
		- pageInit(type)


     SAVE RECORD
		- saveRecord()


     VALIDATE FIELD
		- validateField(type, name, linenum)


     FIELD CHANGED
		- fieldChanged(type, name, linenum)


     POST SOURCING
		- postSourcing(type, name)


	LINE INIT
		- lineInit(type)


     VALIDATE LINE
		- validateLine()


     RECALC
		- recalc()


     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:





*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN SCRIPT UPDATION BLOCK  ====================================
/*


*/
// END SCRIPT UPDATION BLOCK  ====================================




// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{

	//  Initialize any Global Variables, in particular, debugging variables...
var G_Type = '';
var arr_Locations = new Array();
var arr_Expense_Location_Flag = new Array();
}
// END GLOBAL VARIABLE BLOCK  =======================================

// BEGIN PAGE INIT ================================================

function pageInit_getType(type)
{

	var i_Item_line_Count = nlapiGetLineItemCount('item');
	for(var i = 1; i <= i_Item_line_Count ; i++)
	{
		var i_location = nlapiGetLineItemValue('item','location',i);
		var cb_Location_Flag = nlapiGetLineItemValue('item','custcol_cg_ir_locationexpflag',i);
		arr_Locations.push(i_location);
		arr_Expense_Location_Flag.push(cb_Location_Flag);
	}//end of for(var i = 1; i <= i_Item_line_Count ; i++)
	G_Type = type;
//alert('arr_Locations=='+arr_Locations + '###arr_Expense_Location_Flag=='+arr_Expense_Location_Flag);
}//end of function pageInit_getType(type)

// END PAGE INIT ==================================================



// BEGIN FIELD CHANGED ==============================================

function postSourcing_Check_Inv_Flag(type, name, linenum)
{
	
	if(G_Type == 'edit')
	{
		//alert('In function again');
		
	   if(type == 'item' && name == 'location')
	   {
		   /**get the current index*/
		   var i_Current_Index = nlapiGetCurrentLineItemIndex('item');
		   
		  var i_Inv_Adj_Link = nlapiGetCurrentLineItemValue('item','custcol_cg_ir_iteminvadjlink');
		   
		   
		   /**get the current location*/
		   var i_Current_Location = nlapiGetCurrentLineItemValue('item','location');
		   /**get the current Inv Flag*/
		   var i_Current_Location_Exp_Flag = nlapiGetCurrentLineItemValue('item','custcol_cg_ir_locationexpflag');
		 //  alert('Current=='+i_Current_Index+'##'+i_Current_Location+'##'+i_Current_Location_Exp_Flag)
			

		   ///If changed from Expense Location to Inventory Location i.e unchecked to check */
		   
		   if(i_Current_Location_Exp_Flag == 'T' && !_logValidation(i_Inv_Adj_Link))
		   {
			   /**display a dialog box and ask for yes or no*/
			   if(confirm("You are about to reclass this item from inventory to expense.  Are you sure you want to continue?") == true) 
			   {
					//Allow user to edit this line
			   }//end of  true if
			   else 
			   {
				   if(arr_Locations[i_Current_Index-1] != i_Current_Location)
				   {
					//replicate the previous values for location and location checkbox
					nlapiSetCurrentLineItemValue('item','location',arr_Locations[i_Current_Index-1],false,false);
					nlapiSetCurrentLineItemValue('item','custcol_cg_ir_locationexpflag',arr_Expense_Location_Flag[i_Current_Index-1],false,false);
				   }
			   }//end of else
		   }//end of if(i_Current_Location_Exp_Flag == 'T' && i_Previous_Location_Exp_Flag == 'F')  
		   else   
		   if(_logValidation(i_Inv_Adj_Link))
		   {
			   if(i_Current_Location_Exp_Flag == 'F')
			   {
				   if(arr_Locations[i_Current_Index-1] != i_Current_Location)
				   {
					   alert("This item was previously expensed out of inventory and cannot be returned.  Please contact inventory operations for assistance.");
					   nlapiSetCurrentLineItemValue('item','location',arr_Locations[i_Current_Index-1],false,false);
					   nlapiSetCurrentLineItemValue('item','custcol_cg_ir_locationexpflag',arr_Expense_Location_Flag[i_Current_Index-1],false,false);
				   }
			   }
			   else
			   if(i_Current_Location_Exp_Flag == 'T')
			   {
				   if(arr_Locations[i_Current_Index-1] != i_Current_Location)
				   {
					   alert("You cannot change this line as Inventory Adjustment is already created for this.");
					    nlapiSetCurrentLineItemValue('item','location',arr_Locations[i_Current_Index-1],false,false);
						nlapiSetCurrentLineItemValue('item','custcol_cg_ir_locationexpflag',arr_Expense_Location_Flag[i_Current_Index-1],false,false);
				   }
					
			   }
		   }//end of if(i_Current_Location_Exp_Flag == 'T' && i_Previous_Location_Exp_Flag == 'F')  
			   
		///If changed from Expense Location to Inventory Location i.e checked to uncheck*/   
	   }//end of if(type == 'item' && name == 'location')
	}//end of if(type == 'edit')
}//end of function fieldChanged_Check_Inv_Flag(type, name, linenum)

// END FIELD CHANGED ================================================








// BEGIN VALIDATE LINE ==============================================

function validateLine_Check_Inv_Adj(type)
{
	/**if type == item*/
	if(type == 'item')
	{
		
	}//end of if(type == 'item')
	return true;
}//end of function validateLine_Check_Inv_Adj(type)

// END VALIDATE LINE ================================================

//////////////LOGVALIDATION FUNCTION
function _logValidation(value){
    if (value != null && value != '' && value != undefined && value != 'undefined' && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}

/////////////////NULLVALIDATION FUNCTION//////////////////////////

function _nullValidation(value)
{
	if (value == null || value == 'NaN' || value == '' || value == undefined || value == '&nbsp;')
	{
		return true;
	}
	else
	{
		return false;
	}
}


