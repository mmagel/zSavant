// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI_Validate_Customers_PO_Amount.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:11-09-2017
	Description:This script is used to validate Customer Po Amount with Total sales orders amount having same Customer po number.


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --
	13-09-2017			Vinod Pandit                    Anuradha K                Added checks for edit in SO when PO id / amount is changed & change in filter criteria.
	14-09-2017          Vinod Pandit                    SeKhar                    Added a check for _logValidation() for new record
	19-09-2017          Vinod Pandit                    Sekhar                    Changed the option dialog with alert for not saving the so when PO# is duplicate and added filter in
                                                                                   search while getting the sales order with PO#.
	21-09-2017          Vinod Pandit                    Sekhar                    Changed the alert with option dialog box 
	22-09-2017			Sakharam Kolekar				Shekar					Alert should be trigger only if there is changes to the PO#. 
	23-09-2017          Vinod Pandit                    Anuradha K                Added condition for copy to check duplicate PO #
    23-09-2017         Vinod Pandit /Anuradha                   Anuradha K        Added filter to avoid curret record being edited for same number and changed other refnum filter in both functions with operator...
    03-10-2017         Vinod Pandit                     Anuradha K                Changed the search for total sales order amount to subtotal of sales order. So changed the amount comparison from total to subtotal.
    04-10-2017         Vinod Pandit                     Anuradha K                Replaced nlapiLookupfield for getting subtotal to nlapiLoadRecord.
    
Below is a summary of the process controls enforced by this script file.  The control logic is described
more fully, below, in the appropriate function headers and code blocks.


     BEFORE LOAD
		- beforeLoadRecord(type)



     BEFORE SUBMIT
		- beforeSubmitRecord(type)


     AFTER SUBMIT
		- afterSubmitRecord(type)



     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:

               - NOT USED

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{
	//  Initialize any Global Variables, in particular, debugging variables...




}
// END GLOBAL VARIABLE BLOCK  =======================================

var s_G_mode_type = '';
function pageInit_po_override(type)
{
	s_G_mode_type = type;
}

// BEGIN FIELD CHANGED =============================================

function fieldChanged_Set_PO_number(type,name){
	//checking for Customer PO # field
	if(name == 'custbody_tran_salesorder_customerponum'){
		//Getting the internal id of customer PO #
		var i_po_number = nlapiGetFieldValue('custbody_tran_salesorder_customerponum');
		//Logvalidation for cutomer PO#
		if(_logValidation(i_po_number))
        {
			//Look up for customer po number name from customer po custom record
			var s_po_number = nlapiLookupField('customrecord155',i_po_number,'custrecord_custpo_customerponumber');
			//alert('in field CHANGED s_po_number = ' + s_po_number + ' name == ' + name);
			//Set customer po no. on otherrefnum standard field
			nlapiSetFieldValue('otherrefnum',s_po_number,false,false);
			//Disable the otherrefnum field
			nlapiDisableField('otherrefnum', true);
			return true;
		}//End of if(_logValidation(i_po_number))
		else{
			//Set the othrrefnum field blank
			nlapiSetFieldValue('otherrefnum', '',false,false);
			//Enable the otherrefnum field
			nlapiDisableField('otherrefnum', false);
			return true;	
		}//End of else
	} //End of 	if(name == 'custbody_tran_salesorder_customerponum')
	
	// if fieldA is not at least 6 characters, fail validation
	   if ((name === 'otherrefnum') && (s_G_mode_type == 'edit'))
	   {   
		   //alert('inValidate Field' + s_G_mode_type);
	      var i_po_number = nlapiGetFieldValue('custbody_tran_salesorder_customerponum');
	      if (_nullValidation(i_po_number))
	      {   
	    	//Getting the Customer PO # which is entered manually in otherrefnum standard field 
				var otherrefnum = nlapiGetFieldValue('otherrefnum');
	    		//Getting Customer to filter search results by customer.
	    		var cust = nlapiGetFieldValue('entity');
				//Search for sales order having same customer po no. which is entered manually
				if(_logValidation(otherrefnum) && _logValidation(cust))
                {
					var o_sales_order = nlapiSearchRecord('salesorder',null,[new nlobjSearchFilter('otherrefnum',null,'equalto',otherrefnum), new nlobjSearchFilter('entity',null,'anyof',cust),new nlobjSearchFilter('internalid',null,'noneof',nlapiGetRecordId())],new nlobjSearchColumn('internalid'));

					//alert('o_sales_order = ' + o_sales_order);
					//If search result is not null then restrict the user to save the sales order and throw alert
					if(o_sales_order!=null){
		
						var flag = confirm('This customer PO number has been used before. Do you want to proceed?');
			         	//If pressed ok 
			            if(flag == true)
			             {
			               return true;
			             }//End of if(flag == true)
			             //If pressed Cancel
			            else
			              {
							return false;
			              }//End of else
						
					}//End of if(o_sales_order!=null)
				} // _logValidation(otherrefnum)
	      } // if (_nullValidation(i_po_number))
	      return true;
	   }

}
// END FIELD CHANGED =============================================

// BEGIN Save Record =============================================

function saveRecord_ValidateCustomerPOAmount(type){
	//Getting the Customer PO# internal Id
	var i_po_number = nlapiGetFieldValue('custbody_tran_salesorder_customerponum');
	//Check for logValidation
	var i_total_so_amount = 0.00;
	if(_logValidation(i_po_number)){
			//Lookup Customer PO amount from customer PO record
			var i_cust_po_amount = nlapiLookupField('customrecord155',i_po_number,'custrecord_custpo_cuspoamount');
			//Getting current record internal Id, if its EDIT 
			var i_record_id = nlapiGetRecordId();
			//alert('i_record_id' + i_record_id);
			
			//var i_current_so_amount =  nlapiGetFieldValue('total');
			
			//Getting the subtotal from current Sales order transaction 
			var i_current_so_amount =  nlapiGetFieldValue('subtotal');
			
			i_total_so_amount = parseFloat(i_total_so_amount) + parseFloat(i_current_so_amount);
			
			if(_logValidation(i_po_number)){
			//Creating search with filters and column which group by po # and sum of amount on sales order
			/*var salesorderSearch = nlapiSearchRecord("salesorder",null,
			[
			   ["type","anyof","SalesOrd"], 
			   "AND", 
			   ["mainline","is","T"], 
			   "AND", 
			   ["custbody_tran_salesorder_customerponum","anyof",i_po_number]
			], 
			[
			 //  new nlobjSearchColumn("amount",null,"SUM"), 
			   new nlobjSearchColumn("formulacurrency",null,null).setFormula("nvl({totalamount},0)-nvl({discountamount},0)-nvl({taxtotal},0)-nvl({shippingamount},0)"),
			   new nlobjSearchColumn("custbody_tran_salesorder_customerponum",null,"GROUP")
			]
			);*/

	/*		var salesorderSearch = nlapiSearchRecord("salesorder",null,
			[
			   ["type","anyof","SalesOrd"], 
			   "AND", 
			   ["mainline","is","T"], 
			"AND", 
			["custbody_tran_salesorder_customerponum","anyof",i_po_number]
			], 
			[
			   new nlobjSearchColumn("trandate",null,null).setSort(false), 
			   new nlobjSearchColumn("postingperiod",null,null), 
			   new nlobjSearchColumn("tranid",null,null), 
			   new nlobjSearchColumn("entity",null,null), 
			   new nlobjSearchColumn("amount",null,null), 
			   new nlobjSearchColumn("custbody_tran_salesorder_customerponum",null,"GROUP"),
			   new nlobjSearchColumn("formulacurrency",null,null).setFormula("nvl({totalamount},0)-nvl({discountamount},0)-nvl({taxtotal},0)-nvl({shippingamount},0)")
			]
			);*/

			var salesorderSearch = nlapiSearchRecord("salesorder",null,
			[
			   ["type","anyof","SalesOrd"], 
			   "AND", 
			   ["mainline","is","T"], 
			   "AND", 
			   ["custbody_tran_salesorder_customerponum","anyof",i_po_number]
			], 
			[
			   new nlobjSearchColumn("custbody_tran_salesorder_customerponum",null,"GROUP"), 
			   new nlobjSearchColumn("formulacurrency",null,"SUM").setFormula("nvl({totalamount},0)-nvl({discountamount},0)-nvl({taxtotal},0)-nvl({shippingamount},0)")
			]
			);



			if(salesorderSearch){
			//Getting the first occurance of the result.
			var result = salesorderSearch[0];
			//If result exists
				//Getting all the columns from result
				var columns = result.getAllColumns();
				//Getting the amount column
				var amt_column = columns[1];
				
				//Getting the SUM amount column from search 
				var i_Searchtotal_so_amount = result.getValue(amt_column);
				//alert('i_Searchtotal_so_amount = ' +i_Searchtotal_so_amount);
				//Lookup for old amount & customer po id of SO in case of edited so
				if(_logValidation(i_record_id))
				{
                      //***lookup on already saved sales order.........
					//var i_lookup_old_po_id = nlapiLookupField('salesorder',i_record_id,'custbody_tran_salesorder_customerponum');
					
                       //***lookup on current edited  sales order.........
					//var so_fields = ['custbody_tran_salesorder_customerponum','amount','discounttotal','altshippingcost','taxtotal'] ;
					//var so_fields = ['custbody_tran_salesorder_customerponum','subtotal'];
	      			//var i_lookup_obj = nlapiLookupField('salesorder',nlapiGetRecordId(),so_fields);
	      			//var i_lookup_old_po_id = i_lookup_obj.custbody_tran_salesorder_customerponum;
					//var i_lookup_old_so_amount = i_lookup_obj.subtotal;
				
					var load_so = nlapiLoadRecord('salesorder',nlapiGetRecordId());
					var i_lookup_old_so_amount = load_so.getFieldValue('subtotal');
					//alert('subtotal ' + i_lookup_old_so_amount)
					i_lookup_old_so_amount = parseFloat(i_lookup_old_so_amount);
					var i_lookup_old_po_id = load_so.getFieldValue('custbody_tran_salesorder_customerponum');

	      			


	      			//Getting the discount,shipping cost, tax amount and total from sales order 
/*	      			var i_lookup_old_so_discount = i_lookup_obj.discounttotal;
	      			var i_lookup_old_so_shippingcost = i_lookup_obj.altshippingcost;
	      			var i_lookup_old_so_tax_amount = i_lookup_obj.taxtotal;
	      			var i_lookup_old_so_total = i_lookup_obj.amount;

	      			//Check if discount,shipping cost, tax amount are not null if null set to 0
	      			if(_nullValidation(i_lookup_old_so_discount))
	      			{
	      				i_lookup_old_so_discount = 0.0;
	      			}
	      			if(_nullValidation(i_lookup_old_so_shippingcost))
	      			{
	      				i_lookup_old_so_shippingcost = 0.0;
	      			}
	      			if(_nullValidation(i_lookup_old_so_tax_amount))
	      			{
	      				i_lookup_old_so_tax_amount = 0.0;
	      			}
	      			//Calculate subtotal by substracting shipping cost, discount , tax amount from total amount.
	      			var i_lookup_old_so_amount = parseFloat(i_lookup_old_so_total) - parseFloat(i_lookup_old_so_tax_amount)- parseFloat(i_lookup_old_so_shippingcost) - parseFloat(i_lookup_old_so_discount) ;
*/
					//Getting the subtotal from lookupfield
				}

				//alert('i_po_number = ' + i_po_number);
				//alert('i_lookup_old_po_id = ' + i_lookup_old_po_id);
				//alert('i_lookup_old_so_amount = ' + i_lookup_old_so_amount);
	
				//Check for logValidation if its edit then substract the i_lookup_old_so_amount amount from i_Searchtotal_so_amount
				if(_logValidation(i_record_id) && (i_lookup_old_po_id == i_po_number) && (i_lookup_old_so_amount == i_current_so_amount)){
					//Substracting current so amount from total so amount
					var i_Finaltotal_so_amount = parseFloat(i_Searchtotal_so_amount) - parseFloat(i_lookup_old_so_amount);
					i_total_so_amount = i_Finaltotal_so_amount;
					//alert('in edit record ' + i_total_so_amount);	
				}
				//Check for logValidation if its edit & i_lookup_old_so_amount is smaller than i_current_so_amount then add the differnece.when user decreases amount on current saved record....

				else if(_logValidation(i_record_id) && (parseFloat(i_lookup_old_so_amount) < parseFloat(i_current_so_amount)))
				{
					var diff_amount = parseFloat(i_current_so_amount) - parseFloat(i_lookup_old_so_amount);

					var i_Finaltotal_so_amount = parseFloat(i_Searchtotal_so_amount) + parseFloat(diff_amount);
					i_total_so_amount = i_Finaltotal_so_amount;
					//alert('in edit for new amount is greater' + i_total_so_amount);
				}
				//Check for logValidation if its edit & i_lookup_old_so_amount is greater than i_current_so_amount then substract the differnece. when user increases amount on current saved record....

				else if(_logValidation(i_record_id) && (parseFloat(i_lookup_old_so_amount) > parseFloat(i_current_so_amount)))
				{
					var diff_amount = parseFloat(i_lookup_old_so_amount) - parseFloat(i_current_so_amount);

					var i_Finaltotal_so_amount = parseFloat(i_Searchtotal_so_amount) - parseFloat(diff_amount);
					i_total_so_amount = i_Finaltotal_so_amount;
					//alert('in edit for new amount is smaller ' + i_total_so_amount);
				}
				else{
					i_total_so_amount = parseFloat(i_Searchtotal_so_amount) + parseFloat(i_current_so_amount);
					//alert('in new record ' + i_total_so_amount);
					
				}
			}
		}	
				//alert('i_total_so_amount = ' + i_total_so_amount);
				//alert('i_cust_po_amount = ' + i_cust_po_amount);
				//nlapiLogExecution('debug','i_total_so_amount',i_total_so_amount);
				//nlapiLogExecution('debug','i_cust_po_amount',i_cust_po_amount);
			
			//Check if total so amount is greater than customer po amount 		
			if(parseFloat(i_total_so_amount) > parseFloat(i_cust_po_amount)){
				//Restrict the customer for saving the sales order and give alert  
				alert('Customers PO amount is Exceeding, Please verify the customer sales orders created');
				return false;
			}
	}//End of if(_logValidation(i_po_number))
	else
	{
		
		//alert(s_G_mode_type);
         // *********when blanket po is not present and not selected then PO # is entered manaully
		if(s_G_mode_type == 'create' || s_G_mode_type == 'copy')
		{
			//alert('in Save' + s_G_mode_type);
			//Getting the Customer PO # which is entered manually in otherrefnum standard field 
			var otherrefnum = nlapiGetFieldValue('otherrefnum');
      		//Getting Customer to filter search results by customer.
      		var cust = nlapiGetFieldValue('entity');
			//Search for sales order having same customer po no. which is entered manually
			if(_logValidation(otherrefnum) && _logValidation(cust)){
				var o_sales_order = nlapiSearchRecord('salesorder',null,[new nlobjSearchFilter('otherrefnum',null,'equalto',otherrefnum), new nlobjSearchFilter('entity',null,'anyof',cust)],new nlobjSearchColumn('internalid'));

			}
			//alert('o_sales_order = ' + o_sales_order);
			//If search result is not null then restrict the user to save the sales order and throw alert
			if(o_sales_order!=null){

				var flag = confirm('This customer PO number has been used before. Do you want to proceed?');
           	//If pressed ok 
              if(flag == true)
               {
                 return true;
               }//End of if(flag == true)
               //If pressed Cancel
              else
                {
				return false;
                }//End of else

				/*alert('This customer PO number has been used before !');
            	return false;*/
			}//End of if(o_sales_order!=null)
		} //if(s_G_mode_type == 'create')
	}//End of else
	return true;
}//End of function saveRecord_ValidateCustomerPOAmount(type)

// END BEFORE SUBMIT =============================================

//////////////LOGVALIDATION FUNCTION
function _logValidation(value){
    if (value != null && value != '' && value != undefined && value != 'undefined' && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}

/////////////////NULLVALIDATION FUNCTION//////////////////////////

function _nullValidation(value)
{
	if (value == null || value == 'NaN' || value == '' || value == undefined || value == '&nbsp;')
	{
		return true;
	}
	else
	{
		return false;
	}
}



