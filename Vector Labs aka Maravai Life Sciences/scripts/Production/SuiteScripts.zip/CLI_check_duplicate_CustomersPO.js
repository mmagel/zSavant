	// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
	{
	/*
	   	Script Name:CLI_check_duplicate_CustomersPO.js
		Author:Vinod Pandit
		Company:Inspirria Cloudtech Pvt Ltd.
		Date:18-Sep-2017
	    Description: This script is used to check the duplicate customers po number.
		Script Modification Log:
		-- Date --			-- Modified By --				--Requested By--				-- Description --
		23-09-2017           Vinod Pandit                   Anuradha K                     Added _logValidation for customer and po #        
		Below is a summary of the process controls enforced by this script file.  The control logic is described
		more fully, below, in the appropriate function headers and code blocks.

	*/
	}
	// END SCRIPT DESCRIPTION BLOCK  ====================================

	// BEGIN SAVE RECORD ==============================================
	function saveRecord_checkDuplicate()
	{
		var s_record_type =  nlapiGetRecordType();
			if(s_record_type == 'customrecord155')
			{
			var s_cust_po_number = nlapiGetFieldValue('custrecord_custpo_customerponumber');
			var i_customer = nlapiGetFieldValue('custrecord_custpo_parentlink');
			//alert('s_cust_po_number ' + s_cust_po_number);
			if(_logValidation(i_customer) && _logValidation(s_cust_po_number))
			{
				var o_customers_po = nlapiSearchRecord('customrecord155',null,[new nlobjSearchFilter('custrecord_custpo_customerponumber',null,'is',s_cust_po_number),new nlobjSearchFilter('custrecord_custpo_parentlink',null,'is',i_customer)],new nlobjSearchColumn('internalid'));
				if(o_customers_po){
					alert('The PO number already used, Please change the Customer’s PO Number to continue');	
					return false;
				}
				else{
					return true;
				}
			}
		}
		return true;
	}

	function validateLine_checkDuplicate(type){
		var s_record_type =  nlapiGetRecordType();
		if(s_record_type == 'customer'){
			if(type == 'recmachcustrecord_custpo_parentlink')
			{

				var line_count  = nlapiGetLineItemCount('recmachcustrecord_custpo_parentlink');
				var current_line_po_no = nlapiGetCurrentLineItemValue('recmachcustrecord_custpo_parentlink','custrecord_custpo_customerponumber')
				var i_current_line_index = nlapiGetCurrentLineItemIndex('recmachcustrecord_custpo_parentlink');
				//alert('i_current_line_index = '  + i_current_line_index);
				//alert('current_line_po_no = '  + current_line_po_no);

				//alert('line_count' + line_count);
				for(var i=1;i<= line_count;i++){
					//alert('i' + i)
					var s_po_number = nlapiGetLineItemValue('recmachcustrecord_custpo_parentlink','custrecord_custpo_customerponumber',i);
					//alert('s_po_number = '  + s_po_number);
					if((s_po_number == current_line_po_no) && (i_current_line_index != i)){
						alert('The PO number already used, Please change the Customer’s PO Number to continue');	
						return false;
					}
					else{
						//return true;
					}

				}

			}
		}
		return true;
	}


	//////////////LOGVALIDATION FUNCTION
function _logValidation(value){
    if (value != null && value != '' && value != undefined && value != 'undefined' && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}

/////////////////NULLVALIDATION FUNCTION//////////////////////////

function _nullValidation(value)
{
	if (value == null || value == 'NaN' || value == '' || value == undefined || value == '&nbsp;')
	{
		return true;
	}
	else
	{
		return false;
	}
}

