    // BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
    {
        /*
         Script Name:SUIT_Component_Lot_No_Selection_Window.js
         Author: Vinod Pandit
         Company:Inspirria Cloudtech Pvt Ltd.
         Date: 18-Sep-2017
         Description: This script will create a popup window for selrcting Component Lot no. on Assembly Build,Inventory Transfer and Inventory Adjustment.

         Script Modification Log:
         -- Date --         -- Modified By --               --Requested By--                -- Description --
          27-09-2017       Vinod Pandit                      Anuradha K                    PrintData function optimized by creating search and added comments and logvalidations
          29-09-2017       Vinod Pandit                      Anuradha K                    Added code changes for deployment on Inventory adjustment & Inventory Transfer.
          05-10-2017       Vinod Pandit                      Anuradha K                    Change while getting Location object for location id instead of location array.
          09-10-2017       Vinod Pandit                      Anuradha K                    Added code to get expiry date of lot no. & added to data object.
          04-11-2017       Vinod Pandit                      Anuradha K                    Added $ after date string for date array to split in client script for each dates.
          21-11-2017       Vijay Mani													   Changed sort order of lots in window - item, expiry date, internal ID. The list was showing the newer lot when expiry dates were the same.
          26-11-2017       Vijay Mani													   Display on hand and availability for lot and item
         Below is a summary of the process controls enforced by this script file.  The control logic is described
         more fully, below, in the appropriate function headers and code blocks.

         SUB-FUNCTIONS
         - The following sub-functions are called by the above core functions in order to maintain code
         modularization:
         */
    }
    // END SCRIPT DESCRIPTION BLOCK  ====================================



    // BEGIN SCRIPT UPDATION BLOCK  ====================================
    /*

     */

    // END SCRIPT UPDATION BLOCK  ====================================




    // BEGIN GLOBAL VARIABLE BLOCK  =====================================
    {

        //  Initialize any Global Variables, in particular, debugging variables...


    }
    // END GLOBAL VARIABLE BLOCK  =======================================

    // BEGIN SUITELET ==================================================
//*************************START SUITELET*****************************************
    function popup_selectLotNo(request, response){
//Check for request parameter for GET request
        if (request.getMethod() == 'GET') {
            try {
                // create the form to show popup window
                var form = nlapiCreateForm('Serial/Lot Number List');
                //call client script to set the values on sublist 
                form.setScript("customscript_cli_open_popup_window");
                //Get item array from request parameter
                var item_array_req =  request.getParameter('item_array');
              //Split item array string by , to separate each item from array 
                var item_array = item_array_req.split(',');
                nlapiLogExecution('DEBUG','item_array',item_array);
                
               //Getting the location from request parameter
                var i_location =  request.getParameter('i_location');
               
                // add a sublist to the form
                var sublist = form.addSubList('custpage_assembly_sublist', 'list', 'Assembly Item Details'); //inlineeditor
                // add fields to the sublist      
                var fld_radio = sublist.addField('custpage_radio1', 'checkbox', 'Select');
                
                var fld_item_name = sublist.addField('custpage_item_name', 'text', 'Item Name');
                fld_item_name.setDisplayType('hidden');

                var fld_item_name2 = sublist.addField('custpage_item_name_display', 'text', 'Item Name');


                //fld_sector.setDisplayType('hidden');
                var fld_Lot_no = sublist.addField('custpage_lot_number', 'text', 'Lot #');
                var fld_Lot_no2 = sublist.addField('custpage_lot_number_display', 'text', 'Lot #');
                fld_Lot_no2.setDisplayType('hidden');

                
                var fld_Exp_dt = sublist.addField('custpage_exp_dt', 'text', 'Exp Date');
                var fld_Exp_dt2 = sublist.addField('custpage_exp_dt_display', 'text', 'Exp Date');
                fld_Exp_dt2.setDisplayType('hidden');

                //fld_country.setDisplayType('hidden');
                var fld_qty_onhand = sublist.addField('custpage_qty_onhand', 'text', 'Lot Qty Onhand');
                var fld_qty_available = sublist.addField('custpage_qty_available', 'text', 'Lot Qty Avail');
                var fld_item_qty_onhand = sublist.addField('custpage_item_qty_onhand', 'text', 'Item Qty Onhand');
                var fld_item_qty_available = sublist.addField('custpage_item_qty_available', 'text', 'Item Qty Avail');
                var fld_qty_enter = sublist.addField('custpage_enter_qty', 'text', 'Enter Qty').setDisplayType('entry');
                
                //Calling function to print data on sublist
                PrintData(sublist,item_array,i_location);
                //Add Submit and Reset button
                form.addSubmitButton('Submit');
                form.addResetButton('Reset');
                //Write response to the form
                response.writePage(form);
            } 
            catch (e) {
                nlapiLogExecution('DEBUG', 'suitelet_perDiem', 'exception-->' + e);
            }
        }
        //If the request is POST
        else 
            //Check for request parameter for POST
            if (request.getMethod() == 'POST') {
                //Getting sublist count 
                var i_count = request.getLineItemCount('custpage_assembly_sublist');
                //Creating arrays for item, lot no, line_lot no, data array and qty array 
                var item_id_array = new Array();
                var lot_no_array = new Array();
                var line_lot_no_array = new Array();
                var line_qty_array = new Array();
                var line_dt_array = new Array();

                var data_array = new Array();
                var i_qty_array = new Array();
                var s_expdt_array = new Array();

                //Declare flag for repeated item
                var l_flag = false;
                //Declare data initially for making string 
                var data = '';
                //Loop through the sublist line count 
                for (var i = 1; i <= i_count; i++) {
                    //Check for selected sublist line items
                    var isSelected = request.getLineItemValue('custpage_assembly_sublist', 'custpage_radio1', i);

                    nlapiLogExecution('DEBUG', 'suitelet_perDiem', 'isSelected-->' + isSelected);
                    //If the sublist line is selected
                    if (isSelected == 'T') {
                        //Get the item from sublist
                        var i_item = request.getLineItemValue('custpage_assembly_sublist', 'custpage_item_name', i);

                        // Check If next element index is less than the line count 
                        if(i+1<=i_count)
                        {
                          //Getting the next selected sublist line checkbox value
                            isnext_selected =  request.getLineItemValue('custpage_assembly_sublist', 'custpage_radio1', i+1);
                        }
                        //Else set isnext_selected = F
                        else
                        {
                            isnext_selected = 'F';
                        }

                       var i_next_item = null;
                       //If next item is present and selected
                       if(isnext_selected == 'T')
                       {
                        //Get next item id from sublist line
                         i_next_item = request.getLineItemValue('custpage_assembly_sublist','custpage_item_name',i+1);
                       }


                       //Get lot no for sublist line
                        var f_lot_no = request.getLineItemValue('custpage_assembly_sublist', 'custpage_lot_number', i);
                        var d_exp_dt = request.getLineItemValue('custpage_assembly_sublist','custpage_exp_dt',i);


                      //Get entered qty of item from sublist
                        var i_qty_enter = request.getLineItemValue('custpage_assembly_sublist', 'custpage_enter_qty', i);
                      //Get the available quantity from sublist
                        var i_qty_available = request.getLineItemValue('custpage_assembly_sublist', 'custpage_qty_available', i);

                        // Check If next element index is less than the line count 
                        
                        if(i+1<=i_count)
                        {
                            //Get next lot no from sublist line
                             var f_lot_no_next = request.getLineItemValue('custpage_assembly_sublist', 'custpage_lot_number', i+1);
                            //Get next qty from sublist line
                             var i_qty_enter_next = request.getLineItemValue('custpage_assembly_sublist', 'custpage_enter_qty', i+1);
                             var d_exp_dt_next = request.getLineItemValue('custpage_assembly_sublist','custpage_exp_dt',i+1);
                        }
                        //If greater then make f_lot_no_next = null
                        else 
                        {
                            var f_lot_no_next = null;   
                        }
                        //push item id in item_id_array
                        item_id_array.push(i_item);   
                        //If current item = next item then push current line lot no and next line lot no into single array lot_no_array
                        if(i_item == i_next_item){
                            //push current and next lot no in line lot no array
                            line_lot_no_array.push(f_lot_no);
                            line_lot_no_array.push(f_lot_no_next);
                            //Push line lot array into lot array
                            lot_no_array.push(line_lot_no_array);  
                            //push current and next enter qty in line qty array
                            line_qty_array.push(i_qty_enter);
                            line_qty_array.push(i_qty_enter_next); 
                            //push line qty array into i_qty_array
                            i_qty_array.push(line_qty_array);

                            //Push the current & next date in line date array 
                            if(d_exp_dt!= null || d_exp_dt != undefined)
                            {
                              line_dt_array.push(d_exp_dt + '$');
                            }
                            if(d_exp_dt_next!= null || d_exp_dt != undefined)
                            {
                              line_dt_array.push(d_exp_dt_next + '$');
                            }

                            //Push line date array into s_expdt_array array
                             if(line_dt_array != null || line_dt_array != undefined)
                            {
                              s_expdt_array.push(line_dt_array);
                            }
                                

                            //Set l_flag to true 
                            l_flag = true;

                            //Add items to data string
                            data = data +  i_item + '@' + lot_no_array+ '@'+i_qty_array + '@' + s_expdt_array + '@' + i +'#'; 
                            //Making line lot no arry, lot no array, i_qty_array, and line_qty_array to blank
                            line_lot_no_array = [];
                            lot_no_array = [];
                            i_qty_array = []; 
                            line_qty_array = [];
                            s_expdt_array = [];
                            line_dt_array = [];
                        }
                        //If flag is true then skip and make l_flag  = true.
                        else if(l_flag == true)
                        {
                            l_flag = false;
                        }
                        //Else add only f_lot_no to the data string
                        else
                        {
                           
                           if(d_exp_dt!= null || d_exp_dt != undefined)
                           {
                            //Add data to the string 
                             data = data +  i_item + '@' + f_lot_no+ '@'+i_qty_enter + '@' + d_exp_dt +'$'+ '@' +i + '#';  
                           }
                           else
                           {
                             data = data +  i_item + '@' + f_lot_no+ '@'+i_qty_enter + '@' + '' + '@' +i + '#';  

                           }
                          
                        }   
                    }
                }

             //   var myJSON = JSON.stringify(data_array);
               nlapiLogExecution('DEBUG', 'suitelet_perDiem', 'data-->' + data);
                
                   //response.write('<html><head><script>self.close();window.opener.getData("' + data + '");</script></head><body></body></html>');
             // response.write('<html><head><title>Per Diem</title></head><body><script language="JavaScript" type="text/javascript">self.close();parent.getData("' + item_id_array + '","' + lot_no_array + '","' + i_qty_array + '");closePopup();</script></body></html>');//window.close();//
                nlapiLogExecution('debug','data',data)
             if(_logValidation(data))
             {
                //Write response to the form and call client script function getData present on parent form 
                response.write('<html><head><title>Component Lot Number Selection </title></head><body><script language="JavaScript" type="text/javascript">self.close();parent.getData("' + data + '");closePopup();</script></body></html>');//window.close();//
             }
            // response.write('<html><head><script>window.opener.getData("' + myJSON + '");self.close();</script></head><body></body></html>');
            }
        
    }//  function popup_selectLotNo(request, response){

    // END SUITELET ====================================================

//************************************* START CALLING FUNCTION ***************************
  function PrintData(sublist,item_array,i_location){

    nlapiLogExecution('DEBUG','item_array',item_array);
    nlapiLogExecution('DEBUG','i_location',i_location);
    //Add filters for on hand qty, location and items
    var filter = new Array(); 
    filter [0] = new nlobjSearchFilter('isonhand','inventorynumber','is','T');
    filter [1] = new nlobjSearchFilter('location','inventorynumber','anyof',i_location);
    filter [2] = new nlobjSearchFilter('internalid',null,'anyof',item_array);
    //Add columns for item iternal id , name by group, expiry date by group, location by group and quantity on hand SUM 
    var column = new Array();
   column [0] =  new nlobjSearchColumn("internalid",null,"GROUP");
   column [1] = new nlobjSearchColumn("itemid",null,"GROUP"); 
   column [2] = new nlobjSearchColumn("inventorynumber","inventoryNumber","GROUP");
   column [3] = new nlobjSearchColumn("expirationdate","inventoryNumber","GROUP");
   column [4] = new nlobjSearchColumn("location","inventoryNumber","GROUP"); 
   column [5] = new nlobjSearchColumn("quantityavailable","inventoryNumber","SUM");
   column [6] = new nlobjSearchColumn("quantityavailable",null,"MAX");
   column [7] = new nlobjSearchColumn("internalid","inventoryNumber","GROUP");
   column [8] = new nlobjSearchColumn("quantityonhand",null,"MAX");
   column [9] = new nlobjSearchColumn("quantityonhand","inventoryNumber","MAX");
    //Sort by item, then expiration date, and then internal id
    column[1].setSort();
    column[3].setSort();
    column[7].setSort(); 
//Search on item record with the given filter
   var itemSearch = nlapiSearchRecord("item",null,filter,column);
   
if(_logValidation(itemSearch)){
  //Loop through the itemSearch length 
    for(var i=0;i<itemSearch.length;i++){
      //Get the values of item id, item name, lot no, exp date & qty availale from search object
       var i_item_id = itemSearch[i].getValue(column[0]);
       var i_item = itemSearch[i].getValue(column[1]);
       var i_LotNo = itemSearch[i].getValue(column[2]);
       var i_Exp_Dt = itemSearch[i].getValue(column[3]);
       var i_Qty_available = itemSearch[i].getValue(column[5]);
       var i_Item_Qty_available = itemSearch[i].getValue(column[6]);
       var i_Item_Qty_onhand = itemSearch[i].getValue(column[8]);
       var i_Qty_onhand = itemSearch[i].getValue(column[9]);
       nlapiLogExecution('debug','Exp',i_Exp_Dt);
                    
        //Set values to the sublist
        sublist.setLineItemValue('custpage_item_name', i+1, i_item_id);
        sublist.setLineItemValue('custpage_item_name_display', i+1, i_item);

        sublist.setLineItemValue('custpage_lot_number', i+1, i_LotNo);
       // sublist.setLineItemValue('custpage_country_display', cnt, s_country);
        
        sublist.setLineItemValue('custpage_exp_dt', i+1, i_Exp_Dt);
       // sublist.setLineItemValue('custpage_perdiem_type_display', cnt, s_perDiem_type);
        
        sublist.setLineItemValue('custpage_qty_onhand', i+1, i_Qty_onhand);
        sublist.setLineItemValue('custpage_qty_available', i+1, i_Qty_available);
        sublist.setLineItemValue('custpage_item_qty_onhand', i+1, i_Item_Qty_onhand);
        sublist.setLineItemValue('custpage_item_qty_available', i+1, i_Item_Qty_available);
        //sublist.setLineItemValue('custpage_perdiem_currency_dispaly', cnt, s_tranCurrency);
        
        sublist.setLineItemValue('custpage_enter_qty', i+1, '');

    } // End of for(var i=0;i<itemSearch.length;i++)
}//End of if(_logValidation(itemSearch))
}//End of function PrintData(sublist,item_array,i_location){
//************************************* END CALLING FUNCTION ***************************

    function _logValidation(value){
        if (value != null && value != undefined && value != '' && value != 'undefined') {
            return true;
        }
        else {
            return false;
        }
        
    }



    function _nullValidation(val){
        if (val == null || val == undefined || val == '') {
            return true;
        }
        else {
            return false;
        }
        
    }