function mass_update(recordType,internalId){
//	var current = nlapiGetRecordId(recordType,internalId);
		var id = nlapiDeleteRecord(recordType, internalId);
		
		}
		