// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:UES Create Lot Storage Record on WO.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:17-Oct-2017
    Description: This script is used to create/update the Lot Number Storage record on Work order creation/updation .

    
	Script Modification Log:
	-- Date --			-- Modified By --				--Requested By--				-- Description --

	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================

function afterSubmit_saveHistory(type)
{
	try
	{
	nlapiLogExecution('debug','type',type);
	//Load the current record 
	var load_rec = nlapiLoadRecord(nlapiGetRecordType(),nlapiGetRecordId());
	//Getting the VALIDATE LOT NUMBER checkbox value from current record.
	var b_validate_lot_no = load_rec.getFieldValue('custbody_cg_wocompl_validatelotnumber');

//If VALIDATE LOT NUMBER is true
//if(b_validate_lot_no == 'T')
//{
		//Get the Assembly Item id
		var i_assembly_item = load_rec.getFieldValue('item'); 
	 	//Lookup for Lot Number Validation field from assembly item 
	 	var b_item_lot_validation = nlapiLookupField('item',i_assembly_item,'custitem_cg_item_lotnumbervalidation');
		//alert('b_item_lot_validation = '  + b_item_lot_validation);
		//If LOT NUMBER VALIDATION checkbox is checked on Item 
		if(b_item_lot_validation == 'T')
		{
				//Create an array od component ids and line lot numbers.
				var arr_component_ids = new Array();
				var arr_line_lot_nos = new Array(); 
				//Getting the line count of components
				var i_component_count = load_rec.getLineItemCount('component');
				//Get the value of LOT NUMBERS field
				var s_serial_no = load_rec.getFieldValue('serialnumbers');
				//Getting the trandate of work order record
				var d_assembly_creation_dt = load_rec.getFieldValue('trandate');
				
				//Loop through the line item component count
				for(var i=1; i<=i_component_count;i++)
				{
					//Get the item id of component
					var i_component_item = load_rec.getLineItemValue('component','item',i);
					
					//Push the item id into arr_component_ids array
					arr_component_ids.push(i_component_item);
					//Get line Lot number
					var s_line_lot_nos = load_rec.getLineItemValue('component','componentnumbers',i);
					//Push the line lot number into arr_line_lot_nos array
					arr_line_lot_nos.push(s_line_lot_nos);
				}
				//Convert array in to string
				var s_arr_component_ids = arr_component_ids.toString();
				//Removing all the preceding and succeding commas using regex 
				s_arr_component_ids = s_arr_component_ids.replace(/(^\s*,)|(,\s*$)/g, '');

				//Convert array in to string
				var s_arr_line_lot_nos = arr_line_lot_nos.toString();
				//Removing all the preceding and succeding commas using regex 
				s_arr_line_lot_nos = s_arr_line_lot_nos.replace(/(^\s*,)|(,\s*$)/g, '');

		//Check for type if type == create or copy
		if(type == 'create' || type == 'copy')
		{
					//Create Lot Number Storage-WO record and set the field values for it
					var o_create_record = nlapiCreateRecord('customrecord_cg_lotnumberstorage');
					o_create_record.setFieldValue('custrecord_cg_lotnustor_assemblycreatdat',d_assembly_creation_dt);
					o_create_record.setFieldValue('custrecord_cg_lotnustor_assemblyitem',i_assembly_item);
					o_create_record.setFieldValue('custrecordcg_lotnustor_seriallotnumber',s_serial_no);
					o_create_record.setFieldValue('custrecord_cg_lotnustor_componentidconca',s_arr_component_ids);
					o_create_record.setFieldValue('custrecord_cg_lotnustor_compolotnumconca',s_arr_line_lot_nos);
					o_create_record.setFieldValue('custrecord_cg_lotnustor_parentlink',nlapiGetRecordId());
					//Submit the record with parent link of work order record
					var submit = nlapiSubmitRecord(o_create_record);
					nlapiLogExecution('debug','submit',submit);
			}
			//If type == edit 
			else if(type == 'edit')
			{
				//Search into Lot Number Storage-WO record to get the record with parent link as currnt record id
				var searchStorage = nlapiSearchRecord('customrecord_cg_lotnumberstorage',null,new nlobjSearchFilter('custrecord_cg_lotnustor_parentlink',null,'is',nlapiGetRecordId()));
				//If result present then get the first row of result 
				if(searchStorage)
				{
					var storage_Rec_id = searchStorage[0].getId();
					nlapiLogExecution('debug','storage_Rec_id',storage_Rec_id);
				}
				//Load the Lot Number Storage-WO record to set the new field values which are updated on Work Order 
				var o_load_record = nlapiLoadRecord('customrecord_cg_lotnumberstorage',storage_Rec_id);
				o_load_record.setFieldValue('custrecord_cg_lotnustor_assemblycreatdat',d_assembly_creation_dt);
				o_load_record.setFieldValue('custrecord_cg_lotnustor_assemblyitem',i_assembly_item);
				o_load_record.setFieldValue('custrecordcg_lotnustor_seriallotnumber',s_serial_no);
				o_load_record.setFieldValue('custrecord_cg_lotnustor_componentidconca',s_arr_component_ids);
				o_load_record.setFieldValue('custrecord_cg_lotnustor_compolotnumconca',s_arr_line_lot_nos);
				//Submit the record with new values.
				var submit_load = nlapiSubmitRecord(o_load_record);
				nlapiLogExecution('debug','submit_load',submit_load);	
			}
		}//End if(b_item_lot_validation == 'T')
	//}//End of if(b_validate_lot_no == 'T')
	}
	catch(e)
	{
		nlapiLogExecution('debug','in Catch','ERROR');
	}
}//End of function afterSubmit_saveHistory(type)


//***********************************START Supporting Function****************************************//
function getLotNoHistory(i_assembly_item,s_arr_component_ids,s_arr_line_lot_nos,s_serial_no)
{
	//Adding filters for assembly item , component ids string array and line lot number string array
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('custrecord_cg_lotnustor_assemblyitem',null,'is',i_assembly_item);
	filter[1] = new nlobjSearchFilter('custrecord_cg_lotnustor_componentidconca',null,'is',s_arr_component_ids);
	filter[2] = new nlobjSearchFilter('custrecord_cg_lotnustor_compolotnumconca',null,'is',s_arr_line_lot_nos);
	//filter[3] = new nlobjSearchFilter('custrecordcg_lotnustor_seriallotnumber',null,'is',s_serial_no);

//Add columns for parent Work order record link and  LOT NUMBERS
	var column = new Array();
	column[0] = new nlobjSearchColumn('custrecord_cg_lotnustor_parentlink');
	column[1] = new nlobjSearchColumn('custrecordcg_lotnustor_seriallotnumber');

	var searchResult = nlapiSearchRecord('customrecord_cg_lotnumberstorage',null,filter,column);
	//If searchResult present the get the first row from the result 
	if(searchResult)
	{
		//return the first search row's LOT NUMBERS from the searchResult
		return searchResult[0].getValue('custrecordcg_lotnustor_seriallotnumber');
	}
	//If search is null then return null
	else
	{
		return null;
	}
	

}//End of function getLotNoHistory(i_assembly_item,s_arr_component_ids,s_arr_line_lot_nos,s_serial_no)


//***********************************END Supporting Function****************************************//

function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}
