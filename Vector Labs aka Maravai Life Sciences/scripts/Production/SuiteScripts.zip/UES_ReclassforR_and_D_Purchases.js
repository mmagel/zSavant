// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:UES_ReclassforR_and_D_Purchases.js
	Author:Shweta Acharya
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:29 August 2017
	Description:This script is used to create the Inventory Adjustment for Item Receipt.


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --
	4 Sept 2017			Shweta Acharya					Sakharam K						Added code to configure inventory details if present.
	5 Sept 2017			Shweta Acharya					Sakharam K						Added code to resolve the submit record error
	08 Sep 2017			Sakharam						Shekar							changes of inventory detail subrecord.
	12 Sep 2017			Sakharam						Shekar							Disable the line field
	14 Sep 2017			Sakharam						Shekar							Source the body level field : Dept, Class, Custom Segment (EBITDA Add Back & Project)
Below is a summary of the process controls enforced by this script file.  The control logic is described
more fully, below, in the appropriate function headers and code blocks.


     BEFORE LOAD
		- beforeLoadRecord(type)



     BEFORE SUBMIT
		- beforeSubmitRecord(type)


     AFTER SUBMIT
		- afterSubmitRecord(type)



     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:

               - NOT USED

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{
	//  Initialize any Global Variables, in particular, debugging variables...




}
// END GLOBAL VARIABLE BLOCK  =======================================

function beforeload_disablefield(type, form, request)
{
	try{
		if ((nlapiGetContext().getExecutionContext() == 'userinterface') && (type != 'view')) {
			var o_itemSublist = form.getSubList('item');
			//Disable Inventory adj. link
			var fld_custcol_cg_ir_iteminvadjlink = o_itemSublist.getField('custcol_cg_ir_iteminvadjlink');
			if(_logValidation(fld_custcol_cg_ir_iteminvadjlink))
			{
				fld_custcol_cg_ir_iteminvadjlink.setDisplayType('disabled');
			}
			
			//Disable Exp loaction flag
			var fld_custcol_cg_ir_locationexpflag = o_itemSublist.getField('custcol_cg_ir_locationexpflag');
			if(_logValidation(fld_custcol_cg_ir_locationexpflag))
			{
				fld_custcol_cg_ir_locationexpflag.setDisplayType('disabled');
			}
			
			//Disable item expense account
			var fld_custcol_cg_ir_itemopexexpacct = o_itemSublist.getField('custcol_cg_ir_itemopexexpacct');
			if(_logValidation(fld_custcol_cg_ir_itemopexexpacct))
			{
				fld_custcol_cg_ir_itemopexexpacct.setDisplayType('disabled');
			}
				
		} // type != view
	}//try
	catch(e){
		nlapiLogExecution('debug','debug','in catch' + e);
	}
}//End before load
// BEGIN AFTER SUBMIT =============================================

function afterSubmitRecord_Create_InventoryAdjust(type)
{
	try{


	/**get the context object*/
	var obj_Context = nlapiGetContext();
	
		/**get the execution context*/
		var s_Execution_Context = obj_Context.getExecutionContext();
		if((s_Execution_Context == 'userinterface') && (type == 'create' || type == 'edit'))
		{				
				/**get the record id and record type*/
				var i_Record_Id = nlapiGetRecordId();
				
				var i_Record_Type = nlapiGetRecordType();
				
				/**Load the Item Receipt Record*/
				var obj_Transaction_Record = nlapiLoadRecord(i_Record_Type,i_Record_Id);
				
				if(_logValidation(obj_Transaction_Record))
				{
					/**get the body level fields*/
					//Subsidiary
					var i_Transaction_Subsidiary = obj_Transaction_Record.getFieldValue('subsidiary');
					//Date

					var i_Transaction_Date = obj_Transaction_Record.getFieldValue('trandate');
					//Posting Period
					var i_Transaction_Posting_Period = obj_Transaction_Record.getFieldValue('postingperiod');
					//Memo
					var i_Transaction_Memo = obj_Transaction_Record.getFieldValue('memo');
					//Department 
					var i_Transaction_dept = obj_Transaction_Record.getFieldValue('department');
					//class 
					var i_Transaction_class = obj_Transaction_Record.getFieldValue('class');
					//To location 
					var i_Transaction_location = obj_Transaction_Record.getFieldValue('location');
					//Project 
					var i_Transaction_project = obj_Transaction_Record.getFieldValue('custbody_cseg_project');
					
					//Item Sublist Count					
					var i_Item_Sublist_Count = obj_Transaction_Record.getLineItemCount('item');
					
					var a_line_data = new Array();
					/**traverse all the line items*/
					for(var i = 1; i <= i_Item_Sublist_Count; i++)
					{
						obj_Transaction_Record.selectLineItem('item',i);
						/**get the Location Expense Flag Value and if it is true then proceed ahead*/
						var cb_Location_Expense_Flag = obj_Transaction_Record.getLineItemValue('item','custcol_cg_ir_locationexpflag',i);
						
						/**get the Invnetory Adjustment Link Value and if it is blank then proceed ahead*/
							var i_Inventory_Adjustment_Link = obj_Transaction_Record.getLineItemValue('item','custcol_cg_ir_iteminvadjlink',i);
							
								/**get the remaining line level fields*/
								//Open Expense Account
								
								//Item
								var i_Item = obj_Transaction_Record.getLineItemValue('item','item',i);								
								//DESCRIPTION
								var s_Item_Description = obj_Transaction_Record.getLineItemValue('item','itemdescription',i);								
								//Quantity
								var i_Quantity = obj_Transaction_Record.getLineItemValue('item','quantity',i);								
								//To Location
								var i_To_Location = obj_Transaction_Record.getLineItemValue('item','location',i);								
								//Department
								var s_Line_Department = obj_Transaction_Record.getLineItemValue('item','department',i);								
								//Class
								var s_Line_Class = obj_Transaction_Record.getLineItemValue('item','class',i);								
								//Memo
								var s_Line_Memo = obj_Transaction_Record.getLineItemValue('item','memo',i);								
								//Account
								var s_Account = obj_Transaction_Record.getLineItemValue('item','custcol_cg_ir_itemopexexpacct',i);								
								var i_rate = obj_Transaction_Record.getLineItemValue('item','rate',i);								
								var s_units = obj_Transaction_Record.getLineItemValue('item','units',i);								
								var s_serialnumbers = obj_Transaction_Record.getLineItemValue('item','serialnumbers',i);
								var i_custcol_cseg_project = obj_Transaction_Record.getLineItemValue('item','custcol_cseg_project',i);
								//*** Store the all line level data into Associative/JSON array 
								if(cb_Location_Expense_Flag == 'T' && _logValidation(s_Account) && _nullValidation(i_Inventory_Adjustment_Link)){

									  a_line_data.push({
									    'i_Item' : i_Item,
									    's_Item_Description' : s_Item_Description,
									    'i_Quantity' : i_Quantity,
									    'i_To_Location' : i_To_Location,
									    's_Line_Department' : s_Line_Department,
									    's_Line_Class' : s_Line_Class,
									    's_Line_Memo' : s_Line_Memo,
									    's_Account' : s_Account,
									    'i_rate': i_rate,
									    's_units' : s_units,
									    'i_index' : i,
									    's_serialnumbers' : s_serialnumbers,
									    'i_custcol_cseg_project' : i_custcol_cseg_project
									    });
									  }
								}//end of for(var i = 1; i <= i_Item_Sublist_Count; i++)
								//******* below function sort the JSON by account waise, 7 is used for index number of S_Account
								  var a_item_sorted_Array = a_line_data.sort(function(a, b){
								   return (a[7] > b[7]) - (a[7] < b[7]);
								   });
								
								 for(var i=0 ;i < a_item_sorted_Array.length;i++)
								 {
									 var  arr_Line_Indexes_on_IR = new Array();
								  	var s_Account = a_item_sorted_Array[i].s_Account;
								  	
								  	//Create Inventory Adjustment Record 
								  	//Set Body level field on Inventory Adjustment
								  	///Code to create a single Inventory Adjustment
										var obj_Inventory_Adjustment_Rec = nlapiCreateRecord('inventoryadjustment',{'recordmode' : 'dynamic'});
										//nlapiLogExecution('DEBUG','afterSubmitRecord_Create_InventoryAdjustment','obj_Inventory_Adjustment_Rec=='+obj_Inventory_Adjustment_Rec);
										if(_logValidation(obj_Inventory_Adjustment_Rec))
										{
											//**Setting the field values for Inventory Adjustment*/
											//******BODY FIELDS*****/
											
											//Subsidiary
											if(_logValidation(i_Transaction_Subsidiary))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('subsidiary',i_Transaction_Subsidiary);
											}
											//Account
											if(_logValidation(s_Account))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('account',s_Account);
											}//end of if(_logValidation(arr_Account))
											//Use Tax Evalutaion
											obj_Inventory_Adjustment_Rec.setFieldValue('custbody_cg_invadj_taxaccrua','T'); ///Set as True hardcoded
											
											//Memo
											if(_logValidation(i_Transaction_Memo))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('memo',i_Transaction_Memo);
											}	
											//Posting Period
											if(_logValidation(i_Transaction_Posting_Period))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('postingperiod',i_Transaction_Posting_Period);
											}//end of if(_logValidation(i_Transaction_Posting_Period))
											//Date
											if(_logValidation(i_Transaction_Date))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('trandate',i_Transaction_Date);
											}//end of if(_logValidation(i_Transaction_Date))
											//item Receipt Reference
											if(_logValidation(i_Record_Id))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('custbody_cg_invadj_createdfrom',i_Record_Id);
											}//end of if(_logValidation(i_Record_Id))
											
											if(_logValidation(i_Transaction_dept ))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('department',i_Transaction_dept );
											}
											if(_logValidation(i_Transaction_class ))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('class',i_Transaction_class );
											}
											if(_logValidation(i_Transaction_location ))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('adjlocation',i_Transaction_location);
											}
											if(_logValidation(i_Transaction_project ))
											{
												obj_Inventory_Adjustment_Rec.setFieldValue('custbody_cseg_project',i_Transaction_project );
											}
										
										}//end of if(_logValidation(obj_Inventory_Adjustment_Rec))


								  	for(var j=i;j<a_item_sorted_Array.length;j++){
								  		
								  		var s_inner_Account = a_item_sorted_Array[j].s_Account;
								  		if(s_Account == s_inner_Account){
								  			//Add Lines on Inventory Adjustment
										
										nlapiSelectNewLineItem('inventory');
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','item',a_item_sorted_Array[j].i_Item);  //Item
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','adjustqtyby',-(parseFloat(a_item_sorted_Array[j].i_Quantity)));  //Quantity
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','location',a_item_sorted_Array[j].i_To_Location);  //Location
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','class',a_item_sorted_Array[j].s_Line_Class);  //Class
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','department',a_item_sorted_Array[j].s_Line_Department);  //Department
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','description',a_item_sorted_Array[j].s_Item_Description);  //Description
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','units',a_item_sorted_Array[j].s_units);  //Units
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','unitcost',a_item_sorted_Array[j].i_rate);  //Rate										
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','custcol_cseg_project',a_item_sorted_Array[j].i_custcol_cseg_project);  
										obj_Inventory_Adjustment_Rec.setCurrentLineItemValue('inventory','serialnumbers',a_item_sorted_Array[j].s_serialnumbers); 
										
										obj_Inventory_Adjustment_Rec.commitLineItem('inventory');
										
									
										obj_Transaction_Record.selectLineItem('item',a_item_sorted_Array[j].i_index)
										//nlapiLogExecution('DEBUG','afterSubmitRecord_Create_InventoryAdjustment','a_item_sorted_Array[j].i_index=='+a_item_sorted_Array[j].i_index);
										
										
										arr_Line_Indexes_on_IR.push(a_item_sorted_Array[j].i_index);

								  			i = j;
								  		}//End if account is same
								  		else{								  			
								  			
								  			//*****When account will be change then we need to create the new invt. adjustment
								  			break;
								  		}								  		
								  		
								  	}//for(var j=i;j<a_item_sorted_Array.length;j++)
								  	
								  //Submit inventory Adjustment record
						  			if(_logValidation(obj_Inventory_Adjustment_Rec)){

							  		var i_Submitted_Inv_Adj = nlapiSubmitRecord(obj_Inventory_Adjustment_Rec,true,true);
									nlapiLogExecution('DEBUG','afterSubmitRecord_Create_InventoryAdjustment','i_Submitted_Inv_Adj=='+i_Submitted_Inv_Adj);
									
						  			}
						  			//*********update the Invt. Adjustment referance on Item receipt line
						  			for(var s =0;s<arr_Line_Indexes_on_IR.length ;s++){

										obj_Transaction_Record.setLineItemValue('item','custcol_cg_ir_iteminvadjlink',arr_Line_Indexes_on_IR[s],i_Submitted_Inv_Adj);
						  			}

								  }//Outer For Loop
							
					}//if(_logValidation(obj_Transaction_Record))


					var i_Submitted_Item_Receipt = nlapiSubmitRecord(obj_Transaction_Record,true,true)
					nlapiLogExecution('DEBUG','afterSubmitRecord_Create_InventoryAdjustment','i_Submitted_Item_Receipt=='+i_Submitted_Item_Receipt);
			
		}//if(s_Execution_Context == 'userinterface')
	
	return true;
	}
	catch(e){
		nlapiLogExecution('debug','debug','in catch' + e);
	}
}//end of function afterSubmitRecord_Create_InventoryAdjustment(type)

// END AFTER SUBMIT ===============================================





//////////////LOGVALIDATION FUNCTION
function _logValidation(value){
    if (value != null && value != '' && value != undefined && value != 'undefined' && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}

/////////////////NULLVALIDATION FUNCTION//////////////////////////

function _nullValidation(value)
{
	if (value == null || value == 'NaN' || value == '' || value == undefined || value == '&nbsp;')
	{
		return true;
	}
	else
	{
		return false;
	}
}

//////////////////////FUNCTION TO GET DUPLICATE ARRAY VALUES////////////////////////
function has_DuplicateElements(array) {

    var valuesSoFar = [];
    for (var i = 0; i < array.length; ++i) 
	{
		if(_logValidation(array[i]) && _logValidation(array[i + 1]))
		{
			var i_String1 = array[i].split("#");
			var i_String2 = array[i + 1].split("#");
			var i_Prev_Value = i_String1[0];
			var i_Next_Value = i_String2[0];
			if(i_Prev_Value == i_Next_Value)
			{
				return true;
			}
		}
    }
    return false;
}