// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name: UES_setAmortizationFlag
	Author: Shekar
	Company: Inspirria cloudtech Pvt. Ltd.
	Date: 14/09/2017
    Description: This script cehcks hidden checkbox on JE if it is amottization JE.


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --

	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

     SAVE RECORD
		- saveRecord()


     FIELD CHANGED
		- fieldChanged(type, name, linenum)


*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN SCRIPT UPDATION BLOCK  ====================================
/*


*/
// END SCRIPT UPDATION BLOCK  ====================================




// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{

	//  Initialize any Global Variables, in particular, debugging variables...


}
// END GLOBAL VARIABLE BLOCK  =======================================

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type)
{
  nlapiLogExecution('DEBUG', 'type  ',type);
	if(type=='create')
		{
		var recId = nlapiGetRecordId();
	    var recType = nlapiGetRecordType();
	    nlapiLogExecution('DEBUG','Rec Id='+recId, 'Rec Type ='+recType);
		
		var recObj = nlapiLoadRecord(recType,recId);
		nlapiLogExecution('DEBUG', 'recObj  '+recObj);
		
		if(_logValidation(recObj))
	   	{
		  var isAmortization = recObj.getFieldValue('isfromamortization');	
		  nlapiLogExecution('DEBUG', 'Before check isAmortization ',+isAmortization);
		  
		  var isRevRec = recObj.getFieldValue('isfromrevrec');	
		  nlapiLogExecution('DEBUG', 'Before check isRevRec ',+isRevRec);
          
           var isVoidOf = recObj.getFieldValue('void');	
		  nlapiLogExecution('DEBUG', 'Before check isVoidOf ',+isVoidOf);
          
          var isEliminationJE = recObj.getFieldValue('intercoelimination');	
		  nlapiLogExecution('DEBUG', 'Before check isVoidOf ',+isEliminationJE);
          
		  	
	   	   if (isAmortization == 'T' || isRevRec == 'T' || isVoidOf == 'T' || isEliminationJE =='T')
		   {
		   	 nlapiLogExecution('DEBUG', 'Inside Amortization ',+ isAmortization);
		   	 recObj.setFieldValue('custbody_cg_autoapproveflag', 'T');
             recObj.setFieldValue('approvalstatus', 2);
             recObj.setFieldValue('custbody_cg_approvalstatus', 3);
             
		   }
	   	}
		nlapiSubmitRecord(recObj);
		}
}



function userEventBeforeSubmit(type)
{
	if(type=='create')
		{

		  var isAmortization = nlapiGetFieldValue('isfromamortization');	
		  nlapiLogExecution('DEBUG', 'Before check isAmortization ',+isAmortization);
		  	
	   	   if (isAmortization == 'T') 
		   {
		   	 nlapiLogExecution('DEBUG', 'Inside Amortization ',+ isAmortization);
		   	 nlapiSetFieldValue('custbody_cg_isamortization', 'T');
		   }

		}
	    
}

/******** Log Validation Function********/
function _logValidation(value){
    if (value != 'null' && value != '' && value != undefined && value != 'NaN') {
        return true;
    }
    else {
        return false;
    }
}