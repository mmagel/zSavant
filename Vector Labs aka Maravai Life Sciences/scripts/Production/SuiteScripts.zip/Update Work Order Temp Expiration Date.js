function update_TempExpiryDate()
{
	nlapiLogExecution('debug','debug','in function');
	//Declare an Item Date array
	var searchRecord = nlapiSearchRecord(null,'customsearch725',null,null);
	if(searchRecord)
	{
		for(var j=0;j<searchRecord.length;j++)
		{
			var item_dt_array = new Array();
			nlapiLogExecution('debug','Get Id',searchRecord[j].getId());
			var load_wo = nlapiLoadRecord('workorder',searchRecord[j].getId());

			//Getting line count of items
			var line_count = load_wo.getLineItemCount('item');
			//Loop through the line items
			for(var i=1;i<=line_count;i++)
			{
				//Get the expiration date of lot number for line item
				var d_item_exp_dt = load_wo.getLineItemValue('item','custcol_expdate',i);
				//alert('d_item_exp_dt = ' + d_item_exp_dt);
				if(_logValidation(d_item_exp_dt))
				{
					if(d_item_exp_dt != null || d_item_exp_dt != undefined || d_item_exp_dt != '')
					{
						//Converting the line item date into date format
						d_item_exp_dt = nlapiStringToDate(d_item_exp_dt);
						//Push the line item date into item date array
						item_dt_array.push(d_item_exp_dt);
					}
				}
			}
			//alert(item_dt_array);
			if(_logValidation(item_dt_array))
			{
				if(item_dt_array!= null || item_dt_array != '' || item_dt_array != undefined)
				{
					//Getting the first expiration date from array of dates.
					var minDate=new Date(Math.min.apply(null,item_dt_array));
					//alert(minDate);
					//Converting minimum date to string
					minDate = nlapiDateToString(minDate,'date');
					load_wo.setFieldValue('custbody_cg_temp_exp_dt',minDate);
					var submit = nlapiSubmitRecord(load_wo);
					nlapiLogExecution('debug','submit',submit);
					//return true;
				}
			}
		}
	
	}		
}



function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}

