// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:Update_UE_setWipTrue_Disable.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:11-10-2017
	Description:This script is used to set "WIP" status on beforeLoad and beforeSubmit event as per requirement.


	Script Modification Log:

	-- Date --			-- Modified By --				--Requested By--				-- Description --

Below is a summary of the process controls enforced by this script file.  The control logic is described
more fully, below, in the appropriate function headers and code blocks.


     BEFORE LOAD
		- beforeLoadRecord(type)


     BEFORE SUBMIT
		- beforeSubmitRecord(type)


     AFTER SUBMIT
		- afterSubmitRecord(type)



     SUB-FUNCTIONS
		- The following sub-functions are called by the above core functions in order to maintain code
            modularization:

               - NOT USED

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================



// BEGIN GLOBAL VARIABLE BLOCK  =====================================
{
	//  Initialize any Global Variables, in particular, debugging variables...
	
}
// END GLOBAL VARIABLE BLOCK  =======================================


function beforeLoad_showWIP(type,form)
{	
	
	if(type == 'view')//checking type of record
	{
		//if type is view then hide cust "WIP" checkbox
		var custobj = form.getField('custbody_cg_iswip');
		custobj.setDisplayType('hidden');
	}
	else
	{
		//enter else,only if type is not view.
		var stdobj = form.getField('iswip');// getting object of standard "WIP" checkbox.
		stdobj.setDisplayType('hidden');//hide standard "WIP" checkbox.
		var ordersts = nlapiGetFieldValue('orderstatus');//getting orderstatus.
		nlapiLogExecution('debug','ordersts',ordersts);
		
		if(ordersts == 'H')//if orderstatus is 'H',i.e "closed" 
		{
			//set cust "WIP" checkbox as not editable.
			var custobj = form.getField('custbody_cg_iswip');
			custobj.setDisplayType('inline');
			nlapiLogExecution('debug','in if',ordersts);
		}
		else
		{
			//else set cust "WIP" checkbox as normal 
			nlapiLogExecution('debug','in else',ordersts);
			var custobj = form.getField('custbody_cg_iswip');
			custobj.setDisplayType('normal');
		}
	}
}// End of beforeLoad_showWIP block

//start beforeSubmit_checkWIP Block
function beforeSubmit_checkWIP()
{
	var is_custom_wip = nlapiGetFieldValue('custbody_cg_iswip');//getting custom "WIP" checkbox value.
	nlapiLogExecution('debug','is_custom_wip',is_custom_wip);
	if(is_custom_wip == 'T')//checking custom "WIP" checkbox value.
	{
		//if custom "WIP" checkbox value is true then set standard "WIP" Checkbox value as true.
		nlapiSetFieldValue('iswip','T');
	}
	else
	{
		//if custom "WIP" checkbox value is false then set standard "WIP" Checkbox value as false.
		nlapiSetFieldValue('iswip','F');
	}
}// End of beforeSubmit_checkWIP block

