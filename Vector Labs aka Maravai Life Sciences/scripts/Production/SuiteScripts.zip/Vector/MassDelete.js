/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       16 Aug 2016     smarasigan
 *
 */

/**
 * @param {String} recType Record type internal id
 * @param {Number} recId Record internal id
 * @returns {Void}
 */
function mass_update(recordType,internalId){
  try {
	var id = nlapiDeleteRecord(recordType, internalId);
  }
  catch(e){
    nlapiLogExecution('ERROR',internalId,e.message);
  }
}
function opensave(t,i){
  try {
  var rec=nlapiLoadRecord(t,i);
  nlapiSubmitRecord(rec);
  }
  catch(e){
    nlapiLogExecution('ERROR',i,e.message)
  }
}
