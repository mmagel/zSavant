// user event script
function cs_bs(type) {

    nlapiLogExecution('DEBUG', 'type', nlapiGetContext().getExecutionContext());
    if (type == 'create' && nlapiGetContext().getExecutionContext() == 'userevent') {
        var iid = nlapiGetFieldValue('createdfrom');

        if (iid != '' && iid != null) {
            var results = nlapiSearchRecord('salesorder', 'customsearch_auth',
                new nlobjSearchFilter('internalid', null, 'anyof', iid));
            for (var i = 0; results != null && i < results.length; i++) {
                var cols = results[i].getAllColumns();
                var auth = results[i].getValue(cols[1]);
                var meth = nlapiGetFieldValue('paymentmethod');
                //nlapiSetFieldValue('paymentmethod','',true,true);
                //nlapiSetFieldValue('chargeit','F');
                //nlapiSetFieldValue('creditcardprocessor','');
                nlapiSetFieldValue('custbody_fb', 'T');
                //nlapiSetFieldValue('paymentmethod',meth,true,true);
                //nlapiSetFieldValue('ignoreavs','T',true,true);
                //nlapiSetFieldValue('ignorecsc','T',true,true);
                //	nlapiSetFieldValue('pnrefnum',auth);
                break;
            }
        }
    }
}

// scheduled script
function bill_cs(type) {

    var res = nlapiSearchRecord('cashsale', null,
        [new nlobjSearchFilter('custbody_fb', null, 'is', 'T'),
            new nlobjSearchFilter('mainline', null, 'is', 'T')],
        new nlobjSearchColumn('internalid'));
    for (var j = 0; res != null && j < res.length; j++) {
        var cashsale = nlapiLoadRecord('cashsale', res[j].getValue('internalid'));
        var iid = cashsale.getFieldValue('createdfrom');
        if (iid != '' && iid != null) {

            var results = nlapiSearchRecord('salesorder', 'customsearch_auth',
                new nlobjSearchFilter('internalid', null, 'anyof', iid));
            for (var i = 0; results != null && i < results.length; i++) {
                nlapiLogExecution('DEBUG', 'internalid', res[j].getValue('internalid'));
                nlapiDeleteRecord('cashsale', res[j].getValue('internalid'));
                var record = nlapiTransformRecord('salesorder', results[i].getValue('internalid'), 'cashsale', {recordmode: 'dynamic'});
                var cols = results[i].getAllColumns();
                var auth = results[i].getValue(cols[1]);
                var meth = record.getFieldValue('paymentmethod');
                record.setFieldValue('paymentmethod', '');

                //record.setFieldValue('creditcardprocessor','');
                //record.setFieldValue('custbody_fb','T')
                record.setFieldValue('paymentmethod', meth);
                record.setFieldValue('chargeit', 'T');
                record.setFieldValue('ignoreavs', 'T');
                record.setFieldValue('ignorecsc', 'T');
                record.setFieldValue('pnrefnum', auth);
                record.setFieldValue('tobeemailed', 'F');

                nlapiSubmitRecord(record, true, true);
                break;
            }
        }
        if (nlapiGetContext().getRemainingUsage() < 100) {
            return;
        }
        //
    }
}