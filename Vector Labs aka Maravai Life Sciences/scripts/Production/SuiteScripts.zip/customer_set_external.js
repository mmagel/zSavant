function set_external_id(type){
	if (type=='create'||type=='edit'){
		var external=nlapiLookupField('customrecord_sdm_itemattribute',nlapiGetRecordId(),'custrecordmagid');
		//if (external==null||external==''||external.length==0){
			nlapiSubmitField('customrecord_sdm_itemattribute',nlapiGetRecordId(),'externalid',external);
		//}
	}
}