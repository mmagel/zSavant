function item_fulfillment_on_load(){
	var status=nlapiGetFieldText('shipstatus');
	var car=nlapiGetFieldText('shipcarrier');
	if (car=='UPS'){
		document.getElementById("packagedescrups").innerHTML = "Non haz chemicals";
	}
}
function item_fulfillment_field_change(type,name,linenum){
  try {
	if (name=='shipstatus'||name=='shipcarrier'){
		var status=nlapiGetFieldText('shipstatus');
		var car=nlapiGetFieldText('shipcarrier');
		if (car=='UPS'){
			document.getElementById("packagedescrups").innerHTML = "Non haz chemicals";
		}
	}
	if (type=='packageups'&&name=='packagedescrups'){
		nlapiSetCurrentLineItemValue('packageups','packagedescrups',"Non haz chemicals",false)
	}
  }
  catch(e){
  }
}
function item_fulfillment_bs(type,name,linenum){
	nlapiLogExecution('ERROR','type',type);
	if (type=='create'){
		var lines=nlapiGetLineItemCount('packageups');
		nlapiLogExecution('ERROR','type',lines);
		for (var i=1; i<=lines; i++){
			nlapiSetLineItemValue('packageups','packagedescrups',i,"Non haz chemicals");
		}
	}
}

// Sets actual shipped time on item fulfillment record - does not work if date/time preference is DD-MON-YYYY
function if_set_edi_fields(type){
  nlapiLogExecution('ERROR','type',type);
	if (type=='create'){
		nlapiSetFieldValue('custbody_fulfillment_edi_status',1);
		var status=nlapiGetFieldText('shipstatus');
		if (status=='Shipped'){
			var date=new Date();
			date=nlapiDateToString(date,'datetime');
			var date=date.split(' ');
			date[1]=date[1]+':00';
			date=date[0]+' '+date[1]+' '+date[2];
			nlapiSetFieldValue('custbody_status_changed_to_shipped',date);
			//2/15/2017 4:37 pm
		}
	}
	if (type=='edit'||type=='xedit'||type=='ship'){
		var old=nlapiGetOldRecord();;
		var newrec=nlapiGetNewRecord();
		var stat=old.getFieldText('shipstatus');
		var newstat=newrec.getFieldText('shipstatus');
		nlapiLogExecution('ERROR',stat,newstat);
		if (stat!='Shipped'&&newstat=='Shipped'){
			var date=new Date();
			date=nlapiDateToString(date,'datetime');
			var date=date.split(' ');
			date[1]=date[1]+':00';
			date=date[0]+' '+date[1]+' '+date[2];
			nlapiSetFieldValue('custbody_status_changed_to_shipped',date);
		}
	}
}
function in_bs(type){
  // lot selection for invoices brought in using csv import
  // logic is wrong - should be commented out completely
  if (type=='create'||type=='edit'){
      var rectype=nlapiGetRecordType();
      if (rectype=='invoice'&&nlapiGetContext().getExecutionContext()=='csvimport'){

		var lines=nlapiGetLineItemCount('item');
		for (var i=1;i<=lines;i++){
			nlapiSelectLineItem('item',i);
			var item=nlapiGetCurrentLineItemValue('item','item');
			var quant=nlapiGetCurrentLineItemValue('item','quantity');
			var curnum=num=nlapiGetCurrentLineItemValue('item','serialnumbers');
			var nums=nlapiSearchRecord('inventorynumber','customsearch238',new nlobjSearchFilter('item',null,'anyof',item));
			for (var j=0; nums!=null&&j<nums.length; j++){
				var id=nums[j].getValue('internalid');
				var av=nums[j].getValue('quantityavailable');
				var num=nums[j].getValue('inventorynumber');

				nlapiLogExecution('ERROR',i,id+' '+av+' '+quant);
				if (parseFloat(av)>=parseFloat(quant)){	//logic does not account for item quantity on hand - wrong
					try{
						nlapiSetCurrentLineItemValue('item','serialnumbers',num);
						nlapiCommitLineItem('item');
						break;
					}
					catch(e){
						nlapiLogExecution('ERROR','error',e.message);
					}
				}
			}
		}
      }
  }
}

// Main function tha sets the lot number and expiry date on sales orders
// Logic:
// If creation - set lot if lot quantity and item quantity is available to fully complete line quantity
// If editing - set lot and expiry only if all quantities on line are committed, lot number is blank, and no backorders
// For Vector US - default transaction date+1 year for expiry date if expiry date is blank
function so_as(type,form,request){
	if (type=='create'||type=='edit'){
      var rectype=nlapiGetRecordType();
	  var or=nlapiGetFieldValue('custbody_lot_or');
	  var sub=nlapiGetFieldText('subsidiary');

	  // sales orders and override is set to true - only adjust expiration date if it is blank for Vector US
	  if (rectype=='salesorder' && or == 'T'){
		var rec=nlapiLoadRecord(nlapiGetRecordType(),nlapiGetRecordId()	,{recordmode: 'dynamic'});
		var lines=rec.getLineItemCount('item');
		for (var i=1;i<=lines;i++){
			rec.selectLineItem('item',i);
			var item=rec.getCurrentLineItemValue('item','item');
			var quant=rec.getCurrentLineItemValue('item','quantity');
            var currserial=rec.getCurrentLineItemValue('item','serialnumbers');
			var nums=nlapiSearchRecord('inventorynumber','customsearch238',new nlobjSearchFilter('item',null,'anyof',item));
				for (var j=0; nums!=null&&j<nums.length; j++){
					var id=nums[j].getValue('internalid');
					var av=nums[j].getValue('quantityavailable');
					var num=nums[j].getValue('inventorynumber');
                  	var expir=nums[j].getValue('expirationdate');							//rb
                    var yearfromtran = nlapiAddMonths( nlapiStringToDate(rec.getFieldValue('trandate')) , 12 ); //rb-add year
                  	yearfromtran = nlapiDateToString(yearfromtran);		//rb-convert back
					if ((expir == null || expir == '') && (sub == '500 Vector US')){ expir = yearfromtran;}	//rb-if no expir add 1yr to SOdate
					nlapiLogExecution('ERROR',i,id+' '+av+' '+quant);
                    if (currserial == num){
                        rec.setCurrentLineItemValue('item','custcol_expdate',expir);
                        rec.commitLineItem('item');
                        break
                    }
	            }
            }
            nlapiSubmitRecord(rec);
        }

      // sales orders and override is not set to true - adjust lot number and expiration date
      // on creation - set lot number and expiration date
      // on edit - update lot number only if line is committed and lot number is blank
      if ((rectype=='invoice'&&nlapiGetContext().getExecutionContext()=='csvimport')||(rectype=='salesorder'&&or!='T')){
		var rec=nlapiLoadRecord(nlapiGetRecordType(),nlapiGetRecordId()	,{recordmode: 'dynamic'});
		var lines=rec.getLineItemCount('item');
		for (var i=1;i<=lines;i++){
			rec.selectLineItem('item',i);
			var item=rec.getCurrentLineItemValue('item','item');	// item
			var quant=rec.getCurrentLineItemValue('item','quantity');	// quantity ordered
			var curnum=nlapiGetCurrentLineItemValue('item','serialnumbers');	// lot number
            var quantcommitted = rec.getCurrentLineItemValue('item','quantitycommitted');	// quantity committed
            var quantitybo = rec.getCurrentLineItemValue('item','quantitybackordered');	// quantity backordered
            var quantityavail = rec.getCurrentLineItemValue('item','quantityavailable');	// quantity available

          	// get lot numbers for item from the saved search
			var nums=nlapiSearchRecord('inventorynumber','customsearch238',new nlobjSearchFilter('item',null,'anyof',item));
				for (var j=0; nums!=null&&j<nums.length; j++){
					var id=nums[j].getValue('internalid');
					var av=nums[j].getValue('quantityavailable');	// lot quantity available
					var num=nums[j].getValue('inventorynumber');	// lot number
                  	var expir=nums[j].getValue('expirationdate');	// lot expiration date
                    var itemavstr=nums[j].getValue('itemavailable');	// item quantity available - lot may be available but item may not be

                    var itemav = isNaN(itemavstr) ? 0 : parseFloat(itemavstr);	// convert item quantity available to float
                    var yearfromtran = nlapiAddMonths( nlapiStringToDate(rec.getFieldValue('trandate')) , 12 ); // +1yr tran date - used to default +1 year for Vector US if expiration date is blank
                  	yearfromtran = nlapiDateToString(yearfromtran);		//rb-convert back
					if ((expir == null || expir == '') && (sub=='500 Vector US')){ expir = yearfromtran;}				//rb-if no expir add 1yr to SOdate
					nlapiLogExecution('ERROR',i,id+' '+av+' '+quant);
					if (parseFloat(av)>=parseFloat(quant) && type=='create' && parseFloat(quantityavail)>=parseFloat(quant)){	// lot assigned on creation only if lot and item quantity is > quantity on line
						try{
							rec.setCurrentLineItemValue('item','serialnumbers',num);
                          	rec.setCurrentLineItemValue('item','custcol_expdate',expir);	//rb
							rec.commitLineItem('item');
							break;
						}
						catch(e){
							nlapiLogExecution('ERROR','error',e.message);
						}
					}

					// on edit, only default lot if line is committed and lot number is blank
                    if (type=='edit' && curnum=='' && quant==quantcommitted && quantitybo==0 && parseFloat(av)>=parseFloat(quant)){
						try{
							rec.setCurrentLineItemValue('item','serialnumbers',num);
                          	rec.setCurrentLineItemValue('item','custcol_expdate',expir);
							rec.commitLineItem('item');
							break;
						}
						catch(e){
							nlapiLogExecution('ERROR','error',e.message);
						}
					}
				}   //end of 2nd for loop
		}   // end of 1st for loop
		nlapiSubmitRecord(rec);
      }
	}
}