function proform_bl(type,form,request){
	if (type=='view'){
		var fld = form.addField("custpage_google", "inlinehtml",'').setLayoutType('outsideabove');
		fld.setDefaultValue('&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <button onclick="window.open(\'/app/site/hosting/scriptlet.nl?script=80&deploy=1&tranid=\'+nlapiGetRecordId()); return false;">Print Pro Forma Invoice</button>');
	}
}
function pro_forma(request,response){
	var tran=request.getParameter('tranid');
	var rec=nlapiPrintRecord('TRANSACTION',tran,'PDF',{formnumber:116});
	response.setContentType('PDF');
	response.write(rec.getValue());
}