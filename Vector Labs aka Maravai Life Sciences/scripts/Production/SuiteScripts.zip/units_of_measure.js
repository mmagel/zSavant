function po_before_load(type,form,request){
	if (type=='create'||type=='edit'){
		var sub=form.getSubList('item');
		var field=sub.addField('custpage_uomopts','select','Select Units');
		var field1=sub.addField('custpage_uomoptssave','select','Units');
		var selectable=nlapiSearchRecord('customrecord_selectable_uom',null,null,new nlobjSearchColumn('custrecord_units'));
		var array=new Array();
		for (var i=0;selectable!=null&&i<selectable.length; i++){
			var val=selectable[i].getText('custrecord_units');
			if (val.indexOf(',')>-1){
				val=val.split(',');
			}
			array=array.concat(val);
		}
		nlapiLogExecution('ERROR',array.length,array);
		var units=nlapiSearchRecord('unitstype',null,null,[new nlobjSearchColumn('unitname'),new nlobjSearchColumn('conversionrate')]);
		for (var i=0;i<array.length; i++){
			for (var j=0;units!=null&&j<units.length;j++){
				var name=units[j].getValue('unitname');
				if (name==array[i]){
					field1.addSelectOption(units[j].getValue('conversionrate'),name);
				}
			}
		}
		sub.addField('custpage_uom','text','uom');
	}
}
function po_after_submit(type){
	if (type=='create'||type=='edit'){
		var lines=nlapiGetLineItemCount('item');
		for (var i=1; i<=lines; i++){
			var qty=nlapiGetLineItemValue('item','quantity',i);
			var item=nlapiGetLineItemValue('item','item',i);	
			var amtpercase=nlapiGetLineItemValue('item','custcol_amt_per_case',i);
			var cr=nlapiGetLineItemValue('item','custpage_uomoptssave',i);
			var totalcr=amtpercase*cr;
			
		}
	}
}
function uom_field_changed(type,name,linenum){
	if (type=='item'&&name=='item'){
		var item=nlapiGetCurrentLineItemValue(type,name);
		var uom=nlapiLookupField('item',item,'unitstype');
		if (uom!=null&&uom!=''&&typeof uom !='undefined'){
			var units=nlapiSearchRecord('unitstype',null,new nlobjSearchFilter('internalid',null,'anyof',uom),[new nlobjSearchColumn('unitname'),new nlobjSearchColumn('conversionrate')]);
			var selectable=nlapiSearchRecord('customrecord_selectable_uom',null,new nlobjSearchFilter('custrecord_unit_type',null,'anyof',uom),new nlobjSearchColumn('custrecord_units'));
			var selectable_arr=selectable[0].getText('custrecord_units');
			nlapiSetCurrentLineItemValue('item','custpage_uom',uom,false);
			nlapiRemoveLineItemOption('item','custpage_uomopts',null);

			for (var i=0; units!=null&&i<units.length; i++){
				var name=units[i].getValue('unitname');
			
				var index=selectable_arr.indexOf(name);
			
				if (index>-1){
					nlapiInsertLineItemOption('item','custpage_uomopts',units[i].getValue('conversionrate'),name);
				}
			}
		}
	}
	else if (type=='item'&&name=='custpage_uomopts'){
		nlapiSetCurrentLineItemValue('item','custpage_uomoptssave',nlapiGetCurrentLineItemValue(type,name),false);
	}
}
function so_ue(type){
  nlapiLogExecution('ERROR','a',nlapiGetFieldValue('leadsource'));
}
function cust_as(type){
  if (type=='edit'||type=='create'){
    try {
  var name=nlapiGetFieldValue('companyname');
  var nocom=name.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
  nocom=nocom.replace(',','');
      var exid=nlapiLookupField('customer',nlapiGetRecordId(),'externalid');
      if (nocom!=exid){
        nlapiSubmitField('customer',nlapiGetRecordId(),'externalid',nocom)
      }
    }
    catch(e){
      nlapiLogExecution('ERROR','error',e.message);
    }
  }
  }