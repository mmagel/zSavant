/**
 * (c) 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code.
 *
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       1 Sept 2014     dcalibuyo
 *
 */

var WD_NAW_3WAY;
if (!WD_NAW_3WAY) { WD_NAW_3WAY = {}; }
/*
 *
 */
WD_NAW_3WAY.checkSubsMatchField = function _checkSubsMatchField () {
    var retVal = 0;
    var matchField = nlapiGetContext().getSetting('SCRIPT', 'custscript_3way_ws_matchfield');
    var fieldVal = nlapiLookupField('vendorbill', nlapiGetRecordId(), 'subsidiary.' + matchField);
    nlapiLogExecution('DEBUG', 'checkSubsMatchField', 'fieldVal: '  + fieldVal);
    if ( fieldVal ){
       retVal = 1;
    }
    return retVal;
}