/**
 * (c) 2014 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code.
 *
*/

var NWB;
if (!NWB) { NWB = {}; };
if (!NWB.Context) { NWB.Context = {}; };
if (!NWB.Library) { NWB.Library = {}; };

/*
 * test valid input
 */

NWB.Library.isValidObject = function _isValidObject(objectToTest)
{
    var isValidObject = false;
    isValidObject = (objectToTest!=null && objectToTest!='' && objectToTest!=undefined) ? true : false;
    return isValidObject;

};//end NWB.Library.isValidObject
/*
 * check if feature is enabled
 */
NWB.Library.isAcctFeatureOn = function _isAcctFeatureOn(featureName)
{
    var featureStatus = NWB.Context.getFeature(featureName);

    return featureStatus;
};//end NWB.Library.trim
/*
 * check if preference is on
 */
NWB.Library.isAcctPreferenceOn = function _isAcctPreferenceOn(preferenceid)
{
    var isPreferenceOn = false;
    var preferenceStatus = NWB.Context.getPreference(preferenceid);
    if (preferenceStatus == 'T' || preferenceStatus == 't') {
        isPreferenceOn = true;
    }

    return isPreferenceOn;
};//end NWB.Library.isAcctPreferenceOn


NWB.Library.setPreference = function _setPreference(preftype, preferenceid, value)
{
    var acctprefobj = nlapiLoadConfiguration(preftype);
    acctprefobj.setFieldValue(preferenceid, value);
    nlapiSubmitConfiguration(acctprefobj);

};


NWB.Context = nlapiGetContext();