/**
* � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
*/

// object for storing global variables
var stickGlobal = stickGlobal || {};
var STATUS = {
    OK: "\"ok\""
};





function process(request, response)
{
    var datain = JSON.parse(request.getBody());
    nlapiLogExecution("AUDIT", "datain", JSON.stringify(datain));

    if (stickHasNoValue(datain.action))
    {
        response.write(JSON.stringify('ERROR: stickHasNoValue(datain.action'));
        return;
    }

    if (stickHasNoValue(datain.values))
    {
        response.write(JSON.stringify('ERROR: stickHasNoValue(datain.values'));
        return;
    }


    var context = nlapiGetContext();
    var userId = context.getUser();

    switch (datain.action)
    {
        case 'getDataSet':  //get notes
            response.write(_OnGetDataSet(userId, datain.values));
            break;

        case "getBoardData":
            response.write(_OnGetBoardData(userId, datain.values));
            break;

        case 'getDefaultFontSize':
            response.write(JSON.stringify(stickGetDefaultFontSize()));
            break;

        case 'getDefaultNoteSize':
            response.write(JSON.stringify(stickGetDefaultNoteSize()));
            break;

        case 'getNoteAndFontSizes':
            var noteAndFontSizes = [stickGetNoteSizes(), stickGetFontSizes()];
            response.write(JSON.stringify(noteAndFontSizes));
            break;

        case 'getTemplates':
            var templateHash = stickGetTemplates();
            response.write(JSON.stringify(templateHash) + stickGlobal.END_OF_DATA_MARKER);
            break;

        case 'getUserOrAccountCategories':
            response.write(JSON.stringify(stickGetUserOrAccountCategories()));
            break;

        case 'updateUserCategoryColors':
            stickUpdateUserCategoryColors(datain.values);
            response.write(STATUS.OK);
            break;

        case 'deleteUserCategories':
            stickDeleteUserCategories(userId);
            response.write(STATUS.OK);
            break;

        case 'updateZIndex':
            stickUpdateZIndex(datain.values.noteId, datain.values.zIndex);  // this will throw an error if user has no access to the note
            response.write(STATUS.OK);
            break;

        case 'markAsDone':
            stickMarkAsDone(datain.values);  // this will throw an error if user has no access to the note
            response.write(STATUS.OK);
            break;

        case 'archiveNote':
            stickArchiveNote(parseInt(datain.values, 10), userId);
            response.write(STATUS.OK);
            break;

        case 'updatePosition':
            stickUpdatePosition(datain.values.internalid, datain.values.percentTop, datain.values.percentLeft);
            response.write(STATUS.OK);
            break;

        case 'addNote':
            response.write(_OnAddNote(userId, datain.values));
            break;

        case 'addReply':
            var addReplyParam = { noteId: datain.values.noteId, reply: datain.values.reply, file: datain.values.file, isBoard: datain.values.isBoard };
            response.write(JSON.stringify(stickAddReply(userId, addReplyParam)));
            break;

        case 'deleteNote':
            stickDeleteNote(datain.values, userId);  // this will throw an error if user has no access to the note
            response.write(STATUS.OK);
            break;

        case 'deleteReply':
            stickDeleteReply(datain.values, userId);
            response.write(STATUS.OK);
            break;

        case 'updateUserBoardSorterFields':
            stickUpdateUserBoardSortField(datain.values);
            response.write(STATUS.OK);
            break;

        case 'getEmployeeSearch':
            var employees = stickGetEmployeeSearch(datain.values);
            response.write(JSON.stringify(employees));
            break;

        case 'deleteFile':
            stickDeleteFile(datain.values);
            response.write(STATUS.OK);
            break;

        case 'preLoadStandardRecords':
            stickGetStandardRecords();
            response.write(STATUS.OK);
            break;

        default:
            throw 'action not found: ' + datain.action;
    }
}





function stickGetDefaultFontSize()
{
    var columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('custrecord_sfs_font_size')
    ];
    columns[1].setSort();

    var results = nlapiSearchRecord('customrecord_stick_font_size', null, null, columns);
    if (results === null)
    {
        throw 'fontSizeResults===null';
    }

    return {
        internalid: results[1].getId(),
        fontSize: results[1].getValue('custrecord_sfs_font_size')
    };
}





function stickGetDefaultNoteSize()
{
    var columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('custrecord_snz_width')
    ];
    columns[0].setSort();

    var results = nlapiSearchRecord('customrecord_stick_note_size', null, null, columns);
    if (results === null)
    {
        throw 'noteSizeResults===null';
    }

    return {
        internalid: results[1].getId(),
        noteSize: results[1].getValue('custrecord_snz_width')
    };
}





function stickGetNoteSizes()
{
    var columns = [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_snz_width'),
        new nlobjSearchColumn('custrecord_snz_height')
    ];
    columns[1].setSort();

    var results = nlapiSearchRecord('customrecord_stick_note_size', null, null, columns);
    if (results === null)
    {
        return [];
    }

    var noteSizes = [];
    for (var i = 0; i < results.length; i++)
    {
        var noteSize = {
            internalid: results[i].getId(),
            noteSizeName: results[i].getValue('name'),
            height: results[i].getValue('custrecord_snz_height'),
            width: results[i].getValue('custrecord_snz_width')
        };

        noteSizes.push(noteSize);
    }

    return noteSizes;
}





function stickGetFontSizes()
{
    var columns = [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_sfs_font_size')
    ];
    columns[1].setSort();

    var results = nlapiSearchRecord('customrecord_stick_font_size', null, null, columns);
    if (results === null)
    {
        return [];
    }

    var fontSizes = [];
    for (var i = 0; i < results.length; i++)
    {
        var fontSize = {
            internalid: results[i].getId(),
            fontSizeName: results[i].getValue('name'),
            fontSize: results[i].getValue('custrecord_sfs_font_size')
        };

        fontSizes.push(fontSize);
    }

    return fontSizes;
}





function stickGetTemplates()
{
    var fileNames = [
        'stick-record-page-templates.html',
        'stick-board-templates.html',
        'stick-common-templates.html'
    ];

    return stickGetTemplatesParam(fileNames);
}





function stickGetTemplatesParam(files)
{
    var templateHash = {};
    var fileNames = files;
    var fileNameCount = fileNames.length;
    for (var f = 0; f < fileNameCount; f++)
    {
        var fileName = fileNames[f];
        var fileContent = stickGetFileContent(fileName);
        var templates = fileContent.split('<!-- template end -->');
        var templateCount = templates.length;

        for (var i = 0; i < templateCount - 1; i++)
        {
            var template = templates[i];
            // get template id 
            // get start of <!--
            var posStart = template.indexOf('<!-- template') + '<!-- template'.length;

            // get start of -->
            var posEnd = template.indexOf('-->');
            var templateId = template.substring(posStart, posEnd);
            templateId = templateId.trim();

            var templateContent = template.substr(posEnd + '-->'.length);
            templateHash[templateId] = templateContent;
        }
    }

    // for the tmpStickNoteBoard, reuse tmpStickNote
    templateHash['tmpStickNoteBoard'] = templateHash['tmpStickNoteBoard'].replace('[[tmpStickNote]]', templateHash['tmpStickNote']);
    // HACK: prevent name collision between the note in grid and selected note
    templateHash['tmpStickNoteBoard'] = templateHash['tmpStickNoteBoard'].replace('stickReplyBox', 'stickXXXReplyBox');

    return templateHash;
}





function stickHasAccess(noteId)
{
    if (stickHasNoValue(noteId))
    {
        throw 'stickHasNoValue(noteId)';
    }

    var userId = nlapiGetContext().getUser();

    var filterAccess = [
        ['custrecord_sn_allowed_entities', 'anyof', userId.toString()],
        'or',
        ['custrecord_sn_is_public', 'is', 'T']
    ];

    var filters = [
        filterAccess,
        'and',
        ['internalid', 'anyof', noteId.toString()]
    ];

    var results = nlapiSearchRecord('customrecord_stick_note', null, filters);
    if (results === null)
    {
        throw 'No access. userId=' + userId + '; noteId=' + noteId;
    }

    return true;
}





function _SearchEntitiesById(entityIds)
{
    var filters = [
        ['internalid', 'anyof', entityIds]
    ];

    var columns = [
        new nlobjSearchColumn('firstname'),
        new nlobjSearchColumn('lastname')
    ];

    var rs = nlapiSearchRecord('employee', null, filters, columns);

    return rs == null ? [] : rs;
}





function _SearchAllNoteReplies(noteIds)
{
    // get replies for record page only since in board, replies are not displayed by default
    // get all replies for the retrieved notes
    var filters = [
        ['custrecord_snr_note', 'anyof', noteIds]
    ];

    var columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('custrecord_snr_note'),
        new nlobjSearchColumn('custrecord_snr_reply'),
        new nlobjSearchColumn('owner'),
        new nlobjSearchColumn('created'),
        new nlobjSearchColumn('custrecord_snr_file')
    ];
    columns[0].setSort();

    var replies = stickSearchAllRecords2('customrecord_stick_note_reply', null, filters, columns);
    if (stickHasValue(replies))
    {
        // sort by created date
        replies.sort(function(a, b)
        {
            // check created dates
            var aDate = nlapiStringToDate(a.getValue('created'));
            var bDate = nlapiStringToDate(b.getValue('created'));
            if (aDate > bDate)
            {
                return 1;
            }
            else if (aDate < bDate)
            {
                return -1;
            }
            else
            {
                // check internal ids
                return a.getId() > b.getId() ? 1 : (a.getId() < b.getId() ? -1 : 0);
            }
        });
    }
    return replies;
}





function stickProcessNotes(notes, results, noteSizeId, fontSizeId, isBoard)
{
    var logger = new stickobjLogger(undefined, false, 'stickProcessNotes');

    if (stickHasNoValue(noteSizeId))
    {
        throw 'stickHasNoValue(noteSizeId)';
    }

    if (stickHasNoValue(fontSizeId))
    {
        throw 'stickHasNoValue(fontSizeId)';
    }


    var context = nlapiGetContext();
    var userId = context.getUser();

    // get all recipient ids and search first and lastname
    var strEntityIds = '';
    for (var i = 0; i < results.length; i++)
    {
        strEntityIds += results[i].getValue('custrecord_sn_allowed_entities') + ',';
    }

    var entityIds = strEntityIds.split(',');
    var employeeResults = _SearchEntitiesById(entityIds);
    var employeeHash = {};

    for (var i = 0; i < employeeResults.length; i++)
    {
        var employeeResult = employeeResults[i];
        var key = employeeResult.getId();
        if (stickHasNoValue(employeeHash[key]))
        {
            employeeHash[key] = employeeResult.getValue('firstname') + ' ' + employeeResult.getValue('lastname');
        }
    }

    stickGlobal.employeeHash = employeeHash;
    
    var noteIds = [];
    for (var i = 0; i < notes.length; i++)
    {
        noteIds.push(notes[i].internalid);

        notes[i].recordTypeName = results[i].getText('custrecord_sn_scripted_record_type');
        notes[i].extTypes = _GetExtendedTypes(notes[i].custrecord_sn_record_type_script_id, notes[i].custrecord_sn_record_id);
        notes[i].categoryPriority = results[i].getValue('custrecord_snc_priority', 'custrecord_sn_note_category');
        notes[i].categoryName = results[i].getText('custrecord_sn_note_category');
        notes[i].ownerName = results[i].getText('owner');

        var message = notes[i].custrecord_sn_message;
        message = message.toString();
        message = message.replace(/\[br\]/g, '<br>');
        notes[i].message = message;
        notes[i].recipientsName = stickGetEmployeeFullName(results[i].getValue('custrecord_sn_allowed_entities'));

        // remove name of owner
        var currentUserEntityName = results[i].getText('owner');
        notes[i].recipientsName = notes[i].recipientsName.replace(currentUserEntityName + ',', '');
        notes[i].recipientsName = notes[i].recipientsName.replace(',' + currentUserEntityName, '');
        notes[i].isPublicText = notes[i].custrecord_sn_is_public == 'T' ? 'Yes' : 'No';
        notes[i].field_script_id = notes[i].custrecord_sn_field_script_id;
        notes[i].replies = [];
        
        var allowedEntities = notes[i].custrecord_sn_allowed_entities.split(',');
        var stickSubscribeOrUnsubscribeText = 'Subscribe';
        if (allowedEntities.indexOf(userId.toString()) > -1)
        {
            stickSubscribeOrUnsubscribeText = 'Unsubscribe';
        }
        notes[i].stickSubscribeOrUnsubscribeText = stickSubscribeOrUnsubscribeText;
        
        stickCheckFileAttached(notes[i], 'custrecord_sn_file', 'custparam_noteid', isBoard);
    }


    var noteSizeHash = stickGetNoteSize(noteSizeId);
    var fontSize = stickGetFontSize(fontSizeId);
    var width = noteSizeHash.width;
    var height = noteSizeHash.height;
    var categories = stickGetUserOrAccountCategories();
    var categoryHash = {};

    // load colors
    for (var i = 0; i < categories.length; i++)
    {
        var category = categories[i];
        var categoryId = category.categoryId;
        categoryHash[categoryId] = category.categoryColor;
    }


    for (var i = 0; i < notes.length; i++)
    {
        var note = notes[i];
        note.height = height;
        note.width = width;
        note.fontsize = fontSize;
        var categoryId = note.custrecord_sn_note_category;
        note.categoryColor = categoryHash[categoryId];
        // next line is slow if there are many notes, so just get the url when the user clicks the link
        note.link = '#';

        if (stickGlobal.getReplies === false)
        {
            notes[i].replies = [];
        }
    }


    results = _SearchAllNoteReplies(noteIds);
    if (results !== null)
    {
        var repliesHash = {};    //to group replies by note id

        var replies = stickConvertResultsToEntities(results);

        for (i = 0; i < replies.length; i++)
        {
            var noteId = replies[i].custrecord_snr_note;

            replies[i].custrecord_snr_reply = replies[i].custrecord_snr_reply.replace(/\[br\]/g, '<br>');
            replies[i].ownerName = results[i].getText('owner');
            replies[i].fontsize = fontSize;
            replies[i].height = height;
            replies[i].width = width;
            stickCheckFileAttached(replies[i], 'custrecord_snr_file', 'custparam_replyid', isBoard);

            repliesHash[noteId] = repliesHash[noteId] || [];
            repliesHash[noteId].push(replies[i]);
        }

        // set the replies for each note
        for (i = 0; i < notes.length; i++)
        {
            noteId = notes[i].internalid;
            notes[i].replies = repliesHash[noteId] || [];
        }
    }

    return notes;
}


function stickCheckFileAttached(note, fileFieldId, paramId, isBoard) {
    // check if has file
    note.fileStyle = 'display: none;';
    note.fileUrl = '';
    note.fileName = '';
    note.previewUrl = '';
    note.previewStyle = '';
    note.hasPreview = 'none';
    note.linkStyle = '';
    note.fileTypeIcon = '';
    note.transImgUrl = stickGetTransparentImageUrl(false /*bIsClient*/);
    var file = note[fileFieldId];
    if (stickHasValue(file)) {
        
        try {
            file = JSON.parse(file);
        } catch (ex) {
            // file info is invalid
            return;
        }
        
        // ensure file is a valid file object
        if (stickHasValue(file.fileId)) {
            // get file download suitelet url
            if (stickHasNoValue(stickGlobal.fileDownloadUrl)) {
                stickGlobal.fileDownloadUrl = nlapiResolveURL('SUITELET', 'customscript_stick_file_dl_sl', 'customdeploy_stick_file_dl_sl');
            }
            var fileUrl = stickGlobal.fileDownloadUrl + '&' + paramId + '=' + note.internalid + '&custparam_orig=T';
            
            note.fileUrl = fileUrl;
            note.fileName = file.origFileName;
            note.fileStyle = '';
            note.fileTypeIcon = stickGetFileTypeIcon(file.extName, false /*bIsClient*/);
            
            // check if supported image, show preview; otherwise, show file link
            if (stickIsSupportedImage(file.extName) && stickIsEnabledImagePreview(isBoard)) {
                // get preview image url if there's any
                var previewUrl = stickHasValue(file.previewFileId) ? (stickGlobal.fileDownloadUrl + '&' + paramId + '=' + note.internalid) : fileUrl;
                
                note.previewUrl = previewUrl;
                note.previewStyle = '';
                note.hasPreview = 'has';
                note.linkStyle = 'display: none;';
            } else {
                note.previewStyle = 'display: none;';
                note.linkStyle = '';
            }
        }
    }
}


function stickGetNoteSize(noteSizeId)
{
    if (stickHasValue(stickGlobal.stickGetNoteSizeReturn))
    {
        //ok to consider parameter in caching since we don't expect noteSizeId to change during the call
        return stickGlobal.stickGetNoteSizeReturn;
    }


    var filters = [
        ['internalid', 'anyof', noteSizeId]
    ];

    var columns = [
        new nlobjSearchColumn('custrecord_snz_height'),
        new nlobjSearchColumn('custrecord_snz_width')
    ];

    var rs = nlapiSearchRecord('customrecord_stick_note_size', null, filters, columns);


    stickGlobal.stickGetNoteSizeReturn = {
        height: rs[0].getValue('custrecord_snz_height') + 'px',
        width: rs[0].getValue('custrecord_snz_width') + 'px'
    };

    return stickGlobal.stickGetNoteSizeReturn;
}



function _OnGetDataSet(userId, values)
{
    var recType = values.recordTypeScriptId;
    var recId = values.recordId;
    var noteSizeId = stickHasNoValue(values.noteSizeId) ? stickGetDefaultNoteSize().internalid : values.noteSizeId;
    var fontSizeId = stickHasNoValue(values.fontSizeId) ? stickGetDefaultFontSize().internalid : values.fontSizeId;
    var noteState = values.noteState;
    var noteId = values.noteId;
    var isBoard = values.isBoard

    stickGlobal.getReplies = stickHasValue(noteId) || (stickHasValue(recType) && stickHasValue(recId));

    var dataSet = {
        noteSize: stickGetNoteSize(noteSizeId),
        fontSize: stickGetFontSize(fontSizeId),
        templateHash: stickGetTemplates(),
        categories: stickGetUserOrAccountCategories(),
        sortFields: stickGetUserOrDefaultSortFields(),
        notes: _GetNotes(recType, recId, noteSizeId, fontSizeId, userId, noteState, noteId, isBoard),
        isFullAccess: _IsFullAccess(),
        roleName: stickGetCurrentRoleName()
    };

    _SetImageUrls(dataSet);

    return JSON.stringify(dataSet) + stickGlobal.END_OF_DATA_MARKER;
}





function _OnAddNote(userId, values)
{
    var addNoteParam = {
        recordTypeScriptId: values.recordTypeScriptId.toLowerCase(),
        recordId: values.recordId,
        message: values.message,
        recipients: values.recipients,
        percentTop: values.percentTop,
        percentLeft: values.percentLeft,
        categoryId: values.categoryId,
        allowThoseWithRecordAccess: values.allowThoseWithRecordAccess,
        zIndex: values.zIndex,
        fieldScriptId: values.fieldScriptId,
        noteSizeId: values.noteSizeId,
        fontSizeId: values.fontSizeId,
        recordName: values.recordName,
        host: values.host,
        file: values.file,
        isBoard: values.isBoard
    };

    var notes = stickAddNote(userId, addNoteParam);

    return JSON.stringify(notes);
}





function _CreateNoteRecord(userId, note)
{
    var recType = stickGetRecordNameByScriptId(note.recordTypeScriptId);
    if (stickHasNoValue(recType))
    {
        recType = stickGetScriptedRecordType(note.recordTypeScriptId);
    }

    var rec = nlapiCreateRecord('customrecord_stick_note');

    rec.setFieldText('custrecord_sn_scripted_record_type', recType);
    rec.setFieldValues('custrecord_sn_allowed_entities', note.recipients);
    rec.setFieldValue('custrecord_sn_message', note.message.replace(/\n/g, '[br]'));
    rec.setFieldValue('custrecord_sn_record_name', note.recordName);
    rec.setFieldValue('custrecord_sn_record_type_script_id', note.recordTypeScriptId);
    rec.setFieldValue('custrecord_sn_record_id', note.recordId);
    rec.setFieldValue('custrecord_sn_status', 'new');
    rec.setFieldValue('custrecord_sn_note_category', note.categoryId);
    rec.setFieldValue('custrecord_sn_percent_top', note.percentTop);
    rec.setFieldValue('custrecord_sn_percent_left', note.percentLeft);
    rec.setFieldValue('custrecord_sn_is_public', note.allowThoseWithRecordAccess);
    rec.setFieldValue('custrecord_sn_z_index', note.zIndex);
    rec.setFieldValue('custrecord_sn_field_script_id', note.fieldScriptId);
    rec.setFieldValue('custrecord_sn_file', JSON.stringify(note.file));

    var noteRec = {
        id: nlapiSubmitRecord(rec),
        rec: rec
    };

    return noteRec;
}





function stickAddNote(userId, note)
{
    if (note.recipients.indexOf(userId.toString()) == -1)
    {
        note.recipients.push(userId.toString());
    }

    var noteRec = _CreateNoteRecord(userId, note);


    // send notification
    // TODO: how to get the data center using the RECORD
    var recordUrl = nlapiResolveURL('record', note.recordTypeScriptId, note.recordId);
    var priorityName = noteRec.rec.getFieldText('custrecord_sn_note_category');

    if (nlapiGetContext().getPreference('custscript_stick_enable_email') != 'F')  //Checking against "F" ensures uninitiated value defaults to true
    {
        // send email notification
        stickQueue({
            command: 'stickynotes_email_alerts',
            type: 'NOTE',
            noteId: noteRec.id
        });
    }


    var filters = [
        ['internalid', 'anyof', noteRec.id]
    ];

    var results = nlapiSearchRecord('customrecord_stick_note', null, filters, stickGetNoteColumns());
    if (results === null)
    {
        throw 'results === null';
    }

    var notes = stickProcessNotes(stickConvertResultsToEntities(results), results, note.noteSizeId, note.fontSizeId, note.isBoard);
    if (notes.length === 0)
    {
        throw 'notes.length === 0';
    }

    return notes;
}





function stickGetUserCategories()
{
    var userId = nlapiGetContext().getUser();

    var filters = [
        ['owner', 'anyof', userId]
    ];

    var columns = [
        new nlobjSearchColumn('custrecord_snuc_category'),
        new nlobjSearchColumn('custrecord_snuc_color'),
        new nlobjSearchColumn('custrecord_snc_priority', 'custrecord_snuc_category'),
        new nlobjSearchColumn('name', 'custrecord_snuc_category')
    ];
    columns[2].setSort();

    var results = nlapiSearchRecord('customrecord_stick_note_user_category', null, filters, columns);
    if (results === null)
    {
        return [];
    }

    var categories = [];
    for (var i = 0; i < results.length; i++)
    {
        var category = {
            internalid: results[i].getId(),
            categoryId: results[i].getValue('custrecord_snuc_category'),
            categoryName: results[i].getValue('name', 'custrecord_snuc_category'),
            categoryNameSmall: results[i].getValue('name', 'custrecord_snuc_category').toLowerCase(),
            categoryColor: results[i].getValue('custrecord_snuc_color'),
            priority: results[i].getValue('custrecord_snc_priority', 'custrecord_snuc_category')
        };

        categories.push(category);
    }

    return categories;
}





function stickGetAccountCategories()
{
    var logger = new stickobjLogger(arguments);

    var columns = [
        new nlobjSearchColumn('custrecord_snc_color'),
        new nlobjSearchColumn('custrecord_snc_priority'),
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('internalid')
    ];
    columns[1].setSort();

    var results = nlapiSearchRecord('customrecord_stick_note_category', null, null, columns);
    if (results === null)
    {
        return [];
    }


    var categories = [];
    for (var i = 0; i < results.length; i++)
    {
        var category = {
            internalid: results[i].getId(),
            categoryId: results[i].getId(),
            categoryName: results[i].getValue('name'),
            categoryNameSmall: results[i].getValue('name').toLowerCase(),
            categoryColor: results[i].getValue('custrecord_snc_color'),
            priority: results[i].getValue('custrecord_snc_priority')
        };

        categories.push(category);
    }

    logger.end();
    return categories;
}




function stickGetUserOrAccountCategories()
{
    var categories = stickGetUserCategories();
    if (categories.length > 0)
    {
        return categories;
    }

    return stickGetAccountCategories();
}





function stickUpdateUserCategoryColors(categories)
{
    // check if there are user categories
    var userCategories = stickGetUserCategories();
    if (userCategories.length > 0)
    {
        // update
        for (var i = 0; i < categories.length; i++)
        {
            try
            {
                var internalid = categories[i].internalid;
                nlapiSubmitField('customrecord_stick_note_user_category', internalid, 'custrecord_snuc_color', categories[i].categoryColor);
            }
            catch (e)
            {
                throw "nlapiSubmitField('customrecord_stick_note_user_category' failed; internalid=" + internalid + '; e=' + e;
            }
        }
    }
    else //create
    {
        for (var j = 0; j < categories.length; j++)
        {
            var rec = nlapiCreateRecord('customrecord_stick_note_user_category');

            rec.setFieldValue('custrecord_snuc_category', categories[j].categoryId);
            rec.setFieldValue('custrecord_snuc_color', categories[j].categoryColor);

            nlapiSubmitRecord(rec);
        }
    }
}





function _GetNotes(recordTypeScriptId, recordId, noteSizeId, fontSizeId, userId, noteState, noteId, isBoard)
{
    var rs = null;

    if (stickHasValue(noteId))
    {
        rs = _SearchNotesById(noteId, userId) || [];
    }
    else if (stickHasValue(recordTypeScriptId) && stickHasValue(recordId))  // called from a record page
    {
        _CheckUserAccess(recordTypeScriptId.toLowerCase() + recordId);

        rs = _GetRecordNotes(recordTypeScriptId, recordId, userId, noteState, true) || [];

        // limit to 100 notes
        stickGlobal.NOTES_LIMIT = 100;
        if (rs.length > stickGlobal.NOTES_LIMIT)
        {
            rs = rs.slice(0, stickGlobal.NOTES_LIMIT);
        }
    }
    else
    {
        //stickynotes board
        rs = _SearchBoardNotes(noteState, userId) || [];
    }

    if (rs === null || rs.length == 0)
    {
        return [];
    }

    var entities = stickConvertResultsToEntities(rs);

    return stickProcessNotes(entities, rs, noteSizeId, fontSizeId, isBoard);
}





function _GetRecordNotes(recType, recId, userId, noteState, isFieldNoteIncluded)
{
    var rs = _SearchRecordNotes(recType, recId, userId, noteState, isFieldNoteIncluded) || [];

    var srcRec = _GetSourceRecord(recType, recId);
    if (srcRec != null)
    {
        //Recursively get notes
        var rsPrev = _GetRecordNotes(srcRec.Type, srcRec.Id, userId, noteState, false)
        if (rsPrev != null)
        {
            rs = rs.concat(rsPrev);
        }
    }

    return rs;
}





function _SearchRecordNotes(recordTypeScriptId, recordId, userId, noteState, isFieldNoteIncluded)
{
    var recType = recordTypeScriptId.toLowerCase();

    var filters = [
        ['custrecord_sn_record_type_script_id', 'is', recType],
        
        "AND",
        ['custrecord_sn_record_id', 'equalto', recordId],
        
        "AND",
        [
            ['custrecord_sn_allowed_entities', 'anyof', userId.toString()],  // those in the TO list
            'OR',
            ['custrecord_sn_is_public', 'is', 'T']  // those with access to the record
        ],
        
        "AND",
        ['custrecord_sn_status', noteState === 'archived' ? 'is' : 'isnot', 'archived']
    ];

    if (isFieldNoteIncluded === false)
    {
        filters.push("AND");
        filters.push(["custrecord_sn_field_script_id", "is", ""]);
    }

    return nlapiSearchRecord('customrecord_stick_note', null, filters, stickGetNoteColumns());
}





function _GetSourceRecord(recType, recId)
{
    if (nlapiGetContext().getPreference("custscript_stick_enable_notes_transform") != "T")
    {
        return null;
    }

    //Get source record id, if any
    try
    {
        var srcRecId = nlapiLookupField(recType, recId, "createdfrom");
    }
    catch (e)
    {
        return null;
    }

    if (srcRecId == null || srcRecId == "")
    {
        return null;
    }

    //Get source record type
    var srcRecType = nlapiLookupField("transaction", srcRecId, "recordtype");
    if (srcRecType == null || srcRecType == "")
    {
        return null;
    }

    return { Id: srcRecId, Type: srcRecType };
}





function _SearchNotesById(noteId, userId)
{
    var filters = [
        ['internalid', 'anyof', noteId],
        "AND"
    ];

    if (_IsFullAccess())
    {
        filters.push([
            ['custrecord_sn_allowed_entities', 'anyof', userId.toString()],  //my notes
            "OR",
            ["custrecord_sn_is_public", 'is', "T"]  //public notes
        ]);
    }
    else
    {
        filters.push(['custrecord_sn_allowed_entities', 'anyof', userId.toString()]);  //my notes
    }

    return nlapiSearchRecord('customrecord_stick_note', null, filters, stickGetNoteColumns());
}





function _SearchBoardNotes(noteState, userId)
{
    var filters = [
        ['custrecord_sn_status', noteState === 'archived' ? 'is' : 'isnot', 'archived'],
        "AND"
    ];

    if (_IsFullAccess())
    {
        filters.push([
            ['custrecord_sn_allowed_entities', 'anyof', userId.toString()],  //my notes
            "OR",
            ["custrecord_sn_is_public", 'is', "T"]  //public notes
        ]);
    }
    else
    {
        filters.push(['custrecord_sn_allowed_entities', 'anyof', userId.toString()]);  //my notes
    }

    return nlapiSearchRecord('customrecord_stick_note', null, filters, stickGetNoteColumns());
}





function _SearchTransformedRecords()
{
    var filters = [
        ["createdfrom", "noneof", "@NONE@"]
    ];

    var columns = [
        new nlobjSearchColumn("createdfrom"),
        new nlobjSearchColumn("recordtype")
    ];

    var rs = nlapiSearchRecord("transaction", null, filters, columns) || [];

    var recs = {};
    for (var i = 0; i < rs.length; ++i)
    {
        var key = rs[i].getValue("recordtype") + "|" + rs[i].getId();
        recs[key] = rs[i].getValue("createdfrom") ;
    }
    
    return recs;
}





function _SearchParentTypes(parentIds)
{
    if(parentIds == null || parentIds.length == 0)
    {
        return {};
    }
    
    var filters = [
        ["internalid", "anyof", parentIds]
    ];

    var columns = [
        //new nlobjSearchColumn("recordtype"),
        new nlobjSearchColumn("type")
    ];

    var rs = nlapiSearchRecord("transaction", null, filters, columns) || [];

    var parentTypes = {};
    for (var i = 0; i < rs.length; ++i)
    {
        parentTypes[rs[i].getId()] = _ToRecType(rs[i].getValue("type"));
    }
    
    return parentTypes;
}





function _GetRecTree(parentTypes, tranRecs)
{
    var tree = {};
    
    for (var childKey in tranRecs)
    {
        var parentType = parentTypes[tranRecs[childKey]];
        if (parentType === undefined)
        {
            continue;
        }

        var parentKey = parentType + "|" + tranRecs[childKey];
        if (!(parentKey in tree))
        {
            tree[parentKey] = [];
        }

        tree[parentKey].push(childKey);
    }

    return tree;
}





function _GetExtendedTypes(recType, recId)
{
    if (nlapiGetContext().getPreference("custscript_stick_enable_notes_transform") != "T")
    {
        return [];
    }

    if (_GetExtendedTypes.RecTree == null)
    {
        var tranRecs = _SearchTransformedRecords();
        var parentIds = Object.keys(tranRecs).map(function (key) { return tranRecs[key] });
        var parentTypes = _SearchParentTypes(parentIds);
        
        _GetExtendedTypes.RecTree = _GetRecTree(parentTypes, tranRecs);
    }

    var key = recType + "|" + recId;
    
    var oTypes = _GetChildrenTypes(key, _GetExtendedTypes.RecTree);
    
    return Object.keys(oTypes).map(function (key) { return key; });
}





function _GetChildrenTypes(key, tree, oTypes)
{
    if(oTypes == null)
    {
        oTypes = {};
    }
    
    if(!(key in tree))
    {
        return oTypes;
    }
    
    for(var i = 0; i < tree[key].length; ++i)
    {
        var childKey = tree[key][i];
        
        oTypes[childKey.split("|")[0]] = true;
        
        if(childKey in tree)
        {
            _GetChildrenTypes(childKey, tree, oTypes);
        }
    }

    return oTypes;
}





function _ToRecType(type)
{
    var RECTYPES = {
        "Build": "assemblyitem",
        "Unbuild": "assemblyunbuild",
        "VendBill": "vendorbill",
        "VendCred": "vendorcredit",
        "VendPymt": "vendorpayment",
        "BinWksht": "binworksheet",
        "BinTrnfr": "bintransfer",
        "CashRfnd": "cashrefund",
        "CashSale": "cashsale",
        "Check": "check",
        "CustCred": "creditmemo",
        "CustDep": "customerdeposit",
        "CustRfnd": "customerrefund",
        "DepAppl": "depositapplication",
        "Estimate": "estimate",
        "ExpRept": "expensereport",
        "InvAdjst": "inventoryadjustment",
        "InvTrnfr": "inventorytransfer",
        "CustInvc": "invoice",
        "ItemShip": "itemfulfillment",
        "ItemRcpt": "itemreceipt",
        "Journal": "journalentry",
        "Opprtnty": "opportunity",
        "CustPymt": "customerpayment",
        "PurchOrd": "purchaseorder",
        "RtnAuth": "returnauthorization",
        "SalesOrd": "salesorder",
        "VendAuth": "vendorreturnauthorization",
        "WorkOrd": "workorder"
    };

    return type in RECTYPES ? RECTYPES[type] : undefined;
}





function _SetImageUrls(dataSet)
{
    var images = [
        'stick-grid.png',
        'stick-list.png',
        'stick-private.png',
        'stick-public.png',
        'stick-reply.png',
        'stick-help.png',
        'stick-delete.png',
        'stick-employee-delete.png',
        'stick-loading-ani-trans.gif',
        'stick-attachment.png'
    ];

    for (var i = 0; i < images.length; ++i)
    {
        var results = nlapiSearchRecord('file', null, ['name', 'is', images[i]]);
        if (results === null)
        {
            throw 'image not found. imageFileName=' + images[i];
        }

        dataSet[images[i]] = nlapiResolveURL('mediaitem', results[0].getId());
    }
}





function _CheckUserAccess(key)
{
    if (key == null || key == "")
    {
        throw 'Invalid key.';
    }

    // check if user has access to the record. The session object recentlyAccessedRecords is set in the beforeload user event
    var srar = nlapiGetContext().getSessionObject('stickRecentlyAccessedRecords');
    var recentlyAccessedRecords = stickHasNoValue(srar) ? [] : JSON.parse(srar);

    if (recentlyAccessedRecords.indexOf(key) == -1)
    {
        throw 'You dont have access to this record.';
    }

    return recentlyAccessedRecords;
}





function stickUpdateZIndex(noteId, zIndex)
{
    stickHasAccess(noteId);
    nlapiSubmitField('customrecord_stick_note', noteId, 'custrecord_sn_z_index', zIndex);
}





function stickGetEmployeeSearch(searchString)
{
    var logger = new stickobjLogger(arguments);
    var columns = [
        new nlobjSearchColumn('firstname'),
        new nlobjSearchColumn('lastname'),
        new nlobjSearchColumn('internalid')
    ];
    columns[0].setSort();

    // an employee's entity id is the display name or the 'text' in a select employee field
    var filters = [
        [
            ['lastname', 'startswith', searchString],
            "OR",
            ['firstname', 'startswith', searchString],
            "OR",
            ['entityid', 'startswith', searchString]
        ],
        "AND",
        ['isinactive', 'is', 'F']
    ];

    var results = nlapiSearchRecord('employee', null, filters, columns);
    if (results === null)
    {
        return [];
    }

    var employees = stickConvertResultsToEntities(results);
    for (var i = 0; i < results.length; i++)
    {
        employees[i].name = results[i].getValue('firstname') + ' ' + results[i].getValue('lastname');
    }

    employees.sort(function(a, b)
    {
        return a.name > b.name ? 1 : a.name < b.name ? -1 : 0;
    });

    return employees;
}





function stickDeleteReply(replyId, userId)
{
    // delete reply only if user is the owner
    var ownerId = nlapiLookupField('customrecord_stick_note_reply', replyId, 'owner');
    if (ownerId != userId)
    {
        throw 'You cannot delete this reply because you are not the owner';
    }
    
    _DeleteReplyFile(replyId); // delete file attached to reply
    
    // delete reply
    nlapiDeleteRecord('customrecord_stick_note_reply', replyId);
}





function _DeleteReplyFile(replyId)
{
    // check if reply has file attached
    var fileInfo = nlapiLookupField('customrecord_stick_note_reply', replyId, 'custrecord_snr_file');
    if (fileInfo == null || fileInfo == "")
    {
        return;
    }

    var objFile = _TryParse(fileInfo);
    if (objFile == null)
    {
        return;
    }

    // delete file if any
    _TryDeleteFile(objFile.fileId);

    // delete image preview file if any
    _TryDeleteFile(objFile.previewFileId);
}





function stickDeleteNote(noteId, userId)
{
    // check user access to note
    stickHasAccess(noteId);
    
    // delete note only if user is the owner
    var ownerId = nlapiLookupField('customrecord_stick_note', noteId, 'owner');
    if (ownerId != userId)
    {
        throw 'You cannot delete this note because you are not the owner';
    }
    
    _DeleteNoteReplies(noteId);  //delete replies linked to note

    _DeleteNoteEmailCaptures(noteId);  //delete email capture records linked to note

    _DeleteNoteFile(noteId); // delete file attached to note

    // delete note
    nlapiDeleteRecord('customrecord_stick_note', noteId);
}





function _DeleteNoteReplies(noteId)
{
    var filters = [
        ['custrecord_snr_note', 'anyof', noteId]
    ];

    var results = nlapiSearchRecord('customrecord_stick_note_reply', null, filters) || [];

    for (var i = 0; i < results.length; i++)
    {
        var result = results[i];
        
        _DeleteReplyFile(result.getId()); // delete file attached to reply
        
        nlapiDeleteRecord('customrecord_stick_note_reply', result.getId());
    }
}





function _DeleteNoteEmailCaptures(noteId)
{
    var filters = [
        ['custrecord_stick_email_cap_note', 'anyof', noteId]
    ];

    var results = nlapiSearchRecord('customrecord_stick_email_capture', null, filters) || [];

    for (var i = 0; i < results.length; i++)
    {
        nlapiDeleteRecord('customrecord_stick_email_capture', results[i].getId());
    }
}





function _DeleteNoteFile(noteId)
{
    // check if note has file attached
    var fileInfo = nlapiLookupField('customrecord_stick_note', noteId, 'custrecord_sn_file');
    if (fileInfo == null || fileInfo == "")
    {
        return;
    }
    
    var objFile = _TryParse(fileInfo);
    if (objFile == null)
    {
        return;
    }

    // delete file if any
    _TryDeleteFile(objFile.fileId);

    // delete image preview file if any
    _TryDeleteFile(objFile.previewFileId);
}





function _TryParse(s)
{
    try
    {
        return JSON.parse(s);
    }
    catch(e)
    {
    }

    return null;
}





function _IsNumeric(s)
{
    //Test for null, undefined, blank space and non-numeric values
    return /^\d+$/.test(s);
}






function _TryDeleteFile(id)
{
    if (!_IsNumeric(id))
    {
        return;
    }

    try
    {
        nlapiDeleteFile(id);
    }
    catch (e)
    {
        nlapiLogExecution("ERROR", "Error deleting file", "File ID: " + id);
    }
}





function stickMarkAsDone(noteId)
{
    stickHasAccess(noteId);
    nlapiSubmitField('customrecord_stick_note', noteId, 'custrecord_sn_status', 'completed');
}





function stickArchiveNote(noteId, userId)
{
    stickHasAccess(noteId);
    
    var ownerId = nlapiLookupField('customrecord_stick_note', noteId, 'owner');
    if (ownerId != userId)
    {
        throw 'You cannot archive this note because you are not the owner';
    }
    
    nlapiSubmitField('customrecord_stick_note', noteId, 'custrecord_sn_status', 'archived');
}





function stickUpdatePosition(noteId, percentTop, percentLeft)
{
    var r = nlapiLoadRecord('customrecord_stick_note', noteId);
    
    r.setFieldValue('custrecord_sn_percent_top', percentTop);
    r.setFieldValue('custrecord_sn_percent_left', percentLeft);
    
    nlapiSubmitRecord(r);
}





function stickAddReply(userId, param)
{
    // get params
    var noteId = param.noteId;
    var reply = param.reply;
    var checkAccess = param.checkAccess;
    var file = param.file;
    var isBoard = param.isBoard;

    // if checkAccess has no value, default is true
    if (stickHasNoValue(checkAccess))
    {
        checkAccess = true;
    }
    // check if need to check access
    if (checkAccess)
    {
        stickHasAccess(noteId);
    }

    // begin creating note reply
    var r = nlapiCreateRecord('customrecord_stick_note_reply');
    r.setFieldValue('custrecord_snr_note', noteId);
    var replyHtmlEncoded = reply.replace(/\n/g, '[br]');
    r.setFieldValue('custrecord_snr_reply', replyHtmlEncoded);
    r.setFieldValue('owner', userId);
    r.setFieldValue('custrecord_snr_file', JSON.stringify(file));
    var id = nlapiSubmitRecord(r);

    var filters = [
        ['internalid', 'anyof', id]
    ];

    var columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('custrecord_snr_note'),
        new nlobjSearchColumn('custrecord_snr_reply'),
        new nlobjSearchColumn('owner'),
        new nlobjSearchColumn('created'),
        new nlobjSearchColumn('custrecord_snr_file')
    ];

    var results = nlapiSearchRecord('customrecord_stick_note_reply', null, filters, columns);
    if (results === null)
    {
        throw 'results === null';
    }

    var replies = stickConvertResultsToEntities(results);
    for (var i = 0; i < replies.length; i++)
    {
        replies[i].ownerName = results[i].getText('owner');
        replies[i].owner = results[i].getValue('owner');
        replies[i].custrecord_snr_reply = replies[i].custrecord_snr_reply.replace(/\[br\]/g, '<br>');
        stickCheckFileAttached(replies[i], 'custrecord_snr_file', 'custparam_replyid', isBoard);
    }

    if (nlapiGetContext().getPreference('custscript_stick_enable_email') != "F")  //Checking against "F" ensures uninitiated value defaults to true
    {
        // send email notification
        stickQueue({
            command: 'stickynotes_email_alerts',
            type: 'REPLY',
            noteId: noteId,
            replyId: id
        });
    }

    return replies;
}





function stickGetUserBoardSortFields()
{
    var userId = nlapiGetContext().getUser();
    
    var filters = [
        ['owner', 'anyof', userId]
    ];

    var columns = [
        new nlobjSearchColumn('custrecord_snubs_sort_definition')
    ];

    var results = nlapiSearchRecord('customrecord_stick_user_board_sort', null, filters, columns);
    if (results === null)
    {
        return [];
    }


    var userBoardSortFields = [];
    for (var i = 0; i < results.length; i++)
    {
        userBoardSortFields.push({
            internalid: results[i].getId(),
            sortFilter: results[i].getValue('custrecord_snubs_sort_definition')
        });
    }

    return userBoardSortFields;
}





function stickGetDefaultSortFields()
{
    var columns = [
        new nlobjSearchColumn('custrecord_snas_sort_definition')
    ];
    
    var results = nlapiSearchRecord('customrecord_stick_sort_filter', null, null, columns);
    if (results == null)
    {
        return [];
    }


    var sortFields = [];
    for (var i = 0; i < results.length; i++)
    {
        sortFields.push({
            internalid: results[i].getId(),
            sortFilter: results[i].getValue('custrecord_snas_sort_definition')
        });
    }

    return sortFields;
}





function stickGetUserOrDefaultSortFields()
{
    var sortFields = stickGetUserBoardSortFields();

    return sortFields.length > 0 ? sortFields : stickGetDefaultSortFields();
}





function stickUpdateUserBoardSortField(sortFields)
{
    var sortFilterAndDirection = '';

    for (var i = 0; i < sortFields.length; i++)
    {
        var sortField = sortFields[i];
        sortFilterAndDirection = sortFilterAndDirection + sortField.internalid + ' ' + sortField.direction;
        sortFilterAndDirection = sortFilterAndDirection + (i == sortFields.length - 1 ? '' : ',');
    }

    var userBoardSort = stickGetUserBoardSortFields();
    if (userBoardSort.length > 0)
    {
        nlapiSubmitField('customrecord_stick_user_board_sort', userBoardSort[0].internalid, 'custrecord_snubs_sort_definition', sortFilterAndDirection);
    }
    else
    {
        var userId = nlapiGetContext().getUser();

        var r = nlapiCreateRecord('customrecord_stick_user_board_sort');

        r.setFieldValue('custrecord_snubs_sort_definition', sortFilterAndDirection);
        r.setFieldValue('owner', userId);

        nlapiSubmitRecord(r);
    }
}





function stickDeleteUserCategories(userId)
{
    var columns = [
        new nlobjSearchColumn('custrecord_snuc_category')
    ];

    var filters = [
        ['owner', 'anyof', userId]
    ];

    var results = nlapiSearchRecord('customrecord_stick_note_user_category', null, filters, columns) || [];

    for (var i = 0; i < results.length; i++)
    {
        nlapiDeleteRecord('customrecord_stick_note_user_category', results[i].getId());
    }
}





function stickGetFontSize(fontSizeId)
{
    if (stickHasValue(stickGlobal.stickGetFontSizeReturn))
    {
        // ok to consider parameter in caching since we don't expect noteSizeId
        // to change durind the call
        return stickGlobal.stickGetFontSizeReturn;
    }

    var ffilters = [];
    var fcolumns = [];
    fcolumns.push(new nlobjSearchColumn('custrecord_sfs_font_size'));
    ffilters.push(['internalid', 'anyof', fontSizeId]);
    var fontSizeResults = nlapiSearchRecord('customrecord_stick_font_size', null, ffilters, fcolumns);
    if (fontSizeResults === null)
    {
        throw 'fontSizeResults===null';
    }
    stickGlobal.stickGetFontSizeReturn = fontSizeResults[0].getValue('custrecord_sfs_font_size') + 'pt';
    return stickGlobal.stickGetFontSizeReturn;
}





function stickGetScriptedRecordType(recordTypeScriptId)
{
    var logger = new stickobjLogger(arguments, false);

    var myRec = nlapiCreateRecord('customrecord_stick_record_type_holder', {
        recordmode: 'dynamic'
    });
    myRec.setFieldValue('custrecord_srth_script_id', recordTypeScriptId);
    var myFld = myRec.getField('custrecord_srth_scripted_record_type');
    var options = myFld.getSelectOptions();
    var option = options[0];
    var recordTypeName = option.getText();
    logger.log('script id=' + option.getId() + '  script text=' + option.getText());
    return recordTypeName;
}





function stickGetEmployeeFullName(entityIds)
{
    var entityId = entityIds.split(',');
    var employeeNames = [];
    for (var i = 0; i < entityId.length; i++)
    {
        employeeNames.push(stickGlobal.employeeHash[entityId[i]]);
    }
    return employeeNames.join(',');
}





/**
* Deletes a file and a preview image file (if any) given the file object.
* @param fileId
*/
function stickDeleteFile(file)
{
    // delete primary file
    nlapiDeleteFile(file.fileId);
    
    // delete image preview file if any
    if (stickHasValue(file.previewFileId)) {
        nlapiDeleteFile(file.previewFileId);
    }
}





function _IsFullAccess()
{
    var context = nlapiGetContext();
    
    var pref = context.getPreference("custscript_stick_copref_globalusers");
    if (pref == null || pref == "")
    {
        return false;
    }

    var userId = '"' + context.getUser().toString() + '"';
    
    return pref.indexOf(userId) > -1;
}