/**
 * � 2015 NetSuite Inc. User may not copy, modify, distribute, or re-bundle or
 * otherwise make available this code.
 */
E4S.require([ 'E4S.multisort.SortButton', 'E4S.ux.BoxReorderer', 'E4S.ux.DataView.Animated', 'E4S.ux.Spotlight' ]);
stickGlobal = stickGlobal || {};
stickGlobal.isBoard = true;
stickGlobal.showGrid = true;

E4S.onReady(stickBoardPageInit);





function stickViewRecord(evt, target)
{
    var url = nlapiResolveURL('RECORD', target.getAttribute('data-record_type_script_id'), target.getAttribute('data-record_id'));
    open(url);
    return false;
}





/**
 * Displays the board whats new help tooltip
 */
function stickWhatsNewHelpBoard()
{
    if (nlapiGetContext().getPreference('custscript_stick_suppress_tutorial_users') == 'T')
    {
        return;
    }

    if (nlapiGetContext().getPreference('custscript_stick_suppress_board_help') == 'T')
    {
        return;
    }
    
    var item = 'stickBoardWhatsNew';
    
    try
    {
        stickSpotlightBoard(null, item);
    }
    catch (e)
    {
        stickHandleError(e);
    }
}





/**
 * 
 * Shows the in-app help
 * 
 */
function stickHelpBoard()
{
    var helpkey = 'stickBoardOverview';
    stickSpotlightBoard(null, helpkey);
    return;
}





/**
 * The spotlight effect used in the in-app help
 * @param {Object}
 * e
 * @param {Object}
 * helpKey
 */
function stickSpotlightBoard(e, helpKey)
{
    e = e || window.event;
    if (stickHasNoValue(helpKey))
    {
        stickHideHelp();
        return false;
    }
    
    var title = '';
    var helpText = '';
    var anchor = 'top';
    var nextHelpKey = '';
    
    switch (helpKey)
    {
        case 'stickBoardWhatsNew':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += '\Launch the StickyNotes Tutorial to learn more about the feature.';
            nextHelpKey = 'stickBoardOverview';
            break;
            
        case 'stickBoardOverview':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes Board</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'The StickyNotes Board is a convenient location from where you can view all your notes (both active and archived) across record pages. You can do any of the following from the StickyNotes Board:';
            helpText += "<br>";
            helpText += '<ul>';
            helpText += '<li>Display notes in grid or list view.</li>';
            helpText += '<li>Sort and filter notes by priority, creation date, record type, or owner.</li>';
            helpText += '<li>Find a specific note using keywords within the message, recipient, and owner.</li>';
            helpText += '<li>View archived notes.</li>';
            helpText += '</ul>';
            nextHelpKey = 'stickBoardView';
            anchor = 'bottom';
            break;
            
        case 'stickBoardView':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes View</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Click here to display the notes in a grid or list view.';
            nextHelpKey = 'stickBoardSort';
            break;
            
        case 'stickBoardSort':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Sort Notes</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'You can sort notes based on multiple criteria. To change the sorting precedence, drag a sorting field to the left. The left-most option takes precedence over the others. You can click on the sorting fields to change the sort order (ascending to descending, and vice versa).';
            nextHelpKey = 'stickBoardArchived';
            break;
            
        case 'stickBoardArchived':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;View Archived Notes</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Click here to view archived notes.';
            nextHelpKey = 'stickBoardFilters';
            break;
            
        case 'stickBoardFilters':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Display Filters</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Define display filters to show only notes that match the specified criteria.';
            nextHelpKey = 'stickBoardSearch';
            break;
            
        case 'stickBoardSearch':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Search</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Type the keyword that you want to search for in the displayed notes. StickyNotes will search for the keyword within messages, recipient, and owner.';
            nextHelpKey = 'priorityFilter';
            anchor = 'right';
            break;
            
        case 'priorityFilter':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Priority Filters</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Select the note priority that you want to display on the board.';
            nextHelpKey = 'stickBoardCreationDate';
            anchor = 'right';
            break;
            
        case 'stickBoardCreationDate':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Creation Date Range Filters</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Enter a start and end date to display notes within the given period. If no end date is provided, StickyNotes will display notes starting from the specified start date up until the present date.';
            nextHelpKey = 'recordFilter';
            break;
            
        case 'recordFilter':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Record Type Filters</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'Select a record type to display notes created on specific record pages.';
            nextHelpKey = 'stickBoardEnd';
            break;
            
        case 'stickBoardEnd':
            helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;End of Tutorial</b>';
            helpText += '<br>';
            helpText += '<br>';
            helpText += 'You can now start using the StickyNotes Board.';
            break;
            
        default:
            break;
    }
    
    var el = stickGetHelpElementIdBoard(helpKey);
    helpText += '<br><span style="height: 5px; line-height: 5px">&nbsp;</span>';
    if (stickHasValue(helpText))
    {
        stickHideHelp();
        helpText = '<div id="stickHelptext">' + helpText + '</div>';
        stickSetHelp(el, title, helpText, anchor);
    }
    
    jStick('#stickHelptext').append(jStick('#stickTooltipbuttons').clone());
    if (helpKey !== 'stickBoardWhatsNew')
    {
        Ext.select('#tbl_stickNotifChkboxDontShow').hide();
        Ext.select('#stickbtnNext').set({
            'value': 'Next Topic',
            'onclick': "return stickSpotlightBoard(event, '');"
        });
        Ext.select('#stickbtnCancel').set({
            'onclick': "Ext.Msg.hide(); return stickSpotlightBoard(event, '');"
        });
    }
    else
    {
        Ext.select('#stickNotifChkboxDontShow').set({
            'onclick': "stickSuppressWhatsNewHelpBoard();"
        });
        Ext.select('#stickbtnCancel').set({
            'onclick': "stickCloseHelp();"
        });
        Ext.select('.x-tip-body #tdbody_stickNotifChkboxDontShow span').setStyle({
            'font-size': '13px'
        })
    }
    
    if (stickHasValue(Ext.select('#stickHelptext #stickTooltipbuttons')))
    {
        Ext.select('#stickHelptext #stickTooltipbuttons').show();
        Ext.select('#stickHelptext #stickTooltipbuttons #stickbtnNext').on('click', function()
        {
            return stickSpotlightBoard(e, nextHelpKey);
        });
        if (helpKey == 'stickBoardEnd')
        {
            Ext.select('#stickHelptext #stickTooltipbuttons #tbl_stickbtnNext').remove();
        }
    }
    
    stickGlobal.spot = stickGetSpot();
    
    if (Ext.get(el) !== null)
    {
        if (Ext.get(el).getWidth() !== 0)
        {
            stickGlobal.lastHelpEl = el;
            stickGlobal.spot.show(stickGlobal.lastHelpEl);
        }
    }
    if (helpKey !== 'stickBoardWhatsNew')
    {
        var tdCheckboxDontShow = Ext.get('tbl_stickNotifChkboxDontShow').findParent('td');
        Ext.get(tdCheckboxDontShow).setStyle({
            'display': 'none'
        });
        tdCheckboxDontShow = Ext.select('#stick_titleTooltip #tbl_stickNotifChkboxDontShow').findParent('td');
        Ext.get(tdCheckboxDontShow).setStyle({
            'display': 'none'
        });
    }
    
    return false;
}





/**
 * 
 * Suppresses the display of the welcome help
 * 
 */
function stickSuppressWhatsNewHelpBoard()
{
    // stickHideHelp();
    var suppressHelp = 'T';
    if (jStick('#stickNotifChkboxDontShow:checked').length != 0)
    {
        alert('To display the StickyNotes tutorial again, click the help icon beside the display filters.');
    }
    else
    {
        suppressHelp = 'F';
    }

    // make sure the suitelet is not running as admin
    stickSuiteletProcessAsyncUser('suppressWhatsNewHelp', suppressHelp, function(ok)
    {
        if (ok == 'ok')
        {
            //!?
        }
    });
}





/**
 * 
 * Suppress the display of welcome help if Do not display checkbox is checked.
 * 
 */
function stickCloseHelp()
{
    Ext.Msg.hide();
    stickHideHelp();
}





/**
 * Returns the element/element id given the help key
 * @param {Object}
 * helpKey
 */
function stickGetHelpElementIdBoard(helpKey)
{
    switch (helpKey)
    {
        case 'stickBoardWhatsNew':
            return Ext.select('.uir-page-title-firstline').elements[0]; // 'ssHelpIcon';
            
        case 'stickRecordOverview':
            return 'stickToolbarBox';
            
        case 'stickRecordMenu':
            return 'stickToolbarStickyNotesButton';
            
        case 'stickRecordFilter':
            return 'stickNoteFilterLinkBox';
            
        case 'stickRecordEnd':
            return 'stickToolbarBox';
            
        case 'stickBoardOverview':
            return Ext.select('.uir-page-title-firstline').elements[0]; // 'ssHelpIcon';
            
        case 'stickBoardView':
            return 'stickBoardViewType';
            
        case 'stickBoardSort':
            return 'stickSorter';
            
        case 'stickBoardArchived':
            return 'stick-view-archived';
            
        case 'stickBoardFilters':
            return 'stickLeftPane';
            
        case 'stickBoardSearch':
            return 'stickGlobalSearch';
            
        case 'stickBoardPriority':
            return 'stickPriority';
            
        case 'stickBoardRecords':
            return 'stickRecords';
            
        case 'stickBoardEnd':
            return Ext.select('.uir-page-title-firstline').elements[0];
            
        case 'letUsKnowWhatYouThink':
            return 'stickSendCommentsLink';
            
        default:
            return helpKey;
    }
}





function stickGetDataview()
{
    var panel = E4S.getCmp('stickPanel');
    return panel.down('dataview');
}





function stickSortNotes()
{
    var panel = E4S.getCmp('stickPanel');
    var buttons = panel.query('toolbar sortbutton');
    var sorters = [];
    E4S.Array.each(buttons, function(button)
    {
        sorters.push({
            internalid: button.id,
            property: button.getDataIndex(),
            direction: button.getDirection()
        });
    });
    var dv = panel.down('dataview');
    dv.store.sort();
    dv.store.sort(sorters);
    // setTimeout(function() {
    // stickSetBoardHeight();
    // }, 1000);
    // if (stickGlobal.showGrid === false) {
    // HACK:
    // In list view, change sort then change sort again.
    // actual: the height of some rows are not correct
    stickRefreshListView();
    // E4S.get('stickNoteView').fadeIn();
    // E4S.get('stickNoteView').hide();
    // E4S.get('stickNoteView').fadeOut(0);
    // stickGlobal.store.loadData([], true);
    // var dv = E4S.getCmp('stickNoteView');
    // dv.refresh();
    // stickProcessRenderedNotes();
    // E4S.get('stickNoteView').fadeIn(200);
    // }
    // update user sort pref
    var sortFields = sorters;
    stickSuiteletProcessAsync('updateUserBoardSorterFields', sortFields, function(isOK)
    {
        if (isOK !== 'ok')
        {
            // probably user is moving away from page
            // stickShowError('updateUserBoardSorters');
        }
    });
}





function stickGetViewType()
{
    var dv = E4S.getCmp('stickNoteView');
    if (dv.tpl.showGrid)
    {
        return 'grid';
    }
    
    return 'list';
}





function stickShowGrid(showGrid)
{
    var dv = E4S.getCmp('stickNoteView');
    stickGlobal.showGrid = showGrid;
    dv.tpl.showGrid = showGrid;
    
    if (showGrid === false)
    {
        // when blockRefresh = true, animation will wokr
        // we will disable animation on list view because items with different
        // height is not supported by the animation plugin
        // disable animation immediately
        dv.blockRefresh = false;
    }
    
    stickRefreshView();
    if (showGrid)
    {
        Ext.get('stick-view-grid').setStyle({
            border: '1px solid navy'
        });
        Ext.get('stick-view-list').setStyle({
            border: '1px solid transparent'
        });
        stickProcessRenderedNotes();
        setTimeout(stickSortNotes, 100);
        // setTimeout(function() {
        // stickSetBoardHeight();
        // }, 1000);
        // stickGlobal.store.sort();
        // Ext.select('.stickNote').fadeIn(750);
        Ext.select('.stickNote,.stickBox').show();
    }
    else
    {
        Ext.get('stick-view-grid').setStyle({
            border: '1px solid transparent'
        });
        Ext.get('stick-view-list').setStyle({
            border: '1px solid navy'
        });
        stickProcessNotesInListView();
    }
    
    stickProcessRenderedNotes();
    // when blockRefresh = true, animation will wokr
    // we will disable animation on list view because items with different
    // height is not supported by the animation plugin
    if (showGrid)
    {
        // allow animation for sorting and filtering
        dv.blockRefresh = true;
    }
}





function stickSetLinkDisabled(el, msg)
{
    if (stickHasNoValue(el))
    {
        // probably the note is filtered out
        return;
    }

    el.style.color = 'silver';
    el.title = msg;
    if (Ext.isIE)
    {
        jStick(el).click(function()
        {
            stickShowInfo(msg);
            return false;
        });
    }
    else
    {
        el.setAttribute('onclick', 'stickShowInfo("' + msg + '"); return false;');
    }
}





function stickProcessNotesInListView()
{
    // notes has been rendered
    var notes = stickGlobal.store.data.items;
    var currentUserId = nlapiGetContext().getUser();
    for (var i = 0; i < notes.length; i++)
    {
        // disable some links
        var note = notes[i].data;
        if (note.owner != currentUserId)
        {
            var el = Ext.select('#stickBoxList' + note.internalid + ' .stick-delete-link').elements[0];
            stickSetLinkDisabled(el, 'You are not allowed to delete this note because you are not the owner.');
            // archive link
            var el = Ext.select('#stickBoxList' + note.internalid + ' .stick-archive-link').elements[0];
            stickSetLinkDisabled(el, 'You are not allowed to archive this note because you are not the owner.');
        }

        if (note.custrecord_sn_status == 'completed')  //done?
        {
            Ext.select('#stickBoxList' + note.internalid + ' .stick-message').setStyle('text-decoration', 'line-through');
            var el = Ext.select('#stickBoxList' + note.internalid + ' .stick-mark-as-done-link').elements[0];
            stickSetLinkDisabled(el, 'This note has been marked as done.');
        }
        
        if (stickIsActiveView() === false)
        {
            var el = Ext.select('#stickBoxList' + note.internalid + ' .stick-archive-link').elements[0];
            stickSetLinkDisabled(el, 'This note has been archived.');
        }
    }
}





function stickRefreshView()
{
    var dv = E4S.getCmp('stickNoteView');
    E4S.get('stickNoteView').hide();
    dv.refresh();
    E4S.get('stickNoteView').fadeIn(750);
}





function stickShowBoard4(store, sortButtonItems) {
    E4S.QuickTips.init();
    E4S.define('E4S.multisort.Panel', {
        extend: 'E4S.panel.Panel',
        requires: ['E4S.toolbar.TextItem', 'E4S.view.View'],
        title: '',
        width: 'auto',
        height: '10000',
        layout: 'fit',
        initComponent: function()
        {
            this.tbar = E4S.create('E4S.toolbar.Toolbar', {
                id: 'tbar',
                plugins: E4S.create('E4S.ux.BoxReorderer', {
                    listeners: {
                        scope: this,
                        drop: function()
                        {
                            var sorterFields = this.getSorters();
                            this.down('dataview').store.sort(sorterFields);
                            // HACK: bug in ie.
                            // In list view, change sort then change sort again.
                            // actual: the height of some rows are not correct
                            if (stickIsListView())
                            {
                                // var dv = E4S.getCmp('stickNoteView');
                                // dv.refresh();
                                // stickProcessRenderedNotes();
                            }
                            stickProcessRenderedNotes();
                            stickSuiteletProcessAsync('updateUserBoardSorterFields', sorterFields, function(isOK)
                            {
                                if (isOK !== 'ok')
                                {
                                    // probably useris moving away from page 
                                    // stickShowError('updateUserBoardSorters');
                                    // store.clearFilter();
                                    // doSort();
                                }
                            });
                        }
                    }
                }),
                defaults: {
                    listeners: {
                        scope: this,
                        changeDirection: this.updateStoreSorters
                    }
                },
                items: []
            });

            this.tbar.add({
                id: 'stickBoardViewType',
                xtype: 'tbtext',
                text: 'VIEW AS:',
                reorderable: false
            });

            // They can also be referenced by id in or components
            this.tbar.add({
                id: 'stick-view-grid',
                icon: stickGlobal.dataSet['stick-grid.png'], // icons can also be specified inline
                cls: 'x-btn-icon',
                reorderable: false,
                tooltip: '<b>Grid View</b><br/>Click this icon to display notes in grid view.',
                handler: function()
                {
                    stickShowGrid(true);
                }
            });

            this.tbar.add({
                id: 'stick-view-list',
                icon: stickGlobal.dataSet['stick-list.png'], // icons can also be specified inline
                cls: 'x-btn-icon',
                reorderable: false,
                tooltip: '<b>List View</b><br/>Click this icon to display notes in list view.',
                handler: function()
                {
                    stickShowGrid(false);
                }
            });

            this.tbar.add('-');
            this.tbar.add({
                id: 'stick-generate-csv',
                text: 'Save As CSV',
                tooltip: 'Click here to generate a CSV file of all the notes that match the filter criteria.',
                handler: _SaveAsCSV,
                reorderable: false
            });

            this.tbar.add(sortButtonItems);

            this.tbar.add({
                id: 'stickAfterSortButtons',
                xtype: 'tbtext',
                text: '&nbsp;',
                reorderable: false
            });

            //this.tbar.add("->");
            this.tbar.add({
                id: 'stick-view-archived',
                text: 'View Archived Notes',
                tooltip: 'Click here to view archived notes.',
                handler: stickGetActiveOrArchivedNotes,
                reorderable: false
            });

            this.items = {
                xtype: 'dataview',
                tpl: E4S.create('E4S.XTemplate', stickGetTemplate('tmpStickNoteBoard'), {
                    showGrid: true
                }),
                plugins: [E4S.create('E4S.ux.DataView.Animated')],
                itemSelector: 'div.stickNoteLi',
                store: store,
                id: 'stickNoteView',
                showGrid: true,
                style: {
                    'margin-bottom': 50
                }
            };

            this.callParent(arguments);
            this.updateStoreSorters();
        },
        /**
        * Returns the array of Ext.util.Sorters defined by the current toolbar button order
        * @return {Array} The sorters
        */
        getSorters: function()
        {
            var buttons = this.query('toolbar sortbutton'), sorters = [];
            E4S.Array.each(buttons, function(button)
            {
                sorters.push({
                    internalid: button.id,
                    property: button.getDataIndex(),
                    direction: button.getDirection()
                });
            });
            return sorters;
        },
        /**
        * 
        * @private Updates the DataView's Store's sorters based on the current
        * 
        * Toolbar button configuration
        * 
        */
        updateStoreSorters: function(direction, b, c)
        {
            // FIXME: shouldn't have to make the first call
            this.down('dataview').store.sort();
            var sortFields = this.getSorters();

            this.down('dataview').store.sort(sortFields);
            // HACK: unable to get the latest sort order if not called with delay
            setTimeout(stickSortNotes, 100);
        }
    });

    var board = new E4S.multisort.Panel();
    
    new E4S.Panel({
        id : 'stickPanel',
        title : '',
        layout : 'fit',
        items : [ board ],
        height : 'auto',
        width : E4S.get('ns_navigation').getWidth() - E4S.get('stickLeftPane').getWidth() - 15,
        renderTo : 'stickNoteBoxBoard'
    });
    
    Ext.Msg.hide();
    E4S.get('stickNoteView').dom.style.backgroundColor = 'transparent';
    E4S.get('stickBoardViewType').setStyle({ 'font-size': '11px', 'margin': '2px' });
    E4S.get('stickSorter').setStyle({ 'font-size': '11px', 'top': '0px' });
    E4S.select('.x4labs-btn-inner').setStyle({ 'font': 'open-sans', 'font-size': '11px', 'text-transform': 'uppercase' });
    
    E4S.select('.stickNote').show();
    E4S.select('.stickBox').show();
}





function stickPositionSelectedNote(el, callback)
{
    var x = E4S.get(el);
    x.setStyle('position', 'absolute');
    var xPos = (E4S.getBody().getWidth() - E4S.get(el).getWidth()) / 2;
    xPos = xPos - E4S.get(el).getLeft();
    // var yPos = (E4S.getBody().getHeight() -
    // E4S.get(el).getHeight()) / 2;
    // yPos = yPos - E4S.get(el).getTop();
    var props = {
        left: { to: xPos },
        top: { to: 20 }
    };

    x.animate(props, 0.250, function() { if (callback) { callback(); } }, 'easeOut', 'run');
}





function stickRenderNotes(notes, sortFields)
{
    var logger = new stickobjLogger();
    
    stickRenderFilters(notes);
    var fields = [];
    
    for (var p in notes[0])
    {
        fields.push(p);
    }
    
    var store = new E4S.data.JsonStore({
        proxy: new E4S.data.MemoryProxy(),
        fields: fields,
        sortInfo: {
            field: 'internalid',
            direction: 'ASC'
        }
    });

    for (var i = 0; i < notes.length; i++)
    {
        notes[i][0] = parseInt(notes[i][0], 10);
    }

    stickGlobal.notes = notes;
    store.loadData(notes);
    stickGlobal.store = store;
    var sortButtonItems = stickCreateSortButtonItems(sortFields);
    stickShowBoard4(store, sortButtonItems);
    var xMainBox = Ext.get('stickyNotesBoardFrame');
    
    if (notes.length > 0)
    {
        // var dContainer = Ext.select('.pt_container').elements[0];
        // xMainBox.setWidth(Ext.get(dContainer).getWidth());
        // jStick('#stickyNotesBoardFrame').width(jStick('#div__header').width());
        xMainBox.fadeIn();
        stickWhatsNewHelpBoard();
    }
    else
    {
        Ext.Msg.alert('StickyNotes Board', 'There are no active StickyNotes');
        Ext.get('stickyNotesBoardFrame').show();
    }
    
    logger.end();
}





function stickCreateSortButtonItems(sortFields)
{
    var sortButtonItems = [
        {
            id: 'stickSorter',
            xtype: 'tbtext',
            text: '<span style="color: silver;">|</span> SORT BY:',
            reorderable: false
        }
    ];

    var sortDefinitionsString = sortFields[0].sortFilter;
    var sortDefinitions = sortDefinitionsString.split(',');

    for (var i = 0; i < sortDefinitions.length; i++)
    {
        var fieldAndDirectionArray = sortDefinitions[i].split(' ');
        var fieldName = '';
        var fieldNameSmall = '';
        var direction = fieldAndDirectionArray[1];
        var fieldScriptId = fieldAndDirectionArray[0];

        switch (fieldScriptId)
        {
            case 'categoryPriority':
                fieldName = 'Priority';
                fieldNameSmall = 'priority';
                break;

            case 'internalid':
                fieldName = 'Date Created';
                fieldNameSmall = 'creation date';
                break;

            case 'ownerName':
                fieldName = 'Owner';
                fieldNameSmall = 'owner';
                break;

            case 'recordTypeName':
                fieldName = 'Record Type';
                fieldNameSmall = 'record type';
                break;
        }

        sortButtonItems.push({
            id: fieldScriptId,
            xtype: 'sortbutton',
            text: '&nbsp;&nbsp;&nbsp;&nbsp;' + fieldName,
            iconAlign: 'right',
            direction: direction,
            dataIndex: fieldScriptId,
            tooltip: '<b>' + fieldName + ' field</b><br />Drag this field to change the sequence of sorting relative to other fields. The left-most field takes precedence over the others. Click to arrange the note ' + fieldNameSmall + ' in ascending or descending order.'
        });
    }

    return sortButtonItems;
}





function stickCreateSortedRecordFilters(filters)
{
    var sortedFilters = [];
    
    for (var key in filters)
    {
        // do not include added functions to array object
        if (typeof filters[key] == 'function')
        {
            continue;
        }

        var objFilter = {
            internalid:key.replace(/ /g, ''),
            filterName: key,
            filterCount: filters[key].Count,
            nsRecordType: filters[key].TypeId
        };
        
        sortedFilters.push(objFilter);
        sortedFilters.sort(function(a, b) { return a.filterName > b.filterName; });
    }
    
    return sortedFilters;
}





function stickCreateSortedPriorityFilters(categoryFilters)
{
    var sortedFilters = [];
    var arrKey = [];
    for (var key in categoryFilters)
    {
        // do not include added functions to array object
        if (typeof categoryFilters[key] == 'function')
        {
            continue;
        }
        
        var objFilter = {};
        arrKey = key.split(',');
        objFilter.internalid = arrKey[0];
        objFilter.filterPriority = arrKey[0];
        objFilter.filterName = arrKey[1];
        objFilter.filterCategoryColor = arrKey[2];
        objFilter.filterCount = categoryFilters[key];
        sortedFilters.push(objFilter);
    }
    sortedFilters.sort(function(a, b)
    {
        return a.filterPriority > b.filterPriority;
    });

    return sortedFilters;
}





function stickFilterNotesInBoard()
{
    var checkedRecordTypeNames = [];
    var selectedRecTypes = [];
    var checkedPriorityNames = [];
    jStick('#recordFilter input:checkbox:checked').each(function()
    {
        checkedRecordTypeNames.push(this.getAttribute('data-name'));
        selectedRecTypes.push(this.getAttribute("nsRecordType"));
    });
    
    jStick('#priorityFilter input:checkbox:checked').each(function()
    {
        checkedPriorityNames.push(this.getAttribute('data-name'));
    });

    var isViewMine = jStick("#filterisViewMine:checked").val() !== undefined;

    var gSearch = jStick('#stickGlobalSearch').val().toLowerCase();
    
    var dateFrom = jStick('#dateFrom').val();
    var dateTo = jStick('#dateTo').val();

    var nDateFrom = null;
    if (dateFrom !== '')
    {
        dateFrom = dateFrom + ' 00:00 am';
        nDateFrom = new Date(dateFrom);
    }

    var nDateTo = null;
    if (dateTo !== '')
    {
        dateTo = dateTo + ' 11:59 pm';
        nDateTo = new Date(dateTo);
    }
    
    if (Ext.isIE)
    {
        var CALENDAR_POPUP_WIDTH = 188;
        Ext.select('.x-date-menu, .x-ie-shadow').setWidth(CALENDAR_POPUP_WIDTH);
    }

    stickGlobal.store.filterBy(_NoteFilter);
    
    Ext.select('.stickBox').show();
    stickGlobal.store.sort();
    stickProcessRenderedNotes();
    
    // sort animation takes about 750 ms
    setTimeout(function() { stickSetBoardHeight(); }, 1000);



    function _NoteFilter(note)
    {
        if (isViewMine && note.get("owner") != nlapiGetContext().getUser())
        {
            return false;
        }
        
        //Check record type
        if (checkedRecordTypeNames.indexOf(note.get('recordTypeName')) == -1 &&
            !_IsExtType(selectedRecTypes, note.get("extTypes")))
        {
            return false;
        }
                               ;
        //Check priority
        if (checkedPriorityNames.indexOf(note.get('categoryName')) == -1)
        {
            return false;
        }

        //Keyword searching
        if (gSearch != null && gSearch != "")
        {
            var se = new _SearchEngine();
            if (se.Evaluate(note.get('globalSearch'), gSearch) === false)
            {
                return false;
            }
        }

        var nDateCreated = new Date(note.get('created'));
        if (dateTo !== '' && dateFrom !== '')
        {
            return (nDateCreated >= nDateFrom && nDateCreated <= nDateTo);
        }

        if (dateFrom !== '')
        {
            return nDateCreated >= nDateFrom;
        }

        if (dateTo !== '')
        {
            return nDateCreated <= nDateTo;
        }

        return true;
    }



    function _IsExtType(selTypes, extTypes)
    {
        if (extTypes.length == 0)
        {
            return false;
        }
        
        for (var i = 0; i < selTypes.length; ++i)
        {
            if (extTypes.indexOf(selTypes[i]) > -1)
            {
                return true;
            }
        }

        return false;
    }
}





function stickRefreshListView()
{
    if (stickIsListView())
    {
        // var dv = E4S.getCmp('stickNoteView');
        // dv.refresh();
        stickProcessRenderedNotes();
    }
}





function stickRemoveRotation(elementId)
{
    // remove rotation
    jStick('#' + elementId).css({
        'transform': 'rotate(0deg)'
    }).css({
        '-ms-transform': 'rotate(0deg)'
    }).css({
        '-moz-transform': 'rotate(0deg)'
    }).css({
        '-o-transform': 'rotate(0deg)'
    }).css({
        '-webkit-transform': 'rotate(0deg)'
    });
}





function stickGetActiveOrArchivedNotes()
{
    stickWait();
    var xArchive = E4S.get('stick-view-archived-btnInnerEl');
    var currentLabel = xArchive.dom.innerHTML;
    var noteState = (currentLabel == 'View Archived Notes' ? 'archived' : 'active');
    stickGlobal.getDataSetParam.noteState = noteState;
    stickGlobal.getDataSetParam.isBoard = stickGlobal.isBoard;
    
    stickSuiteletProcessAsync('getDataSet', stickGlobal.getDataSetParam, function(dataSet)
    {
        stickGlobal.dataSet = dataSet;
        var notes = dataSet.notes;
        if (notes.length === 0)
        {
            Ext.Msg.hide();
            stickShowInfo('There are no ' + noteState + ' notes.');
            return;
        }
        
        for (var i = 0; i < notes.length; i++)
        {
            notes[i][0] = parseInt(notes[i][0], 10);
        }
        
        stickGlobal.notes = notes;
        stickSetMouseEventsBeforeNotesRender();
        stickProcessRenderedNotes();
        stickSetMouseOverAndOutEvents();
        stickRenderFilters(notes);
        stickGlobal.store.loadData(notes);
        stickGlobal.store.sort();
        E4S.getCmp('stickNoteView').refresh();
        Ext.select('.stickBox').show();
        var xArchive = E4S.get('stick-view-archived-btnInnerEl');
        var currentLabel = xArchive.dom.innerHTML;
        var newLabel = '';
        
        if (currentLabel == 'View Archived Notes')
        {
            newLabel = 'View Active Notes';
            E4S.select('.uir-page-title-firstline h2').update('StickyNotes Archive');
        }
        else
        {
            newLabel = 'View Archived Notes';
            E4S.select('.uir-page-title-firstline h2').update('StickyNotes Board');
        }
        
        xArchive.dom.innerHTML = newLabel;
        stickProcessRenderedNotes();
        stickSetFilterEvents();
        
        if (stickGlobal.showGrid)
        {
            stickSortNotes();
        }
        
        Ext.Msg.hide();
    });
}





function stickRenderFilters(notes)
{
    //Show/hide View My Notes checkbox based on isFullAccess setting
    var fnAction = stickGlobal.dataSet.isFullAccess === true ? "show" : "hide";
    jStick("#spanIsViewMine")[fnAction]();


    if (notes.length > 0)
    {
        var recordFilters = [];
        var priorityFilters = [];
        var sortedRecordFilters = [];
        var sortedPriorityFilters = [];
        
        for (var i = 0; i < notes.length; i++)
        {
            var note = notes[i];
            note.internalid = parseInt(note.internalid, 10);
            
            var gSearch = note.recipientsName + ' ' + note.message + ' ' + note.ownerName;
            note.globalSearch = gSearch.toLowerCase();
            
            if (recordFilters[note.recordTypeName] === undefined)
            {
                recordFilters[note.recordTypeName] = { Count: 0, TypeId: note.custrecord_sn_record_type_script_id };
            }
            recordFilters[note.recordTypeName].Count += 1;

            var pKey = note.categoryPriority + ',' + note.categoryName + ',' + note.categoryColor;
            if (priorityFilters[pKey] === undefined)
            {
                priorityFilters[pKey] = 0;
            }
            priorityFilters[pKey] += 1;
        }
        
        sortedRecordFilters = stickCreateSortedRecordFilters(recordFilters);
        sortedPriorityFilters = stickCreateSortedPriorityFilters(priorityFilters);
        stickTemplateOverwrite('tmpRecordFilter', 'recordFilter', sortedRecordFilters);
        stickTemplateOverwrite('tmpPriorityFilter', 'priorityFilter', sortedPriorityFilters);
    }
    Ext.select('#stickyNotesBoardFrame td, #stickyNotesBoardFrame input').addClass('smalltext');
}





function stickShowNoteThreadPopup(noteId)
{
    stickGlobal.currentNoteId = noteId;
    stickWait();
    var xArchive = E4S.get('stick-view-archived-btnInnerEl');
    var currentLabel = xArchive.dom.innerHTML;
    var noteState = (currentLabel == 'View Archived Notes' ? 'archived' : 'active');
    stickGlobal.getDataSetParam.noteState = noteState;
    stickGlobal.getDataSetParam.noteId = noteId;
    stickGlobal.getDataSetParam.isBoard = stickGlobal.isBoard;
    stickSuiteletProcessAsync('getDataSet', stickGlobal.getDataSetParam, function(dataSet)
    {
        // reset selected note
        stickGlobal.getDataSetParam.noteId = null;
        // stickGlobal.dataSet = dataSet;
        // we expect only 1 note
        notes = dataSet.notes;
        var xNoteBox = Ext.get('stickNoteBox');
        xNoteBox.update('');
        stickTemplateAppend('tmpStickNote', 'stickNoteBox', notes);
        stickProcessRenderedNotes(notes);
        stickRemoveRotation(Ext.select('#stickNoteBox .stickNote').elements[0].id);
        // expand replies
        var noteId = notes[0].internalid;
        jStick('#stickReplyBox' + noteId + ' .stickReply').css({
            'margin-top': -10
        }, 1000);
        jStick('#stickReplyBox' + noteId).css({
            'margin-top': -10
        }, 1000);
        Ext.select('#stickNoteSelected').show();
        // set min height of parent note
        var noteHeight = stickGetNoteSize().height;
        noteHeight = parseInt(noteHeight.replace('px', ''), 10);
        Ext.select('#stickTblNoteSelected #stick' + noteId).setStyle({
            'height': noteHeight
        });
        var msgHeight = stickGetMessageHeight() + 20;
        Ext.select('#stickTblNoteSelected #stickMessage' + noteId).setStyle({
            'min-height': msgHeight + 'px'
        });

        // show/hide image preview
        stickToggleImagePreview(noteId, true /*isNote*/, !stickGlobal.isBoard /*isCollapsed*/, 1);
        
        if (stickGlobal.showGrid)
        {
            var stickMessageEl = Ext.select('#stick' + noteId).elements[0];
        }
        else
        {
            var stickMessageEl = Ext.select('#stickBoxList' + noteId).elements[0];
        }
        
        // set note height to auto if not expanded
        var isDataLong = stickMessageEl.getAttribute('data-autosizeheight');
        if (isDataLong == 'no')
        {
            console.log('data is not long');
            Ext.select('#stickTblNoteSelected #stick' + noteId).setStyle({
                'height': 'auto'
            });
            Ext.select('#stickTblNoteSelected #stick' + noteId + ' .stick-note-inner').setStyle({
                'height': 'auto'
            });
            Ext.select('#stickTblNoteSelected #stickMessage' + noteId).setStyle({
                'height': 'auto'
            });
        }
        var els = Ext.select('#stickReplyBox' + noteId + ' .stickReply').elements;
        for (var i = 0; i < els.length; i++)
        {
            var replyId = els[i].getAttribute('data-internalid');
            var replyTip = Ext.select('#stickReply' + replyId + ' .stick-note-inner .stick-message-reply').first().dom.getAttribute('data-qtip');
            if (stickHasValue(replyTip))
            {
                Ext.select('#stickReply' + replyId).setStyle({
                    'height': 'auto'
                });
                Ext.select('#stickReply' + replyId + ' .stick-note-inner').setStyle({
                    'height': 'auto'
                });
                Ext.select('#stickReply' + replyId + ' .stick-note-inner .stick-message-reply').setStyle({
                    'height': 'auto'
                });
            }
        }
        // TODO: Refactor and place in proper code
        stickSetMouseOverAndOutEvents();
        stickSetMouseEventsForReplies();
        var selector = '#stickNoteSelected .stickBox, #stickNoteSelected .stickNote';
        if (Ext.isIE)
        {
            Ext.select(selector).setStyle({
                position: 'relative',
                display: 'inline-block',
                visibility: 'visible'
            });
        }
        else
        {
            Ext.select(selector).setStyle({
                position: 'relative',
                display: 'inherit',
                visibility: 'inherit'
            });
        }
        
        var xNoteThread = Ext.get('stickNoteSelected');
        xNoteThread.setHeight('auto');
        // var width = 'auto';
        // if (E4S.isIE) {
        var width = parseInt(stickGlobal.dataSet.noteSize.width, 10) + 20;
        // }
        xNoteThread.setWidth(width);
        xNoteThread.center();
        // get the top of the progress bar and use as the top position
        var dProgressInner = Ext.select('.x-progress-inner').elements[0];
        var newTop = Ext.get(dProgressInner).getTop();
        newTop = newTop - 200 /* adjust higher */;
        if (newTop < 100)
        {
            newTop = 100;
        }
        
        var newLeft = Ext.get(dProgressInner).getLeft();
        newLeft = newLeft - 20;
        xNoteThread.setTop(newTop);
        xNoteThread.setLeft(newLeft);
        // stickHideExtWaitBox();
        Ext.select('.x-window').hide();
        Ext.select('.x-shadow').hide();
    });
}





function stickHideNoteThreadPopup()
{
    stickHideNoteActionsMenuNoDelay();
    Ext.get('stickNoteSelected').hide().setLeft(-1000);
    Ext.select('#stickNoteSelected .stickBox').hide();
    Ext.get('stickNoteBox').dom.innerHTML = '';
    Ext.Msg.hide();
}





function stickBoardWindowResize()
{
    var xMainBox = Ext.get('stickyNotesBoardFrame');
    var dBgbar = Ext.get('ns_navigation');
    xMainBox.setWidth(Ext.get(dBgbar).getWidth() - 65);
    var PANEL_WIDTH = E4S.get('ns_navigation').getWidth() - E4S.get('stickLeftPane').getWidth() - 45;
    Ext.get('stickPanel').setWidth(PANEL_WIDTH);
    Ext.get('stickPanel-body').setWidth(PANEL_WIDTH);
    Ext.get('stickNoteView').setWidth(PANEL_WIDTH);
    Ext.select('.x4labs-toolbar').setWidth(PANEL_WIDTH);
    Ext.select('.x4labs-box-inner').setWidth(PANEL_WIDTH)
    Ext.select('.x4labs-panel').setWidth(PANEL_WIDTH);
    Ext.select('.x4labs-panel-body').setWidth(PANEL_WIDTH);
    stickGlobal.store.sort();

    if (Ext.isChrome)
    {
        Ext.get('stickPanel').setStyle({ 'border': '2px solid lightgray' });
    }

    //Align right toolbar item "View Archive Notes"
    var xArchiveLink = Ext.get('stick-view-archived');
    xArchiveLink.setStyle({ 'left': Ext.get('stickyNotesBoardFrame').getWidth() - Ext.get('stickLeftPane').getWidth() - xArchiveLink.getWidth() - 15 + 'px' });
}





function stickSetBoardHeight()
{
    // HACK: not sure why the dataview height adjust automatically.
    // probably because of the animted.js
    
    // for some reasons, there are many spaces at the bottom of the board 
    // get the last note to get the height of the board
    var selector = stickGlobal.showGrid ? '.stickNote' : '.stick-parent';
    var els = Ext.select(selector).elements;
    if (els.length === 0)
    {
        var logger = new stickobjLogger(arguments);
        logger.log('exiting els.length === 0');
        return;
    }

    var last = els[els.length - 1];
    //get the top of the note at the bottom
    var maxTop = 0;
    var height = 0;
    
    for (var i = 0; i < els.length; i++)
    {
        var el = els[i];
        var x = Ext.get(el);
        height += x.getHeight();
        
        if (x.getTop() > maxTop)
        {
            maxTop = x.getTop();
        }
    }
    
    height += 100; // allowance
    if (stickGlobal.showGrid)
    {
        height = maxTop + Ext.get(last).getHeight() + Ext.get('stickNoteView').getTop();
    }
    
    height = height + 'px';
    Ext.get('stickPanel-body').setStyle({ height: height });
    
    var xStickNoteView = Ext.get('stickNoteView');
    xStickNoteView.setStyle({ height: height });

    Ext.get(xStickNoteView.dom.parentNode).setStyle({ height: height });
    
    var xTbar = Ext.get('tbar');
    Ext.get(xTbar.dom.parentNode).setStyle({ height: height });
}





function stickSetFilterDefaults()
{
    new Ext.form.DateField({
        id: 'dateFrom',
        format: 'm/d/Y',
        selectOnFocus: true,
        applyTo: 'dateFrom',
        listeners: {
            select: function(t, n, o)
            {
                Ext.get('dateFrom').setStyle({
                    'font-family': 'Open Sans,Helvetica,sans-serif',
                    'font-size': '14px',
                    'color': 'black',
                    'height': '25px'
                });
                stickFilterNotesInBoard();
            }
        }
    });

    new Ext.form.DateField({
        id: 'dateTo',
        format: 'm/d/Y',
        selectOnFocus: true,
        applyTo: 'dateTo',
        listeners: {
            select: function(t, n, o)
            {
                Ext.get('dateTo').setStyle({
                    'font-family': 'Open Sans,Helvetica,sans-serif',
                    'font-size': '14px',
                    'color': 'black',
                    'height': '25px'
                });
                stickFilterNotesInBoard();
            }
        }
    });

    Ext.select('.x-form-date-trigger').setStyle({ 'background-image': 'url(/images/chiles/sprite_field_widgets_15.png)' });
    Ext.select('.x-form-date-trigger').setStyle({ 'background-position': '-100px -250px' });
    Ext.get('dateFrom').setWidth(110);
    Ext.get(Ext.get('dateFrom').findParent('div')).setWidth(110);
    Ext.get('dateTo').setWidth(110);
    Ext.get(Ext.get('dateTo').findParent('div')).setWidth(110);
}





function stickSetFilterEvents()
{
    jStick(':checkbox').change(function()
    {
        stickFilterNotesInBoard();
    });

    jStick('#stickGlobalSearch').bind('keyup', function(e) { stickFilterNotesInBoard(); });
    
    // HACK: see http://stackoverflow.com/questions/14498396/event-fired-when-clearing-text-input-on-ie10-with-clear-icon
    jStick('#stickGlobalSearch').bind('mouseup', function(e)
    {
        setTimeout(stickFilterNotesInBoard, 100);
    });
    
    // date from
    jStick('#dateFrom').bind('keypress', function(e)
    {
        if (e.keyCode == 13)
        {
            stickFilterNotesInBoard();
        }
    });
    
    jStick('#dateFrom').bind('blur', function(e)
    {
        stickFilterNotesInBoard();
    });
    
    // date to
    jStick('#dateTo').bind('keypress', function(e)
    {
        if (e.keyCode == 13)
        {
            stickFilterNotesInBoard();
        }
    });
    
    jStick('#dateTo').bind('blur', function(e)
    {
        stickFilterNotesInBoard();
    });
}





function stickBoardPageInit()
{
    var logger = new stickobjLogger(arguments);
    
    // remove body's horizontal scrollbar
    Ext.getBody().setStyle({ 'overflow-x': 'hidden' });
    stickWait();
    stickCenter('stickNoteSelected');
    Ext.get('stickNoteSelected').setTop(130);
    
    // set main box width
    var headerWidth = jStick('#div__header').width();
    jStick('#stickyNotesBoardFrame').width(headerWidth);
    
    // Create the spotlight component
    stickGlobal.spot = E4S.create('E4S.ux.Spotlight', { animate: false });
    stickSetFilterDefaults();
    stickSetOtherEvents();

    // pre-load standard records list
    stickPreLoadStandardRecordsList();
    
    stickSuiteletProcessAsyncUser('getUserPreference', 'value', function(paramUserPref)
    {
        var param = {
            'recordTypeScriptId': null,
            'recordId': null,
            'noteSizeId': paramUserPref.noteSizeId,
            'fontSizeId': paramUserPref.fontSizeId,
            'noteState': 'active',
            'isBoard': stickGlobal.isBoard
        };

        stickGlobal.paramUserPref = paramUserPref;
        stickGlobal.getDataSetParam = param;  // this won't change in board so cache it
        stickSuiteletProcessAsync('getDataSet', param, function(dataSet)
        {
            stickGlobal.dataSet = dataSet;
            Ext.get('stickLineHeight').setStyle({ 'font-size': stickGlobal.dataSet.fontSize });

            if (dataSet.notes.length === 0)
            {
                // try archived
                stickGlobal.getDataSetParam.noteState = 'archived';
                stickSuiteletProcessAsync('getDataSet', param, function(dataSet)
                {
                    if (dataSet.notes.length === 0)
                    {
                        Ext.Msg.alert('StickyNotes Board', 'There are no StickyNotes');
                        return;
                    }

                    stickGlobal.dataSet = dataSet;
                    stickProcessPreRendered();
                    stickSetMouseEventsBeforeNotesRender();
                    stickRenderNotes(dataSet.notes, dataSet.sortFields);
                    stickProcessRenderedNotes();
                    stickSetMouseOverAndOutEvents();
                    stickSetFilterEvents();
                    stickBoardWindowResize();
                    jStick(window).resize(stickBoardWindowResize);
                    jStick('#stick-view-archived-btnInnerEl').html('View Active Notes');
                    Ext.Msg.alert('StickyNotes Board', 'No active notes found. Archived notes will be displayed instead.');
                    jStick(".stickNote").click(function(event) { event.stopPropagation(); });

                    Ext.get('stick-view-grid').setStyle({ border: '1px solid navy' });
                    // stickShowGrid(false);
                });

                // this will be used by the ui test library
                labsGlobal.pageHasLoaded = true;

                return;
            }

            stickProcessPreRendered();
            stickSetMouseEventsBeforeNotesRender();
            stickRenderNotes(dataSet.notes, dataSet.sortFields);
            stickProcessRenderedNotes();
            stickSetMouseOverAndOutEvents();
            stickSetFilterEvents();
            stickBoardWindowResize();
            jStick(window).resize(stickBoardWindowResize);
            jStick(".stickNote").click(function(event) { event.stopPropagation(); });
            Ext.get('stick-view-grid').setStyle({ border: '1px solid navy' });
            Ext.get('stickGlobalSearch').setStyle({ 'font-family': 'Open Sans,Helvetica,sans-serif', 'font-size': '14px', 'color': 'black', 'height': '25px' });
            Ext.select('#stickyNotesBoardFrame td, #stickyNotesBoardFrame').setStyle({ 'border': '0px' });

            // sets the image of help icon beside filters label
            if (stickHasValue(Ext.select('.stickImgTooltipHelp')))
            {
                Ext.select('.stickImgTooltipHelp').set({
                    'src': stickGlobal.dataSet['stick-help.png'],
                    'style': {
                        'vertical-align': 'middle'
                    }
                });
            }

            // this will be used by the ui test library
            labsGlobal.pageHasLoaded = true;
        });
    });
}





function _SaveAsCSV()
{
    var csvContent = _GenerateCSV();
    var file = new Blob([csvContent], { type: "text/csv" });
    
    // suitelet url
    var url = nlapiResolveURL("SUITELET", "customscript_stick_csvexport_sl", "customdeploy_stick_csvexport_sl");

    // initialize data and xmlrequest
    var vFD = new FormData();
    vFD.append('blob', file);
    xmlReq = new XMLHttpRequest();
    xmlReq.open('POST', url, true /* async */);
    
    // define onreadystatechange
    xmlReq.onreadystatechange = function() {
        // if upload is cancelled
        if (this.readyState == 4 && this.status == 0) {
            // nothing to do
        }
        // if other conditions/error
        if (this.readyState == 4 && this.status != 200) {
            var strError = 'ERROR: this.status=' + this.status;
            console.error(strError);
        }
        // upload completed
        if (this.readyState == 4 && this.status == 200) {
            // get file object
            var file = JSON.parse(this.responseText);
            if (stickHasValue(file)) {
                if (stickHasValue(file.id)) {

                    // download file
                    url = url + "&fileid=" + file.id;

                    // open url in a new tab/window to invoke download
                    var a = document.createElement("a");
                    a.href = url;
                    document.body.appendChild(a);
                    a.click();

                    // do after a second
                    setTimeout(function() {
                        // delete file from cabinet after being brought to client
                        stickSuiteletProcessAsync('deleteFile', {
                            fileId : file.id
                        }, function(result) {
                            if (result != 'ok') {
                                console.error('Delete failed: ' + result);
                            }
                        });
                        // remove a
                        document.body.removeChild(a);
                    }, 1000);
                    
                    return;
                }
            }
            
            // no valid file
            console.error("no returned file");
        }
    };
    
    // begin request
    xmlReq.send(vFD);
}





function _GenerateCSV()
{
    if (stickGlobal.store == null ||
        stickGlobal.store.data == null ||
        stickGlobal.store.data.items == null)
    {
        return "";
    }

    var CSV_INFO = [
        { internalidText: "Note ID" },
        { REPLY_ID: "Reply ID" },
        { owner: "Author ID" },
        { ownerName: "Author Name" },
        { message: "Note Content" },
        { custrecord_sn_is_public: "Visibility" },
        { custrecord_sn_status: "Status" },
        { custrecord_sn_note_categoryText: "Priority" },
        { custrecord_sn_allowed_entities: "Recipient IDs" },
        { custrecord_sn_allowed_entitiesText: "Recipient Names" },
        { created: "Created Time" },
        { custrecord_sn_record_id: "Record ID" },
        { custrecord_sn_record_name: "Record Name" },
        { recordTypeName: "Record Type" },
        { fileUrl: "File Attachment" },
        { height: "Height" },
        { width: "Width" },
        { fontsize: "Font Size" },
        { categoryColor: "Color" }
    ];

    //header
    var headerLine = "";
    for (var i = 0; i < CSV_INFO.length; ++i)
    {
        for (var x in CSV_INFO[i])  //One iteration only to get the attribute name
        {
            headerLine += (headerLine == "" ? "" : ",") + CSV_INFO[i][x];
        }
    }


    var csv = headerLine + "\r\n";
    var notes = stickGlobal.store.data.items;
    
    for (i = 0; i < notes.length; ++i) //for each note/line
    {
        if (notes[i].data == null)
        {
            continue;
        }

        var csvLine = "";
        for (var j = 0; j < CSV_INFO.length; ++j)  //for each column
        {
            for(var x in CSV_INFO[j])  
            {
                var raw = x == "REPLY_ID" ? "*" : notes[i].data[x];
                var value = raw == null? "" : raw.toString();

                value = _FormatValue(x, value);

                if (value.indexOf(",") > -1)  //has comma?
                {
                    value = value.replace(/"/g, "\"\"");
                    value = "\"" + value + "\"";
                }
            }

            csvLine += (csvLine == "" ? "" : ",") + value;
        }

        csv += csvLine + "\r\n";

        csv += _GenerateCSVReplies(notes[i].data.replies);
    }

    return csv;
}





function _GenerateCSVReplies(replies)
{
    if (replies == null)
    {
        return "";
    }

    var REPLY_INFO = [
        "custrecord_snr_noteText", //Note ID
        "internalidText", //Reply ID
        "owner",  //Author ID
        "ownerName", //Author Name
        "custrecord_snr_reply", //Note Content,
        null,  //Visibility
        null,  //Status
        null,  //Priority
        null,  //Recipient IDs
        null,  //Recipient Names
        "created",  //Created
        null,  //Record ID
        null,  //Record Name
        null,  //Record Type
        "fileUrl",  //File Attachment
        null,  //Height
        null,  //Width
        null,  //Font Size
        null   //Color
    ];

    var s = "";

    for (var i = 0; i < replies.length; ++i)
    {
        var csvLine = "";
        
        for (var j = 0; j < REPLY_INFO.length; ++j)  //for each column
        {
             var x = REPLY_INFO[j];
             var raw = x == null? "": replies[i][x];
             var value = raw == null? "" : raw.toString();

             value = _FormatValue(x, value);

            if (value.indexOf(",") > -1)  //has comma?
            {
                value = value.replace(/"/g, "\"\"");
                value = "\"" + value + "\"";
            }

            csvLine += (csvLine == "" ? "" : ",") + value;
        }

        s += csvLine + "\r\n";
    }

    return s;
}





function _FormatValue(fieldId, value)
{
    if(value == "")
    {
        return "*";
    }

    if (fieldId == "fileUrl")
    {
        return stickGetDataCenterURL() + value;
    }

    if (fieldId == "custrecord_sn_status")
    {
        return value.charAt(0).toUpperCase() + value.slice(1);
    }
    
    if (fieldId == "custrecord_sn_allowed_entities" ||
        fieldId == "custrecord_sn_allowed_entitiesText")
    {
        var a = value.split(",");
        return a.join(", ");
    }

    if (fieldId == "custrecord_sn_is_public")
    {
        return value == "T" ? "Public" : "Private";
    }

    //Strip carriage returns
    value = value.replace(/\r\n/g, "<BR>");  //CR+LF
    value = value.replace(/\r/g, "<BR>");    //just CR
    value = value.replace(/\n/g, "<BR>");    //just LF

    return value;
}





function _SearchEngine()
{
    //Singleton
    if (this.constructor.prototype.instance != null)
    {
        return this.constructor.prototype.instance;
    }
    this.constructor.prototype.instance = this;


    this.Parse = _Parse;
    this.ToFilters = _ToFilters;
    this.Evaluate = _Evaluate;



    function _Parse(s)
    {
        if (s == null || s == "")
        {
            return [];
        }

        var tokens = [];
        var iStart = 0;
        var isOnQuote = false;

        for (var i = 0; i < s.length; ++i)
        {
            var ch = s.charAt(i);

            if (ch == "\"")
            {
                _AddToken(tokens, s, iStart, i, isOnQuote);
                iStart = i + 1;

                isOnQuote = !isOnQuote;
            }
            else if (ch == " " || ch == "\t")
            {
                if (!isOnQuote)
                {
                    _AddToken(tokens, s, iStart, i, false);
                    iStart = i + 1;
                }
            }
        }

        _AddToken(tokens, s, iStart, s.length, isOnQuote);

        return tokens;
    }




    function _AddToken(tokens, s, iStart, iEnd, isOnQuote)
    {
        if (iStart < iEnd)
        {
            var token = new String(s.substring(iStart, iEnd));
            if (token != null && token != "")
            {
                token.IsVerbatim = isOnQuote;
                tokens.push(token);
            }
        }
    }




    function _ToFilters(fieldId, s)
    {
        var tokens = _Parse(s);
        if (tokens.length == 0)
        {
            return null;
        }

        var filters = [];
        for (var i = 0; i < tokens.length; ++i)
        {
            if (tokens[i].toUpperCase() == "OR")
            {
                if (filters.length > 0 && filters[filters.length - 1] != "OR")
                {
                    filters.push("OR");
                }
            }
            else
            {
                if (filters.length > 0 && filters[filters.length - 1] != "OR")
                {
                    filters.push("AND");
                }

                filters.push([fieldId, "CONTAINS", tokens[i].valueOf()]);
            }
        }

        if (filters.length > 0 && filters[filters.length - 1] == "OR")
        {
            filters.pop();
        }

        return filters;
    }





    function _Evaluate(targetString, searchString)
    {
        if (targetString == null || targetString == "")
        {
            return true;
        }
    
        var filters = _ToFilters("", searchString);
        if (filters == null || filters.length == 0)
        {
            return true;
        }

        var value = true;
        var operation = "AND";

        for (var i = 0; i < filters.length; ++i)
        {
            if (filters[i] == "OR" || filters[i] == "AND")
            {
                operation = filters[i];
            }
            else
            {
                var target = targetString.toLowerCase();
                var search = filters[i][2].toLowerCase();
                var v = target.indexOf(search) > -1;

                if (operation == "OR")
                {
                    value = value || v;
                }
                else //AND
                {
                    value = value && v;
                }
            }
        }

        return value;
    }
}