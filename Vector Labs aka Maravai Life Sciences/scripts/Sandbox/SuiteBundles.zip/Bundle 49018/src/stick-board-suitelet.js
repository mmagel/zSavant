/**
 * � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
 */

/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       27 Sep 2012     tcaguioa
 *
 */
function suitelet(request, response)
{
    //Check role
    if (!_IsValidRole())
    {
        var form = nlapiCreateForm('StickyNotes Board');
        form.addField('html', 'inlinehtml').setDefaultValue("You have no access to StickyNotes Board.  Contact your account administrator to request for access.");
        response.writePage(form);
        return;
    }

    var context = nlapiGetContext();
    var BUNDLE_PATH = stickGetSuiteBundlesFolder() + '/Bundle ' + context.getBundleId();
    var SRC_PATH = BUNDLE_PATH + '/src/';
    var LIB_PATH = BUNDLE_PATH + '/lib/';

    
    var css = stickGetFileHtmlCode(SRC_PATH + 'stick-common-style.css');
    css += stickGetFileHtmlCode(SRC_PATH + 'stick-xtheme-reskin-ext4.css');
    css += stickGetFileHtmlCode(LIB_PATH + 'stick-jquery-ui.css');
    css += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-ext-theme-classic-sandbox-all.css');
    // we need to add these 2 styles inline to set the correct image path
    var sortCss = '<style type="text/css">.x4labs-btn .direction-asc { background-image: url(/c.COMPANYID/suitebundleBUNDLEID/images/sort_asc.png);}.x4labs-btn .direction-desc { background-image: url(/c.COMPANYID/suitebundleBUNDLEID/images/sort_desc.png  );}</style>';
    sortCss = sortCss.replace(/COMPANYID/g, context.getCompany());
    sortCss = sortCss.replace(/BUNDLEID/g, context.getBundleId());
    css += sortCss;


    // html
    var html = stickGetFileHtmlCode(SRC_PATH + 'stick-common-markup.html');
    html += stickGetFileHtmlCode(SRC_PATH + 'stick-board-markup.html');


    //js scripts
    var script = stickGetFileHtmlCode(LIB_PATH + 'stick-jquery-1.10.2.min.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'stick-jquery-ui-1.10.1.custom.min.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-ext-all-sandbox.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-Animated.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-BoxReorderer.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-SortButton.js');
    script += stickGetFileHtmlCode(LIB_PATH + 'Ext-4.2.1.883-Spotlight.js');
    script += stickGetFileHtmlCode(SRC_PATH + 'stick-tclib_common.js');
    script += stickGetFileHtmlCode(SRC_PATH + 'stick-tclib_client.js');
    script += stickGetFileHtmlCode(SRC_PATH + 'stick-common-client.js');
    script += stickGetFileHtmlCode(SRC_PATH + 'stick-board-client.js');
    script += stickGetFileHtmlCode(BUNDLE_PATH + '/lib/suidgets/build/js/' + 'suidgets-ui.js');
    script += stickGetFileHtmlCode(BUNDLE_PATH + '/lib/suidgets/build/js/widgets/' + 'filedragndrop.js');
    script += stickGetFileHtmlCode(BUNDLE_PATH + '/lib/suidgets/build/js/utilities/' + 'fileupload.js');

    // images
    var SUIDGETS_IMG_PATH = BUNDLE_PATH + '/lib/suidgets/build/img/';
    var imgFiles = [ 'img_trans.gif', 'file-type-sprite.png', 'cancel-sml.png' ];
    var imageUrls = {};
    for (var i = 0; i < imgFiles.length; i++) {
        imageUrls[imgFiles[i]] = stickGetFileUrl(SUIDGETS_IMG_PATH + imgFiles[i]);
    }
    script += '<div id="stickImageUrls" style="display: none;">' + JSON.stringify(imageUrls) + '</div>';

    if (context.getPreference('custscript_stick_is_automation') === 'T')  //add other files if automation account
    {
        var TEST_PATH = BUNDLE_PATH + '/test/';

        var markup = stickGetFileHtmlCode(TEST_PATH + 'labs-common-markup.html');
        markup = markup.replace(/{accountid}/g, context.getCompany());
        markup = markup.replace(/{bundleid}/g, context.getBundleId());
        html += markup;

        script += stickGetFileHtmlCode(TEST_PATH + 'stick-board-ui-object.js');
        script += stickGetFileHtmlCode(TEST_PATH + 'labs-jsunity-0.6.js');
        script += stickGetFileHtmlCode(TEST_PATH + 'stick_common_test_automation.js');
        script += stickGetFileHtmlCode(TEST_PATH + 'labs-page-object-common.js');
        script += stickGetFileHtmlCode(TEST_PATH + 'labs-labswide-common.js');
    }


    var form = nlapiCreateForm('StickyNotes Board');
    form.addField('custpage_stick_isfullaccess', "checkbox").setDisplayType("hidden").setDefaultValue(_IsFullAccess()?"T":"F");
    form.addField('custpage_stick_board', 'inlinehtml').setLayoutType('outside', 'startcol').setDefaultValue(css + html + script);

    response.writePage(form);
}





function _IsFullAccess()
{
    var context = nlapiGetContext();
    
    var pref = context.getPreference("custscript_stick_copref_globalusers");
    if (pref == null || pref == "")
    {
        return false;
    }
    
    var userId = '"' + context.getUser().toString() + '"';
    
    return pref.indexOf(userId) > -1;
}

function _IsValidRole()
{
    var context = nlapiGetContext();

    var isAllRoles = context.getPreference("custscript_stick_copref_isallroles") != "F";  //Compare to F so it evaluates to true by default
    if (isAllRoles)
    {
        return true;
    }

    var pref = context.getPreference("custscript_stick_copref_stickroles");
    if (pref == null || pref == "")
    {
        return false;
    }

    var roleId = '"' + context.getRole().toString() + '"';

    return pref.indexOf(roleId) > -1;
}
