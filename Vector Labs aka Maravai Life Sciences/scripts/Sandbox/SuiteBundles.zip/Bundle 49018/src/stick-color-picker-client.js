/**
* � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
*/

/**
 * Display the note actions menu at near the link clicked.
 * 
 * @param evt
 * @returns {Boolean}
 */
function stickShowColorPicker(target) {
    stickGlobal.currentColorPickerTarget = target;
    // var e = evt || window.event;
    // var target = e.target;
    var x = Ext.get('stickColorPicker');
    var xTarget = Ext.get(target);
    x.setTop(xTarget.getTop() + xTarget.getHeight());
    x.setLeft(xTarget.getLeft());
    x.dom.style.position = 'absolute';
    x.fadeIn();
    // stickGlobal.currentNoteId = target.getAttribute('data-internalid');

    return false;
}

Ext.select('#stickColorPicker td').setStyle({
    cursor : 'pointer'
});

Ext.select('#stickColorPicker td').on('click', function(evt, target) {
    // alert(target.getAttribute('bgcolor'));
    var color = target.getAttribute('bgcolor');
    if (stickHasNoValue(color)) {
        // might be the cell of the Close button
    	// hide picker
        Ext.get('stickColorPicker').hide();
        return;
    }
    // hide picker
    Ext.get('stickColorPicker').hide();

    // set and show new color
    var elId = stickGlobal.currentColorPickerTarget.id;

    // nlapiSetFieldValue(elId, color);
    stickGlobal.currentColorPickerTarget.value = color;
    // set font and bg color to the selected color
    jStick('#' + elId).animate({
        backgroundColor : color
    }, 750);

    // Ext.get(stickGlobal.currentColorPickerTarget).setStyle({
    // backgroundColor : color
    // });

});