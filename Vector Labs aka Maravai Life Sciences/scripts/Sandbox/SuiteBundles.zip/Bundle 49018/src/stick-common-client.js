/**
 * � 2015 NetSuite Inc. User may not copy, modify, distribute, or re-bundle or
 * otherwise make available this code.
 */

var stickGlobal = stickGlobal || {};
stickGlobal.TITLE = 'StickyNotes';

//5MB is used here instead of 10MB due to the limitation of file.getValue()
//being able to retrieve only up to 5MB of data despite NetSuite supports
//upload of up to 10MB.
stickGlobal.MAXIMUM_FILE_SIZE = 5242880;

/**
 * Prevents the event from bubbling up the DOM tree, preventing any parent
 * handlers from being notified of the event.
 * 
 * @param {event}
 *        e - event
 * @returns {Boolean} True to stop propagation
 */
function stickStopPropagation(e) {
    // var logger = new stickobjLogger(arguments);

    if (e.preventDefault) {
        e.preventDefault();
    }

    if (Ext.isIE) {
        e.cancelBubble = true;
        e.returnValue = false;
    } else {
        if (e.stopPropagation) {
            e.stopPropagation();
        }
    }
    return false;
}

function stickSetTooltipOneLiners(noteId) {
    var oneLineClasses = [ '.stick-created', '.stick-recipients', '.stick-owner', '.stick-record-name' ];
    var count = oneLineClasses.length;
    for (var i = 0; i < count; i++) {
        var oneLineClass = oneLineClasses[i];
        var els = Ext.select('#stick' + noteId + ' ' + oneLineClass).elements;
        if (els.length === 0) {
            continue;
        }
        var el = els[0];
        var x = Ext.get(el);
        if (el.scrollWidth > x.getWidth()) {
            el.setAttribute('data-qtip', el.innerHTML);
        }
    }
}
function stickSetMouseEventsBeforeNotesRender() {
    if (stickIsMobile()) {
        return;
    }
    selector = '#stickNoteActionsBox';
    jStick(selector).mouseenter(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mousemove(function(evt) {
        // var logger = new stickobjLogger(selector + ' mousemove');
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mouseleave(function(evt) {
        stickHideNoteActionsMenu(evt);
    });
    selector = '#stickMenuLink';
    jStick(selector).mousemove(function() {
        stickShowLinksBox();
        return false;
    });
    jStick(selector).mouseleave(function() {
        stickHideLinksBox();
        return false;
    });
    selector = '#stickLinksBox';
    jStick(selector).mousemove(function() {
        stickShowLinksBox();
        return false;
    });
    jStick(selector).mouseleave(function() {
        stickHideLinksBox();
        return false;
    });
    var selector = '#stickNewNoteLinksBox .stick-action-link';
    jStick(selector).mouseenter(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mousemove(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mouseleave(function(evt) {
        stickHideNoteActionsMenu(evt);
    });
    jStick('#stickNewNoteLinksBox .stick-link-box').mouseenter(function(evt) {
        jStick(this).addClass('stick-link-box-hover');
    });
    jStick('#stickNewNoteLinksBox .stick-link-box').mouseleave(function(evt) {
        jStick(this).removeClass('stick-link-box-hover');
    });
}

function stickSetEventsForMobile() {

    jStick('body').click(function(e) {

        // On stickynotes board, when stickynote thread is displayed, clicking
        // outside it will close the thread.
        var actionLinks = 'Close menu, Mark as Done, Reply, Delete Note, Archive Note';

        if (stickGlobal.isBoard && Ext.get('stickNoteSelected').isVisible() && stickGlobal.tooltips.length == 0) {

            var itemClicked = e.target.textContent;

            if (stickHasValue(itemClicked) && actionLinks.indexOf(itemClicked) > -1) {

                return;

            }

            stickHideNoteThreadPopup();

            return;

        }

    });

}

function stickSetMouseOverAndOutEvents() {
    var logger = new stickobjLogger(arguments);
    if (stickIsMobile()) {

        stickSetEventsForMobile();
        return;
    }
    Ext.select('.stickNote').on('mouseenter', function(e) {
        try {
            if (e.target.id === '') {
                return;
            }
            Ext.select('#stickNoteBox .stickShowOnHover').hide();
            Ext.select('#' + e.target.id + ' .stickShowOnHover').show();
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseenter ' + e);
            }
        }
    });
    Ext.select('.stickNote').on('mouseleave', function(e) {
        try {
            Ext.select('#stickNoteBox .stickShowOnHover').hide();
            return true;
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseleave ' + e);
            }
        }
    });
    var selector = '#stickNoteBox .stick-action-link, #stickNoteBoxBoard .stick-action-link, #stickNoteSelected .stick-action-link';
    jStick(selector).mouseenter(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mousemove(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mouseleave(function(evt) {
        stickHideNoteActionsMenu(evt);
    });
    selector = '#stickNoteBox .stick-link-box, #stickNoteBoxBoard .stick-link-box, #stickNoteSelected .stick-link-box';
    jStick(selector).mouseenter(function(evt) {
        jStick(this).addClass('stick-link-box-hover');
    });
    jStick(selector).mouseleave(function(evt) {
        jStick(this).removeClass('stick-link-box-hover');
    });

    jStick('body').click(function(e) {
        try {
            var elId = e.target.id;
            if (stickGlobal.isBoard == true) {
                // if a user clicks outside a pop-up box of a note on the board,
                // it
                // should close the pop-up box
                if (stickHasNoValue(Ext.get(elId))) {
                    return;
                }
                // stickHideHelp();
                if (Ext.get(elId).hasClass('ext-el-mask') && Ext.get('stickNoteSelected').isVisible() && stickGlobal.tooltips.length == 0) {
                    stickHideNoteThreadPopup();
                    return;
                }
            } else {
                // this will set parent note to default size if user clicks
                // outside the box on record pages
                if (!Ext.get(e.target).findParent('#stickNoteBox .stickBox')) {
                    var els = Ext.select('.stick-parent[data-autosizeheight="yes"]').elements;
                    for (var i = 0; i < els.length; i++) {
                        var el = els[i];
                        var noteId = el.getAttribute('data-internalid');
                        stickSetNoteHeightToFixed(noteId);
                        el.setAttribute('data-autosizeheight', 'no');
                    }
                    return;
                }
            }
        } catch (ex) {
            stickHandleError(ex, 'stickSetMouseEvents() ' + stickGetErrorDetails(ex));
        }

    });
    logger.log('end');
}
/**
 * 
 * start of in-app help
 * 
 */
stickGlobal.tooltips = [];
// Init the singleton. Any tag-based quick tips will start working.
E4S.tip.QuickTipManager.init(true, {
    style : 'background-color: ivory ; padding: 0px; margin: 0px',
    dismissDelay : 0,
    trackMouse : false,
    anchorToTarget : true,
    anchor : 'right'
/* disable automatic hiding */
}); // v4
// Apply a set of config properties to the singleton
E4S.apply(E4S.tip.QuickTipManager.getQuickTip(), {
    trackMouse : false
});
function stickGetSpot() {
    stickGlobal.spot = stickGlobal.spot || new E4S.create('E4S.ux.Spotlight', {
        animate : false
    });
    return stickGlobal.spot;
}
// stores help tooltips
stickGlobal.tooltips = [];
function stickSetHelp(el, title, helpContent, anchor, anchorOffset) {
    var logger = new stickobjLogger(arguments);
    logger.log('typeof el=' + typeof el);
    title = title || '';
    var target = null;
    if (typeof el == 'string') {
        if (stickHasValue(el)) {
            if (Ext.get(el) === null) {
                throw 'el=' + el;
            }
            target = Ext.get(el).dom;
        }
    } else {
        target = el;
    }
    if (Ext.get(target) === null) {
        // element has not been created
        target = Ext.get('stickyNotesBoardFrame').dom;
        helpContent = 'Note: This element is currently hidden because the timeline is collapsed.<br><br>' + helpContent;
    }
    logger.log('Ext.get(target).getWidth() =' + Ext.get(target).getWidth());
    if (Ext.get(target).getWidth() === 0) {
        // element is hidden
        // set default element which is the whole timeline table
        target = Ext.get('stickyNotesBoardFrame').dom;
        helpContent = 'Note: This element is currently hidden because your timeline is collapsed.<br><br>' + helpContent;
    }
    if (stickHasNoValue(target.id)) {
        target.id = 'random' + stickRandom();
    }
    if (typeof anchor == 'undefined') {
        anchor = 'top';
    }
    if (typeof anchorOffset == 'undefined') {
        anchorOffset = 0;
    }

    // Issue 337646 : [StickyNotes] Record Page Tutorial > A "V" like character
    // is displayed in some tutorials
    if (el == 'stickLeftPane' || el == 'recordFilter') {
        anchor = 'left';
    }

    logger.log('target.id=' + target.id);
    var tooltip = (new Ext.ToolTip({
        title : title,
        ids : target.id + 'Tooltip',
        target : target,
        anchor : anchor,
        html : helpContent,
        autoWidth : false,
        minWidth : 250,
        maxWidth : 350,
        autoHide : false,
        closable : false,
        autoShow : false,
        hideDelay : 0,
        dismissDelay : 0,
        anchorOffset : anchorOffset,
        style : {
            color : 'red'
        },
        listeners : {
            'hide' : function() {
                this.destroy();
                if (stickHasValue(stickGlobal.spot)) {
                    // if (stickGlobal.spot.active) {
                    stickGlobal.spot.hide();
                    delete stickGlobal.spot;
                    // }//
                }

                stickHideHelp();
            },
            'clickX' : function() {
                if (stickGlobal.spot) {
                    stickGlobal.spot.hide();
                    delete stickGlobal.spot;
                }
                stickHideHelp();
            }
        }
    }));
    tooltip.show();
    stickApplyCSSToFolderTooltip();
    if (Ext.isIE) {
        Ext.select('.x-ie-shadow').hide();
    }
    // // reposition for bottom docked since it does not properly
    // if (stickGlobal.placement == 'Bottom (Docked)') {
    // stickGlobal.ALLOWANCE = 10;
    // var leftPos = Ext.get(target).getLeft();
    // if ([ 'stickSendCommentsLink', 'tblSummaryFields' ].indexOf(target.id) >
    // -1) {
    // leftPos = leftPos - tooltip.getWidth() - stickGlobal.ALLOWANCE;
    // } else {
    // leftPos = leftPos + stickGlobal.ALLOWANCE;
    // }
    // var topPos = Ext.get(target).getTop() - tooltip.getHeight() -
    // stickGlobal.ALLOWANCE;
    // tooltip.setPosition(leftPos, topPos);
    // // hide the tooltip arrow since it is difficult to set to the correct
    // // position
    // Ext.select('.x-tip-anchor').hide();
    // }
    stickGlobal.tooltips.push(tooltip);
}
function stickHideHelp() {
    var logger = new stickobjLogger(arguments);
    for (var i = 0; i < stickGlobal.tooltips.length; i++) {
        try {
            stickGlobal.tooltips[i].hide();
        } catch (e) {
            logger.error(e);
        }
    }
    stickGlobal.tooltips = [];
    logger.log('end');
}
function stickIsActiveView() {
    var x = E4S.get('stick-view-archived-btnInnerEl');
    if (x === null) {
        // in record page
        return true;
    }
    return x.dom.innerHTML === 'View Archived Notes';
}
function stickGetLineHeight() {
    return Ext.get('stickLineHeight').getHeight();
}
function stickGetMessageHeight() {
    var logger = new stickobjLogger(arguments, true);
    var lineHeight = stickGetLineHeight();
    // logger.log('lineHeight=' + lineHeight);
    var noteHeight = parseInt(stickGetNoteSize().height.replace('px', ''), 10);
    var messageHeight = noteHeight;
    // messageHeight -= 10; // top margin
    // messageHeight -= lineHeight; // action link
    messageHeight -= lineHeight; // created date
    if (stickGlobal.isBoard) {
        messageHeight -= lineHeight; // record name
    }
    messageHeight -= lineHeight; // recipients
    messageHeight -= 10; // message top margin
    messageHeight -= 10; // message bottom margin
    messageHeight -= lineHeight; // owner
    messageHeight -= 15; // icons
    var paddings = 30;
    messageHeight -= paddings;
    messageHeight -= 10; // adjustment
    logger.end();
    return messageHeight;
}
function stickGetReplyHeight() {
    var messageHeight = stickGetMessageHeight();
    var lineHeight = Ext.get('stickLineHeight').getHeight();
    var height = messageHeight + (2 * lineHeight);
    return height;
}
function stickSetNoteElementsSizes() {
    var logger = new stickobjLogger(arguments);
    // set font size
    Ext.select('.stickNote div').setStyle({
        'font-size' : stickGlobal.dataSet.fontSize
    });
    var noteHeight = parseInt(stickGetNoteSize().height.replace('px', ''), 10);
    // logger.log('noteHeight=' + noteHeight);
    var noteWidth = parseInt(stickGetNoteSize().width.replace('px', ''), 10);
    // logger.log('noteWidth=' + noteWidth);
    var xNotes = Ext.select('.stickNote');
    // xNotes.setWidth(noteWidth).setHeight(noteHeight);
    // logger.log('b4 setSize');
    xNotes.setSize({
        width : noteWidth,
        height : noteHeight
    });
    // logger.log('after setSize');
    var margin = 10;
    var xNoteInners = Ext.select('.stick-note-inner');
    var innerWidth = noteWidth - margin - margin;
    // logger.log('b4 setHeight');
    // xNoteInners.setWidth(noteWidthNoMargin);
    var innerHeight = noteHeight - margin - margin;
    // xNoteInners.setHeight(innerHeight);
    xNoteInners.setSize({
        width : innerWidth,
        height : innerHeight
    });
    // logger.log('after setHeight');
    // logger.log('b4 setHeight');
    // // Ext.select('.stick-created, .stick-recipients, .stick-record-name,
    // // .stick-record-name a').setHeight(lineHeight);
    // logger.log('after setHeight');
    if (stickGlobal.isBoard === false || stickGlobal.showGrid) {
        // set only when in grid view and record page
        var messageHeight = stickGetMessageHeight();
        logger.log('messageHeight=' + messageHeight);
        Ext.select('.stick-message').setHeight(messageHeight);
        // replies
        var replyMessageHeight = stickGetReplyHeight(); // messageHeight +
        // lineHeight;
        Ext.select('.stick-message-reply').setHeight(replyMessageHeight);
    }
    if (stickGlobal.isBoard) {
        var messageHeight = stickGetMessageHeight();
        logger.log('messageHeight=' + messageHeight);
        Ext.select('#stickNoteSelected .stick-message').setHeight(messageHeight);
        // replies
        var replyMessageHeight = stickGetReplyHeight(); // messageHeight +
        // lineHeight;
        Ext.select('#stickNoteSelected .stick-message-reply').setHeight(replyMessageHeight);
        var noteHeight = stickGetNoteSize().height.replace('px', '');
        noteHeight -= 20; // margins
        noteHeight -= 10; // distance between replies
        jStick('#stickNoteSelected .stickReplyBox').css({
            'margin-top' : noteHeight
        });
        jStick('#stickNoteSelected .stickReply').css({
            'margin-top' : -1 * noteHeight
        });
    }
    if (Ext.isIE) {
        jStick('.stickReply').css({
            'padding-top' : 0
        });
    }
    var notes;
    if (stickGlobal.isBoard) {
        notes = stickGlobal.store.data.items;
    } else {
        notes = stickGlobal.dataSet.notes;
    }
    var count = notes.length;
    for (var i = 0; i < count; i++) {
        var note;
        if (notes[i].internalid) {
            note = notes[i];
        } else {
            note = notes[i].data;
        }
        stickSetTooltipOneLiners(note.internalid);
    }

    var els = Ext.select('.stickReply').elements;
    var repliesCount = els.length;
    for (var j = 0; j < repliesCount; j++) {
        var el = els[j];
        var elReplyMessage = Ext.get(el).select('.stick-message-reply').elements[0];
        var elReplyPreviewImage = Ext.get(elReplyMessage).query('.stick-file .preview.has');
        if (elReplyMessage.scrollHeight > Ext.get(elReplyMessage).getHeight() || elReplyPreviewImage.length > 0) {
            elReplyMessage.setAttribute('data-qtip', stickAdjustTooltipContent(elReplyMessage.innerHTML));
        } else {
            elReplyMessage.setAttribute('data-qtip', '');
        }
    }
    // 
    if (!stickGlobal.isBoard) {
        stickSetNoteMinHeight();

        selector = '.stick-parent[data-replies-position=lined]';
        jStick(selector).each(function(i, el) {
            var noteId = jStick(el).attr('data-internalid');
            stickExpandReplies(noteId);
        });

        selector = '.stick-parent[data-replies-position=piled]';
        jStick(selector).each(function(i, el) {
            var noteId = jStick(el).attr('data-internalid');
            stickCollapseReplies(noteId);
        });
    }
    logger.end();
}
// function stickProcessNotesBeforeRender() {
// var notes = stickGlobal.dataSet.notes;
// // display replies for each note
// for (var i = 0; i < notes.length; i++) {
// // var note = notes[i];
// notes[i]
//
// note.message = note.message.replace(/\[br\]/gi, '<br>');
//
// }
//
// }
/**
 * 
 * Perform processing before render of notes
 * 
 */
function stickProcessPreRendered() {
    try {
        var logger = new stickobjLogger(arguments);
        if (Ext.get('div_ACTIONMENU_d1')) {
            // change the zindex of the NetSuite More Actions dropdown menu so
            // that it is on top of the notes
            var b4 = "Ext.get('div_ACTIONMENU_d1').dom.parentNode.style.zIndex = 9999999;";
            Ext.get('div_ACTIONMENU_d1').dom.parentNode.style.zIndex = 9999999;
        }
        // see http://css-tricks.com/ie-10-specific-styles/
        var doc = document.documentElement;
        var b4 = "doc.setAttribute('data-useragent', navigator.userAgent);";
        doc.setAttribute('data-useragent', navigator.userAgent);
        logger.end();
    } catch (e) {
        // stickHandleError(e, stickGetArgumentDetails(arguments));
        // alert('trace='+trace);
        stickHandleError(e, 'stickProcessPreRendered() b4=' + b4);
        // throw e;
    }
}
function stickProcessRenderedNotes(notes) {
    // alert('stickProcessRenderedNotes')
    // disable logger initially so that notes won't be logged
    var logger = new stickobjLogger(arguments, true);
    logger.setDisabled(false);
    logger.log('start');
    //
    if (stickGlobal.isBoard) {
        notes = notes || stickGlobal.store.data.items;
    } else {
        notes = notes || stickGlobal.dataSet.notes;
    }
    logger.log('notes.length=' + notes.length);
    // display replies for each note
    var messageHeight = stickGetMessageHeight();
    var lineHeight = Ext.get('stickLineHeight').getHeight();
    var replyHeight = stickGetReplyHeight();
    var selector = '';
    for (var i = 0; i < notes.length; i++) {
        var note;
        if (notes[i].internalid) {
            note = notes[i];
        } else {
            note = notes[i].data;
        }
        // logger.log('note.internalid=' + note.internalid);
        note.message = note.message.replace(/\[br\]/gi, '<br>');
        // get highest z index
        if (parseInt(notes[i].custrecord_sn_z_index, 10) > stickGlobal.lastZIndex) {
            stickGlobal.lastZIndex = parseInt(notes[i].custrecord_sn_z_index, 10);
        }
        // logger.log('note.isPublicText=' + note.isPublicText)
        if (note.isPublicText === 'Yes') {
            // show
            selector = '#stickBox' + note.internalid + ' .stick-public';
            selector += ', #stickBoxList' + note.internalid + ' .stick-public';
            Ext.select(selector).setStyle({
                visibility : 'inherit'
            });
            // hide
            selector = '#stickBox' + note.internalid + ' .stick-private';
            selector += ', #stickBoxList' + note.internalid + ' .stick-private';
            Ext.select(selector).setStyle({
                display : 'none'
            });
        } else {
            selector = '#stickBox' + note.internalid + ' .stick-private';
            selector += ', #stickBoxList' + note.internalid + ' .stick-private';
            Ext.select(selector).setStyle({
                visibility : 'inherit'
            });
            selector = '#stickBox' + note.internalid + ' .stick-public';
            selector += ', #stickBoxList' + note.internalid + ' .stick-public';
            Ext.select(selector).setStyle({
                display : 'none'
            });
        }
        
        // check if note has attachment
        var noteHasFile = stickHasValue(note.fileName);
        
        var repliesCount = note.replies.length;
        // logger.log('note.replies.length=' + repliesCount);
        if (repliesCount > 0) {
            selector = '#stickBox' + note.internalid + ' .stick-with-reply';
            selector += ', #stickBoxList' + note.internalid + ' .stick-with-reply';
            if (stickGlobal.isBoard) {
                // Ext.select(selector).setStyle({
                // display : 'inline'
                // }).show();
                Ext.select(selector).setStyle({
                    visibility : 'inherit'
                });
            }
            var xReplyBox = Ext.get('stickReplyBox' + note.internalid);
            if (xReplyBox) {
                xReplyBox.dom.style.display = 'block';
                for (var j = 0; j < repliesCount; j++) {
                    note.replies[j].ordernumber = j;
                    if (stickGlobal.isBoard) {
                        note.replies[j].ordernumber = 1005 + j;
                    }
                }
                stickTemplateAppend('tmpReply', 'stickReplyBox' + note.internalid, note.replies);
            }

            // check if reply has attachment
            for (var j = 0; j < repliesCount; j++) {
                if (stickHasValue(note.replies[j].fileName)) {
                    noteHasFile = true;
                }
            }
            
            // show/hide image preview
            stickToggleImagePreview(note.internalid, false /*isNote*/, !stickGlobal.isBoard /*isCollapsed*/);
            
        } else {
            Ext.select('#stickBox' + note.internalid + ' .stick-with-reply').setStyle({
                display : 'none'
            });
        }
        
        // show/hide image preview
        stickToggleImagePreview(note.internalid, true /*isNote*/, !stickGlobal.isBoard /*isCollapsed*/);
        
        // if note/reply has file, show file icon
        if (noteHasFile) {
            selector = '#stickBox' + note.internalid + ' .stick-attachment';
            selector += ', #stickBoxList' + note.internalid + ' .stick-attachment';
            Ext.select(selector).setStyle({
                visibility : 'inherit'
            });
        }
        
        if (note.custrecord_sn_status == 'completed') {
            selector = '#stickBox' + note.internalid + ' .stick-parent .stick-message';
            selector += ', #stickBoxList' + note.internalid + ' .stick-message';
            Ext.select(selector).setStyle('text-decoration', 'line-through');
            // Ext.select('#stickBoxList' + note.internalid + '
            // .stick-message').setStyle('text-decoration', 'line-through');
        }
        if (stickGlobal.isBoard === false || stickGlobal.showGrid) {
            // set the tips since it is safer here
            var elMessage = Ext.select('#stick' + note.internalid + ' .stick-message').elements[0];
            // logger.log()
            if (Ext.get(elMessage) === null) {
                // logger.log('#stick' + note.internalid + ' .stick-message');
                // note might be filtered out
                continue;
            }

            // set note height to fixed
            stickSetNoteHeightToFixed(note.internalid);
            var elPreviewImage = Ext.get(elMessage).query('.stick-file .preview.has');
            if (Ext.get(elMessage).getHeight() > messageHeight || elPreviewImage.length > 0) {
                elMessage.setAttribute('data-qtip', stickAdjustTooltipContent(elMessage.innerHTML));
            }

            var elRecipients = Ext.select('#stick' + note.internalid + ' .stick-recipients').elements[0];
            if (Ext.get(elRecipients).getHeight() > lineHeight) {
                elRecipients.setAttribute('data-qtip', note.recipientsName);
                Ext.get(elRecipients).setStyle({
                    'white-space' : 'nowrap'
                });
            }
        } else {
            // board in list view
            // set note height to fixed
            var $note = jStick('#stickBoxList' + note.internalid);
            $note.attr('data-autosizeheight', 'no');
        }
        // Ext.select('#stick' + note.internalid + '
        // .stick-recipients').elements[0].setAttribute('data-qtip',
        // note.recipientsName);
    }
    logger.log('after loop');
    if (stickGlobal.isBoard) {
        Ext.select('#stickyNotesBoardFrame td, #stickyNotesBoardFrame input').addClass('smalltext');
        Ext.select('.stickBox, .stickNote').setStyle({
            cursor : 'text'
        });
    } else {
        selector = '.stick-with-reply';
        Ext.select(selector).setStyle({
            display : 'none'
        });
    }
    // set icons icons
    jStick('.stick-private').attr('src', stickGlobal.dataSet['stick-private.png']);
    jStick('.stick-public').attr('src', stickGlobal.dataSet['stick-public.png']);
    jStick('.stick-with-reply').attr('src', stickGlobal.dataSet['stick-reply.png']);
    jStick('.stick-delete').attr('src', stickGlobal.dataSet['stick-delete.png']);
    jStick('.stick-attachment').attr('src', stickGlobal.dataSet['stick-attachment.png']);
    stickSetNoteElementsSizes();
    // run code for tablets
    if (stickIsMobile()) {
        Ext.select('.stick-reply-delete, .stick-action-link').show();
    } else {
    }
    stickSetMouseEvents();
    if (Ext.isIE) {
        Ext.select('.stick-action-link').setStyle({
            padding : '2px'
        });
        Ext.select('#stickNoteBox .stickReply:nth-child(odd)').setStyle({
            marginLeft : -5
        });
        Ext.select('#stickNoteBox .stickReply:nth-child(even)').setStyle({
            marginLeft : 5
        });
    }
    jStick('#stickEntry, #stickNewReplyEntry').draggable();
    if (stickGlobal.isBoard) {
        // Issue 280773 [StickyNotes] Disappearing notes on StickyNotes board
        // when view is changed
        if (Ext.isSafari) {
            // HACK: not sure why the notes don't display
            Ext.select('#stickNoteBoxBoard .stickBox').show();
        }
        // end of Issue 280773 [StickyNotes] Disappearing notes on StickyNotes
        setTimeout(function() {
            stickSetBoardHeight();
        }, 1000);
    }
    jStick(".stickNote,.stickNoteLi,.stick-parent").click(function(event) {
        event.stopPropagation();
    });
    if (stickIsListView()) {
        stickProcessNotesInListView();
    }
    logger.end();
}
function stickIsListView() {
    return stickGlobal.isBoard && stickGlobal.showGrid === false;
}
function stickSetMouseEvents() {// set mouse enter events
    if (stickIsMobile()) {
        return;
    }
    var selector = '.stick-link-box';
    jStick(selector).mouseenter(function(evt) {
        jStick(this).addClass('stick-link-box-hover');
    });
    jStick(selector).mouseleave(function(evt) {
        jStick(this).removeClass('stick-link-box-hover');
    });
    selector = '.stickNote';
    jStick(selector).mouseenter(function(evt) {
        // jStick(this).find('.stick-action-link').show();
        Ext.get(this).select('.stick-action-link').show();
        Ext.get('stickNoteActionsBox').hide();
        Ext.select('.stick-action-link').removeClass('stick-menu-link-hover').removeClass('stick-link-box-hover').addClass('stick-menu-link-normal');
    });
    jStick(selector).mouseleave(function(evt) {
        // jStick(this).find('.stick-action-link').hide();
        if (Ext.get('stickNoteActionsBox').isVisible()) {
            // do not hide action link if the dropdown is visible
            return;
        }
        Ext.get(this).select('.stick-action-link').hide();
    });

}
function stickRenderNoteSizes() {
    stickSuiteletProcessAsync('getNoteSizes', 'any', function(noteSizes) {
        stickTemplateAppend('tmpNoteSize', 'stickNoteSizeSelect', noteSizes);
        // set the size of the stickNoteSizeSelect
        var x = Ext.get('stickNoteSizeSelect');
        x.setWidth(x.getWidth() + 50);
        x.setHeight(x.getHeight() + 50);
    });
}
function stickShowUserPreferenceActions(evt) {
    stickHideNoteActionsMenu();
    var target = evt.target;
    var x = Ext.get('stickUserPreferenceActionsBox');
    var xTarget = Ext.get(target);
    x.setTop(xTarget.getTop());
    x.setLeft(xTarget.getLeft());
    x.dom.style.position = 'absolute';
    x.fadeIn();
    return false;
}
/**
 * 
 * Return true if in board and in active view
 * 
 */
function stickIsActiveView() {
    if (stickGlobal.isBoard == false) {
        return false;
    }
    var xArchive = E4S.get('stick-view-archived-btnInnerEl');
    var currentLabel = xArchive.dom.innerHTML;
    if (currentLabel == 'View Archived Notes') {
        return true;
    }
    return false;
}
/**
 * 
 * Return true if in board and in active view
 * 
 */
function stickIsArchiveView() {
    if (stickGlobal.isBoard == false) {
        return false;
    }
    var xArchive = E4S.get('stick-view-archived-btnInnerEl');
    var currentLabel = xArchive.dom.innerHTML;
    if (currentLabel == 'View Archived Notes') {
        return false;
    }
    return true;
}
/**
 * 
 * Display the note actions menu at near the link clicked.
 * 
 * 
 * 
 * @param evt
 * 
 * @returns {Boolean}
 * 
 */
function stickShowNoteActionsMenu(evt) {
    var logger = new stickobjLogger(arguments);
    evt = evt || window.event;
    var target = evt.target || evt.srcElement;
    var xNoteActionsBox = Ext.get('stickNoteActionsBox');
    logger.log('stickGlobal.noteActionsMenuTimeout=' + stickGlobal.noteActionsMenuTimeout);
    if (stickHasValue(stickGlobal.noteActionsMenuTimeout)) {
        clearTimeout(stickGlobal.noteActionsMenuTimeout);
    }
    if (xNoteActionsBox.isVisible()) {
        logger.log('returning...xNoteActionsBox.isVisible()');
        return;
    }
    var dStickBox = Ext.get(target).findParent('.stickBox');
    if (dStickBox === null) {
        logger.error('returning...dStickBox === null target=' + target.outerHTML);
        return;
    }
    stickGlobal.currentNoteId = dStickBox.getAttribute('data-internalid');
    var noteId = stickGlobal.currentNoteId;
    // show/hide close button
    if (stickIsMobile()) {
        Ext.select('#stickNoteCloseLink').setStyle({
            display : ''
        });
    } else {
        Ext.select('#stickNoteCloseLink').setStyle({
            display : 'none'
        });
    }
    // show/hide delete/archive links
    var ownerId = Ext.select('#stick' + stickGlobal.currentNoteId + ' .stick-owner').elements[0].getAttribute('data-owner');
    if (ownerId == nlapiGetContext().getUser()) {
        Ext.select('#stickNoteDeleteLink, #stickNoteArchiveLink').setStyle({
            display : ''
        });
    } else {
        Ext.select('#stickNoteDeleteLink, #stickNoteArchiveLink').setStyle({
            display : 'none'
        });
    }
    // remove archive link in archive view
    if (stickIsArchiveView()) {
        Ext.select('#stickNoteArchiveLink').setStyle({
            display : 'none'
        });
    }
    // show/hide pile or line up replies
    var replyCount = Ext.select('#stickBox' + stickGlobal.currentNoteId + ' .stickReply').elements.length;
    if (replyCount > 0) {
        Ext.select('#stickCollapseOrExpandReplies').setStyle({
            display : ''
        });
    } else {
        Ext.select('#stickCollapseOrExpandReplies').setStyle({
            display : 'none'
        });
    }
    if (stickGlobal.isBoard) {
        Ext.select('#stickCollapseOrExpandReplies').setStyle({
            display : 'none'
        });
    }
    // show/hide mark as done
    if (Ext.get('stickMessage' + noteId).getStyle('text-decoration') != 'line-through') {
        Ext.select('#stickNoteMarkAsDoneLink').setStyle({
            display : ''
        });
    } else {
        Ext.select('#stickNoteMarkAsDoneLink').setStyle({
            display : 'none'
        });
    }
    // get Actions link
    var dActionsLink;
    // try the selected node first
    var els = Ext.select('#stickNoteSelected .stick-action-link').elements;
    if (els.length === 0) {
        // no selected node
        els = Ext.select('#stick' + stickGlobal.currentNoteId + ' .stick-action-link').elements;
    }
    dActionsLink = els[0];
    var xLink = Ext.get(dActionsLink);
    xLink.addClass('stick-menu-link-hover');
    xLink.removeClass('stick-menu-link-normal');
    // get action link
    // var xTarget = Ext.get(target);
    var topPos = xLink.getTop() + xLink.getHeight();
    if (Ext.isIE) {
        topPos = topPos - 3;
    } else {
        topPos = topPos - 2;
    }
    xNoteActionsBox.setTop(topPos);
    xNoteActionsBox.setLeft(xLink.getLeft());
    xNoteActionsBox.dom.style.position = 'absolute';
    xNoteActionsBox.show();
    // set name of stickCollapseOrExpandReplies
    var xNote = Ext.get('stick' + stickGlobal.currentNoteId);
    var curRepliesPosition = xNote.dom.getAttribute('data-replies-position');
    var collapseOrExpandLabel = curRepliesPosition === 'lined' ? 'Compile Replies' : 'Expand Replies';
    var collapseOrExpandHelp = curRepliesPosition === 'lined' ? ' Collapse the note reply thread.' : 'Expand the note reply thread to display all replies.';
    Ext.get('stickCollapseOrExpandReplies').update(collapseOrExpandLabel);
    Ext.get('stickCollapseOrExpandReplies').set({
        'data-qtip' : collapseOrExpandHelp
    });
    return stickStopPropagation(evt);
}
function stickHideNoteActionsMenuNoDelay() {
    var dActionsLink = Ext.select('#stick' + stickGlobal.currentNoteId + ' .stick-action-link').elements[0];
    if (stickIsNoteThreadVisible()) {
        var xLink = Ext.get(Ext.select('#stickNoteSelected .stick-action-link').elements[0]);
        xLink.removeClass('stick-menu-link-hover');
        xLink.removeClass('stick-link-box-hover');
        xLink.addClass('stick-menu-link-normal');
    }
    Ext.get('stickNoteActionsBox').hide();
    delete stickGlobal.noteActionsMenuTimeout;
    if (stickGlobal.isBoard && stickGlobal.showGrid === false) {
        // return in list view
        return;
    }
    var xLink = Ext.get(dActionsLink);
    xLink.removeClass('stick-menu-link-hover');
    xLink.removeClass('stick-link-box-hover');
    xLink.addClass('stick-menu-link-normal');
}
/**
 * 
 * Hides the note actions menu popup
 * 
 */
function stickHideNoteActionsMenu() {
    if (Ext.get('stickNoteActionsBox').isVisible() === false) {
        return;
    }
    if (stickGlobal.noteActionsMenuTimeout) {
        clearTimeout(stickGlobal.noteActionsMenuTimeout);
        stickGlobal.noteActionsMenuTimeout = null;
    }
    stickGlobal.noteActionsMenuTimeout = setTimeout(function() {
        stickHideNoteActionsMenuNoDelay();
    }, 300);
}
/**
 * 
 * Display the reply actions menu at near the link clicked.
 * 
 * 
 * 
 * @param evt
 * 
 * @returns {Boolean}
 * 
 */
function stickShowReplyActionsMenu(evt) {
    var logger = new stickobjLogger(arguments);
    if (stickHasValue(stickGlobal.replyActionsMenuTimeout)) {
        clearTimeout(stickGlobal.replyActionsMenuTimeout);
    }
    var x = Ext.get('stickReplyActionsBox');
    if (x.isVisible()) {
        return;
    }
    var target = evt.target;
    // get parent reply box
    var dReplyBox = Ext.get(target).findParent('.stickReply');
    logger.log('dReplyBox=' + dReplyBox);
    stickGlobal.currentReplyId = dReplyBox.getAttribute('data-internalid');
    logger.log('stickGlobal.currentReplyId=' + stickGlobal.currentReplyId);
    // get Actions link
    var xLink = Ext.get('stickReplyActionLink' + stickGlobal.currentReplyId);
    xLink.addClass('stick-menu-link-hover');
    xLink.removeClass('stick-menu-link-normal');
    stickHideNoteActionsMenu();
    var xTarget = Ext.get(target);
    x.setTop(xTarget.getTop() + xTarget.getHeight() - 2);
    x.setLeft(xTarget.getLeft());
    x.dom.style.position = 'absolute';
    x.show();
    // // set name of stickCollapseOrExpandReplies
    // var xNote = Ext.get('stick' + stickGlobal.currentNoteId);
    // var curRepliesPosition = xNote.dom.getAttribute('data-replies-position');
    // var collapseOrExpandLabel = curRepliesPosition === 'lined' ? 'Pile
    // replies' : 'Line-up replies';
    // Ext.get('stickCollapseOrExpandReplies').update(collapseOrExpandLabel);
    return false;
}
/**
 * 
 * Executes a suitelet asynchronously and returns the response as object.
 * 
 * 
 * 
 * @param {string}
 * 
 * action - the action that will be executed which corresponds to a case
 * 
 * in the switch statement.
 * 
 * @param {any}
 * 
 * values - action parameter. This can be a simple string, number, JSON,
 * 
 * array or any object that can be JSON.stringifyied.
 * 
 * @param {function}
 * 
 * callback - function that will be called upon completion of the action.
 * 
 * The back end suitelet return value is passed as the lone argument to
 * 
 * this function.
 * 
 * @param {boolean}
 * 
 * useAdminCredentials - True to use the admin back end suitelet.
 * 
 * Defaults to true. Use stickSuiteletProcessAsyncUser() if you want to
 * 
 * use the user back end suitlet.
 * 
 */
function stickSuiteletProcessAsync(action, values, callback, useAdminCredentials) {
    var logger = new stickobjLogger(arguments, true);
    if (typeof useAdminCredentials == 'undefined') {
        useAdminCredentials = true;
    }
    var xmlRequest = new XMLHttpRequest();
    try {
        // var logger = new stickobjLogger(arguments);
        window.status = 'Processing ' + action + '... ';
        // logger.log('action=' + action);
        var data = {};
        data.action = action;
        data.values = values;
        var url = null;
        // logger.log('useAdminCredentials=' + useAdminCredentials);
        if (useAdminCredentials) {
            if (stickHasNoValue(stickGlobal.stickSuiteletProcessAsyncUrl)) {
                url = nlapiResolveURL('SUITELET', 'customscript_stick_admin_backend_sl', 'customdeploy_stickease_admin_backend_sl');
                stickGlobal.stickSuiteletProcessAsyncUrl = url;
            } else {
                url = stickGlobal.stickSuiteletProcessAsyncUrl;
            }
        } else {
            if (stickHasNoValue(stickGlobal.stickSuiteletProcessAsyncUrlUser)) {
                url = nlapiResolveURL('SUITELET', 'customscript_stick_user_backend_sl', 'customdeploy_stickease_user_backend_sl');
                stickGlobal.stickSuiteletProcessAsyncUrlUser = url;
            } else {
                url = stickGlobal.stickSuiteletProcessAsyncUrlUser;
            }
        }
        logger.logAlways('===========================================================');
        logger.logAlways('AJAX CALL action=' + action + '; values=' + JSON.stringify(values));
        xmlRequest.onreadystatechange = function() {
            // logger.log('xmlRequest.readyState=' + xmlRequest.readyState);
            // logger.log('xmlRequest.status=' + xmlRequest.status);
            if (xmlRequest.readyState == 4) {
                if (xmlRequest.status == 200) {
                    // success
                    var returnValue = stickHandleResponse(xmlRequest);
                    callback(returnValue);
                } else {
                    var text = xmlRequest.responseText;
                    if (text.indexOf('Please provide more detailed keywords so your search does not return too many results') > -1) {
                        setTimeout("Ext.get('placeHolderColleagueOthers').update('Please provide more detailed keywords so your search does not return too many results', 'SuiteSocial');", 500);
                        callback([]);
                        return;
                    }
                    // stickShowError(text, 'Unexpected Error');
                    callback([]);
                    return;
                    // if(text.indexOf('Could not determine customer compid') >
                    // -1){
                    // stickShowError('Check if you are still logged into
                    // NetSuite.', 'Unexpected Error');
                    // return;
                    // }
                }
                window.status = 'Ready';
            }
        };
        // parameters
        logger.log('url=' + url);
        xmlRequest.open('POST', url, true /* async */);
        xmlRequest.setRequestHeader("Content-Type", "application/json");
        xmlRequest.send(JSON.stringify(data));
        return;
    } catch (e) {
        alert('stickSuiteletProcessAsync(). action=' + JSON.stringify(action) + '; values=' + JSON.stringify(values) + stickGetErrorDetails(e) + '<br />xmlRequest.responseText=' + xmlRequest.responseText);
    }
}
function stickSuiteletProcessAsyncUser(action, values, callback) {
    stickSuiteletProcessAsync(action, values, callback, false /* useAdminCredentials */);
}
function stickMarkAsDone(noteId) {
    var logger = new stickobjLogger(arguments);
    stickHideNoteActionsMenuNoDelay();
    noteId = noteId || stickGlobal.currentNoteId;
    logger.log('noteId=' + noteId);
    if (stickHasNoValue(noteId)) {
        stickShowError('stickMarkAsDone() stickHasNoValue(noteId)');
        return;
    }
    // HACK: bring the dialog below the MsgBox
    // the zindex of the Msgbox is 9003
    var xSelected = Ext.get('stickNoteSelected');
    if (stickIsNoteThreadVisible()) {
        xSelected.setStyle({
            'z-index' : 9002
        });
    }
    Ext.Msg.show({
        title : stickGlobal.TITLE,
        msg : 'Mark as "Done"?',
        buttons : Ext.Msg.YESNOCANCEL,
        width : 187,
        fn : stickMarkAsDoneCallback,
        icon : Ext.MessageBox.INFO,
        buttons : {
            ok : "Yes",
            cancel : "No"
        },
        minWidth : 220,
        noteId : noteId
    });
}
function stickMarkAsDoneCallback(btn, e, rec) {
    var xSelected = Ext.get('stickNoteSelected');
    if (stickIsNoteThreadVisible()) {
        xSelected.setStyle({
            'z-index' : 9004
        });
    }
    if (btn !== 'ok') {
        return;
    }
    var noteId = rec.noteId;
    // JC : Updates note status to completed
    stickSuiteletProcessAsync('markAsDone', noteId, function(isOK) {
        if (isOK == 'ok') {
            // Ext.get('stickBox' + noteId).setStyle('text-decoration',
            // 'line-through');
            Ext.select('#stickBox' + noteId + ' .stick-parent .stick-message').setStyle('text-decoration', 'line-through');
            if (stickIsListView()) {
                Ext.select('#stickBoxList' + noteId + ' .stick-message').setStyle('text-decoration', 'line-through');
                var link = Ext.select('#stickBoxList' + noteId + ' .stick-mark-as-done-link').elements[0];
                stickSetLinkDisabled(link, 'This note has been marked as done.');
                // TODO: find a way to make animation work on list view and we
                // can remove this update store
                stickGlobal.store.findRecord('internalid', noteId).set('custrecord_sn_status', 'completed');
                stickProcessRenderedNotes();
            }
        }
    });

    // Issue 327805 : [StickyNotes] StickyNotes Board > Thread Window > Actions
    // > Mark as Done is not working > xSelected is not defined
    if (stickIsNoteThreadVisible()) {
        stickWait();
        Ext.select('.x-window').hide();
    }
}





function fnOnNoteKeyDown(e)
{
    if(Ext.get('tbl_stickbtnNewNote').dom.style["pointer-events"] == "none")  //Submit button disabled?
    {
        return;
    }
    
    var kbShortcut = stickGlobal.paramUserPref.kbShortcut !== undefined? stickGlobal.paramUserPref.kbShortcut: nlapiGetContext().getPreference("custscript_stick_submit_keyboardshortcut");
    var isSubmit = (kbShortcut == "1" && e.ctrlKey && e.getKey() == Ext.EventObject.ENTER) ||
                   (kbShortcut == "2" && e.shiftKey && e.getKey() == Ext.EventObject.ENTER);
    if(isSubmit)
    {
        Ext.get('stickNewNoteButton').dom.click();
        return false;
    }
}





function fnOnReplyKeyDown(e)
{
    if(Ext.get('tbl_stickbtnReply').dom.style["pointer-events"] == "none")  //Submit button disabled?
    {
        return;
    }
    
    var kbShortcut = stickGlobal.paramUserPref.kbShortcut !== undefined? stickGlobal.paramUserPref.kbShortcut: nlapiGetContext().getPreference("custscript_stick_submit_keyboardshortcut");
    var isSubmit = (kbShortcut == "1" && e.ctrlKey && e.getKey() == Ext.EventObject.ENTER) ||
                   (kbShortcut == "2" && e.shiftKey && e.getKey() == Ext.EventObject.ENTER);
    if(isSubmit)
    {
        Ext.get('stickReplyButton').dom.click();
        return false;
    }
}





function stickNewReply() {
    var logger = new stickobjLogger(arguments);
    stickHideNoteActionsMenuNoDelay();

    Ext.get('stickInfoReplyNew').update('');
    var x = Ext.get('stickNewReplyEntry');
    var zIndex = 9004;
    if (stickGlobal.isBoard) {
        zIndex = 9999;
    }
    x.setStyle({
        'z-index' : zIndex
    });
    x.dom.setAttribute('data-nodeId', stickGlobal.currentNoteId);
    x.center();
    stickWait('.');
    x.fadeIn({
        callback : function() {
            Ext.get('stickReplyTextArea').dom.value = '';

            // apply dnd on text area of reply
            stickEnableDnDOnNewNote(false, 'stickReplyTextArea', 'stickNewReplyEntry');

            Ext.get('stickReplyTextArea').focus();
        }
    });
    Ext.get('stickReplyButton').dom.disabled = false;
    Ext.get('stickReplyTextArea').on("keydown", fnOnReplyKeyDown);
    logger.log('end');
}





function stickCollapseOrExpandReplies(e) {
    var logger = new stickobjLogger(arguments);
    stickHideNoteActionsMenuNoDelay();
    e = e || window.event;
    // var target = e.target || e.srcElement;
    var noteId = stickGlobal.currentNoteId;
    logger.log('noteId=' + noteId);
    var curRepliesPosition = jStick('#stick' + noteId).attr('data-replies-position');
    // var xBox = Ext.get('stickReplyBox' + noteId);
    // var xLink = Ext.get('stickCollapseOrExpand' + noteId);
    logger.log('curRepliesPosition=' + curRepliesPosition);
    if (curRepliesPosition == 'piled') {
        logger.log('expand');
        stickExpandReplies(noteId);
    } else {
        logger.log('collapse');
        stickCollapseReplies(noteId);
    }
    stickStopPropagation(e);
    logger.log('end');
}

/**
 * Sets the min height of note elements
 */
function stickSetNoteMinHeight() {

    // parent note
    var noteHeight = stickGetNoteSize().height;
    noteHeight = parseInt(noteHeight.replace('px', ''), 10);
    jStick('.stick-parent').height(noteHeight);
    jStick('.stick-message').css({
        minHeight : stickGetMessageHeight()
    });

    // reply box
    jStick('.stickReply').css({
        minHeight : noteHeight
    });

    // reply message
    var selector = '.stick-message-reply';
    jStick(selector).css({
        minHeight : stickGetReplyHeight()
    });
}

function stickCollapseReplies(noteId) {
    var logger = new stickobjLogger(arguments);

    // restore replies
    Ext.select('#stickBox' + noteId + ' .stick-message-reply').setHeight(stickGetReplyHeight());

    var noteHeight = stickGetNoteSize().height;
    noteHeight = parseInt(noteHeight.replace('px', ''), 10);
    Ext.select('#stickBox' + noteId + ' .stickReply').setHeight(noteHeight);

    // restore parent note
    stickSetNoteHeightToFixed(noteId);

    // hide image preview
    stickToggleImagePreview(noteId, false /*isNote*/, true /*isCollapsed*/);

    noteHeight -= 20; // margins
    noteHeight -= 10; // distance between replies

    var marginTopReply = -1 * noteHeight;
    if (Ext.isIE) {
        // marginTopReply += 15;
    }
    jStick('#stickReplyBox' + noteId + ' .stickReply').animate({
        'margin-top' : marginTopReply
    }, 250);
    // adjust the box of the replies
    var marginTopBox = noteHeight;
    if (Ext.isIE) {
        marginTopBox -= 15;
    }
    jStick('#stickReplyBox' + noteId).animate({
        'margin-top' : marginTopBox
    }, 250);
    jStick('#stick' + noteId).attr('data-replies-position', 'piled');

    stickShowToolTips(noteId);
}

/**
 * Expands the parent note and replies. If the message is long, the note's
 * height adjusts depending on the message content.
 * 
 * @param {integer}
 *        noteId - internal id of the note
 */
function stickExpandReplies(noteId) {
    var logger = new stickobjLogger(arguments);
    stickSetNoteMinHeight();

    // adjust replies
    var selector = '#stickBox' + noteId + ' .stickReply';
    selector += ', #stickBox' + noteId + ' .stick-note-inner';
    selector += ', #stickBox' + noteId + ' .stick-note-inner .stick-message-reply';
    Ext.select(selector).setStyle({
        'height' : 'auto'
    });

    // adjust parent note
    stickSetNoteHeightToAuto(noteId);
    
    // show image preview
    stickToggleImagePreview(noteId, false /*isNote*/, false /*isCollapsed*/);

    jStick('#stickReplyBox' + noteId + ' .stickReply').animate({
        'margin-top' : -10
    }, 250);
    jStick('#stickReplyBox' + noteId).animate({
        'margin-top' : -10
    }, 250);
    jStick('#stick' + noteId).attr('data-replies-position', 'lined');

    stickHideToolTips(noteId);

}

/**
 * Displays the file-icon/filename instead of image preview if collapsed.
 * @param noteId
 */
function stickToggleImagePreview(noteId, isNote, isCollapsed, iIndex) {
    var parentElem = '#' + (isNote ? 'stick' : 'stickReplyBox') + noteId;
    // collapse image files
    var selector = parentElem + ' .stick-file .preview.has';
    var jPreview = stickHasValue(iIndex) ? jStick(jStick(selector).get(iIndex)) : jStick(selector);
    jPreview.css('display', isCollapsed ? 'none' : '');
    jPreview.siblings('.link').css('display', isCollapsed ? '' : 'none');
}

/**
 * Adjusts the tooltip content to show the image preview.
 * 
 * @param {String} tooltip
 * @returns {String}
 */
function stickAdjustTooltipContent(tooltip) {
    var jMsg = jStick("<span>").html(tooltip);
    var imgPrvw = jMsg.find('.stick-file .preview.has');
    imgPrvw.css('display', '');
    imgPrvw.siblings('.link').css('display', 'none');
    return jMsg.html();
}

/**
 * Adjusts the height of the parent note so that the whole content will be
 * displayed
 * 
 * @param {integer}
 *        noteId - internal id of the note
 */
function stickSetNoteHeightToAuto(noteId) {
    // adjust parent note

    // Issue 337676 : [StickyNotes] StickyNotes Board > Notes in grid view
    // expands when you create a new reply in pop up view
    var selectedNoteId = '';
    if (stickGlobal.isBoard && stickGlobal.showGrid) {
        selectedNoteId = '#stickNoteSelected ';
    }

    var selector = selectedNoteId + '#stickBox' + noteId + ' .stick-parent';
    selector += ', ' + selectedNoteId + ' #stickBox' + noteId + ' .stick-note-inner';
    selector += ', ' + selectedNoteId + ' #stickBox' + noteId + ' .stick-message';
    jStick(selector).height('auto');
    
    stickToggleImagePreview(noteId, true /*isNote*/, false /*isCollapsed*/);

    var $note = jStick('#stick' + noteId);
    $note.attr('data-autosizeheight', 'yes');
    // hide tooltip
    selector = '#stickBox' + noteId + ' .stick-message';
    jStick(selector).attr('data-qtip', '');
}

/**
 * Sets the note height to the default size
 * 
 * @param {integer}
 *        noteId - internal id of the note
 */
function stickSetNoteHeightToFixed(noteId) {
    var noteHeight = stickGetNoteSize().height;
    noteHeight = parseInt(noteHeight.replace('px', ''), 10);

    var selector = '#stickBox' + noteId + ' .stick-parent';
    jStick(selector).height(noteHeight);
    
    stickToggleImagePreview(noteId, true /*isNote*/, true /*isCollapsed*/);

    var $note = jStick('#stick' + noteId);
    $note.attr('data-autosizeheight', 'no');

    selector = '#stickBox' + noteId + ' .stick-message';
    $messages = jStick(selector);
    $messages.height(stickGetMessageHeight());

    // show tooltip if needed
    var el = $messages[0];
    var elPreviewImage = $messages.find('.stick-file .preview.has');
    if (el.scrollHeight > jStick(el).height() || elPreviewImage.length > 0) {
        jStick(el).attr('data-qtip', stickAdjustTooltipContent(el.innerHTML));
    }
}

function stickGetNoteSize() {
    var noteSize = stickGlobal.dataSet.noteSize;
    return noteSize;
}
function stickDeleteNote(noteId) {
    stickHideNoteActionsMenuNoDelay();
    noteId = noteId || stickGlobal.currentNoteId;
    // HACK: bring the dialog below the MsgBox
    // the zindex of the Msgbox is 9003
    var xSelected = Ext.get('stickNoteSelected');
    if (xSelected !== null && xSelected.isVisible()) {
        xSelected.setStyle({
            'z-index' : 9002
        });
    }
    Ext.Msg.show({
        title : stickGlobal.TITLE,
        msg : 'Delete this note?',
        buttons : Ext.Msg.YESNOCANCEL,
        fn : stickDeleteNoteCallback,
        icon : Ext.MessageBox.INFO,
        buttons : {
            ok : "Yes",
            cancel : "No"
        },
        minWidth : 220,
        noteId : noteId
    });
}
function stickDeleteNoteCallback(btn, e, rec) {
    var xSelected = Ext.get('stickNoteSelected');
    if (xSelected !== null && xSelected.isVisible()) {
        xSelected.setStyle({
            'z-index' : 9004
        });
        stickWait();
    }
    if (btn !== 'ok') {
        return false;
    }
    var noteId = rec.noteId;
    jStick('.stickNoteInfo' + noteId).html('<br>Deleting...');
    // JC : Deletes note in server by passing note id
    stickSuiteletProcessAsync('deleteNote', noteId, function(isOK) {
        if (isOK == 'ok') {
            // jStick('#stickBox' + noteId).fadeOut();
            // jStick('#stickBoxList' + noteId).hide('explode');
            // Ext.select('#stickBoxList' + noteId).remove();
            if (stickHasValue(stickGlobal.store)) {
                // board
                stickRemoveInBoard(noteId);
                var xSelected = Ext.get('stickNoteSelected');
                if (xSelected !== null && xSelected.isVisible()) {
                    Ext.Msg.hide();
                    xSelected.hide();
                    // remove the currently displayed note and replies
                    xSelected.select('.stickBox').update('');
                }
            } else {
                jStick('#stickBox' + noteId).hide('explode');
                Ext.select('#stickBox' + noteId).remove();
            }
        }
    });
}
function stickRemoveInBoard(noteId) {
    if (stickGlobal.isBoard === false) {
        return;
    }
    // when in board
    var selector;
    if (stickGlobal.showGrid) {
        selector = '#stickBox' + noteId;
    } else {
        selector = '#stickBoxList' + noteId;
    }
    jStick(selector).hide({
        duration : 400,
        effect : 'blind',
        complete : function() {
            // set category name to empty so that it will be filtered
            // out
            stickGlobal.store.findRecord('internalid', noteId).data.categoryName = '';
            stickFilterNotesInBoard();
        }
    });
}
function stickArchiveNote(noteId) {
    stickHideNoteActionsMenuNoDelay();
    noteId = noteId || stickGlobal.currentNoteId;
    if (stickHasNoValue(noteId)) {
        uiShowError('stickArchiveNote() stickHasNoValue(noteId)');
        return;
    }
    // HACK: bring the dialog below the MsgBox
    // the zindex of the Msgbox is 9003
    var xSelected = Ext.get('stickNoteSelected');
    if (xSelected !== null && xSelected.isVisible()) {
        xSelected.setStyle({
            'z-index' : 9002
        });
    }
    Ext.Msg.show({
        title : stickGlobal.TITLE,
        msg : 'Archive this note?',
        buttons : Ext.Msg.YESNOCANCEL,
        fn : stickArchiveNoteCallback,
        icon : Ext.MessageBox.INFO,
        buttons : {
            ok : "Yes",
            cancel : "No"
        },
        minWidth : 220,
        noteId : noteId
    });
}
function stickArchiveNoteCallback(btn, e, rec) {
    var xSelected = Ext.get('stickNoteSelected');
    if (xSelected !== null && xSelected.isVisible()) {
        xSelected.setStyle({
            'z-index' : 9004
        });
        stickWait();
    }
    if (btn !== 'ok') {
        return false;
    }
    var noteId = rec.noteId;
    stickSuiteletProcessAsync('archiveNote', noteId, function(isOK) {
        if (isOK == 'ok') {
            if (stickGlobal.isBoard) {
                stickRemoveInBoard(noteId);
                // hide the note thread
                var xSelected = Ext.get('stickNoteSelected');
                if (xSelected !== null && xSelected.isVisible()) {
                    Ext.Msg.hide();
                    xSelected.hide();
                    // remove the currently displayed note and replies
                    xSelected.select('.stickBox').update('');
                }
            } else {
                var xStickBox = Ext.get('stickBox' + noteId);
                if (xStickBox) {
                    jStick('#stickBox' + noteId).hide('fold');
                    xStickBox.remove();
                }
            }
        }
    });
}
/**
 * 
 * Re-render the note. This is called when a reply id added.
 * 
 */
function stickRepaintNoteReplies(noteId) {
    var logger = new stickobjLogger(arguments);
    var curRepliesPosition = jStick('#stick' + noteId).attr('data-replies-position');
    logger.log('curRepliesPosition=' + curRepliesPosition);
    if (curRepliesPosition == 'piled') {
        stickCollapseReplies(noteId);
    } else {
        stickExpandReplies(noteId);
    }
    Ext.select('#stick' + noteId + ' .stickReplyBox .stick-note-inner div').setHeight(stickGetLineHeight());
    if (stickIsMobile()) {
        Ext.select('.stick-reply-delete, .stick-action-link').show();
    }
}
function stickIsNoteThreadVisible() {
    if (stickGlobal.isBoard === false) {
        return false;
    }
    return Ext.get('stickNoteSelected').isVisible();
}
function stickShowReplyIcon(replyId) {
    var logger = new stickobjLogger(arguments);
    if (stickGlobal.isBoard === false) {
        logger.log('exiting... stickGlobal.isBoard === false');
        return;
    }
    var noteInternalId;
    if (stickHasNoValue(replyId)) {
        noteInternalId = stickGlobal.currentNoteId;
    } else {
        var xReply = Ext.get('stickReply' + replyId);
        var selector;
        if (stickIsListView()) {
            selector = '.stickNoteLi';
        } else {
            selector = '.stickBox';
        }
        var xNoteBox = xReply.findParent(selector, 50, true);
        noteInternalId = xNoteBox.getAttribute('data-internalid');
    }
    logger.log('noteInternalId=' + noteInternalId);
    E4S.select('[data-internalid=' + noteInternalId + '] .stick-with-reply').setStyle({
        display : 'inline',
        visibility : 'visible'
    });
    // }
}
function stickSaveReplyNew() {
    var logger = new stickobjLogger(arguments);
    var noteId = jStick('#stickNewReplyEntry').attr('data-nodeId');// ..stickGlobal.currentNoteId;
    var reply = Ext.get('stickReplyTextArea').dom.value.trim();
    if (reply === '') {
        Ext.get('stickReplyInfo').update('Please provide a reply.');
        return;
    }
    // the max length allowed is 4000 but we need to allot around 500 when the
    // message is encoded in html
    if (reply.length > 3500) {
        Ext.get('stickReplyInfo').update('Reply should not be more than 3,500 characters.');
        Ext.get('stickReplyTextArea').dom.focus();
        return;
    }
    Ext.get('stickReplyButton').dom.disabled = true;
    var param = {};
    param.noteId = noteId;
    param.reply = Ext.get('stickReplyTextArea').dom.value;
    // include file attached if any
    param.file = stickHasValue(stickGlobal.fileDnD) ? stickGlobal.fileDnD.getFileDetails() : '';
    param.isBoard = stickGlobal.isBoard;

    // stickWait();
    Ext.get('stickInfoReplyNew').show();
    // JC : Creates a new reply to a specific post
    stickSuiteletProcessAsync('addReply', param, function(replies) {
        // clear and hide file info
        if (stickHasValue(stickGlobal.fileDnD)) {
            stickGlobal.fileDnD.clearAndHideFileInfo();
        }
        // alert(replies.length);
        // stickTemplateAppendReplies(replies);
        Ext.get('stickInfoReplyNew').hide();
        Ext.get('stickReplyTextArea').dom.value = '';
        Ext.get('stickReplyTextArea').update('');
        if (stickHasNoValue(Ext.get('stickNoteSelected')) || !Ext.get('stickNoteSelected').isVisible()) {
            Ext.Msg.hide();
        }
        Ext.get('stickNewReplyEntry').hide();
        var noteId = stickGlobal.currentNoteId; // replies[0].custrecord_snr_note;
        logger.log('noteId=' + noteId);
        Ext.select('#stick' + noteId + ' .stick-with-reply').show();
        var replyId = replies[0].internalid;
        if (stickGlobal.isBoard) {
            // logger.log('JSON.stringify(replies)=' + JSON.stringify(replies));
            // alert(noteId)
            // Ext.get('stickReplyBox' + noteId).dom.style.display = 'block';
            stickShowReplyIcon();
            if (Ext.select('#stickNoteSelected .stickReplyBox').elements.length === 0) {
                return;
            }
            var stickReplyBoxId = Ext.select('#stickNoteSelected .stickReplyBox').elements[0].id;
            stickTemplateAppend('tmpReply', stickReplyBoxId, replies);
            stickSetMouseEventsForReplies();
            // TODO: refactor this and the code below since they have common
            // code
            // logger.log('replies[0].internalid=' + replies[0].internalid);
            var newReplyElementId = 'stickReply' + replyId;
            // resize based on the user/account setting
            var xReply = Ext.get(newReplyElementId);
            xReply.setStyle(stickGlobal.dataSet.noteSize);
            // set font size
            xReply.select('.stick-note-inner div').setStyle({
                'font-size' : stickGlobal.dataSet.fontSize
            });
            // set reply height
            xReply.select('.stick-message-reply').setHeight(stickGetReplyHeight());
            // get number of replies and use it as z-index of the new reply
            var replyCount = jStick('#stickNoteSelected .stickReply').length;
            var zIndex = replyCount + 1;
            if (stickIsNoteThreadVisible()) {
                zIndex += 2000;
                jStick('#stickNoteSelected .stickReplyBox').show();
            }
            xReply.setStyle({
                'z-index' : zIndex
            });
            // Ext.get(newReplyElementId).highlight();
            // jStick('#' + newReplyElementId).effect('bounce', null, 400);
            jStick('#stick' + noteId).attr('data-replies-position', 'lined');
            stickRepaintNoteReplies(noteId);
            jStick('.stick-delete').attr('src', stickGlobal.dataSet['stick-delete.png']);
            // xReply.scrollIntoView();
            setTimeout(function() {
                jStick('html, body').animate({
                    scrollTop : jStick('#' + newReplyElementId).offset().top - 20
                }, 400);
            }, 250);
            return;
        }
        // logger.log('JSON.stringify(replies)=' + JSON.stringify(replies));
        // alert(noteId)
        Ext.get('stickReplyBox' + noteId).dom.style.display = 'block';
        stickTemplateAppend('tmpReply', 'stickReplyBox' + noteId, replies);
        stickSetMouseEventsForReplies();
        // logger.log('replies[0].internalid=' + replies[0].internalid);
        var newReplyElementId = 'stickReply' + replyId;
        // resize based on the user/account setting
        var xReply = Ext.get(newReplyElementId);
        xReply.setStyle(stickGlobal.dataSet.noteSize);
        // set font size
        xReply.select('.stick-note-inner div').setStyle({
            'font-size' : stickGlobal.dataSet.fontSize
        });
        // set reply height
        xReply.select('.stick-message-reply').setHeight(stickGetReplyHeight());
        // get number of replies and use it as z-index of the new reply
        var replyCount = jStick('#stickReplyBox' + noteId + ' .stickReply').length;
        xReply.setStyle({
            'z-index' : replyCount + 1
        });
        xReply.scrollIntoView();
        // set tooltip if message is long
        var elReplyMessage = xReply.select('.stick-message-reply').elements[0];
        var elReplyPreviewImage = Ext.get(elReplyMessage).query('.stick-file .preview.has');
        if (elReplyMessage.scrollHeight > Ext.get(elReplyMessage).getHeight() || elReplyPreviewImage.length > 0) {
            elReplyMessage.setAttribute('data-qtip', stickAdjustTooltipContent(elReplyMessage.innerHTML));
        }
        // Ext.get(newReplyElementId).highlight();
        // jStick('#' + newReplyElementId).effect('bounce', null, 400);
        stickRepaintNoteReplies(noteId);
        jStick('.stick-delete').attr('src', stickGlobal.dataSet['stick-delete.png']);
        setTimeout(function() {
            xReply.scrollIntoView();
        }, 250);
    });
}

function stickCloseReplyNew() {
    // define local function to close new reply
    function closeReply() {
        if (stickHasNoValue(Ext.get('stickNoteSelected')) || !Ext.get('stickNoteSelected').isVisible()) {
            Ext.Msg.hide();
        };
        Ext.get('stickNewReplyEntry').fadeOut();
        Ext.get('stickReplyInfo').update('');
    }
    
    // check if has file attached
    if (stickHasValue(stickGlobal.fileDnD)) {
        var fileInfo = stickGlobal.fileDnD.getFileDetails();
        if (stickHasValue(fileInfo)) {
            // ask to delete on close of new reply
            
            stickShowExtMessage('stickNewReplyEntry', {
                title : stickGlobal.TITLE,
                msg : 'You have an uploaded file.  Do you want to cancel this upload?',
                buttons : Ext.Msg.YESNOCANCEL,
                fn : function(btn) {
                    console.log('btn = ' + btn);
                    if (btn == 'ok') {
                        // delete and clear file
                        stickDeleteUploadedFile(fileInfo);
                        stickGlobal.fileDnD.clearAndHideFileInfo();
                        // proceed to close new reply
                        closeReply();
                        return;
                    }
                    stickWait('Please wait...');
                },
                icon : Ext.MessageBox.INFO,
                buttons : {
                    ok : "Yes",
                    cancel : "No"
                },
                minWidth : 220
            });
            return;
        }
    }
    
    // proceed to close new reply
    closeReply();
}

/**
 * Re-displays the tooltips for note with long content
 * 
 * @param {integer}
 *        noteId - internal id of the note
 */
function stickShowToolTips(noteId) {
    var selector = '#stickBox' + noteId + ' .stick-message';
    selector += ', #stickBox' + noteId + ' .stick-message-reply';
    var $notes = jStick(selector);
    $notes.each(function(i, el) {
        // set tooltip if message is long
        var elPreviewImage = jStick(el).find('.stick-file .preview.has');
        if (el.scrollHeight > jStick(el).height() || elPreviewImage.length > 0) {
            el.setAttribute('data-qtip', stickAdjustTooltipContent(el.innerHTML));
        }
    });
}

/**
 * Hides tooltips for note with long content
 * 
 * @param {integer}
 *        noteId - internal id of the note
 */
function stickHideToolTips(noteId) {
    var selector = '#stickBox' + noteId + ' .stick-message';
    selector += ', #stickBox' + noteId + ' .stick-message-reply';
    var $notes = jStick(selector);
    $notes.attr('data-qtip', '');
}

function stickDeleteReply(replyId) {
    var logger = new stickobjLogger(arguments);
    stickGlobal.currentReplyId = replyId;
    if (stickGlobal.isBoard) {
        // HACK: bring the dialog bewo the MsgBox
        // the zindex of the Msgbox is 9003
        Ext.get('stickNoteSelected').setStyle({
            'z-index' : 9002
        });
    }
    Ext.Msg.show({
        title : stickGlobal.TITLE,
        msg : 'Delete this reply?',
        buttons : Ext.Msg.YESNOCANCEL,
        fn : stickDeleteReplyCallback,
        icon : Ext.MessageBox.INFO,
        buttons : {
            ok : "Yes",
            cancel : "No"
        },
        minWidth : 220,
    });
}
function stickDeleteReplyCallback(btn, e, rec) {
    if (stickGlobal.isBoard) {
        // HACK: bring the dialog on top again
        stickWait();
        Ext.get('stickNoteSelected').setStyle({
            'z-index' : 9004
        });
    }
    if (btn == 'cancel') {
        return false;
    }
    // JC : Deletes reply in server by passing reply id
    stickSuiteletProcessAsync('deleteReply', stickGlobal.currentReplyId, function(isOK) {
        if (isOK != 'ok') {
            return;
        }
        // stickAnimateHide(Ext.get('stickReply' + id));
        // stickAnimate(Ext.get('stickReply' + id), function(){
        // Ext.get('stickReply' + id).remove();
        // });
        jStick('#stickReply' + stickGlobal.currentReplyId).toggle('explode', {
            size : 100
        }, 500, function() {
            var xReply = Ext.get('stickReply' + stickGlobal.currentReplyId);
            // remove reply icon if there no more replies
            var xReplyBox = xReply.findParent('.stickReplyBox', 50, true);
            // console.log(xReplyBox.select('.stickReply').elements.length)
            var replyCount = xReplyBox.select('.stickReply').elements.length;
            // we compare against 1 since we havent removed the element
            if (replyCount === 1) {
                var xNoteBox = xReply.findParent('.stickBox', 50, true);
                var noteInternalId = xNoteBox.getAttribute('data-internalid');
                E4S.select('[data-internalid=' + noteInternalId + '] .stick-with-reply').setStyle({
                    display : 'none'
                });
            }
            xReply.remove();
        });
    });
}
function stickNoteClicked(evt) {
    var logger = new stickobjLogger(arguments);
    evt = evt || window.event;
    var target = evt.target || evt.srcElement;
    // get parent note
    var dNote = Ext.get(target).findParent('.stickNote') || target;
    var noteId = dNote.getAttribute('data-internalid');
    if (stickHasNoValue(noteId)) {
        stickShowError(' stickHasNoValue(noteId) ');
        return false;
    }

    // check if file
    if (jStick(target).parents('.stick-file .preview, .stick-file .link').length > 0) {
        return false;
    }

    if (stickGlobal.isBoard === true) {
        if (stickGlobal.showGrid === true) {
            stickShowNoteThreadPopup(noteId);
        }

        if (evt.stopPropagation) {
            evt.stopPropagation();
        } else {
            evt.returnValue = false;
        }
        logger.log('exiting: board');
        return false;
    } else {

        // checks if event is click or drag
        if (jStick('#stickBox' + noteId).hasClass('dragStartCalled')) {
            // dragged
            jStick('#stickBox' + noteId).removeClass('dragStartCalled');
        } else {
            // clicked
            var $notes = jStick('#stick' + noteId);
            var autoSize = $notes.attr('data-autosizeheight');
            if (autoSize === 'yes') {
                stickSetNoteHeightToFixed(noteId);
            } else {
                stickSetNoteHeightToAuto(noteId);
            }
        }
    }
    logger.log('not board');
    evt = evt || window.event;
    
    stickSetNoteOnTop(noteId);
}

function stickSetNoteOnTop(noteId) {
    // get the highest z-index for notes
    var els = Ext.select('#stickNoteBox .stickBox').elements;
    if (els.length === 0) {
        // probably in board
        return false;
    }
    var maxZindex = 0;
    for (var i = 0; i < els.length; i++) {
        var zindex = els[i].style.zIndex;
        // logger.log('zindex=' + zindex);
        if (stickHasNoValue(zindex)) {
            continue;
        }
        if (parseInt(zindex) > maxZindex) {
            maxZindex = parseInt(zindex);
        }
    }

    // logger.log('maxZindex=' + maxZindex);
    var d = Ext.get('stickBox' + noteId).dom;
    if (d.style.zIndex == maxZindex) {
        return false;
    }
    maxZindex = maxZindex + 1;
    d.style.zIndex = maxZindex;
    var param = {
        noteId : noteId,
        zIndex : maxZindex
    };
    // logger.log('updateZIndex');
    stickSuiteletProcessAsync('updateZIndex', param, function(isOK) {
        if (isOK != 'ok') {
            throw 'error in updateZIndex';
        }
    });
}

function stickSetMouseEventsForReplies() {
    // ==================================
    // for replies
    // ==================================
    // Ext.select('.stickReply').on('mouseenter', function(e) {
    // // var logger = new stickobjLogger(arguments);
    // try {
    // if (e.target.id === '') {
    // return;
    // }
    // Ext.select('#stickNoteBox .stickShowOnHover').hide();
    // Ext.select('#' + e.target.id + ' .stickShowOnHover').show();
    // } catch (e) {
    // if (typeof console != 'undefined') {
    // console.error('postouter mouseenter ' + e);
    // }
    // }
    // });
    //
    // Ext.select('.stickReply').on('mouseleave', function(e) {
    // try {
    // Ext.select('#stickNoteBox .stickShowOnHover').hide();
    // return true;
    // } catch (e) {
    // if (typeof console != 'undefined') {
    // console.error('postouter mouseleave ' + e);
    // }
    //
    // }
    // });
    var selector = '.stickReply';
    jStick(selector).mouseenter(function(evt) {
        // stickShowNoteActionsMenu(evt);
        // var logger = new stickobjLogger('stickReply mouseenter');
        if (this.getAttribute('data-owner') != nlapiGetContext().getUser()) {
            return;
        }
        Ext.get(this.id.replace('stickReply', 'stickReplyActionLink')).show();
        // Ext.get(this).select('.stick-action-link').show();
    });
    jStick(selector).mouseleave(function(evt) {
        // var logger = new stickobjLogger('stickReply mouseleave');
        if (this.getAttribute('data-owner') != nlapiGetContext().getUser()) {
            return;
        }
        Ext.get(this.id.replace('stickReply', 'stickReplyActionLink')).hide();
    });

}
function stickSetOtherEvents() {
    // S3 - Issue 281157 : [StickyNotes] Pressing enter while composing a note
    // on a record on edit mode will submit the form
    jStick('#stickNote, #stickReplyTextArea').bind('keypress', function(e) {
        var code = e.keyCode || e.which;
        if (code == 13) { // Enter keycode
            if (e.stopPropagation) {
                e.stopPropagation();
            }
        }
    });
}

function stickApplyCSSToFolderTooltip() {

    Ext.select('.x-tip-body').setStyle({
        'padding' : '20px 20px 20px 20px',
        'font-size' : '13px',
        'color' : '#545454',
        'font-family' : 'Open Sans,Helvetica,sans-serif',
        'border-bottom-style' : 'none',
        'border-radius' : '0px',
        'background-color' : '#f0f0f0',
        'width' : 'auto'
    });

    Ext.select('#stickHelptext, #stickHelptext li, #stickHelptext b').setStyle({
        'font-size' : '13px',
        'color' : '#545454',
        'font-family' : 'Open Sans,Helvetica,sans-serif',
    });

    Ext.select('#stickHelptext b').setStyle({
        'font-weight' : 'bold'
    });

    Ext.select('.x-tip-body a').setStyle({
        'font-size' : '12px',
        'color' : '#255599',
        'font' : 'Open Sans,Light',
        'margin-top' : '3px',
        'margin-bottom' : '5px',
        'margin-left' : '4px',
        'text-decoration' : 'none'
    });

    Ext.select('.x-tip-mc').setStyle({
        'background-color' : '#f0f0f0',
        'box-shadow' : 'rgba(0, 0, 0, 0.6) 0px 2px 4px'
    });

    Ext.select('.x-tip-body hr').setStyle({
        'height' : '2px',
        'border-color' : 'rgba(235, 235, 235, 0.5)',
        'margin' : '6px 0 7px 0'
    });

    Ext.select('.dottedlink').setStyle({
        'color' : '#336699',
        'border-bottom-style' : 'none'

    });

    if (stickHasValue(Ext.select('.stickImgTooltipHelp'))) {
        Ext.select('.stickImgTooltipHelp').set({
            'src' : stickGlobal.dataSet['stick-help.png'],
            'style' : {
                'vertical-align' : 'middle'
            }
        });
    }
}

function stickShowExtMessage(elementId, msgBoxConfig) {
    // HACK: bring the element below the MsgBox; the zindex of the Msgbox is 9003
    Ext.get(elementId).setStyle({
        'z-index' : 9002
    });
    
    // bring back the zindex of the element on callback
    var origFn = msgBoxConfig.fn;
    msgBoxConfig.fn = function(btn, text) {
        // do provided fn callback
        if (stickHasValue(origFn)) {
            origFn(btn, text);
        }
        
        // HACK: bring the element on top again
        Ext.get(elementId).setStyle({
            'z-index' : 9004
        });
    };
    
    // show msgbox
    Ext.Msg.show(msgBoxConfig);
}

function stickEnableDnDOnNewNote(isNote, targetId, containerId) {
    // first, check preference if file attachments is allowed
    if (nlapiGetContext().getPreference('custscript_stick_allow_file_attach') != 'T') {
        // file attachment is disabled
        return;
    }

    // get image urls
    if (stickHasNoValue(stickGlobal.imageUrls)) {
        var imageUrls = jStick('#stickImageUrls');
        if (stickHasValue(imageUrls)) {
            stickGlobal.imageUrls = JSON.parse(imageUrls.text());
        }
    }
    
    // apply dnd on text area of note
    stickGlobal.fileDnD = new Suidgets.FileDragNDrop({
        target : targetId,
        transImgUrl : stickGlobal.imageUrls['img_trans.gif'],
        fileTypeSpriteImgUrl : stickGlobal.imageUrls['file-type-sprite.png'],
        cancelImgUrl : stickGlobal.imageUrls['cancel-sml.png'],
        onFileDrop : function(files) {
            // get files
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                console.log('file = ' + file.name);   
            }
            
            // check no. of files dropped
            var count = files.length;
            if (count === 0) {
                console.log('no files');
                return;
            }
            
            // check no. of files
            if (count > 1) {
                stickShowExtMessage(containerId, {
                    title : stickGlobal.TITLE,
                    msg : 'You can drop only one file at a time.',
                    width : 300,
                    buttons : Ext.MessageBox.OK,
                    icon : Ext.MessageBox.WARNING,
                    fn : function(btn, text) {
                        stickWait('Please wait...');
                    }
                 });
                return;
            }

            // check file size, do not allow more than 5mb
            var file = files[0];
            if (file.size > stickGlobal.MAXIMUM_FILE_SIZE) {
                stickShowExtMessage(containerId, {
                    title : stickGlobal.TITLE,
                    msg : 'The file ' + file.name + ' exceeds the maximum file size of 5MB.',
                    width : 300,
                    buttons : Ext.MessageBox.OK,
                    icon : Ext.MessageBox.WARNING,
                    fn : function(btn, text) {
                        stickWait('Please wait...');
                    }
                 });
                return;
            }
            
            // check for pending upload
            if (stickHasValue(stickGlobal.fileUploader)) {
                if (stickGlobal.fileUploader.hasUploadInProgress()) {
                    stickShowExtMessage(containerId, {
                        title : stickGlobal.TITLE,
                        msg : 'An upload is currently in progress.',
                        width : 300,
                        buttons : Ext.MessageBox.OK,
                        icon : Ext.MessageBox.WARNING,
                        fn : function(btn, text) {
                            stickWait('Please wait...');
                        }
                     });
                    return;
                }
            }
            
            // check for an uploaded file
            var fileInfo = stickGlobal.fileDnD.getFileDetails();
            if (stickHasValue(fileInfo)) {
                // ask to delete the uploaded one, and proceed with the new one
                stickShowExtMessage(containerId, {
                    title : stickGlobal.TITLE,
                    msg : 'There is already an uploaded file.  Do you want to cancel that upload and proceed with this new one?',
                    width : 300,
                    buttons : Ext.MessageBox.YESNOCANCEL,
                    icon : Ext.MessageBox.WARNING,
                    fn : function(btn, text) {
                        if (btn == 'yes') {
                            // delete uploaded file; then proceed with uploading the new one
                            stickDeleteUploadedFile(fileInfo);
                            // proceed to start uploading
                            stickUploadFile(isNote, file);
                        }
                        stickWait('Please wait...');
                    }
                });
                return;
            }

            // proceed to start uploading
            stickUploadFile(isNote, file);
        },
        onCancelUpload : function() {
            console.log('onCancelUpload');
            stickCancelFileUpload(isNote);
        },
        onDeleteUploaded : function(fileInfo) {
            console.log('onDeleteUploaded: fileInfo = ' + JSON.stringify(fileInfo));
            stickDeleteUploadedFile(fileInfo);
        }
    });
}

function stickUploadFile(isNote, file) {

    try {
        // get suitelet url
        var url = nlapiResolveURL('SUITELET', 'customscript_stick_file_dnd_sl', 'customdeploy_stick_file_dnd_sl');
        
        // upload file
        stickGlobal.fileUploader = new Suidgets.FileUpload({
            file : file,
            url : url,
            imagePreview : {
                generate : true,
                minWidthToGen : 150
            },
            onError : function(result) {
                console.error('on error : ' + JSON.stringify(result));
                // enable buttons
                stickEnableNoteReplyButtons(isNote, true);
            },
            onProgress : function(result) {
                // get progress
                if (stickHasValue(result)) {
                    console.log('on progress : ' + JSON.stringify(result));
                    
                    // update progress info to file dnd UI
                    stickGlobal.fileDnD.showUploadProgress({
                        progress : result.progress,
                        name : result.name
                    });
                }
            },
            onComplete : function(result) {
                // get file uploaded
                if (stickHasValue(result)) {
                    console.log('on complete : ' + JSON.stringify(result));
                    
                    // show file uploaded
                    stickGlobal.fileDnD.showFileUploaded({
                        name : result.origFileName,
                        extName : result.extName
                    });
                    // keep file info
                    stickGlobal.fileDnD.keepFileDetails({
                        fileName : result.fileName,
                        origFileName : result.origFileName,
                        extName : result.extName,
                        fileId : result.fileId,
                        previewFileId : result.previewFileId
                    });

                    // enable buttons
                    stickEnableNoteReplyButtons(isNote, true);
                }
            }
        });
        stickGlobal.fileUploader.beginUpload();
        
        // disable buttons
        stickEnableNoteReplyButtons(isNote, false);
    }
    catch(ex) {
        console.error('Error occurred: ' + ex);
    }
}

function stickCancelFileUpload(isNote) {
    // cancel file upload
    if (stickHasValue(stickGlobal.fileUploader)) {
        stickGlobal.fileUploader.abortUpload();
    }
    // enable buttons
    stickEnableNoteReplyButtons(isNote, true);
}

function stickDeleteUploadedFile(fileInfo) {
    // delete file uploaded
    if (stickHasValue(stickGlobal.fileUploader)) {
        stickSuiteletProcessAsync('deleteFile', {
            fileId : fileInfo.fileId,
            previewFileId : fileInfo.previewFileId
        }, function(result) {
            if (result != 'ok') {
                console.error('Delete failed: ' + result);
            } else {
                console.log('Delete success');
            }
        });
    }
}

function stickPreLoadStandardRecordsList() {
    // this will pre-load standard records list at the backend
    stickSuiteletProcessAsync('preLoadStandardRecords', 'any', function(isOK) {
        if (isOK != 'ok') {
            console.error('preLoadStandardRecords failed');
        }
    });
}

function stickEnableNoteReplyButtons(isNote, isEnable) {
    if (isNote) {
        stickEnableNoteButtons(isEnable);
    } else {
        stickEnableReplyButtons(isEnable);
    }
}

function stickEnableNoteButtons(isEnable) {
    if (isEnable) {
        // Save
        jQuery('#tbl_stickbtnNewNote').css('pointer-events', '');
        jQuery('#tr_stickbtnNewNote').removeClass('pgBntGDis pgBntBDis').addClass('pgBntG pgBntB');
        
        // Close
        jQuery('#tbl_stickbtnCancel').css('pointer-events', '');
        jQuery('#tr_stickbtnCancel').removeClass('tabBntDis').addClass('tabBnt');
    } else {
        // Save
        jQuery('#tbl_stickbtnNewNote').css('pointer-events', 'none');
        jQuery('#tr_stickbtnNewNote').removeClass('pgBntG pgBntB').addClass('pgBntGDis pgBntBDis');
        
        // Close
        jQuery('#tbl_stickbtnCancel').css('pointer-events', 'none');
        jQuery('#tr_stickbtnCancel').removeClass('tabBnt').addClass('tabBntDis');
    }
}

function stickEnableReplyButtons(isEnable) {
    if (isEnable) {
        // Save
        jQuery('#tbl_stickbtnReply').css('pointer-events', '');
        jQuery('#tr_stickbtnReply').removeClass('pgBntGDis pgBntBDis').addClass('pgBntG pgBntB');
        
        // Close
        jQuery('#tbl_stickbtnReplyCancel').css('pointer-events', '');
        jQuery('#tr_stickbtnReplyCancel').removeClass('tabBntDis').addClass('tabBnt');
    } else {
        // Save
        jQuery('#tbl_stickbtnReply').css('pointer-events', 'none');
        jQuery('#tr_stickbtnReply').removeClass('pgBntG pgBntB').addClass('pgBntGDis pgBntBDis');
        
        // Close
        jQuery('#tbl_stickbtnReplyCancel').css('pointer-events', 'none');
        jQuery('#tr_stickbtnReplyCancel').removeClass('tabBnt').addClass('tabBntDis');
    }
}
