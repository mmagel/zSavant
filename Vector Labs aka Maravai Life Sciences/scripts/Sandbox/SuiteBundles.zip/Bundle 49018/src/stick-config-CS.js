var _existingTypes = [];
var _types = null;


function OnPageInit()
{
    //Remember existing record types
    for (var i = 1; i <= nlapiGetLineItemCount("custpage_record_types"); ++i)
    {
        _existingTypes.push(nlapiGetLineItemValue("custpage_record_types", "custrecord_sert_record_type", i));
    }

    //Init roles
    var stickRoles = _TryParse(nlapiGetFieldValue("custpage_stick_rolesvalue"));
    if (stickRoles != null)
    {
        nlapiSetFieldValues("custpage_stick_roles", stickRoles);
    }
    
    //Init global search users
    var globalUsers = _TryParse(nlapiGetFieldValue("custpage_gs_usersvalue"));
    if (globalUsers != null)
    {
        nlapiSetFieldValues("custpage_gs_users", globalUsers);
    }
}



function _TryParse(s)
{
    try
    {
        return JSON.parse(s);
    }
    catch (e)
    {
    }

    return null;
}



function OnSaveRecord()
{
    var newTypes = [];
    for (var i = 1; i <= nlapiGetLineItemCount("custpage_record_types"); ++i)
    {
        newTypes.push(nlapiGetLineItemValue("custpage_record_types", "custrecord_sert_record_type", i));
    }


    for (i = 0; i < _existingTypes.length; ++i)
    {
        if (newTypes.indexOf(_existingTypes[i]) == -1)
        {
            //Delete type
            var typeId = _GetTypeId(_existingTypes[i]);
            if (typeId != null)
            {
                try { nlapiDeleteRecord("customrecord_stick_enabled_record_type", typeId); } catch (e) { }
            }
        }
    }
    

    for (i = 0; i < newTypes.length; ++i)
    {
        if (_existingTypes.indexOf(newTypes[i]) == -1)
        {
            //Add type
            var rec = nlapiCreateRecord("customrecord_stick_enabled_record_type");
            rec.setFieldValue("custrecord_sert_record_type", newTypes[i]);
            nlapiSubmitRecord(rec, true);

            _existingTypes.push(newTypes[i]);
        }
    }


    //Save Roles setting
    var stickRoles = nlapiGetFieldValues("custpage_stick_roles");
    if (stickRoles == null)
    {
        stickRoles = [];
    }
    nlapiSetFieldValue("custpage_stick_rolesvalue", JSON.stringify(stickRoles))


    //Save Global Search setting
    var globalUsers = nlapiGetFieldValues("custpage_gs_users");
    if (globalUsers == null)
    {
        globalUsers = [];
    }

    for (var j = 0; j < globalUsers.length; ++j)
    {
        if (globalUsers[j] == "-1")
        {
            globalUsers.splice(j, 1);
            break;
        }
    }
    nlapiSetFieldValue("custpage_gs_usersvalue", JSON.stringify(globalUsers))
    
        
    return true;
}



function _GetTypeId(type)
{
    if(_types == null)
    {
        _types = {};
        
        var rs = nlapiSearchRecord("customrecord_stick_enabled_record_type", null, null, [new nlobjSearchColumn("custrecord_sert_record_type")]) || [];
        for (var i = 0; i < rs.length; ++i)
        {
            _types[rs[i].getValue("custrecord_sert_record_type")] = rs[i].getId();
        }
    }

    return _types[type];
}