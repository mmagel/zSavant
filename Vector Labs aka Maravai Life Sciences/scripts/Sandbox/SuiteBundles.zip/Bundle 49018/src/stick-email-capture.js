/**
 * � 2016 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code.
 */

/**
 * Accepts the email object that contains the captured email.
 * 
 * @param {Object}
 *        email - Email object that provides methods to retrieve email
 *        information
 */
function process(email) {
    var logTitle = 'process';

    // get sender info
    var fromAddress = email.getFrom();
    nlapiLogExecution('DEBUG', logTitle, 'fromAddress = ' + fromAddress);
    // get emp id from fromAddress
    var emailAddr = fromAddress.getEmail();
    nlapiLogExecution('DEBUG', logTitle, 'emailAddr = ' + emailAddr);
    var results = nlapiSearchRecord('employee', null, [ [ 'email', 'is', emailAddr ] ]);
    if (results === null) {
        throw 'Email address not found. emailAddr=' + emailAddr;
    }
    var empId = results[0].getId();
    nlapiLogExecution('DEBUG', logTitle, 'empId = ' + empId);

    // get the email text body
    var textBody = email.getTextBody();
    nlapiLogExecution('DEBUG', logTitle, 'textBody = ' + textBody);

    // get guid
    var marker = 'Do not edit or delete this line: ';
    var startPos = textBody.lastIndexOf(marker) + marker.length;
    var guid = textBody.substr(startPos);
    nlapiLogExecution('DEBUG', logTitle, 'guid = ' + guid);
    nlapiLogExecution('DEBUG', logTitle, 'guid.length = ' + guid.length);
    // replace line break with space
    guid = guid.replace(/(\r\n|\n|\r)/gm, " ");
    // get the guid only, in case there's other lines after guid line
    var idxSpace = guid.indexOf(" ");
    if (idxSpace > 0) {
        guid = guid.substr(0, idxSpace);
    }
    nlapiLogExecution('DEBUG', logTitle, 'guid = ' + guid);
    nlapiLogExecution('DEBUG', logTitle, 'guid.length = ' + guid.length);

    // validate guid and email address
    var filters = [];
    filters.push([ 'custrecord_stick_email_cap_recipient', 'is', empId ]);
    filters.push('and');
    filters.push([ 'custrecord_stick_email_cap_guid', 'is', guid ]);
    var columns = [];
    columns.push(new nlobjSearchColumn('custrecord_stick_email_cap_note'));
    var results = nlapiSearchRecord('customrecord_stick_email_capture', null, filters, columns);
    if (results === null) {
        nlapiLogExecution('DEBUG', logTitle, 'Email capture record not found. empId=' + empId + '; guid=' + guid);
        var replyBody = 'The note you replied to has already been deleted.<br/><br/>';
        replyBody += 'Original email below:<br/>--------------------------------------------------<br/>';
        replyBody += email.getHtmlBody();
        nlapiSendEmail('-5', empId, email.getSubject() || 'StickyNotes Email Reply Failed', replyBody);
        return;
    }

    // get note id
    var noteId = results[0].getValue('custrecord_stick_email_cap_note');

    // get message
    var reply = parseReplyPlainText(textBody);
    nlapiLogExecution('DEBUG', logTitle, 'reply = ' + reply);
    // trim down extra weird html markups from Outlook
    var extraMarkup = '<html><body';
    if (reply.indexOf(extraMarkup) == 0) {
        reply = reply.substring(extraMarkup.length);
        nlapiLogExecution('DEBUG', logTitle, 'reply = ' + reply);
    }

    // add reply to note
    var param = {
        noteId : noteId,
        reply : reply,
        checkAccess : false,
        file : ''
    };
    var replies = stickAddReply(empId, param);
    nlapiLogExecution('DEBUG', logTitle, 'replies = ' + replies);
}
