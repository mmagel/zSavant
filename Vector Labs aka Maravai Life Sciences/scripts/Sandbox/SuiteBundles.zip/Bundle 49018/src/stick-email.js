/*** � 2016 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. */
// global variables definedvar stickGlobal = stickGlobal || {};
// email typesstickGlobal.EMAIL_TYPES = {};stickGlobal.EMAIL_TYPES.NOTE = {    subject : '{priority} Priority Note on {recordName}',    template : 'stick-email-template-note.html',    templateNoGuid : 'stick-email-template-note-noguid.html'};stickGlobal.EMAIL_TYPES.REPLY = {    subject : '{owner} replies to: {priority} Priority Note on {recordName}',    template : 'stick-email-template-reply.html',    templateNoGuid : 'stick-email-template-reply-noguid.html'};//define module if undefinedvar module = module || {};
/** * Main function to be called when sending email notification. * @param {Object} params */
function stickEmail(params)
{
    // check params properties
    if (stickHasNoValue(params))
    {
        throw 'stickEmail: params has no value';
    }
    
    if (stickHasNoValue(params.type))
    {
        throw 'stickEmail: params.type has no value';
    }

    // check email type
    var emailType = stickGlobal.EMAIL_TYPES[params.type];
    if (emailType == stickGlobal.EMAIL_TYPES.NOTE)
    {
        stickEmailNote(params.noteId, emailType);
    }
    else if (emailType == stickGlobal.EMAIL_TYPES.REPLY)
    {
        stickEmailReply(params.noteId, params.replyId, emailType);
    }
    else
    {
        throw 'stickEmail: params.type unknown = ' + params.type;
    }
}
/** * Creates a StickyNotes Email Capture record for the specified note and * recipient, and returns the guid linked to this record. */function stickCreateEmailCaptureRecord(noteId, recpId) {    // generate guid    var guid = stickGenerateGuid(noteId + "_" + recpId);    // create record to email capture    var rec = nlapiCreateRecord("customrecord_stick_email_capture");    rec.setFieldValue("custrecord_stick_email_cap_note", noteId);    rec.setFieldValue("custrecord_stick_email_cap_recipient", recpId);    rec.setFieldValue("custrecord_stick_email_cap_guid", guid);    nlapiSubmitRecord(rec);    return guid;}/** * Gets the email template for the specified email type. * @param emailType * @returns */function stickGetEmailTemplate(emailType) {    // get email capture address for reply-to    emailType.replyTo = nlapiGetContext().getSetting('SCRIPT', 'custscript_stick_email_capture_address');    nlapiLogExecution('DEBUG', 'stickGetEmailTemplate', 'replyTo = ' + emailType.replyTo);        // if has reply-to, then get template with guid; otherwise, get that with no guid    var template = stickHasValue(emailType.replyTo) ? emailType.template : emailType.templateNoGuid;    if (stickHasValue(template)) {        // get html format from template        var filters = [ 'name', 'is', template ];        var searchresults = nlapiSearchRecord('file', null, filters);        if (stickHasValue(searchresults)) {            // expecting only one file            var file = nlapiLoadFile(searchresults[0].getId());            return file.getValue();        }    }        // if template is missing, throw error    throw nlapiCreateError('EMAIL_TEMPLATE_MISSING', 'Email template is missing.  emailType : ' + JSON.stringify(emailType));}/** * Gets the file attachment info. * @param file * @param paramId * @param id * @returns {Object} */function stickGetFileAttachment(file, paramId, id) {    var objFile = null;    if (stickHasValue(file)) {        try {            file = JSON.parse(file);                        // check if valid file object            if (stickHasValue(file.origFileName)) {                // initialize file object                objFile = {};                // get file download suitelet url                if (stickHasNoValue(stickGlobal.fileDownloadUrl)) {                    stickGlobal.fileDownloadUrl = nlapiResolveURL('SUITELET', 'customscript_stick_file_dl_sl', 'customdeploy_stick_file_dl_sl');                }                objFile.fileUrl = stickGetDataCenterURL() + stickGlobal.fileDownloadUrl + '&' + paramId + '=' + id + '&custparam_orig=T';                objFile.fileName = file.origFileName;                objFile.fileIconUrl = stickGetFileTypeIconForEmail(file.extName);            }        } catch (ex) {            // file info is invalid        }    }    return objFile;}/** * Gets the url of the specific image for the file type icon to display. This is used in the email notification's file link. *  * @param {String} *        extName Extension name of the file * @returns {String} Returns the url */function stickGetFileTypeIconForEmail(extName) {    extName = extName.toLowerCase();    // get images path    if (stickHasNoValue(stickGlobal.bundlePath)) {        stickGlobal.bundlePath = "/c." + nlapiGetContext().getCompany() + '/suitebundle' + nlapiGetContext().getBundleId();    }    var imagesPath = stickGetDataCenterURL() + stickGlobal.bundlePath + '/images/';    // get appropriate image file    if (extName == ".htm" || extName == ".html")        return imagesPath + "file_type_html.png";    else if (extName == ".xml")        return imagesPath + "file_type_xml.png";    else if (extName == ".pdf")        return imagesPath + "file_type_pdf.png";    else if (extName == ".zip" || extName == ".rar")        return imagesPath + "file_type_compressed.png";    else if (extName == ".xls" || extName == ".xlsx")        return imagesPath + "file_type_excel.png";    else if (extName == ".doc" || extName == ".docx")        return imagesPath + "file_type_word.png";    else if (extName == ".ppt" || extName == ".pptx")        return imagesPath + "file_type_powerpoint.png";    else if (extName == ".txt")        return imagesPath + "file_type_text.png";    else if (extName == ".jpg" || extName == ".jpeg" || extName == ".png" || extName == ".bmp")        return imagesPath + "file_type_image.png";    else        return imagesPath + "file_type_generic.png"; // generic}
/** * Function for sending email notification for note. * @param noteId */
function stickEmailNote(noteId, emailType)
{    // get note details    var filters = [        ['internalid', 'anyof', noteId]    ];    var columns = stickGetNoteColumns();    var results = nlapiSearchRecord('customrecord_stick_note', null, filters, columns);    if (results === null)    {        throw 'note results === null';    }    var notes = stickConvertResultsToEntities(results);    // get single result    var note = notes[0];    var senderId = note.owner;    var recordName = note.custrecord_sn_record_name;    var priorityName = note.custrecord_sn_note_categoryText;    var host = stickGetDataCenterURL();    var messageHtml = note.custrecord_sn_message.replace(/\[br\]/g, '<br/>');    var recordUrl = nlapiResolveURL('RECORD', note.custrecord_sn_record_type_script_id, note.custrecord_sn_record_id);    var recipients = note.custrecord_sn_allowed_entities;    recipients = recipients.split(',');    if (recipients.length == 0)  //no recipient?    {        return;    }        // get file if any    var objFile = stickGetFileAttachment(note.custrecord_sn_file, 'custparam_noteid', note.internalid);    // get email template    var html = stickGetEmailTemplate(emailType);        // prepare email    var subject = emailType.subject.replace(/{priority}/g, priorityName);    subject = subject.replace(/{recordName}/g, recordName);    html = html.replace(/{priority}/g, priorityName);    html = html.replace(/{viewUrl}/g, host + recordUrl);    html = html.replace(/{editUrl}/g, host + recordUrl + '&e=T');    html = html.replace(/{message}/g, messageHtml);    if (stickHasValue(objFile)) {        html = html.replace(/{displayStyle}/g, '');        html = html.replace(/{fileUrl}/g, objFile.fileUrl);        html = html.replace(/{fileIconUrl}/g, objFile.fileIconUrl);        html = html.replace(/{filename}/g, objFile.fileName);    } else {        html = html.replace(/{displayStyle}/g, 'display: none;');    }        // send email    for (var i = 0; i < recipients.length; i++)    {        try        {            // get each recipient            var recipientId = recipients[i];                        // do not send to owner            if (recipientId == senderId) {                continue;            }            // check if recipient has email            var recipientEmail = nlapiLookupField('employee', recipientId, 'email');            if (stickHasNoValue(recipientEmail)) {                continue;            }            // if has reply-to, then add guid            if (stickHasValue(emailType.replyTo)) {                // generate guid and save to custom record                var guid = stickCreateEmailCaptureRecord(noteId, recipientId);                                // append guid to email body                html = html.replace(/{guid}/g, guid);            }            // proceed to send email            nlapiSendEmail(senderId, recipientId, subject, html, null /*cc*/, null /*bcc*/, null /*records*/, null /*attachments*/, null /*notifySenderOnBounce*/, null /*internalOnly*/, emailType.replyTo /*replyTo*/);        }        catch (e)        {            stickHandleError(e, 'Error in sending email');        }    }
}

/** * Function for sending email notification for reply. * @param {Integer} noteId * @param {Integer} replyId */
function stickEmailReply(noteId, replyId, emailType)
{
    // get note details
    var filters = [
        ['internalid', 'anyof', noteId]
    ];
    var columns = stickGetNoteColumns();
    var results = nlapiSearchRecord('customrecord_stick_note', null, filters, columns);
    if (results === null)
    {
        throw 'note results === null';
    }
    var notes = stickConvertResultsToEntities(results);
    // get single result
    var note = notes[0];
    var recordName = note.custrecord_sn_record_name;
    var priorityName = note.custrecord_sn_note_categoryText;
    var host = stickGetDataCenterURL();
    var messageHtml = note.custrecord_sn_message.replace(/\[br\]/g, '<br/>');
    var recordUrl = nlapiResolveURL('RECORD', note.custrecord_sn_record_type_script_id, note.custrecord_sn_record_id);
    var recipients = note.custrecord_sn_allowed_entities;
    recipients = recipients.split(',');
    if (recipients.length == 0)  //no recipient?
    {
        return;
    }

    // get reply details
    filters = [
        ['internalid', 'anyof', replyId]
    ];
    columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('custrecord_snr_note'),
        new nlobjSearchColumn('custrecord_snr_reply'),
        new nlobjSearchColumn('owner'),
        new nlobjSearchColumn('created'),        new nlobjSearchColumn('custrecord_snr_file')
    ];
    results = nlapiSearchRecord('customrecord_stick_note_reply', null, filters, columns);
    if (results === null)
    {
        throw 'reply results === null';
    }
    var replies = stickConvertResultsToEntities(results);
    // get single result
    var reply = replies[0];
    var ownerName = reply.ownerText;    var senderId = reply.owner;
    var replyHtml = reply.custrecord_snr_reply.replace(/\[br\]/g, '<br/>');    // get file if any    var objFile = stickGetFileAttachment(reply.custrecord_snr_file, 'custparam_replyid', reply.internalid);    // get email template    var html = stickGetEmailTemplate(emailType);        // prepare email    var subject = emailType.subject.replace(/{priority}/g, priorityName);    subject = subject.replace(/{recordName}/g, recordName);    subject = subject.replace(/{owner}/g, ownerName);    html = html.replace(/{priority}/g, priorityName);    html = html.replace(/{viewUrl}/g, host + recordUrl);    html = html.replace(/{editUrl}/g, host + recordUrl + '&e=T');    html = html.replace(/{message}/g, replyHtml);    if (stickHasValue(objFile)) {        html = html.replace(/{displayStyle}/g, '');        html = html.replace(/{fileUrl}/g, objFile.fileUrl);        html = html.replace(/{fileIconUrl}/g, objFile.fileIconUrl);        html = html.replace(/{filename}/g, objFile.fileName);    } else {        html = html.replace(/{displayStyle}/g, 'display: none;');    }    html = html.replace(/{orignote}/g, messageHtml);    
    //get "repliers" as other recipients
    filters = [
        ['custrecord_snr_note', 'anyof', noteId],
        "AND",
        ['internalid', 'noneof', replyId]  //exclude newly added reply
    ];
    columns = [
        new nlobjSearchColumn('internalid'),
        new nlobjSearchColumn('owner')
    ];
    columns[0].setSort();
    results = stickSearchAllRecords2('customrecord_stick_note_reply', null, filters, columns);
    if (results !== null)
    {
        for (var i = 0; i < results.length; i++)
        {
            var ownerId = results[i].getValue('owner');
            // add to recipients if not yet added
            if (recipients.indexOf(ownerId) == -1)
            {
                recipients.push(ownerId);
            }
        }
    }

    // send email
    for (var i = 0; i < recipients.length; i++)
    {
        try
        {            // get each recipient
            var recipientId = recipients[i];            // check if recipient has email            var recipientEmail = nlapiLookupField('employee', recipientId, 'email');            if (stickHasNoValue(recipientEmail)) {                continue;            }            // if has reply-to, then add guid            if (stickHasValue(emailType.replyTo)) {                // generate guid and save to custom record                var guid = stickCreateEmailCaptureRecord(noteId, recipientId);                // append guid to email body                html = html.replace(/{guid}/g, guid);            }            // proceed to send email
            nlapiSendEmail(senderId, recipientId, subject, html, null /*cc*/, null /*bcc*/, null /*records*/, null /*attachments*/, null /*notifySenderOnBounce*/, null /*internalOnly*/, emailType.replyTo /*replyTo*/);
        }
        catch (e)
        {
            stickHandleError(e, 'Error in sending email');
        }
    }
}
