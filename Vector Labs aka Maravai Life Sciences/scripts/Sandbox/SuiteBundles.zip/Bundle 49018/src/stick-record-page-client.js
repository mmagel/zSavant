/**
 * � 2015 NetSuite Inc. User may not copy, modify, distribute, or re-bundle or
 * otherwise make available this code.
 */

var stickGlobal = stickGlobal || {};
stickGlobal.folderFullName = 'Getting full folder name ...';
stickGlobal.browserSupported = true;
stickGlobal.HOURGLASS = '<img src=/images/setup/hourglass.gif />';
stickGlobal.hasLoaded = false;
stickGlobal.noteMargin = 20;
stickGlobal.isBoard = false;
stickGlobal.lastClientWidth = Ext.getBody().dom.clientWidth;
function stickRecordPageResize() {
    var logger = new stickobjLogger(arguments);
    var newClientWidth = Ext.getBody().dom.clientWidth;
    // var newClientHeight = Ext.getBody().dom.clientHeight;
    var els = Ext.select('.stickBox').elements;
    var count = els.length;
    for (var i = 0; i < count; i++) {
        var el = els[i];
        var x = Ext.get(el);
        var newLeft = x.getLeft() * newClientWidth / stickGlobal.lastClientWidth;
        x.setLeft(newLeft);
    }
    stickGlobal.lastClientWidth = Ext.getBody().dom.clientWidth;
}
function stickFilterByCategory(evt) {
    var logger = new stickobjLogger(arguments);

    if (stickAreNotesVisible() === false) {
        stickShowInfo('Filters cannot be applied to hidden notes.');
        logger.log('exiting...stickAreNotesVisible() === false');
        return;
    }
    evt = evt || window.event;
    var target = evt.target || evt.srcElement;
    var backEl = target.parentNode;
    if (target.getAttribute('class') !== 'inputreadonly stick-link-box stick-link-box-hover') {
        target = backEl;
    }

    if (target.getAttribute('data-is-displayed') === 'true') {
        target.setAttribute('data-is-displayed', 'false');
        jStick(target).css({
            'opacity' : 0.3
        });
    } else {
        target.setAttribute('data-is-displayed', 'true');
        jStick(target).css({
            'opacity' : 1.0
        });
    }
    var els = Ext.select('#stickFilterLinkBox .stick-link-box[data-is-displayed=true]').elements;
    var displayedCategoryNames = [];
    // alert(els.length);
    for (var i = 0; i < els.length; i++) {
        displayedCategoryNames.push(els[i].getAttribute('data-category-name'));
    }
    logger.log('displayedCategoryNames=' + JSON.stringify(displayedCategoryNames));
    var elNotes = Ext.select('#stickNoteBox .stickBox').elements;
    for (var i = 0; i < elNotes.length; i++) {
        var elNote = elNotes[i];
        var xNote = Ext.get(elNote);
        var categoryName = elNote.getAttribute('data-category-name');
        logger.log('categoryName=' + categoryName);
        if (displayedCategoryNames.indexOf(categoryName) > -1) {
            if (xNote.isVisible() === false) {
                xNote.fadeIn(100);
            }
        } else {
            if (xNote.isVisible()) {
                // xNote.fadeOut(100);
                jStick(elNote).hide('fade', {}, 300);
            }
        }
    }
    stickStopPropagation(evt);
    // alert(JSON.stringify(displayedCategoryNames));
}
function stickShowLinksBox() {
    var xLinksBox = Ext.get('stickLinksBox');
    if (xLinksBox.isVisible()) {
        if (stickHasValue(stickGlobal.hideLinksBoxTimeout)) {
            clearTimeout(stickGlobal.hideLinksBoxTimeout);
        }
        return;
    }
    if (stickIsMobile()) {
        Ext.get('stickToolboxClose').dom.style.display = '';
    }
    var xLink = Ext.get('stickMenuLink');
    xLink.addClass('stick-menu-link-hover');
    xLink.removeClass('stick-menu-link-normal');
    xLinksBox.setTop(xLink.getTop() + xLink.getHeight() - 2);
    xLinksBox.setLeft(xLink.getLeft());
    xLinksBox.show();
}
function stickHideLinksBoxNoDelay() {
    var xLink = Ext.get('stickMenuLink');
    xLink.removeClass('stick-menu-link-hover');
    xLink.addClass('stick-menu-link-normal');
    var xLinksBox = Ext.get('stickLinksBox');
    xLinksBox.hide();
    delete stickGlobal.hideLinksBoxTimeout;
}
function stickHideUserPreferenceDialog() {
    Ext.get("stickUserPreferenceBox").hide();
    Ext.Msg.hide();
    Ext.get("stickColorPicker").hide();
    Ext.get("stickNoteSize").hide();
    Ext.get("stickFontSize").hide();
    // stickGetSpot().hide();
    // delete stickGlobal.spot;
}
function stickHideLinksBox() {
    if (stickGlobal.spot) {
        // if (stickGlobal.spot.active) {
        // spotlight is active so dont hide
        return;
        // }
    }
    if (stickHasValue(stickGlobal.hideLinksBoxTimeout)) {
        clearInterval(stickGlobal.hideLinksBoxTimeout);
        delete stickGlobal.hideLinksBoxTimeout;
    }
    stickGlobal.hideLinksBoxTimeout = setTimeout(function() {
        stickHideLinksBoxNoDelay();
    }, 300);
}
/**
 * Displays the what new help tooltip
 */
function stickWhatsNewHelp() {
    var logger = new stickobjLogger(arguments);
    try {
        if (nlapiGetContext().getPreference('custscript_stick_suppress_tutorial_users') == 'T') {
            return;
        }

        if (stickGlobal.paramUserPref.suppressHelpInRecord == 'T') {
            return;
        }
        var item = 'whatsnew';
        stickSpotlight(null, item);
    } catch (e) {
        stickHandleError(e);
    }
    logger.end();
}
/**
 * Shows the in-app help
 */
function stickHelp() {
    // var e;
    var helpkey = 'overview';
    stickSpotlight(null, helpkey);
    return;
}
/**
 * Suppresses the display of the welcome help
 */
function stickSuppressWhatsNewHelp() {
    stickHideHelp();
    stickShowInfo('To display the StickyNotes tutorial again, click Help from the StickyNotes toolbar menu.');
    // make sure the suitelet is not running as admin
    stickSuiteletProcessAsyncUser('suppressWhatsNewHelp', 'any', function(ok) {
        if (ok == 'ok') {
        }
    });
}
/**
 * Returns the element/element id given the help key
 * 
 * @param {Object}
 *        helpKey
 */
function stickGetHelpElementId(helpKey) {
    var el;
    switch (helpKey) {
    case 'whatsnew':
        el = 'stickToolbarBox';
        break;
    case 'overview':
        el = 'stickToolbarBox';
        break;
    case 'stickyNotesRecordButton':
        el = 'stickToolbarStickyNotesButton';
        break;
    case 'stickyNotesRecordFilter':
        el = 'stickFilterLinkBox';
        break;
    case 'end':
        el = 'stickToolbarBox';
        break;
    case 'help':
        el = 'stickLinksBox';
        break;
    case 'newNote':
        el = 'stickNewNoteLinkBox';
        break;
    case 'newNoteYellow':
        el = 'stickNewWarning';
        break;
    case 'newNoteRed':
        el = 'stickNewUrgent';
        break;
    case 'stickShowOrHideAll':
        el = 'stickShowOrHideAll';
        break;
    case 'stickSOpenBoard':
        el = 'stickSOpenBoard';
        break;
    case 'recordCount':
        var els = Ext.get('sortable').select('.stickRecordCount').elements;
        if (els.length > 0) {
            var el = els[els.length - 1];
        }
        break;
    case 'stickUserSettings':
        el = 'stickUserSettings';
        break;
    case 'letUsKnowWhatYouThink':
        el = 'stickSendCommentsLink';
        break;
    case 'stickSendCommentsLink':
        el = 'stickSendCommentsLink';
        break;
    case 'firstFieldLabel':
        // HACK: dom
        var labelElId;
        var selector = '#detail_table_lay [style="cursor:help"]';
        if (Ext.select(selector).elements.length > 0) {
            labelElId = Ext.select(selector).elements[0].parentNode.id;
        } else {
            // happens in IE
            selector = '#detail_table_lay [title="What\'s this?"]';
            labelElId = Ext.select(selector).elements[0].parentNode.id;
        }

        return labelElId;
    default:
        return helpKey;
    }
    return el;
}
/**
 * The spotlight effect used in the in-app help
 * 
 * @param {Object}
 *        e
 * @param {Object}
 *        helpKey
 */
function stickSpotlight(e, helpKey) {
    var logger = new stickobjLogger(arguments);
    e = e || window.event;
    if (stickHasNoValue(helpKey)) {
        stickHideLinksBoxNoDelay();
        stickHideHelp();
        Ext.get('stickUserPreferenceBox').hide();
        Ext.Msg.hide();
        Ext.get('stickFieldMenuBox').hide();
        return false;
    }
    var title = '';
    var helpText = '';
    var anchor = 'top';
    var nextHelpKey = '';
    switch (helpKey) {
    case 'whatsnew':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += '\Launch the StickyNotes Tutorial to learn more about the feature.';
        nextHelpKey = 'overview';
        break;
    case 'overview':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes Overview</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'StickyNotes lets you create and track notes on record pages. You can communicate effectively with others by adding recipients, so people are notified when you leave a note for them on the record page. This also ensures that only specific people have access to your note. You can also make your note public if you want everyone with access to the record page to view your note.';
        helpText += "<br>";
        helpText += "<br>This feature provides the following additional functionalities:";
        helpText += '<ul>';
        helpText += '<li>Improve collaboration by sharing notes with and gathering responses from your team.</li>';
        helpText += '<li>Highlight important information or critical action items on a record by defining custom color notes.</li>';
        helpText += '<li>Make notes more informative by attaching files or images.</li>';
        helpText += '<li>Be notified when you are added as a recipient in a note or when someone replies to a note you own or a recipient of.</li>';
        helpText += '<li>View all your notes across different record pages from the StickyNotes Board. You can also search for keywords within notes, and filter, sort, or archive notes from the StickyNotes Board.</li>';
        helpText += '</ul>';
        nextHelpKey = 'stickyNotesRecordButton';
        stickHideLinksBoxNoDelay();
        break;
    case 'stickyNotesRecordButton':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes Menu</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click or point to the StickyNotes Menu to do any of the following:';
        helpText += "<br>";
        helpText += "<br>";
        helpText += '<ul>';
        helpText += '<li>Filter notes on the record page</li>';
        helpText += '<li>Show or hide notes on record pages</li>';
        helpText += '<li>Open the StickyNotes Board</li>';
        helpText += '<li>Set user preferences</li>';
        helpText += '<li>Launch the StickyNotes tutorial</li>';
        helpText += '</ul>';
        nextHelpKey = 'newNote';
        stickHideLinksBoxNoDelay();
        break;
    case 'newNote':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;New StickyNote</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Select the color that corresponds to the note priority that you want to create.';
        nextHelpKey = 'stickyNotesRecordFilter';
        anchor = 'left';
        break;
    case 'stickyNotesRecordFilter':
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Note Filters</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click any of the note colors to display only the notes that corresponds to the selected priority.';
        nextHelpKey = 'stickShowOrHideAll';
        break;
    case 'stickShowOrHideAll':
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Show or Hide StickyNotes</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click here to show or hide all notes. This setting is applied across all record pages.';
        nextHelpKey = 'stickSOpenBoard';
        anchor = 'left';
        break;
    case 'stickSOpenBoard':
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Open StickyNotes Board</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click here to open the StickyNotes Board in a new page.';
        nextHelpKey = 'stickUserSettings';
        anchor = 'left';
        break;
    case 'stickUserSettings':
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes Preferences</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click here to open the StickyNotes Preferences window, and customize the appearance of your notes.';
        nextHelpKey = 'stickUserPreferenceBox';
        anchor = 'left';
        break;
    case 'stickUserPreferenceBox':
        stickShowUserPreferenceDialog();
        stickHideLinksBoxNoDelay();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;StickyNotes Preferences</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Set your preferred notes priority colors, font size, and note size. You can restore the original settings by clicking <b>Reset to Default.</b>';
        nextHelpKey = 'stickHelpLink';
        anchor = 'left';
        break;
    case 'stickHelpLink':
        Ext.Msg.hide();
        stickHideUserPreferenceDialog();
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Tutorial</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Click here to launch the tutorial.';
        nextHelpKey = 'stickSendCommentsLink';
        anchor = 'left';
        break;
    case 'stickSendCommentsLink':
        stickShowLinksBox();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Rate StickyNotes</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Let us know what you think about StickyNotes.';
        nextHelpKey = 'stickComments';
        anchor = 'left';
        break;
    case 'stickComments':
        stickSendComments();
        stickHideLinksBoxNoDelay();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Rate StickyNotes</b>';
        helpText += '<br>';
        helpText += '<br>';
        nextHelpKey = 'firstFieldLabel';
        anchor = 'left';
        break;
    case 'firstFieldLabel':
        stickHideLinksBoxNoDelay();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Field-Level Notes</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'Point to the field label to create a note linked to a specific field.';
        nextHelpKey = 'end';
        var labelElId = stickGetHelpElementId(helpKey);
        stickShowFieldMenuNoDelay(labelElId);
        break;
    case 'end':
        Ext.get('stickFieldMenuBox').hide();
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;End of Tutorial</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'You can now start using StickyNotes.';
        break;
    case 'recordCount':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Group Record Count</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'The number after the group title shows number of transactions within each group.';
        break;
    case 'summary':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;Timeline</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'This displays the information configured by your admnistrator to appear in the transaction summary.';
        break;
    case 'letUsKnowWhatYouThink':
        helpText = '<b><img class="stickImgTooltipHelp" src="">&nbsp;&nbsp;User Feedback</b>';
        helpText += '<br>';
        helpText += '<br>';
        helpText += 'This allows you to give us your feedback and rate the StickyNotes SuiteApp.';
        break;
    default:
        break;
    }
    var el = stickGetHelpElementId(helpKey);
    helpText += '<br><span style="height: 5px; line-height: 5px">&nbsp;</span>';
    if (stickHasValue(helpText)) {
        stickHideHelp();
        helpText = '<div id="stickHelptext">' + helpText + '</div>';
        stickSetHelp(el, title, helpText, anchor);
    }

    jStick('#stickHelptext').append(jStick('#stickTooltipbuttons').clone());
    if (helpKey !== 'whatsnew') {
        Ext.select('#tbl_stickNotifChkboxDontShow').hide();
        Ext.select('#stickbtnNext').set({
            'value' : 'Next Topic'
        });
    }

    if (stickHasValue(Ext.select('#stickHelptext #stickTooltipbuttons'))) {
        Ext.select('#stickHelptext #stickTooltipbuttons').show();
        Ext.select('#stickHelptext #stickTooltipbuttons #stickbtnNext').on('click', function() {
            return stickSpotlight(e, nextHelpKey);
        });

        if (helpKey == 'end') {
            Ext.select('#stickHelptext #stickTooltipbuttons #tbl_stickbtnNext').remove();
        }
    }

    stickGlobal.spot = stickGetSpot();
    // if (stickGlobal.spot.active) {
    // logger.log('stickGlobal.spot.doHide();');
    // // stickGlobal.spot.hide();
    // }
    if (Ext.get(el) !== null) {
        if (Ext.get(el).getWidth() === 0) {
            // hidden
        } else {
            if (stickGlobal.lastHelpEl) {
                // Ext.get(stickGlobal.lastHelpEl).stopFx();
            }
            // Ext.get(el).highlight("ffff9c", {
            // attr : "background-color", // can be any valid CSS property
            // // (attribute) that supports a color
            // // value
            // endColor : 'FFFFFF',
            // easing : 'easeIn',
            // duration : 5
            // });
            // logger.log('stickGlobal.spot.show(el); el=' + el);
            // // setTimeout(function() {
            // // alert('el='+el);
            // stickGlobal.spot.show(el);
            // }, 50);
            stickGlobal.lastHelpEl = el;
            stickGlobal.spot.show(stickGlobal.lastHelpEl);
            // setTimeout(function() {
            // stickGlobal.spot.show(stickGlobal.lastHelpEl);
            // }, 100);
        }
    }
    if (e) {
        stickStopPropagation(e);
    }

    if (helpKey !== 'whatsnew') {
        var tdCheckboxDontShow = Ext.get('tbl_stickNotifChkboxDontShow').findParent('td');
        Ext.get(tdCheckboxDontShow).setStyle({
            'display' : 'none'
        });
        tdCheckboxDontShow = Ext.select('#stick_titleTooltip #tbl_stickNotifChkboxDontShow').findParent('td');
        Ext.get(tdCheckboxDontShow).setStyle({
            'display' : 'none'
        });
    }

    logger.log('end');
    return false;
}
function stickShowTooltip(target, html, anchor) {
    if (stickHasNoValue(anchor)) {
        anchor = 'top';
    }
    var tooltip = (new Ext.ToolTip({
        title : null,
        id : target + 'tooltipId',
        target : target,
        anchor : 'top',
        html : html,
        autoHide : true,
        closable : false,
        autoShow : true,
        hideDelay : 5000,
        dismissDelay : 5000,
        anchorOffset : 0,
        width : 'auto',
        height : 'auto',
        bodyStyle : 'padding: 10px; background-color: ivory',
        listeners : {
            'hide' : function() {
                this.destroy();
                delete stickGlobal.folderTooltip;
            },
            'renderX' : function() {
                this.header.on('click', function(e) {
                    e.stopEvent();
                    Ext.Msg.alert('Link', 'Link to something interesting.');
                }, this, {
                    delegate : 'a'
                });
            }
        }
    }));
    tooltip.show();
    stickGlobal.tooltips.push(tooltip);
    stickApplyCSSToFolderTooltip();
}
function stickSubscribeOrUnsubscribe(e, noteId) {
    var logger = new stickobjLogger(arguments);
    if (stickHasNoValue(noteId)) {
        stickShowError('stickUnsubscribe() stickHasNoValue(noteId)');
        return;
    }
    // Ext.Msg.confirm(stickGlobal.TITLE, 'by supressing this sticky note 1) you
    // will no longer see this note 2) will no longer receive email
    // notifications regarding this note. Continue?', function(btn){
    // if (btn == 'yes') {
    var param = {};
    param.noteId = noteId;
    var xLink = Ext.get('stickSubscribeOrUnsubscribe' + noteId)
    param.subscribeOrUnsubscribe = xLink.dom.innerHTML;
    stickSuiteletProcessAsync('subscribeOrUnsubscribe', param, function(isOK) {
        if (isOK != 'ok') {
            stickShowError('error in subscribeOrUnsubscribe');
            return;
        }
        logger.log('xLink.dom.innerHTML=' + xLink.dom.innerHTML);
        if (xLink.dom.innerHTML == 'Subscribe') {
            xLink.update('Unsubscribe');
        } else {
            xLink.update('Subscribe');
        }
    });
    return stickStopPropagation(e);
}

function stickRemoveRecipient(e) {
    e = e || window.event;
    var target = e.target || e.srcElement;
    Ext.get(target.parentNode).fadeOut({
        callback : function() {
            Ext.get(target.parentNode).remove();
            // display help message when there are no recipients displayed
            var dRecipients = Ext.get('stickRecipients').dom;
            if (stickHasNoValue(dRecipients.innerHTML)) {
                Ext.get('stickEmployeeSearchInfo').dom.innerHTML = 'Type the first few characters of the employee name';
            }
        }
    });
}
/**
 * @event
 * @param {Object}
 *        element
 */
function onStickEmployeeSelectClick(element) {
    // e = e || window.event;
    // var target = e.target || e.srcElement;
    //    
    var select = element;
    var index = select.selectedIndex;
    if (index == -1) {
        return;
    }
    var value = select.options[index].value;
    var name = select.options[index].text;
    Ext.get('stickEmployeeSelectBox').hide();
    if (Ext.isIE) {
        Ext.get('stickEmployeeSelect').hide();
    }
    var dRecipients = Ext.get('stickRecipients').dom;
    var deleteMarkup = "<img class='stickShowOnHover' src='" + stickGlobal.dataSet['stick-employee-delete.png'] + "' title='Remove " + name + "' onclick='stickRemoveRecipient(event);' style='cursor: pointer; visibility: hidden'/>";
    dRecipients.innerHTML = dRecipients.innerHTML + '<a id="recipient' + value + '" data-id="' + value + '" href="#" class="stickRecipient">' + name.replace(' ', '&nbsp;') + deleteMarkup + '<span style="text-decoration: none;"></span>' + '</a>';
    // hide help message when there are recipients
    if (stickHasValue(dRecipients.innerHTML)) {
        Ext.get('stickEmployeeSearchInfo').dom.innerHTML = '';
    }
    Ext.get('stickSearchEmployeeTextBox').dom.value = '';
    Ext.get('stickSearchEmployeeTextBox').dom.focus();
    stickSetMouseOverAndOutEventsForRecipients();
    return false;
}
/**
 * Displays the results of the employee search
 * 
 * @param {Object}
 *        str
 */
function stickShowEmployeeSearch(str) {
    // var logger = new stickobjLogger(arguments);
    if (str.length < 2) {
        Ext.get('stickEmployeeSearchInfo').dom.innerHTML = 'Type at least 2 characters.';
        return false;
    }
    Ext.get('stickEmployeeSearchInfo').update('Type the first few characters of the employee name');
    // JC : Gets employee id and entity id from server that matches inputted
    // string str
    stickSuiteletProcessAsync('getEmployeeSearch', str, function(employees) {
        var logger = new stickobjLogger(arguments, false, 'stickEmployeeSelect');
        logger.log('employees.length=' + employees.length);
        stickGlobal.employeeSearchId = null;
        if (employees.length === 0) {
            Ext.get('stickEmployeeSearchInfo').dom.innerHTML = 'No employees found';
            Ext.get('stickEmployeeSelectBox').hide();
            return;
        }
        // ===============
        // add options
        // ===============
        var select = document.getElementById("stickEmployeeSelect");
        jStick("#stickEmployeeSelect").empty();
        for (var i = 0; i < employees.length; i++) {
            // show only first 100 to prevent browser from freezing
            if (i == 99) {
                break;
            }
            var option = document.createElement("option");
            option.value = employees[i].internalid;
            option.text = employees[i].name;
            try {
                // for IE earlier than version 8
                select.add(option, select.options[null]);
            } catch (e) {
                select.add(option, null);
            }
        }
        // end add options
        // ===================
        if (select.options.length === 0) {
            // Ext.get('noresultsfoundrich').dom.style.display = '';
        } else {
            select.style.display = '';
            if (select.options.length > 10) {
                select.size = 10;
            } else if (select.options.length == 1) {
                // so that it will not become a dropdown
                select.size = 2;
            } else {
                select.size = select.options.length;
            }
        }
        // ===============
        // show and position dropdown list
        // ===============
        var xSearchColleaguesTextBox = Ext.get('stickSearchEmployeeTextBox');
        var top = xSearchColleaguesTextBox.getTop() + xSearchColleaguesTextBox.getHeight();
        var xStickEmployeeSelectBox = Ext.get('stickEmployeeSelectBox');
        xStickEmployeeSelectBox.setTop(top);
        var left = xSearchColleaguesTextBox.getLeft();
        xStickEmployeeSelectBox.setLeft(left);
        xStickEmployeeSelectBox.show();
        if (Ext.isIE) {
            Ext.get('stickEmployeeSelect').show();
        }
    });
}
function onStickSearchEmployeeTextBoxKeyup(event) {
    // Ext.get('placeHolderColleagueOthers').dom.innerHTML = HOURGLASS;
    var e = event || window.event;
    // Standard or IE model
    var target = e.target || e.srcElement;
    var str = target.value;
    str = str.replace('@', '');
    str = str.replace('emp:', '');
    if (stickGlobal.employeeSearchId) {
        clearTimeout(stickGlobal.employeeSearchId);
    }
    // perform search 1 second after the user stopped typing
    var MILLISECONDS_BEFORE_SEARCHING = 1000;
    Ext.get('stickEmployeeSearchInfo').update(stickGlobal.HOURGLASS + ' Searching...');
    // 1 second
    stickGlobal.employeeSearchId = setTimeout('stickShowEmployeeSearch("' + str + '")', MILLISECONDS_BEFORE_SEARCHING);
}
function stickHideOrShowAll() {
    var logger = new stickobjLogger(arguments);
    stickHideLinksBoxNoDelay();
    var link = Ext.get('stickShowOrHideAll');
    var initiallyHideStickyNotes = 'F';
    if (link.dom.innerHTML == 'Hide Notes') {
        logger.log('hide');
        jStick('#stickNoteBox .stickBox').hide('fade');
        link.update('Show Notes');
        initiallyHideStickyNotes = 'T';
    } else {
        logger.log('show');
        Ext.select('#stickNoteBox .stickBox').fadeIn(500);
        link.update('Hide Notes');
        // reset filters
        jStick('#stickFilterLinkBox .stick-link-box').attr({
            'data-is-displayed' : 'true'
        }).css({
            opacity : 1
        });
    }
    if (stickGlobal.hasLoaded === false) {
        stickGlobal.paramUserPref.hideNotes = ''; // show
        stickProcessDataSet();
    }
    stickSuiteletProcessAsyncUser('showOrHideNotes', initiallyHideStickyNotes, function(isOK) {
        if (isOK != 'ok') {
            stickShowError('error in showOrHideNotes');
        }
    });
}
function stickSetMouseOverAndOutEventsForRecipients() {
    var logger = new stickobjLogger(arguments);
    var cssClass = 'stickRecipient';
    Ext.select('.' + cssClass).on('mouseenter', function(e) {
        // var logger = new stickobjLogger(arguments);
        try {
            if (e.target.id === '') {
                logger.log("e.target.id === ''");
                return;
            }
            Ext.select('#stickRecipients .stickShowOnHover').hide();
            Ext.select('#' + e.target.id + ' .stickShowOnHover').show();
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseenter ' + e);
            }
        }
    });
    Ext.select('.' + cssClass).on('mouseleave', function(e) {
        try {
            Ext.select('#stickRecipients .stickShowOnHover').hide();
            return true;
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseleave ' + e);
            }
        }
    });
    logger.log('end');
}
function stickGetNoteTypeColor(noteType) {
    var color = '';
    switch (noteType) {
    case 'remind':
        color = '#A2D39C';
        break;
    case 'warning':
        color = '#FFF79A';
        break;
    case 'urgent':
        color = '#F6989D';
        break;
    default:
        // default_statement;
    }
    return color;
}





function stickNewNote(e) {
    var logger = new stickobjLogger(arguments);
    e = e || window.event;
    var target = e.target || e.srcElement;
    stickHideFieldMenuNoDelay();
    // empty info
    Ext.get('stickEntryInfo').update('');
    var xStickEntry = Ext.get('stickEntry');
    // stickGlobal.fieldScriptId = target.getAttribute('data-fieldscriptid');
    // var dStickEntry = xStickEntry.dom;
    var dStickLinkBox = Ext.get(target).findParent('.stick-link-box');
    stickGlobal.categoryId = dStickLinkBox.getAttribute('data-category-id');
    
    var backColor = dStickLinkBox.getAttribute('data-background-color');
    if (stickHasNoValue(backColor)) {
        // for the label
        throw 'stickHasNoValue(backColor))';
    }
    xStickEntry.setStyle({
        'background-color' : backColor
    });
    
    var borderColor = 'white';
    
    Ext.get('stickSearchEmployeeTextBox').setStyle('border', '1px dashed ' + borderColor);
    var textareaNote = Ext.get('stickNote');
    textareaNote.setStyle('border', '1px dashed ' + borderColor);
    textareaNote.on("keydown", fnOnNoteKeyDown);
    
    var width = 300;
    var height = 300;

    // adjust text area height
    jStick('#stickNote').css({
        height : height - 100
    });
    var xTarget = Ext.get(target);
    xStickEntry.setTop(xTarget.getTop());
    xStickEntry.setLeft(xTarget.getLeft());
    xStickEntry.setWidth(xTarget.getWidth());
    xStickEntry.setHeight(xTarget.getHeight());
    stickRemoveRotation('stickEntry');
    // stickCenter('stickEntry');
    xStickEntry.show().setStyle({
        'z-index' : 9004
    });
    stickWait('Please wait...');
    var newLeft = (Ext.getBody().dom.clientWidth - width) / 2;
    // position entry screen just a little above the progress bar
    var xProgress = Ext.get(Ext.select('.x-window-tl').elements[0]);
    var newTop = xProgress.getTop() - 20;
    jStick('#stickEntry').animate({
        height : height,
        width : width,
        left : newLeft,
        top : newTop
    }, 400, 'swing', function() {
        Ext.get('stickNote').dom.value = '';
        Ext.get('stickNote').focus();
        jStick('#stickEntry').css({
            height : 'auto'
        });
    });

    Ext.get('stickNewNoteButton').dom.disabled = false;
    
    // apply dnd on text area of note
    stickEnableDnDOnNewNote(true, 'stickNote', 'stickEntry');
    
    logger.log('end');
}





/**
 * Position notes from right to left, row by row
 */
function stickGetNextNotePositionPercent() {
    var logger = new stickobjLogger(arguments);
    var dBody = Ext.getBody().dom;
    var clientWidth = dBody.clientWidth;
    var clientHeight = dBody.clientHeight;
    var marginFromRight = 50;
    var noteWidth = parseInt(stickGetNoteSize().width, 10);
    var left = clientWidth - noteWidth - marginFromRight;
    var topOffset = 200;
    var top = topOffset;
    var noteHeight = parseInt(stickGetNoteSize().height, 10);
    var els = Ext.select('.stickNote').elements;
    if (els.length > 0) {
        var loop = 0;
        var row = 0;
        top = topOffset + parseInt(row * noteHeight, 10);
        loop++;
        if (loop > 100) {
            throw 'loop > 100';
        }
        while (true) {
            var count = els.length;
            var isOverlap = false;
            for (var i = 0; i < count; i++) {
                var el = els[i];
                var x = Ext.get(el);
                var existingTop = x.getTop();
                // if (existingTop > 500) {
                // throw 'existingTop > 500';
                // }
                var existingLeft = x.getLeft();
                logger.log('existingTop=' + existingTop + '; top=' + top + '; existingLeft=' + existingLeft + '; left=' + left);
                // logger.log('existingTop == top && existingLeft == left='
                // +
                // (existingTop == top && existingLeft == left));
                // consider tolerance
                var tolerance = 15;
                // logger.log('existingLeft - tolerance' + (existingLeft -
                // tolerance));
                // logger.log('existingLeft + tolerance' + (existingLeft +
                // tolerance));
                // logger.log('existingLeft + tolerance' + (existingLeft +
                // tolerance));
                logger.log((existingLeft - tolerance) < left && (existingLeft + tolerance) > left);
                if ((existingTop - tolerance) < top && (existingTop + tolerance) > top && (existingLeft - tolerance) < left && (existingLeft + tolerance) > left) {
                    logger.log('isOverlap=true');
                    isOverlap = true;
                    break;
                }
            }
            if (isOverlap === false) {
                break;
            }
            // add 10px to top and left
            var distanceBetweenNotesInPx = 10;
            var noteWidth = parseInt(stickGetNoteSize().width, 10);
            // var noteWidth = parseInt(stickGetNoteSize().width, 10);
            // top += distanceBetweenNotesInPx;
            left = left - noteWidth - distanceBetweenNotesInPx;
            if (left < 1) {
                // make sure note wont go out of bounds, try next row
                row += 1;
                top = topOffset + parseInt(row * noteHeight, 10) + distanceBetweenNotesInPx;
                // reset default left
                var left = clientWidth - noteWidth - marginFromRight;
            }
        }
    }
    logger.log('FINAL top=' + top + '; left=' + left);
    var lastPercentTop = parseInt(100 * top / clientHeight, 10);
    var lastPercentLeft = parseInt(100 * left / clientWidth, 10);
    logger.end();
    return {
        lastPercentTop : lastPercentTop,
        lastPercentLeft : lastPercentLeft
    };
}
// stickGlobal.lastPercentLeft = 75;
// // set the default top at 200
// stickGlobal.lastPercentTop = 100 * 200 / Ext.getBody().dom.clientHeight;
function stickSaveNoteNew() {
    var logger = new stickobjLogger(arguments);
    Ext.get('stickEntryInfo').update('');
    var nextPositionPercent = stickGetNextNotePositionPercent();
    // ================
    // get recipients
    // ================
    var recipients = [];
    var els = Ext.select('#stickRecipients .stickRecipient').elements;
    for (var i = 0; i < els.length; i++) {
        var empId = els[i].getAttribute('data-id');
        // recipients.push(parseInt(empId, 10));
        empId = empId.toString();
        if (recipients.indexOf(empId) == -1) {
            recipients.push(empId);
        }
    }
    // end get recipients
    // ================
    // var allowThoseWithRecordAccess = 'F'; //
    // Ext.get('stickWithAccessToRec').dom.checked
    var allowThoseWithRecordAccess;
    if (Ext.get('stickNoteIsPublic').dom.checked == true) {
        allowThoseWithRecordAccess = 'T';
    } else {
        allowThoseWithRecordAccess = 'F';
    }
    // Ext.Msg.alert('public?', allowThoseWithRecordAccess);
    // ? 'T' : 'F';
    stickGlobal.lastZIndex = stickGlobal.lastZIndex + 1;
    var param = {};
    param.recipients = recipients;
    var message = Ext.get('stickNote').dom.value.trim();
    if (message === '') {
        Ext.get('stickEntryInfo').update('Please provide message.');
        Ext.get('stickNote').dom.focus();
        return;
    }
    // the max length allowed is 4000 but we need to allot around 500 when the
    // message is encoded in html
    if (message.length > 3500) {
        Ext.get('stickEntryInfo').update('Message should not be more than 3,500 characters.');
        Ext.get('stickNote').dom.focus();
        return;
    }
    Ext.get('stickNewNoteButton').dom.disabled = true;
    param.message = message;
    param.recordTypeScriptId = stickGetRecordType();
    param.recordId = nlapiGetRecordId();
    param.percentTop = nextPositionPercent.lastPercentTop; // stickGlobal.lastPercentTop;
    param.percentLeft = nextPositionPercent.lastPercentLeft; // stickGlobal.lastPercentLeft;
    param.categoryId = stickGlobal.categoryId;
    param.allowThoseWithRecordAccess = allowThoseWithRecordAccess;
    param.zIndex = stickGlobal.lastZIndex;
    param.fieldScriptId = stickGlobal.fieldScriptId || '';
    param.noteSizeId = stickGlobal.paramUserPref.noteSizeId;
    param.fontSizeId = stickGlobal.paramUserPref.fontSizeId;

    var recordName = Ext.select('.pt_title').elements[0];
    if (stickHasValue(recordName)) {
        recordName = Ext.select('.pt_title').elements[0].innerHTML;
        recordName = recordName.substr(recordName.indexOf(' ') + 1);
        // recordName = Contact: Contact 123
    } else {
        recordName = Ext.select('.uir-record-type').elements[0].innerHTML;
        recordName += ': ' + (Ext.select('.uir-record-name').elements.length > 0 ? Ext.select('.uir-record-name').elements[0].innerHTML : param.recordId);
    }
    param.recordName = recordName;
    param.host = window.location.host;
    // include file attached if any
    param.file = stickHasValue(stickGlobal.fileDnD) ? stickGlobal.fileDnD.getFileDetails() : '';
    param.isBoard = stickGlobal.isBoard;
    
    // alert(JSON.stringify(param));
    // reset the current field value
    delete stickGlobal.fieldScriptId;
    // stickWait();
    Ext.get('stickInfoNew').show();
    // JC : Creates a new note by passing required parameters and notifies
    // recipients if there is any
    ;
    stickSuiteletProcessAsync('addNote', param, function(notes) {
        // clear and hide file info
        if (stickHasValue(stickGlobal.fileDnD)) {
            stickGlobal.fileDnD.clearAndHideFileInfo();
        }
        Ext.Msg.hide();
        Ext.get('stickInfoNew').hide();
        Ext.get('stickNote').dom.value = '';
        Ext.get('stickEntry').hide();
        // clear the chosen recipients
        Ext.get('stickRecipients').update('');
        // alert(notes.length);
        // we expect only 1 note
        stickGlobal.notes = stickGlobal.notes.concat(notes);
        // JC : Render the notes template and data (newly created notes)
        stickTemplateAppendNotes(notes);
        // TODO: merge the 2 functions below?
        stickSetMouseOverAndOutEvents();
        stickSetMouseEvents();
        stickProcessRenderedNotes(notes);
        stickPositionNotes();
        Ext.get('stickBox' + notes[0].internalid).fadeIn();
        jStick('#stickBox' + notes[0].internalid).effect('bounce');
        jStick('#stickNoteIsPublic').attr('checked', false);
    });
}

function stickCloseNoteNew() {
    // define local function to close new note
    function closeNote() {
        Ext.Msg.hide();
        Ext.get('stickEntry').fadeOut();
        Ext.get('stickEntryInfo').update('');
        Ext.get('stickEmployeeSelectBox').hide();
        Ext.get('stickSearchEmployeeTextBox').dom.value = '';
        jStick('#stickNoteIsPublic').attr('checked', false);
    }
    
    // check if has file attached
    if (stickHasValue(stickGlobal.fileDnD)) {
        var fileInfo = stickGlobal.fileDnD.getFileDetails();
        if (stickHasValue(fileInfo)) {
            // ask to delete on close of new note
            
            stickShowExtMessage('stickEntry', {
                title : stickGlobal.TITLE,
                msg : 'You have an uploaded file.  Do you want to cancel this upload?',
                buttons : Ext.Msg.YESNOCANCEL,
                fn : function(btn) {
                    console.log('btn = ' + btn);
                    if (btn == 'ok') {
                        // delete and clear file
                        stickDeleteUploadedFile(fileInfo);
                        stickGlobal.fileDnD.clearAndHideFileInfo();
                        // proceed to close new note
                        closeNote();
                        return;
                    }
                    stickWait('Please wait...');
                },
                icon : Ext.MessageBox.INFO,
                buttons : {
                    ok : "Yes",
                    cancel : "No"
                },
                minWidth : 220
            });
            return;
        }
    }
    
    // proceed to close new note
    closeNote();
}

function stickOpenPopup(url) {
    var width = screen.width - 200;
    var height = screen.height - 300;
    var left = (screen.width - width) / 2;
    var top = (screen.height - height) / 2;
    top = top - 50; // position window slightly above so that we can see the
    // status bar
    var params = 'width=' + width + ', height=' + height;
    params += ', top=' + top + ', left=' + left;
    params += ', directories=no';
    params += ', location=no';
    params += ', menubar=no';
    params += ', resizable=no';
    params += ', scrollbars=no';
    params += ', status=no';
    params += ', toolbar=no';
    // stickWait('Opening popup window' + '...');
    // IN SS record popup for example, when a row is deleted, NetSuite redirects
    // to a listing instead of showing the form of the parent SS Form. We track
    // the original
    // url so that when we detected the listing, we change the location to this
    // URL
    var popupWindow = window.open(url, "mywindow", params);
}
function stickTemplateAppendNotes(notes) {
    var logger = new stickobjLogger(arguments, true);
    var fullWidth = Ext.getBody().dom.clientWidth;
    var fullHeight = Ext.getBody().dom.clientHeight;
    for (var i = 0; i < notes.length; i++) {
        // notes[i].message = notes[i].custrecord_sn_message;
        notes[i].status = notes[i].custrecord_sn_status;
        notes[i].id = notes[i].internalid;
        notes[i].top = parseInt(notes[i].custrecord_sn_percent_top * fullHeight / 100, 10);
        notes[i].topPos = notes[i].top;
        notes[i].left = parseInt(notes[i].custrecord_sn_percent_left * fullWidth / 100, 10);
        // notes[i].color =
        // stickGetNoteTypeColor(notes[i].custrecord_sn_note_type);
        // notes[i].message = notes[i].custrecord_sn_status;
    }
    // JC : Render the notes template and data
    stickTemplateAppend('tmpStickNote', 'stickNoteBox', notes);
    if (Ext.isIE) {
        for (var i = 0; i < notes.length; i++) {
            var id = notes[i].internalid;
            Ext.get('stickBox' + id).setTop(notes[i].top);
            Ext.get('stickBox' + id).setLeft(notes[i].left);
            var dRepliesBox = Ext.get('stickReplyBox' + id).dom;
            // dRepliesBox.style.marginTop = '-20px';
            // logger.log('dRepliesBox.style.marginTop='+dRepliesBox.style.marginTop);
            // logger.log('dRepliesBox='+dRepliesBox);
            // // Ext.get('stickReplyBox' + id).setStyle('marginTop',
            // dRepliesBox.style.marginTop.replace('px', ''));
            // dRepliesBox.style.marginTop =
            // dRepliesBox.style.marginTop.replace('px', '');
        }
    }
    // Ext.select('#stickNoteBox .stickBox').fadeIn();
    jStick('#stickNoteBox .stickBox').draggable({

        start : function(evt, ui) {
            jStick(this).addClass('dragStartCalled');
            
            evt = evt || window.event;
            var target = evt.target || evt.srcElement;
            // get parent note
            var dNote = Ext.get(target).findParent('.stickNote') || target;
            var noteId = dNote.getAttribute('data-internalid');
            if (stickHasNoValue(noteId)) {
                return false;
            }
            
            stickSetNoteOnTop(noteId);
        },

        stop : function(event, ui) {
            // var logger = new stickobjLogger(arguments);
            logger.log('event.target=' + event.target);
            logger.log('ui.position=' + JSON.stringify(ui.position));
            logger.log('ui.offset=' + JSON.stringify(ui.offset));
            var param = {};
            param.internalid = event.target.getAttribute('data-internalid');
            param.percentTop = parseInt(100 * ui.position.top / Ext.getBody().dom.clientHeight);
            param.percentLeft = parseInt(100 * ui.position.left / Ext.getBody().dom.clientWidth);
            stickSuiteletProcessAsync('updatePosition', param, function(isOk) {
                if (isOk != 'ok') {
                    throw 'error in updatePosition';
                }
            });
        }
    });

    logger.log('end');
}
function stickShowHelp() {
    return;
    if (nlapiGetContext().getPreference('custscript_stick_suppress_help') == 'T') {
        return;
    }
    stickGlobal.helpTooltip = (new Ext.ToolTip({
        title : 'SuiteLabs StickyNotes',
        id : 'stickTooltipHelp',
        target : 'stickLinksBox',
        anchor : 'left',
        html : Ext.get('stickHelp').dom.innerHTML,
        autoWidth : true,
        autoHide : false,
        closable : true,
        autoShow : true,
        hideDelay : 10000,
        dismissDelay : 100000,
        anchorOffset : 0,
        bodyStyle : 'padding: 10px; background-color: ivory',
        listeners : {
            'hide' : function() {
                this.destroy();
            },
            'renderX' : function() {
                this.header.on('click', function(e) {
                    e.stopEvent();
                    Ext.Msg.alert('Link', 'Link to something interesting.');
                }, this, {
                    delegate : 'a'
                });
            }
        }
    }));
    stickGlobal.helpTooltip.show();
    Ext.get('stickTooltipHelp').highlight();
}

/**
 * 
 * When Don't show this message agin checkbox is clicked, update the suppress
 * 
 * help in the user preference
 * 
 */
function stickSuppressHelp() {

    var logger = new stickobjLogger(arguments);

    var suppressHelp = 'T';

    if (jStick('#stickNotifChkboxDontShow:checked').length != 0) {

        alert('To display the StickyNotes tutorial again, click Help from the StickyNotes toolbar menu.');

    } else {

        suppressHelp = 'F';

    }

    stickSuiteletProcessAsyncUser('suppressHelp', suppressHelp, function(isOK) {

        logger.log('isOK=' + isOK);

        if (isOK != 'ok') {

            stickShowError('error in suppressHelp');

            return;

        }

    });

}

/**
 * 
 * Suppress the display of welcome help if Do not display checkbox is checked.
 * 
 */
function stickCloseHelp() {

    var logger = new stickobjLogger(arguments);

    Ext.Msg.hide();

    stickHideHelp();

}
stickGlobal.lastZIndex = 100;
function stickGetRecordType() {
    return nlapiGetRecordType() || stickGlobal.recordTypeScriptId;
}
/**
 * Adds trim functions if browser has no support
 */
function stickAddTrimFunctions() {
    if (typeof String.trim == 'undefined') {
        String.prototype.trim = function() {
            return this.replace(/^\s+|\s+$/g, "");
        };
    }
    if (typeof String.ltrim == 'undefined') {
        String.prototype.ltrim = function() {
            return this.replace(/^\s+/, "");
        };
    }
    if (typeof String.rtrim == 'undefined') {
        String.prototype.rtrim = function() {
            return this.replace(/\s+$/, "");
        };
    }
}
stickAddTrimFunctions();
/**
 * Renders the new note icon beside the field
 * 
 * @param {string}
 *        id - This is the element id of the span label
 */
function stickSetFieldIcon(labelId) {
    var fieldScriptId = labelId.replace('_fs_lbl', '');
    var iconMarkup = '<div title="Click to create a StickyNotes note linked to this field." onclick="stickNewNote(event);" data-fieldScriptId="' + fieldScriptId + '" class="stickFieldIcon" style="" class="stickNote" title="Create a new reminder" id="stickNew' + fieldScriptId + '"></div>';
    // get parent
    // var parentTdNode = Ext.get(labelId).findParent('td', 50, true);
    // var parentX = Ext.get(parentNode);
    Ext.get(labelId).insertHtml('beforeBegin', iconMarkup);
    // var icon = '<a href=#><img onclick="return msgSendMessage(event, \'' + id
    // + '\');"
    // src=/c.3487292/suitebundle26198/images/icon_lists_wordballoon.png
    // /></a>';
    // Ext.get(id).dom.outerHTML = iconMarkup + ' ' + Ext.get(id).dom.outerHTML;
}
function stickSetFieldLinks() {
    var logger = new stickobjLogger(arguments);
    /**
     * reset the linked field if the user clicks a button at the top of the page
     */
    Ext.get('stickNewNoteLinkBox').on('mouseenter', function(e) {
        delete stickGlobal.fieldScriptId;
    });
    // copy the new notes buttons
    Ext.get('stickFieldMenuLinksBox').update('New Field-Level Note: ' + Ext.get('stickNewNoteLinkBox').dom.innerHTML.substring(11));
    var els = Ext.select('span span.smallgraytextnolink').elements;

    // logger.log('els.length=' + els.length);
    for (var i = 0; i < els.length; i++) {
        var el = els[i];
        // var onclick = el.onclick;
        var labelElId = el.id;
        if (stickHasNoValue(labelElId)) {
            continue;
        }
        if (labelElId.indexOf('_lbl') == -1) {
            // not a field
            continue;
        }
        var innerText = jStick(el).text(); // el.innerText || el.textContent;
        if (labelElId == 'autoname_fs_lbl') {
            logger.log('innerText=' + innerText);
        }
        if (typeof String.prototype.trim !== 'function') {
            String.prototype.trim = function() {
                return this.replace(/^\s+|\s+$/g, '');
            };
        }
        if (innerText.trim() === '') {
            continue;
        }
        if (labelElId !== null) {
            // logger.log(id);
            // stickSetFieldIcon(labelElId);
            stickSetMouseEventsForLabel(labelElId);
        }
    }
}
function stickShowFieldMenuNoDelay(labelId) {
    delete stickGlobal.showMenuTimeoutId;
    var xLabel = Ext.get(labelId);
    var xMenu = Ext.get('stickFieldMenuBox');
    // position above the label since the "What's this" tooltip is
    // at the bottom
    xMenu.setTop(xLabel.getTop() - xMenu.getHeight());
    xMenu.setLeft(xLabel.getLeft());
    if (xMenu.isVisible()) {
        return;
    }
    xMenu.fadeIn();
}
function stickHideFieldMenuNoDelay(labelId) {
    // delete stickGlobal.showMenuTimeoutId;
    // var xLabel = Ext.get(labelId);
    var xMenu = Ext.get('stickFieldMenuBox');
    xMenu.hide();
    // // position above the label since the "What's this" tooltip is
    // // at the bottom
    // xMenu.setTop(xLabel.getTop() - xMenu.getHeight());
    // xMenu.setLeft(xLabel.getLeft());
    // if (xMenu.isVisible()) {
    // return;
    // }
    // xMenu.fadeIn();
}
function stickSetMouseEventsForLabel(labelId) {
    var logger = new stickobjLogger(arguments, true);
    /**
     * field label
     */
    jStick('#' + labelId).on('mouseenter', function(e) {
        logger.log('mouseenter');
        try {
            // stickGlobal.labelId = this.id;
            // keep track of the field script id only if the note entry screen
            // is not yet displayed
            if (Ext.get('stickEntry').isVisible() === false) {
                stickGlobal.fieldScriptId = this.id.replace('_fs_lbl', '');
                stickGlobal.fieldScriptId = stickGlobal.fieldScriptId.replace('_lbl', '');
            }
            if (stickHasValue(stickGlobal.hideMenuTimeoutId)) {
                clearInterval(stickGlobal.hideMenuTimeoutId);
                delete stickGlobal.hideMenuTimeoutId;
            }
            if (stickHasValue(stickGlobal.showMenuTimeoutId)) {
                clearInterval(stickGlobal.showMenuTimeoutId);
                delete stickGlobal.showMenuTimeoutId;
            }
            stickGlobal.showMenuTimeoutId = setTimeout(function() {
                stickShowFieldMenuNoDelay(labelId);
                // delete stickGlobal.showMenuTimeoutId;
                // var xLabel = Ext.get(labelId);
                // var xMenu = Ext.get('stickFieldMenuBox');
                //
                // // position above the label since the "What's this" tooltip
                // is
                // // at the bottom
                // xMenu.setTop(xLabel.getTop() - xMenu.getHeight());
                // xMenu.setLeft(xLabel.getLeft());
                // if (xMenu.isVisible()) {
                // return;
                // }
                // xMenu.fadeIn();
            }, 1000);
            // if (e.target.id === '') {
            // logger.log("e.target.id === ''");
            // return;
            // }
            // Ext.select('#stickRecipients .stickShowOnHover').hide();
            // Ext.select('#' + e.target.id + ' .stickShowOnHover').show();
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseenter ' + e);
            }
        }
    });
    jStick('#' + labelId).on('mouseleave', function(e) {
        logger.log('mouseleave');
        try {
            if (stickHasValue(stickGlobal.showMenuTimeoutId)) {
                clearInterval(stickGlobal.showMenuTimeoutId);
                delete stickGlobal.showMenuTimeoutId;
            }
            if (stickHasValue(stickGlobal.hideMenuTimeoutId)) {
                clearInterval(stickGlobal.hideMenuTimeoutId);
                delete stickGlobal.hideMenuTimeoutId;
            }
            stickGlobal.hideMenuTimeoutId = setTimeout(function() {
                var xMenu = Ext.get('stickFieldMenuBox');
                xMenu.hide();
                delete stickGlobal.hideMenuTimeoutId;
            }, 1000);
            return true;
        } catch (e) {
            if (typeof console != 'undefined') {
                console.error('postouter mouseleave ' + e);
            }
        }
    });
    Ext.get('stickFieldMenuBox').on('mouseenter', function(e) {
        logger.log('stickFieldMenuBox mouseenter');
        if (stickIsMobile()) {
            return;
        }
        // try {
        //
        if (stickHasValue(stickGlobal.hideMenuTimeoutId)) {
            clearInterval(stickGlobal.hideMenuTimeoutId);
            delete stickGlobal.hideMenuTimeoutId;
        }
        //
        // // stickGlobal.hideMenuTimeoutId = setTimeout(function() {
        // // var xMenu = Ext.get('stickFieldMenuBox');
        // // xMenu.fadeOut();
        // // delete stickGlobal.hideMenuTimeoutId;
        // // }, 1500);
        // return true;
        // } catch (e) {
        // if (typeof console != 'undefined') {
        // console.error('postouter mouseleave ' + e);
        // }
        //
        // }
    });
    Ext.get('stickFieldMenuBox').on('mouseleave', function(e) {
        logger.log('stickFieldMenuBox mouseleave');
        if (stickIsMobile()) {
            return;
        }
        // try {
        //
        if (stickHasValue(stickGlobal.showMenuTimeoutId)) {
            clearInterval(stickGlobal.showMenuTimeoutId);
            delete stickGlobal.showMenuTimeoutId;
        }
        if (stickHasValue(stickGlobal.hideMenuTimeoutId)) {
            clearInterval(stickGlobal.hideMenuTimeoutId);
            delete stickGlobal.hideMenuTimeoutId;
        }
        //
        stickGlobal.hideMenuTimeoutId = setTimeout(function() {
            var xMenu = Ext.get('stickFieldMenuBox');
            xMenu.hide();
            delete stickGlobal.hideMenuTimeoutId;
        }, 1000);
        return true;
    });
    logger.log('end');
}



/**
 * Positions the notes
 */
function stickPositionNotes() {
    var logger = new stickobjLogger(arguments);
    // distance between 2 notes when the fields they are linked to are hidden.
    stickGlobal.NOTES_DISTANCE = 40;
    var hiddenFieldCount = 0;
    var notes = stickGlobal.notes;
    // this will be used keeping track of the number of notes attached per field
    // so that the notes don't overlap
    var fieldNoteCountHash = {};
    // logger.log('notes.length=' + notes.length);
    for (var i = 0; i < notes.length; i++) {
        var note = notes[i];
        var fieldScriptId = note.field_script_id;

        if (stickHasValue(fieldScriptId)) {
            if (stickHasValue(fieldNoteCountHash[fieldScriptId])) {
                fieldNoteCountHash[fieldScriptId] = fieldNoteCountHash[fieldScriptId] + 1;
            } else {
                fieldNoteCountHash[fieldScriptId] = 1;
            }
            // logger.log('labelId=' + labelId);
            var elNote = Ext.get('stickBox' + note.internalid);
            // display below the label
            var labelId = fieldScriptId + '_fs_lbl';
            var xNote = Ext.get(elNote);
            if (stickHasNoValue(xNote)) {
                // probably deleted
                continue;
            }
            // logger.log('labelId=' + labelId);
            // check if label is visible
            var xLabel = Ext.get(labelId);
            if (xLabel === null) {
                // Issue: 281386 [StickyNotes] When a note is attached to a
                // field that becomes hidden at certain condition, an error is
                // encountered, making the notes dysfunctional
                labelId = fieldScriptId + '_displayval';
                xLabel = Ext.get(labelId);
                if (xLabel === null) {
                    continue;
                }
            }
            
            // not sure why xLabel.isVisible() returns true even if it is hidden
            var isVisible = (xLabel.getLeft() > 0);
            if (Ext.isIE) {
                // there is a problem in IE where when the label is hidden, the
                // getLeft value is greater than the clientWidth
                // so treat that as hidden
                if (xLabel.getLeft() > jStick('#div__header').width()) {
                    isVisible = false;
                }
            }
            var curTop = xNote.getTop();
            var curLeft = xNote.getLeft();
            var newTop, newLeft;
            // logger.log('isVisible=' + isVisible);
            if (isVisible) {
                // align left to label
                // 10 is obtained from the margin of stickNote css class
                stickGlobal.NOTE_MARGIN = 0;
                newLeft = xLabel.getLeft() - stickGlobal.NOTE_MARGIN - 10 + ((fieldNoteCountHash[fieldScriptId] - 1) * stickGlobal.NOTES_DISTANCE);
                // place just below the field 
                // the field value (either text or input) is a child of the field label (span)
                var tdLabel = xLabel.dom.parentNode;
                var xTdLabel = Ext.get(tdLabel);
                // logger.log('xField.getHeight() =' + xField.getHeight());
                newTop = xTdLabel.getTop() + xTdLabel.getHeight() - stickGlobal.NOTE_MARGIN;
            } else {
                // place at the top right just below the pt_body
                var xPtBody = Ext.get(Ext.select('.pt_body').elements[0]);
                if (stickHasNoValue(xPtBody)) {
                    xPtBody = Ext.get(Ext.select('.uir-page-title-firstline').elements[0]);
                }
                // logger.log('xBar.getTop()=' + xBar.getTop());
                newTop = xPtBody.getTop() + xPtBody.getHeight();
                newTop = newTop + hiddenFieldCount * stickGlobal.NOTES_DISTANCE;
                newLeft = Ext.get('div__header').getWidth() - xNote.getWidth() - stickGlobal.noteMargin;
                newLeft = newLeft - hiddenFieldCount * stickGlobal.NOTES_DISTANCE;
                hiddenFieldCount++;
            }
            if (curTop == newTop && curLeft == newLeft) {
                // position didnot change
                continue;
            }
            if (stickGlobal.hasLoaded) {
                // animate
                jStick('#stickBox' + note.internalid).animate({
                    top : newTop,
                    left : newLeft
                });
            } else {
                xNote.setLeft(newLeft);
                xNote.setTop(newTop);
            }
            // remove rotation
            stickRemoveRotation('stick' + note.internalid);
        }
    }
    delete stickGlobal.stickPositionNotesTimeoutId;
    logger.end();
}
/**
 * Sets the rotation of an element to 0
 * 
 * @param elementId
 */
function stickRemoveRotation(elementId) {
    // remove rotation
    jStick('#' + elementId).css({
        'transform' : 'rotate(0deg)'
    }).css({
        '-ms-transform' : 'rotate(0deg)'
    }).css({
        '-moz-transform' : 'rotate(0deg)'
    }).css({
        '-o-transform' : 'rotate(0deg)'
    }).css({
        '-webkit-transform' : 'rotate(0deg)'
    });
}





function stickSetColorInputEvents()
{
    Ext.select('.stickColorInput').on('focus', function(evt, target) { stickShowColorPicker(target); });

    Ext.select('.stickColorInput').on('keyup', function(evt, target)
    {
        var color = target.value;
        Ext.get(target).setStyle({
            backgroundColor: color
        });
        // animate doesnot support powderblue
        // jStick('#' + target.id).animate({
        // backgroundColor : color
        // }, 500);
    });
}





function stickRenderUserPrefs()
{
    stickSuiteletProcessAsync('getUserOrAccountCategories', 'test', function(categories)
    {
        stickTemplateAppend('tmpStickNoteCategory', 'stickNoteCategoryBox', categories);
        stickSetColorInputEvents();
        stickTemplateAppend('tmpStickNoteUserPreference', 'stickNoteUserPreference', stickGlobal.paramUserPref);
        stickLoadFontAndNoteSizes();
        Ext.get('stickFontSize').show();
        Ext.get('stickNoteSize').show();
    });
}





function stickSaveCategoryColors() {
    Ext.get('stickColorPicker').hide();
    var usercategoryColors = [];
    var els = Ext.select('#stickNoteCategoryBox .stickColorInput').elements;
    for (var i = 0; i < els.length; i++) {
        var userCategory = {};
        userCategory.internalid = els[i].getAttribute('data-internalid');
        userCategory.categoryId = els[i].getAttribute('data-categoryid');
        userCategory.priority = els[i].getAttribute('data-priority');
        var color = els[i].value;
        userCategory.categoryColor = color;
        usercategoryColors.push(userCategory);
        // update color of displayed notes
        Ext.select('.stick-' + userCategory.categoryId).setStyle({
            backgroundColor : color
        });
        Ext.select('.stick-new-link[data-category-id="' + userCategory.categoryId + '"]').setStyle({
            backgroundColor : color
        });
        Ext.select('#stickFilterLinkBox div .stick-filter-note-link[data-category-id="' + userCategory.categoryId + '"]').setStyle({
            backgroundColor : color
        });
        Ext.select('#stickFilterLinkBox .stick-link-box[data-category-id="' + userCategory.categoryId + '"]').set({
            'data-background-color' : color
        });
        Ext.get('stickCategoryColor' + userCategory.priority).setStyle({
            backgroundColor : color
        });
        // jStick('.stick-' + userCategory.internalid).animate({
        // backgroundColor : color
        // }, 750);
    }
    stickSuiteletProcessAsync('updateUserCategoryColors', usercategoryColors, function(isOk) {
        if (isOk !== 'ok') {
            throw 'Error in updateUserCategoryColors';
        }
        // Ext.get('stickUserPreferenceBox').hide();
    });
}



function stickShowUserPreferenceDialog()
{
    jStick('#stickUserPrefInfo').html('&nbsp;');
    stickHideLinksBoxNoDelay();
    stickWait();
    Ext.get('stickUserPreferenceBox').center();
    Ext.get('stickFontSize').show();
    Ext.get('stickNoteSize').show();
    jStick('#stickHideNote').attr('checked', nlapiGetContext().getPreference("custscript_stick_initially_hide_sticky_n") == "T");
    Ext.get('stickHideNote').dom.disabled = false;
    Ext.get('stickUserPreferenceBox').dom.style.visibility = 'visible';
}





function stickLoading()
{
    stickWait('Please wait while StickyNotes loads...');
}





function stickResetToDefault()
{
    // sort by font size then get 2nd record
    stickSuiteletProcessAsync('getDefaultFontSize', 'test', function(defaultFontSize)
    {
        jStick('#stickFontSize').val('stickFontSize' + defaultFontSize.internalid);
        // sort by width then get 1st record
        stickSuiteletProcessAsync('getDefaultNoteSize', 'test', function(defaultNoteSize)
        {
            jStick('#stickNoteSize').val('stickNoteSize' + defaultNoteSize.internalid);

            jStick('#stickHideNote').attr('checked', nlapiGetContext().getPreference("custscript_stick_initially_hide_sticky_n") == "T");
            
            jStick("#selectKbShortcut").val(nlapiGetContext().getPreference("custscript_stick_submit_keyboardshortcut"));
            
            stickSavePreference();
            // default delete user category settings
            stickSuiteletProcessAsync('deleteUserCategories', 'test', function(isOk)
            {
                stickSuiteletProcessAsync('getUserOrAccountCategories', 'test', function(categories)
                {
                    var els = Ext.select('#stickNoteCategoryBox .stickColorInput').elements;
                    for (var i = 0; i < els.length; i++)
                    {
                        var category = categories[i];
                        Ext.get('stickCategoryColor' + category.priority).setStyle({
                            backgroundColor: category.categoryColor
                        });
                        jStick('#stickCategoryColor' + category.priority).val(category.categoryColor);
                        Ext.select('.stick-' + category.categoryId).setStyle({
                            backgroundColor: category.categoryColor,
                            width: defaultNoteSize.noteSize,
                            height: defaultNoteSize.noteSize,
                            'font-size': defaultFontSize.fontSize + 'px'
                        });
                        Ext.select('.stick-new-link[data-category-id="' + category.categoryId + '"]').setStyle({
                            backgroundColor: category.categoryColor
                        });
                        Ext.select('#stickFilterLinkBox div .stick-filter-note-link[data-category-id="' + category.categoryId + '"]').setStyle({
                            backgroundColor: category.categoryColor
                        });

                        Ext.select('.inputreadonly .stick-link-box[data-category-id="' + category.categoryId + '"]').set({
                            'data-background-color': category.categoryColor
                        });
                    }
                });
                if (isOk !== 'ok')
                {
                    throw 'Error in deleteUserCategories';
                }
            });
        });
    });
}





//TODO
function stickValidateUserPreference()
{
    var colorNoValueCount = jStick('#stickNoteCategoryBox input[value=]').length;
    if (colorNoValueCount > 0)
    {
        jStick('#stickNoteCategoryBox input[value=]')[0].focus();
        jStick('#stickUserPrefInfo').html('Please provide color value');
        return false;
    }
    return true;
}





//TODO
function stickSavePreference()
{
    var param = {
        hideSticky: jStick('#stickHideNote').prop('checked') === true ? 'T' : 'F',
        noteSize: jStick('#stickNoteSize option:selected').attr('data-internalid'),
        fontSize: jStick('#stickFontSize option:selected').attr('data-internalid'),
        kbShortcut: jStick("#selectKbShortcut").val()
    };

    Ext.get('stickHideNote').dom.disabled = true;
    
    
    if (stickGlobal.paramUserPref.hideNotes === '' && param.hideSticky === 'T')
    {
        stickHideOrShowAll();
        stickGlobal.paramUserPref.hideNotes = 'checked';
    }
    else if (stickGlobal.paramUserPref.hideNotes === 'checked' && param.hideSticky === 'F')
    {
        stickHideOrShowAll();
        stickGlobal.paramUserPref.hideNotes = '';
    }
    
    stickSuiteletProcessAsyncUser('updateUserPreference', param, function(isOk)
    {
        if (isOk !== 'ok')
        {
            throw 'Error in updateUserPreference';
        }
        
        var fontSize = jStick('#stickFontSize option:selected').attr('data-fontsize') + 'pt';
        var width = jStick('#stickNoteSize option:selected').attr('data-width');
        var height = jStick('#stickNoteSize option:selected').attr('data-height');
        stickGlobal.dataSet.noteSize.width = width;
        stickGlobal.dataSet.noteSize.height = height;
        Ext.select('.stickNoteBox').setStyle({
            width: width,
            height: width,
            'font-size': fontSize
        });
        Ext.select('#stickLineHeight').setStyle({
            'font-size': fontSize
        });
        stickGlobal.dataSet.fontSize = fontSize;
        stickSetNoteElementsSizes();
    });

    stickGlobal.paramUserPref.kbShortcut = param.kbShortcut;
    
}





function stickLoadFontAndNoteSizes()
{
    var param = {};
    param.noteSizeId = '';
    param.fontSizeId = '';
    stickSuiteletProcessAsync('getNoteAndFontSizes', param, function(noteAndFontSizes)
    {
        jStick("#stickNoteSize").empty();
        jStick("#stickFontSize").empty();
        var noteSizes = noteAndFontSizes[0];
        var fontSizes = noteAndFontSizes[1];
        for (var i = 0; i < noteSizes.length; i++)
        {
            var noteSize = noteSizes[i];
            var select = document.getElementById("stickNoteSize");
            var option = document.createElement("option");
            option.value = 'stickNoteSize' + noteSize.internalid;
            option.text = noteSize.noteSizeName;
            option.setAttribute('data-internalid', noteSize.internalid);
            option.setAttribute('data-width', noteSize.width);
            option.setAttribute('data-height', noteSize.height);
            option.selected = noteSize.internalid === stickGlobal.paramUserPref.noteSizeId;
            select.add(option);
        }

        for (var i = 0; i < fontSizes.length; i++)
        {
            var fontSize = fontSizes[i];
            var select = document.getElementById("stickFontSize");
            var option = document.createElement("option");
            option.value = 'stickFontSize' + fontSize.internalid;
            option.text = fontSize.fontSizeName;
            option.setAttribute('data-internalid', fontSize.internalid);
            option.setAttribute('data-fontSize', fontSize.fontSize);
            option.selected = fontSize.internalid === stickGlobal.paramUserPref.fontSizeId;
            select.add(option);
        }

        jStick("#selectKbShortcut").val(nlapiGetContext().getPreference("custscript_stick_submit_keyboardshortcut"));
    });
}





function stickCancelPreference()
{
    var els = Ext.select('.stickColorInput').elements;
    for (var i = 0; i < els.length; i++)
    {
        var internalid = els[i].getAttribute('data-internalid');
        var oldColor = els[i].getAttribute('value');
        Ext.select('.stickColorInput[data-internalid="' + internalid + '"]').setStyle({
            backgroundColor: oldColor
        });
        jStick('.stickColorInput[data-internalid="' + internalid + '"]').val(oldColor);
    }
    jStick('#stickFontSize').val('stickFontSize' + stickGlobal.paramUserPref.fontSizeId);
    jStick('#stickNoteSize').val('stickNoteSize' + stickGlobal.paramUserPref.noteSizeId);
    jStick('#stickHideNote').attr('checked', stickGlobal.paramUserPref.hideNotes === '' ? false : true);

    jStick("#selectKbShortcut").val(nlapiGetContext().getPreference("custscript_stick_submit_keyboardshortcut"));
}





function stickProcessDataSet()
{
    var logger = new stickobjLogger(arguments);
    // render the new note links
    var dataSet = stickGlobal.dataSet;
    var paramUserPref = stickGlobal.paramUserPref;

    // render the notes
    stickProcessPreRendered();
    var notes = dataSet.notes;
    // JC : Render the notes template and data (existing notes)
    stickTemplateAppendNotes(notes);
    stickPositionNotes();
    stickProcessRenderedNotes();

    // re-positions notes on click of tab to position the notes attached to hidden fields
    Ext.select('.formtaboff, .formtabon').on('click', function() { stickPositionNotes(); });

    stickSetMouseOverAndOutEvents();
    stickSetMouseEventsForReplies();
    if (paramUserPref.hideNotes == '')
    {
        // display the notes
        Ext.select('#stickNoteBox .stickBox').fadeIn();
    }

    jStick(window).resize(stickRecordPageResize);
    stickGlobal.hasLoaded = true;
    stickWhatsNewHelp();
    Ext.Msg.hide();
    logger.end();
}





function stickDisplayToolBar() {
    // Append stickynotes toolbar at the right of actions menu

    var trToolbar = Ext.select('.uir-header-buttons tr').elements[0];

    var stickButtonMenuDivider = '<td><table border="0" cellpadding="0" cellspacing="0" class="uir-button-menu-divider" style="margin-right:6px;  margin-left:15px;"><tbody><tr><td class="rndbuttoncaps" bgcolor="#B5B5B5"><img src="/images/nav/ns_x.gif" border="0" width="1" height="19"></td></tr></tbody></table></td>'

    trToolbar.innerHTML += stickButtonMenuDivider + '<td id="td_stickToolBar"></td>';

    Ext.get('td_stickToolBar').appendChild('stickToolbarBox');
    Ext.get('stickToolbarBox').setStyle({
        'display' : 'inline-block'
    }).show();
    // Ext.get('tbl_secondarycustpage_stick_new').dom.style.display = 'none';
}
function stickSetMouseEventsBeforeNotesRender() {
    if (stickIsMobile()) {
        return;
    }
    selector = '#stickNoteActionsBox';
    jStick(selector).mouseenter(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mousemove(function(evt) {
        // var logger = new stickobjLogger(selector + ' mousemove');
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mouseleave(function(evt) {
        stickHideNoteActionsMenu(evt);
    });
    selector = '#stickMenuLink';
    jStick(selector).mousemove(function() {
        stickShowLinksBox();
        return false;
    });
    jStick(selector).mouseleave(function() {
        stickHideLinksBox();
        return false;
    });
    selector = '#stickLinksBox';
    jStick(selector).mousemove(function() {
        stickShowLinksBox();
        return false;
    });
    jStick(selector).mouseleave(function() {
        stickHideLinksBox();
        return false;
    });
    jStick('body').click(function(e) {
        if (e.target.id !== 'stickSOpenBoard' && Ext.get('stickLinksBox').isVisible() && stickGlobal.tooltips.length == 0) {
            stickHideLinksBoxNoDelay();
            return false;
        }
    });
    var selector = '#stickNewNoteLinksBox .stick-action-link';
    jStick(selector).mouseenter(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mousemove(function(evt) {
        stickShowNoteActionsMenu(evt);
    });
    jStick(selector).mouseleave(function(evt) {
        stickHideNoteActionsMenu(evt);
    });
    jStick('#stickFilterLinkBox .stick-link-box').mouseenter(function(evt) {
        jStick(this).addClass('stick-link-box-hover');
    });
    jStick('#stickFilterLinkBox .stick-link-box').mouseleave(function(evt) {
        jStick(this).removeClass('stick-link-box-hover');
    });
}

function stickAreNotesVisible() {
    return Ext.get('stickShowOrHideAll').dom.innerHTML == 'Hide Notes';
}



function stickPageInit()
{
    var logger = new stickobjLogger(arguments);
    Ext.get('stickSOpenBoard').dom.href = nlapiResolveURL('suitelet', 'customscript_stick_board_frontend_sl', 'customdeploy_stick_board_frontend_sl');
    if (Ext.isIE)
    {
        // stickShowWarning("C'mon! Don't expect a prototype to run on IE ;) Use
        // the latest version of Firefox.", stickGlobal.TITLE);
        // return;
    }
    Ext.get('stickSearchEmployeeTextBox').on('keyup', function(e)
    {
        onStickSearchEmployeeTextBoxKeyup(e);
    });
    stickGlobal.isBoard = Ext.get('custpage_stick_board_val') !== null;
    var recordTypeScriptId = stickGetRecordType();
    // the existence of custpage_stick_board_val means the page is the stick
    // board
    if (recordTypeScriptId === null && !stickGlobal.isBoard)
    {
        logger.log('recordTypeScriptId === null');
        return;
    }

    stickSetOtherEvents();
    
    // pre-load standard records list
    stickPreLoadStandardRecordsList();

    // get size preference
    stickSuiteletProcessAsyncUser('getUserPreference', 'value', function(paramUserPref)
    {
        // var logger = new stickobjLogger(undefined, false,
        // 'getUserPreference');
        // logger.log('after getUserPreference');
        stickGlobal.paramUserPref = paramUserPref;
        var param = {
            'recordTypeScriptId': recordTypeScriptId,
            'recordId': nlapiGetRecordId(),
            'noteSizeId': paramUserPref.noteSizeId,
            'fontSizeId': paramUserPref.fontSizeId,
            'isBoard': stickGlobal.isBoard
        };
        // JC : Gets the user's notes from the server
        stickSuiteletProcessAsync('getDataSet', param, function(dataSet)
        {
            // var logger = new stickobjLogger(undefined, false, 'getDataSet');
            // try {
            stickGlobal.dataSet = dataSet;
            stickGlobal.notes = dataSet.notes;
            // set font size for stickLineHeight
            Ext.get('stickLineHeight').setStyle({
                'font-size': dataSet.fontSize
            });
            if (!stickGlobal.isBoard)
            {
                stickDisplayToolBar();
            }
            var categories = dataSet.categories;
            // new notes
            stickTemplateAppend('tmpNoteFiltersLink', 'stickFilterLinkBox', categories);
            // filtering
            stickTemplateAppend('tmpNewNoteLink', 'stickNewNoteLinkBox', categories);
            stickRenderUserPrefs();
            stickSetFieldLinks();
            stickSetMouseEventsBeforeNotesRender();
            
            // set loading image
            jStick('#stickInfoNew img').attr({
                src : dataSet['stick-loading-ani-trans.gif']
            });
            
            // get image urls
            if (stickHasNoValue(stickGlobal.imageUrls)) {
                var imageUrls = jStick('#stickImageUrls');
                if (stickHasValue(imageUrls)) {
                    stickGlobal.imageUrls = JSON.parse(imageUrls.text());
                }
            }

            if (paramUserPref.hideNotes == 'checked')
            {
                Ext.get('stickShowOrHideAll').update('Show Notes');
                // if there are notes, show a tooltip
                if (dataSet.notes.length > 0)
                {
                    var noteOrNotes = dataSet.notes.length > 1 ? 'notes' : 'note';
                    var isOrAre = dataSet.notes.length > 1 ? 'are' : 'is';
                    var helpText = '<div id="stickHiddenNotesText">' + 'There ' + isOrAre + ' ' + dataSet.notes.length + ' hidden ' + noteOrNotes + ' on this record page. To display the ' + noteOrNotes + ', click or point to the StickyNotes menu, and then click Show Notes.' + '<br><br></div>';
                    stickShowTooltip('stickToolbarStickyNotesButton', helpText);
                    jStick('#stickHiddenNotesText').append(jStick('#stickHiddenNotesbuttons').clone());
                    Ext.select('#stickHiddenNotesbuttons').show();
                }
                // do not render the notes when they are initially hidden to
                // prevent freezing of the screen when they are rendered

                // next line will be used by the ui test library
                labsGlobal.pageHasLoaded = true;

                return;
            }
            stickProcessDataSet();

            // next line will be used by the ui test library
            labsGlobal.pageHasLoaded = true;
        });
    });
    logger.log('end');
}




Ext.onReady(function() {
    // try {
    stickPageInit();
    // stickSetFieldLinks();
    // } catch (e) {
    // // uncomment next line in production
    // throw e;
    //
    // }
});



function stickSendCommentsCallback(buttonId, text, opt)
{
    if (nlapiGetContext().getPreference('custscript_stick_enable_email') == "F")  //Checking against "F" ensures uninitiated value defaults to true
    {
        return;
    }

    if (buttonId == 'cancel')
    {
        return false;
    }
    
    var msg = Ext.get('stickComments').dom.value.trim();
    if (msg === '')
    {
        uiShowWarning('Please provide message.', null, function()
        {
            stickSendComments();
        });
        return;
    }
    
    nlapiSendEmail(nlapiGetUser(), 'suitelabs-support@netsuite.com', 'StickyNotes Feedback', msg + '\r\nRating: ' + stickGlobal.rating + (stickGlobal.rating == 1 ? ' star' : ' stars'));
    if (Ext.isChrome)
    {
        alert('Your message has been sent.', 'Confirmation');
    } else
    {
        Ext.Msg.alert('Confirmation', 'Your message has been sent.');
    }
}



function stickSendComments() {
    // show send message popup window
    var msg = "<textarea id='stickComments' rows='10' style='width: 100%; font-size: 8pt'>";
    msg += '\r\n';
    msg += '\r\n';
    msg += '\r\n';
    msg += 'User: ' + nlapiGetContext().getName() + '\r\n';
    msg += 'Role: ' + stickGlobal.dataSet.roleName + '\r\n';
    msg += 'Email: ' + nlapiGetContext().getEmail() + '\r\n';
    msg += 'Company: ' + nlapiGetContext().getCompany() + '\r\n';
    msg += '</textarea>';
    msg += '<div style="background-color: white; border: 1px solid gray; margin-top: 2px; padding: 2px; vertical-align: middle; font-size: 8pt"><span style="top: -3px; position: relative">Rating:</span> ' + stickGetRatingMarkup() + '</div>';
    Ext.Msg.show({
        title : 'StickyNotes &raquo; Let us know what you think',
        msg : msg,
        width : 480,
        buttons : Ext.MessageBox.OKCANCEL,
        multiline : false,
        fn : stickSendCommentsCallback,
        animEl : 'addAddressBtn',
        icon : Ext.MessageBox.INFO,
        buttons : {
            ok : "Send",
            cancel : "Cancel"
        }
    });
    setTimeout("Ext.get('stickComments').dom.focus();", 500);
    return false;
}