/**
 * � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
 */

/**
 * @author tcaguioa
 *
 *
 *
 *
 */

/**
 * Hi all, As you probably know, UI code refactoring is currently going on in
 * order to enable mobile view of records in our upcoming iPhone app. As a part
 * of this refactoring we had to make a few changes to the internal UI api used
 * by other developer teams. In particular, the following javascript variables
 * and functions are no longer supported: - window.ischanged - window.isvalid -
 * window.isinited and window.setIsInited() The variables were encapsulated in a
 * new NS.form javascript object that is defined in NLUtil.jsp. To access them
 * please use the following methods: - NS.form.setChanged(boolean) and
 * NS.form.isChanged() - NS.form.setValid(boolean) and NS.form.isValid() -
 * NS.form.setInited(boolean) and NS.form.isInited() In case you need to change
 * the state of parent window, it is possible prepend the calls with �parent.�
 * or �opener.� prefixes (e.g., parent.NS.form.setInited(true)). The main motive
 * for this change is to be able to perform actions in response to the change of
 * these attributes in the mobile app. IMPORTANT: All occurrences of the
 * deprecated variables in ML and NetLedger_Release_George were replaced. Please
 * check you feature branches and update them appropriately. Please let me or
 * the UI team know if you have any questions or comments regarding this change.
 * Thanks, Ondrej
 */

if (typeof NS == 'undefined') {

    NS = {};

    NS.form = {};

    NS.form.setChanged = function(bool) {

        window.ischanged = bool;

    };

    NS.form.isChanged = function(bool) {

        return window.ischanged;

    };

}

var stickGlobal = stickGlobal || {};

/**
 * Returns true if the browser is running on mobile
 * 
 * @returns
 */

function stickIsMobile() {

    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

}

/**
 * Animates an element by changing the height until it becomes 0
 * 
 * @param {Object}
 *        extElement
 */

function stickAnimateHide(extElement) {

    // if (Ext.isIE) {

    // extElement.dom.style.display = 'none';

    // return;

    // }

    if (extElement.getHeight() !== 0) {

        extElement.dom.setAttribute('originalHeight', extElement.getHeight());

    }

    extElement.setStyle('overflow', 'hidden');

    var props = {

        height : {

            to : 0,

            from : extElement.getHeight()

        }

    };

    extElement.animate(props, 0.250, function() {

        extElement.hide();

    }, 'easeOut', 'run');

}

/**
 * Animates an element by changing the height until it becomes 0
 * 
 * @param {Object}
 *        extElement
 */

function stickAnimate(extElement, callback) {

    // if (Ext.isIE) {

    // extElement.dom.style.display = 'none';

    // return;

    // }

    if (extElement.getHeight() !== 0) {

        extElement.dom.setAttribute('originalHeight', extElement.getHeight());

    }

    extElement.setStyle('overflow', 'hidden');

    var props = {

        height : {

            to : 0,

            from : extElement.getHeight()

        }

    };

    if (callback) {

        extElement.animate(props, 0.250, null, 'easeOut', 'run');

    } else {

        extElement.animate(props, 0.250, callback(), 'easeOut', 'run');

    }

}

function stickCenter(el) {

    // var logger = new stickobjLogger(arguments);

    // if (typeof el == 'string') {

    // el = Ext.get(el).dom;

    // }

    Ext.get(el).center();

    // var left = (Ext.getBody().dom.clientWidth - Ext.get(el).getWidth()) / 2;

    // var top = (Ext.getBody().dom.clientHeight - Ext.get(el).getHeight()) / 2;

    // logger.log('left=' + left);

    // logger.log('top=' + top);

    // Ext.get(el).setTop(top);

    // Ext.get(el).setLeft(left);

    // Ext.get(el).setStyle({

    // position : 'absolute'

    // });

}

function stickCenterUsingXY(el) {

    var logger = new stickobjLogger(arguments);

    if (typeof el == 'string') {

        el = Ext.get(el).dom;

    }

    var x = (Ext.getBody().getWidth() - Ext.get(el).getWidth()) / 2;

    var y = (Ext.getBody().getHeight() - Ext.get(el).getHeight()) / 2;

    logger.log('x=' + x);

    logger.log('y=' + y);

    Ext.get(el).setY(y);

    Ext.get(el).setX(x);

}

function stickCenterAnimate(el) {

    var x = Ext.get(el);

    x.setStyle('position', 'absolute');

    var xPos = (Ext.getBody().getWidth() - Ext.get(el).getWidth()) / 2;

    var yPos = (Ext.getBody().getHeight() - Ext.get(el).getHeight()) / 2;

    var props = {

        left : {

            to : xPos,

            from : x.getX()

        },

        top : {

            to : yPos,

            from : x.getY()

        }

    };

    x.animate(props, 0.250, function() {

        // extElement.hide();

    }, 'easeOut', 'run');

}

/**
 * @author user
 */

// add indexOf() for Array object since not all browsers support it
if (!Array.prototype.indexOf) {

    Array.prototype.indexOf = function(obj, start) {

        for (var i = (start || 0), j = this.length; i < j; i++) {

            if (this[i] === obj) {

                return i;

            }

        }

        return -1;

    };

}

function stickTemplateApply(tmpId, data) {

    var template = stickGetTemplate(tmpId);

    var myTplPost = new Ext.XTemplate('<tpl for=".">' + template + '</tpl>');

    return myTplPost.apply(data, false);

}

function stickGetTemplate(tmpId) {

    var logger = new stickobjLogger(arguments, true);

    // check if in the template hash

    var template = stickGlobal.dataSet.templateHash[tmpId];

    if (stickHasNoValue(template)) {

        if (Ext.get(tmpId) === null) {

            throw tmpId + ' is null';

        }

        template = document.getElementById(tmpId).innerHTML;

    }

    // it seems IE removes CSS entries on an inline style when the value is

    // invalid.

    // so we needed to use data-style instead of style in the template and then

    // here we replace them

    template = template.replace(/data-style/g, 'style');

    // alert(tmpPost);

    // replace [[ with { and ]] with }

    template = template.replace(/\[\[/g, '{').replace(/\]\]/g, '}');

    logger.log('end');

    return template;

}

function stickTemplateAppend(tmpId, targetId, data) {

    var logger = new stickobjLogger(arguments, true);

    var template = stickGetTemplate(tmpId);

    var myTplPost = new E4S.XTemplate('<tpl for=".">' + template + '</tpl>');

    myTplPost.append(document.getElementById(targetId), data, false);

    logger.log('end');

}

function stickTemplateOverwrite(tmpId, targetId, data) {

    var logger = new stickobjLogger(arguments, true);

    var template = stickGetTemplate(tmpId);

    var myTplPost = new E4S.XTemplate('<tpl for=".">' + template + '</tpl>');

    myTplPost.overwrite(document.getElementById(targetId), data, false);

    logger.log('end');

}

function stickAddTrimFunctions() {

    // add trim functions if browser has no support

    if (typeof String.trim == 'undefined') {

        String.prototype.trim = function() {

            return this.replace(/^\s+|\s+$/g, "");

        };

    }

    if (typeof String.ltrim == 'undefined') {

        String.prototype.ltrim = function() {

            return this.replace(/^\s+/, "");

        };

    }

    if (typeof String.rtrim == 'undefined') {

        String.prototype.rtrim = function() {

            return this.replace(/\s+$/, "");

        };

    }

}

stickAddTrimFunctions();

/**
 * Hides the New option in a select field
 */

function stickHideNewInOptionList() {

    var logger = new stickobjLogger('stickHideNewInOptionList', true);

    // S3 Issue 240819 : [SuiteSocial] the option -New- should be hidden even in

    // other languages

    // drop down item

    var els = document.getElementsByTagName('div');

    for (var i = 0; i < els.length; i++) {

        var text = els[i].innerHTML;

        if (text.length < 2) {

            continue;

        }

        // for the 'New' options, it is in the format '- New -' where the New

        // changes per language

        if (text.substr(0, 2) == '- ') {

            els[i].style.display = 'none';

        }

    }

    logger.log('DONE');

}

function stickHandleResponse(xmlRequest) {

    // alert('stickHandleResponse');

    // alert('stickHandleResponse ' + xmlRequest.responseText);

    if (xmlRequest.status !== 200) {

        // error

        stickShowError('An unexpected error occurred. xmlRequest.status=' + xmlRequest.status);

        return null;

    }

    if (xmlRequest.responseText.indexOf('ERROR:') > -1) {

        stickShowError(JSON.parse(xmlRequest.responseText));

        return false;

    }

    /**
     * For some reasons, the returned string from suitelets sometimes contains
     * debug information from core. This debugging information start with <!--.
     * If this string is found, process only the string before this or better
     * yet mark the end of the data with stickGlobal.END_OF_DATA_MARKER.
     */

    var responseText = xmlRequest.responseText;

    var position = responseText.indexOf(stickGlobal.END_OF_DATA_MARKER);

    if (position > -1) {

        responseText = responseText.substr(0, position);

    } else {

        var position = responseText.indexOf('<!--');

        if (position > -1) {

            responseText = responseText.substr(0, position);

        }

    }

    try {

        var returnObject = JSON.parse(responseText);

    } catch (e) {

        alert('xmlRequest.responseText=' + xmlRequest.responseText);

        return false;

    }

    return returnObject;

}

/**
 * Hides a netsuite button
 * 
 * @param {Object}
 *        label The label of the button
 */

function stickHideNsButton(label) {

    var el = Ext.select('input[value="' + label + '"]').elements[0];

    if (stickHasNoValue(el)) {

        return;

    }

    if (stickHasNoValue(el.parentNode)) {

        return;

    }

    if (stickHasNoValue(el.parentNode.parentNode)) {

        return;

    }

    el.parentNode.parentNode.style.display = 'none';

}

/**
 * TODO: not working consistently This is used in hiding the row where the Add
 * button is located in sublists
 * 
 * @param {Object}
 *        formElementIds Array of form ids of sublists. The ids can be obtained
 *        by using firebug
 */

function stickHideAddButtonRow(formElementId) {

    var logger = new stickobjLogger(arguments);

    // logger.log('formElementIds.length=' + formElementIds.length);

    // for (var i = 0; i < formElementIds.length; i++) {

    var id = formElementId;

    // alert(id);

    var tb = Ext.get(id).dom.children[0];

    // tb.children[0].style.visibility = 'hidden';

    // tb.children[0].style.display = 'none';

    // tb.children[0].children[0].style.visibility = 'hidden';

    tb.children[0].children[0].style.display = 'none';

    // logger.log(tb.children[0].children[0].innerHTML);

    // alert(tb.children[0].children[0].innerHTML);

    // tb.children[0].children[0].innerHTML = '';

    // }

}

// function getFirefoxNotice() {

// if (Ext.isGecko) {

// // browser = "Firefox";

// return '<br /><br />If a dialog box displays with the message below, check

// "Don\'t ask me again" and click "Continue" button in the displayed dialog

// box.<br /><br /><i>"A script on this page may be busy, or it may have stopped

// responding. You can stop the script now, open the script in the debugger, or

// let the script continue."</i><br />';

// }

// return '';

// }

function stickOuterHTML(node) {

    return node.outerHTML || new XMLSerializer().serializeToString(node);

}

/*
 * browser independent implementation of indexOf since IE does not support it
 */

function stickArrayIndexOf(arr, obj) {

    if (Array.indexOf) {

        return arr.indexOf(obj);

    }

    // no support

    for (var i = 0; i < arr.length; i++) {

        if (arr[i] == obj) {

            return i;

        }

    }

    return -1;

}

function stickImplementMissingFunctions() {

    // //*** Array.indexOf implementation

    // if (!Array.indexOf) {

    // Array.prototype.indexOf = function(obj){

    // for (var i = 0; i < this.length; i++) {

    // if (this[i] == obj) {

    // return i;

    // }

    // }

    // return -1;

    // };

    // }

    // jSOn implementation

    var JSON = JSON || {};

    // // implement JSON.stringify serialization

    JSON.stringify = JSON.stringify || Ext.encode;

    JSON.parse = JSON.parse || Ext.decode;

}

// jSOn implementation

var JSON = JSON || {};

// // implement JSON.stringify serialization

JSON.stringify = JSON.stringify || Ext.encode;

JSON.parse = JSON.parse || Ext.decode;

/**
 * Displays an information
 * 
 * @param {Object}
 *        info
 * @param {Object}
 *        title
 */

function stickShowInfo(info, title) {

    if (stickHasNoValue(title)) {

        title = 'Information';

    }

    Ext.MessageBox.show({

        title : title,

        msg : info,

        buttons : Ext.MessageBox.OK,

        icon : Ext.MessageBox.INFO

    });

}

/**
 * Displays a warning
 * 
 * @param {Object}
 *        info
 * @param {Object}
 *        title
 */

function stickShowWarning(info, title) {

    if (stickHasNoValue(title)) {

        title = 'Warning';

    }

    Ext.MessageBox.show({

        title : title,

        msg : info,

        buttons : Ext.MessageBox.OK,

        icon : Ext.MessageBox.WARNING

    });

}

/**
 * Displays an error such as run-time errors and validation errors
 * 
 * @param {Object}
 *        error
 * @param {Object}
 *        title
 */

function stickShowError(error, title) {

    if (stickHasNoValue(title)) {

        title = 'Error';

    }

    Ext.MessageBox.show({

        title : title,

        msg : error,

        buttons : Ext.MessageBox.OK,

        icon : Ext.MessageBox.ERROR

    });

}

stickGlobal.stickWaitPeriods = '.';

function stickWait(message) {

    if (!document) {

        // should run only on browsers

        return;

    }

    stickGlobal.stickWaitPeriods += '.';

    if (stickGlobal.stickWaitPeriods == '....') {

        stickGlobal.stickWaitPeriods = '.';

    }

    if (stickHasNoValue(message)) {

        message = 'Processing';

    }

    Ext.Msg.wait(message, 'Please wait' + stickGlobal.stickWaitPeriods + '<span id="stickWait"></span>');

}

function stickSaveOk() {

    Ext.Msg.hide();

    // Ext.Msg.alert('Save', 'Save succeeded');

    // NS.form.setChanged(false); needs to be placed here since it seems

    // window.ischanged is set to true after the recalc event

    Ext.MessageBox.show({

        title : 'Save'.tl(),

        msg : 'Save succeeded'.tl(),

        buttons : Ext.MessageBox.OK,

        icon : Ext.MessageBox.INFO,

        fn : function() {

            NS.form.setChanged(false);

        }

    });

}

// var t = typeof (obj);

// if (t != "object" || obj === null) {

// // simple data type

// if (t == "string")

// obj = '"' + obj + '"';

// return String(obj);

// } else {

// // recurse array or object

// var n, v, json = [], arr = (obj && obj.constructor == Array);

// for (n in obj) {

// v = obj[n];

// t = typeof (v);

// if (t == "string")

// v = '"' + v + '"';

// else if (t == "object" && v !== null)

// v = JSON.stringify(v);

// json.push((arr ? "" : '"' + n + '":') + String(v));

// }

// return (arr ? "[" : "{") + String(json) + (arr ? "]" : "}");

// }

// };

// // implement JSON.parse de-serialization

// JSON.parse = JSON.parse || function() {

// var r = "(?:-?\\b(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\\b)", k

// = '(?:[^\\0-\\x08\\x0a-\\x1f"\\\\]|\\\\(?:["/\\\\bfnrt]|u[0-9A-Fa-f]{4}))';

// k = '(?:"' + k + '*")';

// var s = new RegExp(

// "(?:false|true|null|[\\{\\}\\[\\]]|" + r + "|" + k + ")", "g"), t = new

// RegExp(

// "\\\\(?:([^u])|u(.{4}))", "g"), u = {

// '"' : '"',

// "/" : "/",

// "\\" : "\\",

// b : "\u0008",

// f : "\u000c",

// n : "\n",

// r : "\r",

// t : "\t"

// };

// function v(h, j, e) {

// return j ? u[j] : String.fromCharCode(parseInt(e, 16));

// }

// var w = new String(""), x = Object.hasOwnProperty;

// return function(h, j) {

// h = h.match(s);

// var e, c = h[0], l = false;

// if ("{" === c)

// e = {};

// else if ("[" === c)

// e = [];

// else {

// e = [];

// l = true;

// }

// for ( var b, d = [ e ], m = 1 - l, y = h.length; m = 0;)

// delete f[i[g]];

// }

// return j.call(n, o, f);

// };

// e = p({

// "" : e

// }, "");

// }

// return e;

// };

// }();

/*
 * An entity here is composed of multiple name-value pairs. Example entity:
 * {name: 'teddy', age: 33} @param {nlobjSubList} sublist. Not sure what the API
 * requires this @param {string} sublistId @param {string[]} columnIds An array
 * of column ids from the sublist @return {object[]} An array of entities
 */

function stickConvertSublistItemToEntity(sublistId, columnIds, lineNumber) {

    // stickWait();

    // var logger = new stickobjLogger('stickConvertSublistItemToEntity');

    var entity = {};

    for ( var j in columnIds) {

        var columnId = columnIds[j];

        // logger.log('columnId=' + columnId);

        entity[columnId] = nlapiGetLineItemValue(sublistId, columnId, lineNumber);

    }

    return entity;

}

/*
 * An entity here is composed of multiple name-value pairs. Example entity:
 * {name: 'teddy', age: 33} @param {nlobjSubList} sublist. Not sure what the API
 * requires this @param {string} sublistId @param {string[]} columnIds An array
 * of column ids from the sublist @return {object[]} An array of entities
 */

function stickConvertSublistItemsToEntities(sublistId, columnIds) {

    var logger = new stickobjLogger('stickConvertSublistItemsToEntities');

    logger.log('sublistId=' + sublistId + '; columnIds=' + columnIds);

    var lineCount = nlapiGetLineItemCount(sublistId);

    logger.log('sublistId=' + sublistId + '; lineCount=' + lineCount);

    var entities = [];

    for (var lineNumber = 1; lineNumber <= lineCount; lineNumber++) {

        var entity = {};

        entity = stickConvertSublistItemToEntity(sublistId, columnIds, lineNumber);

        entities.push(entity);

    }

    logger.log('entities.length=' + entities.length);

    return entities;

}

/*
 * An entity here is composed of multiple name-value pairs. Example entity:
 * {name: 'teddy', age: 33} @param {nlobjSubList} sublist. Not sure what the API
 * requires this @param {string} sublistId @param {string[]} columnIds An array
 * of column ids from the sublist @return {object[]} An array of entities
 */

function stickConvertSublistItemToEntityText(sublistId, columnIds, lineNumber) {

    var logger = new stickobjLogger('stickConvertSublistItemToEntity', true);

    var entity = {};

    for ( var j in columnIds) {

        var columnId = columnIds[j];

        logger.log('columnId=' + columnId);

        var fld = nlapiGetLineItemField(sublistId, columnId, lineNumber);

        if (fld.getType() == 'select') {

            entity[columnId] = nlapiGetLineItemText(sublistId, columnId, lineNumber);

        } else {

            entity[columnId] = nlapiGetLineItemValue(sublistId, columnId, lineNumber);

        }

    }

    return entity;

}

/*
 * This is the same as stickConvertSublistItemsToEntities except that for select
 * columns, the text is obtained instead of the value An entity here is composed
 * of multiple name-value pairs. Example entity: {name: 'teddy', age: 33} @param
 * {nlobjSubList} sublist. Not sure what the API requires this @param {string}
 * sublistId @param {string[]} columnIds An array of column ids from the sublist
 * @return {object[]} An array of entities
 */

function stickConvertSublistItemsToEntitiesText(sublistId, columnIds) {

    var logger = new stickobjLogger('stickConvertSublistItemsToEntities', true);

    logger.log('sublistId=' + sublistId + '; columnIds=' + columnIds);

    var lineCount = nlapiGetLineItemCount(sublistId);

    logger.log('sublistId=' + sublistId + '; lineCount=' + lineCount);

    var entities = [];

    for (var lineNumber = 1; lineNumber <= lineCount; lineNumber++) {

        var entity = {};

        entity = stickConvertSublistItemToEntityText(sublistId, columnIds, lineNumber);

        entities.push(entity);

    }

    logger.log('entities.length=' + entities.length);

    return entities;

}

function stickGetParameterByName(name) {

    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");

    var regexS = "[\\?&]" + name + "=([^&#]*)";

    var regex = new RegExp(regexS);

    var results = regex.exec(window.location.search);

    if (results === null) {

        return "";

    } else {

        return decodeURIComponent(results[1].replace(/\+/g, " "));

    }

}
