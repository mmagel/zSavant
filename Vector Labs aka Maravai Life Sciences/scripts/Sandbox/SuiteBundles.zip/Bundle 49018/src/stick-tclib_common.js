/**
 * � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
 */

/**
 * @fileOverview Common library used by client and server
 * @author tcaguioa
 */
// 
/**
 * @namespace Global object for storing global variables
 */
var stickGlobal = stickGlobal || {};
var labsGlobal = labsGlobal || {};

/**
 * For some reasons, the returned string from suitelets sometimes contains debug
 * information from core. This debugging information start with <!--. If this
 * string is found, process only the string before this or besticker yet mark
 * the end of the data with stickGlobal.END_OF_DATA_MARKER.
 */
stickGlobal.END_OF_DATA_MARKER = 'END_OF_DATA_MARKER';

stickGlobal.SUPPORTED_IMAGES = [ ".png", ".jpg", ".jpeg", ".PNG", ".JPG", ".JPEG" ];

/**
 * returns true if using the new ui
 * 
 * @returns {Boolean}
 */
function stickIsNewUI() {
    return true;
}

/**
 * Returns the "_oldui" suffix if old ui
 * 
 * @returns
 */
function stickAddSuffixIfOldUI() {
    return '';
}

/**
 * Creates a random unique number
 */
function stickRandom() {
    return (new Date()).getTime() + Math.floor((Math.random() * 1000) + 1);
}

/**
 * Creates a span markup given the text and color
 * 
 * @param {Object}
 *        str The text/innerHTML of the span
 * @param {Object}
 *        color the font color
 */
function stickColor(str, color) {
    return '<span style="color: ' + color + '">' + str + '</span>';
}

/**
 * Shortcut function for making a html markup bold
 * 
 * @param {Object}
 *        markup The markup that will be surrounded with bold tags
 * @return {string} Markup surrounded with bold tags
 */
function stickBold(markup, color) {
    return '<b>' + markup + '</b>';
}

/**
 * Creates a span with green font
 * 
 * @param {Object}
 *        str
 */
function stickGreen(str) {
    return stickColor(str, 'green');
}

/**
 * Returns a string representation of an object. This is used in debugging.
 * 
 * @param {Object}
 *        obj
 */
function stickGetObjectDetailViaJSON(obj) {
    // Calling JSON.stringify on some nl objects like nlobjAssistant,
    // nlobjResponse,nlobjRequest and nlobjSelectOptions throws an error even
    // when inside a try catch statement
    var objS = obj.toString();
    if ([ 'nlobjAssistant' ].indexOf(objS) > -1) {
        return objS;
    }

    if (objS.indexOf('nlobjResponse') > -1) {
        return objS;
    }
    if (objS.indexOf('nlobjRequest') > -1) {
        return objS;
    }
    if (objS.indexOf('nlobjForm') > -1) {
        return objS;
    }

    if (obj instanceof Array) {
        if (obj[0] && obj[0].getId && obj[0].getText) {
            var detail = 'nlobjSelectOptions[' + obj.length + ']';
            if (obj.length <= 10) {
                // show items if they are not more than 10
                detail += '[';
                var count = obj.length;
                for (var i = 0; i < count; i++) {
                    var option = obj[0];
                    detail += '{id: ' + option.getId() + ', text:' + option.getText() + '}';
                }
                detail += ']';
            }
            return detail;
        }
    }

    // Calling JSON.stringify on nlobjSelectOption throws an error
    if (obj && obj.getId && obj.getText) {
        var detail = 'nlobjSelectOption';
        detail += '{id: ' + obj.getId() + ', text:' + obj.getText() + '}';
        return detail;
    }

    // for other objects
    try {
        detail = JSON.stringify(obj);
    } catch (e) {
        return null;
    }
    return detail;
}

/**
 * Returns information about the object.
 * 
 * @param {Object}
 *        obj
 */
function stickGetObjectDetail(obj) {
    return stickGetObjectDetailViaJSON(obj);
}

/**
 * Obtains debugging information from the built in object arguments
 * 
 * @param {object}
 *        args Built-in arguments object from a function
 * @return {string} The details of a function's arguments
 */
function stickGetArgumentDetails(args) {
    var details = '';
    try {
        // get the function name and parameters
        var fullFunc = args.callee.toString();
        var funcAndArgs = fullFunc.substr(0, fullFunc.indexOf('{')).replace('function ', '');
        // get array of argument name
        var paramsStr = funcAndArgs.replace(args.callee.name, '').replace(')', '').replace('(', '');
        var params = paramsStr.split(',');
        details = stickGetNewLine(1) + 'Function=' + funcAndArgs.replace('\n', ' ');
        if (args.length > 0) {
            details += stickGetNewLine() + 'ARGUMENTS:' + stickGetNewLine(1);
            for (var i = 0; i < args.length; i++) {
                var paramName = 'arg' + i;
                if (stickHasValue(params[i])) {
                    paramName = params[i].trim();
                }
                var arg = '';
                if (typeof args[i] == 'object') {
                    // is it an array
                    if (args[i] instanceof Array) {
                        for (var x = 0; x < args[i].length; x++) {
                            arg += stickGetObjectDetail(args[i]);
                        }
                    }

                    else {
                        arg += stickGetObjectDetail(args[i]);
                        // try {
                        // arg += args[i];
                        // } catch (e) {
                        // arg += args[i];
                        // }
                    }
                } else {
                    arg = args[i];
                }
                details += paramName + '=' + arg + '<br />';
            }
        }
    } catch (e) {
        nlapiLogExecution('debug', 'stickGetArgumentDetails', 'error in stickGetArgumentDetails e=' + e);
    }
    return details;
}

/**
 * Error handling routine
 * 
 * @param {Object}
 *        e Exception
 * @param {Object}
 *        customMessage Any message you want included
 */
function stickHandleError(e, customMessage) {
    try {
        var fullMessage = 'EXECUTION CONTEXT' + stickGetNewLine() + stickGetContextDetails() + stickGetNewLine(1) + 'customMessage=' + customMessage + stickGetNewLine(2);
        var isInBrowser = (typeof document != 'undefined');
        if (stickHasNoValue(customMessage)) {
            customMessage = '';
        }

        fullMessage += stickGetErrorDetails(e);
        // =====================================================================================================
        // client-side stack trace
        // =====================================================================================================

        if (isInBrowser) {
            var clientStackTrace = '';
            if (stickHasValue(Error)) {
                var err = new Error();
                clientStackTrace = err.stack;
                fullMessage += 'CLIENT STACK TRACE=' + clientStackTrace + stickGetNewLine(2);
            }
            if (typeof console != 'undefined') {
                if (typeof console.error != 'undefined') {
                    console.error(stickGlobal.TITLE + ' Error: ' + fullMessage);
                    return fullMessage;
                }

                if (typeof console.log != 'undefined') {
                    console.log(stickGlobal.TITLE + ' Error: ' + fullMessage);
                    return fullMessage;
                }
            }
            nlapiLogExecution('error', stickGlobal.TITLE, 'Error in stickHandleError(); fullMessage=' + fullMessage);
            return fullMessage;

        } else {
            // =====================================================================================================
            // server-side stack trace
            // =====================================================================================================
            var html = fullMessage.replace(new RegExp('\n', 'gi'), '<br />');
            nlapiLogExecution('error', stickGlobal.TITLE + ' Error', html);
        }
        return fullMessage;
    } catch (e) {
        nlapiLogExecution('error', 'StickyNotes Runtime error', 'Error in stickHandleError(); e=' + e);
        // comment line below when released
        // throw e;

    }

}

/**
 * @class This is used in measuring execution time in milli-seconds
 */
function stickobjStopWatch() {

    stickGlobal = stickGlobal || {};
    if (stickHasNoValue(stickGlobal.startOfScriptMilliseconds)) {
        stickGlobal.startOfScriptMilliseconds = (new Date()).getTime();
    }

    var startMilliSeconds = (new Date()).getTime();
    var lastCallToMeasure = (new Date()).getTime();

    /**
     * @public
     * @description Starts the timer
     */
    this.start = function() {
        startMilliSeconds = (new Date()).getTime();
    };

    /**
     * @public
     * @description Returns the current elapsed time (in ms) and resets the
     *              start time
     */
    this.stop = function() {
        var currentMilliSeconds = (new Date()).getTime();
        var ms = currentMilliSeconds - startMilliSeconds;
        startMilliSeconds = currentMilliSeconds;
        return ms;
    };

    /**
     * @public
     * @description Returns the current elapsed time (in ms) WITHOUT
     *              resesticking the start time (from the last call to start or
     *              stop)
     */
    this.measure = function() {
        var currentMilliSeconds = (new Date()).getTime();
        var ms = currentMilliSeconds - startMilliSeconds;
        return ms;
    };

    /**
     * Returns the current elapsed time (in ms) from start of the script call
     */
    this.measureFromScript = function() {
        var currentMilliSeconds = (new Date()).getTime();
        var ms = currentMilliSeconds - stickGlobal.startOfScriptMilliseconds;
        return ms;
    };

    /**
     * Returns the current elapsed time (in ms) from start of the function call
     */
    this.measureFromFunction = function() {
        var currentMilliSeconds = (new Date()).getTime();
        var ms = currentMilliSeconds - startMilliSeconds;
        return ms;
    };

    /**
     * Returns the current elapsed time (in ms) starting from the last call to
     * measureSegment but WITHOUT resesticking the start time (from the last
     * call to start or stop)
     */
    this.measureSegment = function() {
        var currentMilliSeconds = (new Date()).getTime();
        var ms = currentMilliSeconds - lastCallToMeasure;
        lastCallToMeasure = currentMilliSeconds;
        return ms;
    };
}

function stickGetErrorDetails(ex) {
    var errorDetails = '';
    try {
        errorDetails = 'ERROR DETAILS' + stickGetNewLine();
        errorDetails += 'ex=' + ex.toString() + stickGetNewLine();

        if (ex.getDetails) {
            errorDetails += 'Details: ' + ex.getDetails() + stickGetNewLine();
        }
        if (ex.getCode) {
            errorDetails += 'Code: ' + ex.getCode() + stickGetNewLine();
        }
        if (ex.getId) {
            errorDetails += 'Id: ' + ex.getId() + stickGetNewLine();
        }
        if (ex.getStackTrace) {
            errorDetails += 'StackTrace: ' + ex.getStackTrace() + stickGetNewLine();
        }
        if (ex.getUserEvent) {
            errorDetails += 'User event: ' + ex.getUserEvent() + stickGetNewLine();
        }
        if (ex.getInternalId) {
            errorDetails += 'Internal Id: ' + ex.getInternalId() + stickGetNewLine();
        }
        if (ex.rhinoException) {
            errorDetails += 'RhinoException: ' + ex.rhinoException.toString() + stickGetNewLine();
        }
        if (ex.stack) {
            errorDetails += 'Stack=' + ex.stack;
        }

        if (ex instanceof nlobjError) {
            errorDetails += 'Type: nlobjError' + stickGetNewLine();
        } else if (stickHasValue(ex.rhinoException)) {
            errorDetails += 'Type: rhinoException' + stickGetNewLine();
        } else {
            errorDetails += 'Type: Generic Error' + stickGetNewLine();
        }

    } catch (e) {
        errorDetails += ' Error in stickGetErrorDetails=' + e;
    }
    return errorDetails;
}

/**
 * Returns details about the execution context
 * 
 * @return {string}
 */
function stickGetContextDetails() {
    var detail = '';
    try {
        var userId = nlapiGetUser();
        var context = nlapiGetContext();
        detail += 'Company: ' + context.getCompany() + stickGetNewLine();
        try {
            if (context.getFeature('departments')) {
                detail += 'Department: ' + nlapiGetDepartment() + stickGetNewLine();
            }
        } catch (e) {
            detail += 'Department: error ' + e + stickGetNewLine();
        }

        try {
            if (context.getFeature('locations')) {
                detail += 'Location: ' + nlapiGetLocation() + stickGetNewLine();
            }
        } catch (e) {
            detail += 'Location: error ' + e + stickGetNewLine();
        }

        try {
            if (context.getFeature('subsidiaries')) {
                detail += 'Subsidiary: ' + nlapiGetSubsidiary() + stickGetNewLine();
            }
        } catch (e) {
            detail += 'Subsidiary: error ' + e + stickGetNewLine();
        }

        detail += 'User Id: ' + userId + stickGetNewLine();
        detail += 'User Name: ' + context.getName() + stickGetNewLine();
        detail += 'Role: ' + nlapiGetRole() + stickGetNewLine();
        detail += 'Role Center: ' + context.getRoleCenter() + stickGetNewLine();
        try {
            detail += 'DeploymentId: ' + context.getDeploymentId() + stickGetNewLine();
        } catch (e) {
            detail += 'DeploymentId: error ' + e + stickGetNewLine();
        }

        detail += 'User Email: ' + context.getEmail() + stickGetNewLine();
        detail += 'Environment: ' + context.getEnvironment() + stickGetNewLine();
        detail += 'ExecutionContext: ' + context.getExecutionContext() + stickGetNewLine();
        detail += 'Name: ' + context.getName() + stickGetNewLine();
        detail += 'ScriptId: ' + context.getScriptId() + stickGetNewLine();
        detail += 'Version: ' + context.getVersion() + stickGetNewLine();

    } catch (e) {
        detail = 'Error in stickGetContextDetails(); ' + e;
    }
    return detail;
}

/**
 * Returns newlines depending on the execution context
 * 
 * @param {integer}
 *        repeat Number of newlines to return
 */
function stickGetNewLine(repeat) {
    if (typeof repeat == 'undefined') {
        repeat = 1;
    }
    var newline = '';
    for (var i = 1; i <= repeat; i++) {
        // if (stickHasValue(console)) {
        if (typeof console !== 'undefined') {
            newline += '\n';
        } else {
            newline += '\n';
        }
    }
    return newline;
}

/**
 * Browser and server independent implementation of indexOf since IE does not
 * support it
 * 
 * @param {object[]}
 *        arr
 * @param {object}
 *        obj
 */
function stickArrayIndexOf(arr, obj) {
    if (arr.indexOf) {
        return arr.indexOf(obj);
    }
    // no support
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == obj) {
            return i;
        }
    }
    return -1;
}

/**
 * Prepend non breaking space on the string if the string length is less than
 * the desired length
 * 
 * @param {string}
 *        s
 * @param {integer}
 *        length - the desired length of the string
 * @returns {String}
 */
function stickPad(s, length) {
    var diff = length - s.length;
    if (diff > 0) {
        for (var i = 1; i <= diff; i++) {
            s = '&nbsp;' + s;
        }
    } else {
        s = s.substr(0, length);
    }
    return s;
}

/**
 * Append non breaking space on the string if the string length is less than the
 * desired length
 * 
 * @param {string}
 *        s
 * @param {integer}
 *        length - the desired length of the string
 * @returns {String}
 */
function stickPadRight(s, length) {
    var diff = length - s.length;
    if (diff > 0) {
        for (var i = 1; i <= diff; i++) {
            s = s + '&nbsp;';
        }
    } else {
        s = s.substr(0, length);
    }
    return s;
}

/**
 * Adds commas to a number
 * 
 * @param {string}
 *        nStr
 * @returns {string}
 */
function stickAddCommas(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

/**
 * Used in logging
 * 
 * @param {string}
 *        msg
 * @param {string}
 *        otherDetails Not being used?
 * @param {string}
 *        source Not being used?
 */
function stickLog(msg, otherDetails, source, type) {
    var completeMsg = msg;// + ': ' + eval(msg);
    if (stickHasNoValue(type)) {
        type = 'debug';
    }

    if (!stickHasNoValue(otherDetails)) {
        completeMsg = completeMsg + ' otherDetails=' + otherDetails + '; ';
    }
    if (!stickHasNoValue(source)) {
        completeMsg = source + '() ' + completeMsg + '; ';
    }
    if (typeof document !== 'undefined') {
        if (typeof console !== 'undefined') {
            console.log(completeMsg);
        }
        // nlapiLogExecution('debug', completeMsg, '');
    } else {
        completeMsg = '(' + nlapiGetContext().getRemainingUsage() + ') ' + completeMsg;
        nlapiLogExecution(type, 'stickobjLogger', completeMsg);
    }
    return completeMsg;
}

/**
 * Logs an error
 * 
 * @param {Object}
 *        msg
 * @param {Object}
 *        otherDetails
 * @param {Object}
 *        source
 */
function stickLogError(msg, otherDetails, source) {
    if (typeof document !== 'undefined' && typeof console !== 'undefined') {
        msg = 'ERROR: ' + msg;
        stickLog();
    } else {
        msg = '<span style="background-color: pink">' + msg + '</span>';
        stickLog(msg, otherDetails, source, 'error');
    }
    return msg;

}

/**
 * Logs a successful activity
 * 
 * @param {Object}
 *        msg
 * @param {Object}
 *        otherDetails
 * @param {Object}
 *        source
 */
function stickLogOk(msg, otherDetails, source) {
    if (typeof document !== 'undefined' && typeof console !== 'undefined') {
        msg = 'SUCCESS: ' + msg;
        stickLog(msg);
    } else {
        msg = '<span style="background-color: lightgreen">' + msg + '</span>';
        stickLog(msg, otherDetails, source, 'debug');
    }
    return msg;
}

/**
 * Logs a warning
 * 
 * @param {Object}
 *        msg
 * @param {Object}
 *        otherDetails
 * @param {Object}
 *        source
 */
function stickLogWarn(msg, otherDetails, source) {
    if (typeof document !== 'undefined' && typeof console !== 'undefined') {
        msg = 'WARNING: ' + msg;
        stickLog(msg);
    } else {
        msg = '<span style="background-color: yellow">' + msg + '</span>';
        stickLog(msg, otherDetails, source, 'debug');
    }
    return msg;
}

/**
 * @class Object used in logging. Used in both client and server
 * @example // sample 1 var logger = new stickobjlogger(arguments); // sample 2
 *          var logger = new stickobjlogger(arguments, false, 'getData()');
 * @param {Object}
 *        args 'arguments' is a built-in object in functions. Pass 'arguments'
 *        always.
 * @param {Boolean}
 *        (optional) isDisabled Set to true to temporarily disable logging.
 *        Default to false.
 * @param {String}
 *        commonLog (optional) All succeeding calls to log will prepend the
 *        commonLog .
 * @return {void}
 */
function stickobjLogger(args, isDisabled, commonLog) {

    commonLog = commonLog || '';
    var sw = new stickobjStopWatch();
    var _disabled = false;

    if (stickHasValue(isDisabled)) {
        _disabled = isDisabled;
    }

    var _commonLog;
    var _argumentsDetails = '';
    if (typeof args == 'object') {
        _commonLog = (args.callee.name || commonLog) + '()';
        _argumentsDetails = stickGetArgumentDetails(args);
    } else {
        _commonLog = commonLog + ' ' + args + '()';
    }

    this.auditReset = function(msg) {
        return sw.measureSegment();
    };

    this.audit = function(msg) {
        if (_disabled === false) {
            var MAX_ARG_LENGTH = 100;
            if (stickHasValue(msg)) {
                msg = msg + '; ' + _argumentsDetails;
            } else {
                msg = _argumentsDetails;
            }

            if (msg.length > MAX_ARG_LENGTH) {
                msg = msg.substr(0, MAX_ARG_LENGTH);
            }

            var finalMsg = _commonLog + ' ';
            finalMsg += stickPad(stickAddCommas(sw.measureFromScript()), 6) + ' ms; &nbsp;&nbsp;';
            finalMsg += stickPad(stickAddCommas(sw.measureFromFunction()), 6) + ' ms; &nbsp;&nbsp;';
            finalMsg += stickPad(stickAddCommas(sw.measureSegment()), 6) + ' ms; &nbsp;&nbsp;';
            finalMsg += msg;

            finalMsg = '<span style="font-family: courier new">' + finalMsg + '</span>';
            stickLog(finalMsg, null, null, 'audit');
        }
    };

    this.auditToConsole = function(msg) {
        if (_disabled === false) {
            var MAX_ARG_LENGTH = 100;
            if (stickHasValue(msg)) {
                msg = msg + '; ' + _argumentsDetails;
            } else {
                msg = _argumentsDetails;
            }

            if (msg.length > MAX_ARG_LENGTH) {
                msg = msg.substr(0, MAX_ARG_LENGTH);
            }

            var finalMsg = _commonLog + ' ';
            finalMsg += sw.measureFromScript() + ' ms; ';
            finalMsg += sw.measureFromFunction() + ' ms;';
            finalMsg += sw.measureSegment() + ' ms;';
            finalMsg += msg;

            stickLog(finalMsg, null, null, 'audit');
        }
    };

    this.log = function(msg) {
        if (_disabled === false) {
            stickLog(_commonLog + ' ' + sw.measure() + 'ms; ' + msg);
        }
    };
    /**
     * @public
     * @description Logs everytime even if _disabled is true
     * @param {Object}
     *        msg
     */
    this.logAlways = function(msg) {
        stickLog(_commonLog + ' ' + sw.measure() + 'ms; ' + msg);
    };

    /**
     * @public
     * @description Logs an error. In NetSuite, error log entries have red
     *              background.
     * @param {Object}
     *        msg
     */
    this.error = function(msg) {
        if (_disabled === false) {
            stickLogError(_commonLog + ' ' + sw.measure() + 'ms; ' + msg);
        }
    };
    /**
     * @public
     * @description Logs a warning. In NetSuite, warning log entries have yellow
     *              background.
     * @param {Object}
     *        msg
     */
    this.warn = function(msg) {
        if (_disabled === false) {
            stickLogWarn(_commonLog + ' ' + sw.measure() + 'ms; ' + msg);
        }
    };
    /**
     * @public
     * @description Logs a successful activity. In NetSuite, 'successful' log
     *              entries have green background.
     * @param {Object}
     *        msg
     */
    this.ok = function(msg) {
        if (_disabled === false) {
            stickLogOk(_commonLog + ' ' + sw.measure() + 'ms; ' + msg);
        }
    };

    this.end = function(msg) {
        // var MAX_ARG_LENGTH =70;
        // var shortArgumentsDetails = _argumentsDetails;
        // if(shortArgumentsDetails.length > MAX_ARG_LENGTH){
        // shortArgumentsDetails = shortArgumentsDetails.substr(0,
        // MAX_ARG_LENGTH);
        // }
        var shortArgumentsDetails = '';
        if (stickHasValue(msg)) {
            msg = 'END ' + shortArgumentsDetails + '; ' + msg;
        } else {
            msg = 'END ' + shortArgumentsDetails;
        }

        if (_disabled === false) {
            // if (stickArrayIndexOf(disabledCommonLogs, _commonLog) > -1) {
            // return;
            // }
            this.log(msg);
        }
    };

    /**
     * @public
     * @description Enable or disables logging
     * @param {Boolean}
     *        isDisabled
     */
    this.setDisabled = function(isDisabled) {
        _disabled = isDisabled;
    };

    this.log(_argumentsDetails);

}



/**
 * Returns true is the param is undefined or null or empty
 * 
 * @param {any}
 *        param
 * @return {boolean}
 */
function stickHasNoValue(param)
{
    return (typeof param == 'undefined') || param === null || param === '';
}



/**
 * Returns true is the param is undefined or null or empty
 * 
 * @param {any}
 *        param
 * @return {boolean}
 */
function stickHasValue(param) {
    return !stickHasNoValue(param);
}



/**
 * This handles unexpected errors and sends it to the user specified in script
 * parameter.
 * 
 * @param ex
 *        Exception to be handled.
 */
function stickHandleUnexpectedError(ex, customMsg)
{
    var errorMsg = "";
    
    try
    {
        errorMsg = 'stickHandleUnexpectedError(). Unexpected error: ' + stickGetErrorDetails(ex) + '; customMsg=' + customMsg;
        nlapiLogExecution('error', 'Transaction Timeline', errorMsg);

        var empId = nlapiGetContext().getPreference('custscript_stick_error_message_recipient');
        if (stickHasValue(empId))
        {
            nlapiSendEmail(empId, empId, 'Transaction Timeline Error', 'Unexpected error: ' + stickGetErrorDetails(ex));
        }
    }
    catch (e)
    {
        errorMsg = 'stickHandleUnexpectedError(). Unexpected error: ' + stickGetErrorDetails(e);
        nlapiLogExecution('error', 'Transaction Timeline: stickHandleUnexpectedError()', errorMsg);
    }

    return errorMsg;
}



/**
 * An entity here is composed of multiple name-value pairs. Example entity:
 * {name: 'teddy', age: 33}
 * 
 * @param {nlobjSearchResult[]}
 *        results
 * @return {object[]} An array of entities
 */
function stickConvertResultsToEntities(results) {
    var logger = new stickobjLogger('stickConvertResultsToEntities', true);

    if (results === null) {
        logger.log('results === null');
        return null;
    }
    var searchColumns = results[0].getAllColumns();
    logger.error('searchColumns=' + searchColumns);
    var columnIds = [];
    for (var m = 0; m < searchColumns.length; m++) {
        // logger.error('searchColumns[m].getName()=' +
        // searchColumns[m].getName());
        columnIds.push(searchColumns[m].getName());
    }
    var entities = [];
    for (var i = 0; i < results.length; i++) {
        var result = results[i];
        var entity = {};
        for (var j = 0; j < columnIds.length; j++) {
            var columnId = columnIds[j];
            entity[columnId] = result.getValue(columnId);
            var text = result.getText(columnId);
            if (stickHasValue(text)) {
                entity[columnId + 'Text'] = text;
            }

        }
        entities.push(entity);
    }
    logger.log('entities.length=' + entities.length);
    return entities;
}

/**
 * Returns all nlobjSearchResult of a record search even if they are more than
 * 1000; this one is using the filter expression syntax
 * 
 * @param {Object}
 *        type
 * @param {Object}
 *        id
 * @param {Object}
 *        filters
 * @param {Object}
 *        columns
 * @return {Any[]} Array of nlobjSearchResult
 */
function stickSearchAllRecords2(type, id, filters, columns) {
    var allResults = [];
    // set to lowest employee id value
    var lowerId = -100;
    // // add support for 'select all columns' if no columns is supplied
    // if (stickHasNoValue(columns) || typeof columns == 'string') {
    // // get all columns
    // var allColumns = nlapiCreateRecord(type).getAllFields();
    // // include only custom fields
    // columns = [];
    // for (var i = 0; i < allColumns.length; i++) {
    // var columnId = allColumns[i];
    // // exclude fields whose stored in value is F
    // // TODO: check by code this condition
    // var excludeNotStoredColumns = ['custrecord_timeline_autosub_type_ft',
    // 'custrecord_timeline_autopost_fld_ft'];
    // if (excludeNotStoredColumns.indexOf(columnId) > -1) {
    // continue;
    // }
    // if (columnId.substr(0, 10) == 'custrecord' || columnId == 'name' ||
    // columnId == FLD_INTERNAL_ID) {
    // columns.push(new nlobjSearchColumn(columnId));
    // }
    // }
    // }
    if (stickHasNoValue(columns)) {
        columns = [];
    }

    columns.push(new nlobjSearchColumn('internalid'));
    columns[columns.length - 1].setSort(); // sort ascending
    // add filter used in paging
    if (filters === null) {
        filters = [];
    }
    if (filters.length > 0) {
        filters.push('and');
    }
    filters.push([ 'internalidnumber', 'greaterthan', lowerId ]);

    var results = nlapiSearchRecord(type, id, filters, columns);
    while (results !== null) {
        for (var i = 0; i < results.length; i++) {
            allResults.push(results[i]);
        }
        lowerId = results[results.length - 1].getValue('internalid');
        filters[filters.length - 1] = [ 'internalidnumber', 'greaterthan', lowerId ];
        results = nlapiSearchRecord(type, id, filters, columns);
    }
    if (allResults.length === 0) {
        // consistent with nlapiSearchRecord() where it returns null if no rows
        // passed
        return null;
    }
    return allResults;
}

/**
 * Gets the array of columns for Note record.
 * @returns {Array}
 */
function stickGetNoteColumns() {
    var columns = [];
    columns.push(new nlobjSearchColumn('internalid'));
    columns[0].setSort(true);
    columns.push(new nlobjSearchColumn('custrecord_sn_message'));
    columns.push(new nlobjSearchColumn('custrecord_sn_status'));
    columns.push(new nlobjSearchColumn('custrecord_sn_percent_top'));
    columns.push(new nlobjSearchColumn('custrecord_sn_percent_left'));
    columns.push(new nlobjSearchColumn('custrecord_sn_allowed_entities'));
    columns.push(new nlobjSearchColumn('owner'));
    columns.push(new nlobjSearchColumn('created'));
    columns.push(new nlobjSearchColumn('custrecord_sn_record_name'));
    columns.push(new nlobjSearchColumn('custrecord_sn_record_type_script_id'));
    columns.push(new nlobjSearchColumn('custrecord_sn_record_id'));
    columns.push(new nlobjSearchColumn('custrecord_sn_is_public'));
    columns.push(new nlobjSearchColumn('custrecord_sn_z_index'));
    columns.push(new nlobjSearchColumn('custrecord_sn_note_category'));
    columns.push(new nlobjSearchColumn('custrecord_sn_field_script_id'));
    columns.push(new nlobjSearchColumn('custrecord_sn_scripted_record_type'));
    columns.push(new nlobjSearchColumn('custrecord_sn_file'));

    columns.push(new nlobjSearchColumn('custrecord_snc_priority', 'custrecord_sn_note_category'));

    return columns;
}

/**
 * Gets the data center URL (e.g. https://system.netsuite.com).
 * 
 * @returns {String}
 */
function stickGetDataCenterURL() {
    // check if already has value in global
    if (stickHasValue(stickGlobal.dataCenterUrl)) {
        return stickGlobal.dataCenterUrl;
    }

    // get the external url of a suitelet included in the bundle
    var url = nlapiResolveURL("SUITELET", "customscript_stick_board_frontend_sl", "customdeploy_stick_board_frontend_sl", true);

    // get http or https
    var index = url.indexOf("://");
    var http = url.substr(0, index) + "://";

    // index of domain's first character
    var indexStart = index + 3;

    // get data center
    var indexDot = url.indexOf(".", indexStart);
    var indexEnd = url.indexOf("/", indexStart);
    var dataCenter = url.substring(indexDot, indexEnd);
    var dataCenterUrl = http + "system" + dataCenter;
    // save to global
    stickGlobal.dataCenterUrl = dataCenterUrl;
    return dataCenterUrl;
}

function stickGetRandomNumber(userId) {
    // generate random number using datetime, math functions, and user id
    var random = stickRandom();
    return random.toString() + (userId || nlapiGetUser()).toString();
}

/**
 * Checks if the file is supported for image preview.
 * 
 * @param {String}
 *        extName Extension name of the file
 * @returns {Boolean} Returns true if supported image, otherwise, false
 */
function stickIsSupportedImage(extName) {
    return (stickGlobal.SUPPORTED_IMAGES.indexOf(extName) > -1);
}

/**
 * Gets the url of the image given the filename and folder path.
 * 
 * @param {String}
 *        imageFileName File name only
 * @param {String}
 *        folderPath Folder path where the file resides.  Root is bundle folder.
 * @param {Boolean}
 *        bIsClient Set to true if on client side, otherwise false
 * @returns {String} Returns the url
 */
function stickGetImageUrl(imageFileName, folderPath, bIsClient) {
    if (bIsClient) {
        return stickGlobal.imageUrls[imageFileName];
    } else {
        stickGlobal.imageUrls = stickGlobal.imageUrls || {};
        if (stickHasNoValue(stickGlobal.imageUrls[imageFileName])) {
            var fullPath = stickGetSuiteBundlesFolder() + '/Bundle ' + nlapiGetContext().getBundleId() + folderPath + imageFileName;
            stickGlobal.imageUrls[imageFileName] = stickGetFileUrl(fullPath);
        }
        return stickGlobal.imageUrls[imageFileName];
    }
}

/**
 * Gets the url of the sprite image of file type icons.
 * 
 * @param {Boolean}
 *        bIsClient Set to true if on client side, otherwise false
 * @returns {String} Returns the url
 */
function stickGetSpriteImageUrl(bIsClient) {
    return stickGetImageUrl('file-type-sprite.png', '/lib/suidgets/build/img/', bIsClient);
}

/**
 * Gets the url of the transparent image that is used with sprite images.
 * 
 * @param {Boolean}
 *        bIsClient Set to true if on client side, otherwise false
 * @returns {String} Returns the url
 */
function stickGetTransparentImageUrl(bIsClient) {
    return stickGetImageUrl('img_trans.gif', '/lib/suidgets/build/img/', bIsClient);
}

/**
 * Gets the url of the sprite image with the specified position that identifies
 * the file type icon to display.
 * 
 * @param {String}
 *        extName Extension name of the file
 * @param {Boolean}
 *        bIsClient Set to true if on client side, otherwise false
 * @returns {String} Returns the url
 */
function stickGetFileTypeIcon(extName, bIsClient) {
    extName = extName.toLowerCase();
    var bgUrl = "url(" + stickGetSpriteImageUrl(bIsClient) + ") ";

    if (extName == ".htm" || extName == ".html")
        return bgUrl + " -2px -4px";
    else if (extName == ".xml")
        return bgUrl + " -2px -32px";
    else if (extName == ".pdf")
        return bgUrl + " -2px -59px";
    else if (extName == ".zip" || extName == ".rar")
        return bgUrl + " -2px -86px";
    else if (extName == ".xls" || extName == ".xlsx")
        return bgUrl + " -2px -114px";
    else if (extName == ".doc" || extName == ".docx")
        return bgUrl + " -2px -141px";
    else if (extName == ".ppt" || extName == ".pptx")
        return bgUrl + " -2px -169px";
    else if (extName == ".txt")
        return bgUrl + " -2px -224px";
    else if (extName == ".jpg" || extName == ".jpeg" || extName == ".png" || extName == ".bmp")
        return bgUrl + " -2px -251px";
    else
        return bgUrl + " -2px -197px"; // generic
}

/**
 * Checks if image preview is enabled.
 * 
 * @param {Boolean} isBoard Set to true if on StickyNotes Board; Set to false if on record page.
 * @returns {Boolean}
 */
function stickIsEnabledImagePreview(isBoard) {
    // check for isBoard if no value; then default to false (record page)
    if (stickHasNoValue(isBoard)) {
        isBoard = false;
    }
    
    // get company and user preference ids whether on board or on record page
    var companyPrefId = isBoard ? 'custscript_stick_prevw_img_board_users' : 'custscript_stick_prevw_img_record_users';
    var userPrefId = isBoard ? 'custscript_stick_prevw_img_board' : 'custscript_stick_prevw_img_record';
    
    // check if enabled
    return (nlapiGetContext().getPreference(companyPrefId) == 'T' && nlapiGetContext().getPreference(userPrefId) == 'T');
}

/**
 * Gets the account's SuiteBundles folder name.
 * @returns {String}
 */
function stickGetSuiteBundlesFolder() {
    if (stickHasValue(stickGlobal.sbFolderName)) {
        return stickGlobal.sbFolderName;
    }
    
    var sbFolderName = 'SuiteBundles';
    var results = nlapiSearchRecord('file', null, [ 'name', 'is', '329f45cd-129f-40d0-b5da-ef9ad97ed512' ], [ new nlobjSearchColumn('folder')]);
    if (stickHasValue(results)) {
        var folderId = results[0].getValue('folder');
        var sbResults = nlapiSearchRecord('folder', null, [ 'internalid', 'is', folderId ], [ new nlobjSearchColumn('parent')]);
        var parentFolder = sbResults[0].getText('parent');
        if (stickHasValue(parentFolder)) {
            sbFolderName = parentFolder;
        }
    }
    stickGlobal.sbFolderName = sbFolderName;
    return sbFolderName;
}
