/**
 * � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
 */

/**
 * © 2015 NetSuite Inc. User may not copy, modify, distribute, or re-bundle or
 * otherwise make available this code.
 */

// global variable across many scripts
var stickGlobal = stickGlobal || {};
stickGlobal.FILE_DRAG_AND_DROP_FOLDER_NAME = 'StickyNotesFiles-1830A98B-E45A-4672-8191-6E59658B2C55';

// global variable only in this script
var stickobjGlobal = stickobjGlobal || {};

/**
 * get css, html and js
 */
function stickGetRecordPageCodeHtml() {
    var logger = new stickobjLogger(arguments);
    logger.audit('start of file loading');
    var context = nlapiGetContext();
    var bundleId = context.getBundleId();
    logger.log('bundleId=' + bundleId);
    
    var sbFolderName = stickGetSuiteBundlesFolder();

    var path = sbFolderName + '/Bundle ' + bundleId + '/lib/';

    // jquery scripts
    var jqueryscript = '';
    var jsFiles = [ 'stick-jquery-1.10.2.min.js', 'stick-jquery-ui-1.10.1.custom.min.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        jqueryscript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    // css
    path = sbFolderName + '/Bundle ' + bundleId + '/src/';
    var css = stickGetFileHtmlCode(path + 'stick-common-style' + stickAddSuffixIfOldUI() + '.css');
    css = css + stickGetFileHtmlCode(path + 'stick-record-page-markup' + stickAddSuffixIfOldUI() + '.css');
    css = css + stickGetFileHtmlCode(path + 'stick-animation-style.css');
    if (stickIsNewUI()) {
        css = css + stickGetFileHtmlCode(path + 'stick-xtheme-reskin-ext4.css');
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/';
    css = css + stickGetFileHtmlCode(path + 'stick-jquery-ui.css');
    css = css + stickGetFileHtmlCode(path + 'Ext-4.2.1.883-ext-theme-classic-sandbox-all.css');

    // html
    path = sbFolderName + '/Bundle ' + bundleId + '/src/';
    var html = stickGetFileHtmlCode(path + 'stick-record-page-markup' + stickAddSuffixIfOldUI() + '.html');
    html += stickGetFileHtmlCode(path + 'stick-common-markup' + stickAddSuffixIfOldUI() + '.html');
    html += stickGetFileHtmlCode(path + 'stick-color-picker-markup.html');
    html += stickGetFileHtmlCode(path + 'stick-rating-widget.html');

    // js
    var javascript = '';

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/';
    var jsFiles = [ 'Ext-4.2.1.883-ext-all-sandbox.js', 'Ext-4.2.1.883-Spotlight.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        javascript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/src/';
    var jsFiles = [ 'stick-tclib_common.js', 'stick-tclib_client.js', 'stick-common-client' + stickAddSuffixIfOldUI() + '.js', 'stick-record-page-client.js', 'stick-color-picker-client.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        javascript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/suidgets/build/js/';
    var jsFiles = [ 'suidgets-ui.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        javascript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/suidgets/build/js/widgets/';
    var jsFiles = [ 'filedragndrop.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        javascript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/suidgets/build/js/utilities/';
    var jsFiles = [ 'fileupload.js' ];
    for (var i = 0; i < jsFiles.length; i++) {
        javascript += stickGetFileHtmlCode(path + jsFiles[i]);
    }

    path = sbFolderName + '/Bundle ' + bundleId + '/lib/suidgets/build/img/';
    var jsFiles = [ 'img_trans.gif', 'file-type-sprite.png', 'cancel-sml.png' ];
    var imageUrls = {};
    for (var i = 0; i < jsFiles.length; i++) {
        imageUrls[jsFiles[i]] = stickGetFileUrl(path + jsFiles[i]);
    }
    javascript += '<div id="stickImageUrls" style="display: none;">' + JSON.stringify(imageUrls) + '</div>';

    if (context.getPreference('custscript_stick_is_automation') === 'T') {
        // add other files if automation account
        path = sbFolderName + '/Bundle ' + bundleId + '/test/';

        var markup = stickGetFileHtmlCode(path + 'labs-common-markup' + stickAddSuffixIfOldUI() + '.html');
        markup = markup.replace(/{accountid}/g, context.getCompany());
        markup = markup.replace(/{bundleid}/g, context.getBundleId());

        html += markup;

        path = sbFolderName + '/Bundle ' + bundleId + '/test/';
        var jsFiles = [ 'stick_common_test_automation.js', 'labs-jsunity-0.6.js', 'labs-labswide-common.js', 'labs-labswide-client.js', 'stick_common_test_automation.js', 'labs-page-object-common.js', 'stick-record-page-ui-object.js' ];
        for (var i = 0; i < jsFiles.length; i++) {
            javascript += stickGetFileHtmlCode(path + jsFiles[i]);
        }

    }

    var codeHtml = jqueryscript + css + html + javascript;
    logger.audit('after file loading');
    return codeHtml;

}

/**
 * Retrieves the select options for standard record types
 * 
 * @return {nlobjSelectOptions[]}
 */
function stickGetStandardOptions() {

    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        return stickobjGlobal[key];
    }

    var record = nlapiCreateRecord('customrecord_stick_standard_record', {
        recordmode : 'dynamic'
    });
    var fld = record.getField('custrecord_snsr_scripted_record_type');
    var options = fld.getSelectOptions();
    logger.log('options.length=' + options.length);
    stickobjGlobal[key] = options;
    return options;
}

/**
 * gets the script id of a standard record given the id (number)
 * 
 * @param {number}
 *        id
 * @return {string} script id
 */
function stickGetStandardRecordScriptIdById(id) {
    // var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = 'customrecord_stick_standard_record';
    var record = null;
    if (stickHasValue(stickobjGlobal[key])) {
        record = stickobjGlobal[key];
    } else {
        record = nlapiCreateRecord('customrecord_stick_standard_record', {
            recordmode : 'dynamic'
        });
    }
    record.setFieldValue('custrecord_snsr_scripted_record_type', id);
    stickobjGlobal[key] = record;
    return record.getFieldValue('custrecord_snsr_script_id');
}

/**
 * @return {any[]} array of standard records
 */
function stickGetStandardRecords() {
    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + 'Return';
    var sessionObj = nlapiGetContext().getSessionObject(key);
    if (stickHasValue(sessionObj)) {
        return JSON.parse(sessionObj);
    }

    var options = stickGetStandardOptions();
    var standardRecords = [];
    for (var i = 0; i < options.length; i++) {
        var id = options[i].getId();
        var item = {
            name : options[i].getText(),
            id : id,
            scriptid : stickGetStandardRecordScriptIdById(id),
            type : 'standard'
        };
        standardRecords.push(item);
    }

    nlapiGetContext().setSessionObject(key, JSON.stringify(standardRecords));
    return standardRecords;
}

/**
 * 
 * @param {Object}
 *        key
 * @return {any[]} Named array of custom record types with param 'key' as key
 */
function stickGetStandardRecordsHashByKey(namedKey) {
    var logger = new stickobjLogger(arguments, true);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + namedKey + 'Return';
    var sessionObj = nlapiGetContext().getSessionObject(key);
    if (stickHasValue(sessionObj)) {
        return JSON.parse(sessionObj);
    }

    var records = stickGetStandardRecords();
    var recordHash = {};
    for (var i = 0; i < records.length; i++) {
        recordHash[records[i][namedKey]] = records[i];
    }
    nlapiGetContext().setSessionObject(key, JSON.stringify(recordHash));
    return recordHash;
}

/**
 * Retrieves the list of custom record types. The properties are name, scriptid,
 * id
 * 
 * @return {Any[]}
 */
function stickGetCustomRecords() {
    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object for use in succeeding calls in the same request
    var key = arguments.callee + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        logger.log('cached');
        return stickobjGlobal[key];
    }

    var recordScriptId = 'customrecordtype';
    var lowerId = 0;
    var searchColumns = [ new nlobjSearchColumn('internalid') ];
    searchColumns[0].setSort(); // sort ascending
    searchColumns.push(new nlobjSearchColumn('name'));
    searchColumns[1].setSort(); // sort ascending
    searchColumns.push(new nlobjSearchColumn('scriptid'));
    // add filter used in paging
    var searchFilters = [ new nlobjSearchFilter('formulanumeric', null, 'greaterthan', lowerId) ];
    searchFilters[0].setFormula('ROUND({internalid})');
    searchFilters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));

    var results = nlapiSearchRecord(recordScriptId, null, searchFilters, searchColumns);
    var customRecords = [];
    while (results !== null) {
        for (var i = 0; i < results.length; i++) {
            var scriptId = results[i].getValue('scriptid');
            if (stickHasValue(scriptId)) {
                scriptId = scriptId.toLowerCase();
            }
            // get scripted record type id. This is the id being used by the
            // Scripted Record Type list
            // xxx
            var name = results[i].getValue('name');
            customRecords.push({
                name : results[i].getValue('name'),
                scriptid : scriptId,
                id : results[i].getId(),
                type : 'custom'
            });
        }
        lowerId = results[results.length - 1].getValue('internalid');
        searchFilters[0] = new nlobjSearchFilter('formulanumeric', null, 'greaterthan', lowerId);
        searchFilters[0].setFormula('ROUND({internalid})');
        results = nlapiSearchRecord(recordScriptId, null, searchFilters, searchColumns);
    }
    stickobjGlobal[key] = customRecords;
    return customRecords;
}

/**
 * 
 * @param {Object}
 *        key
 * @return {any[]} Named array of custom record types with param 'namedKey' as
 *         namedKey
 */
function stickGetCustomRecordsHashByKey(namedKey) {
    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + namedKey + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        return stickobjGlobal[key];
    }

    var customRecords = stickGetCustomRecords();
    var recordHash = {};
    for (var i = 0; i < customRecords.length; i++) {
        recordHash[customRecords[i][namedKey]] = customRecords[i];
    }
    stickobjGlobal[key] = recordHash;
    return recordHash;
}

/**
 * Returns sorted record type names
 * 
 * @return {Any[]}
 */
function stickGetRecordTypeNames() {
    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        return stickobjGlobal[key];
    }
    var names = [];
    // standard
    var options = stickGetStandardOptions();
    for (var i = 0; i < options.length; i++) {
        names.push(options[i].getText());
    }
    // custom records
    var customRecords = stickGetCustomRecords();
    for (i = 0; i < customRecords.length; i++) {
        names.push(customRecords[i].name);
    }
    names.sort();
    stickobjGlobal[key] = names;
    return names;

}

/**
 * @return {Any[]} Array of record type objects. Properties are id, name,
 *         scriptid, type (custom or standard) The returned list is sorted by
 *         name
 * 
 */
function stickGetRecordTypes() {
    var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object
    // for use in succeeding calls in the same request
    var key = arguments.callee + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        return stickobjGlobal[key];
    }

    var standardRecordsHash = stickGetStandardRecordsHashByKey('name');
    var customRecordsHash = stickGetCustomRecordsHashByKey('name');

    var recordTypes = [];
    var recordNames = stickGetRecordTypeNames();
    for (var i = 0; i < recordNames.length; i++) {
        var recordName = recordNames[i];
        var record = standardRecordsHash[recordName];
        if (stickHasValue(record)) {
            recordTypes.push(record);
        } else {
            recordTypes.push(customRecordsHash[recordName]);
        }
    }
    stickobjGlobal[key] = recordTypes;
    return recordTypes;
}

/**
 * 
 * @param {Object}
 *        namedKey Can be id, name, scriptid
 */
function stickGetRecordTypesHashByKey(namedKey) {
    // var logger = new stickobjLogger(arguments);
    // create a unique key for the return value that will be stored in a global
    // object for use in succeeding calls in the same request
    var key = arguments.callee + namedKey + 'Return';
    if (stickHasValue(stickobjGlobal[key])) {
        return stickobjGlobal[key];
    }

    var records = stickGetRecordTypes();
    var recordHash = {};
    for (var i = 0; i < records.length; i++) {
        recordHash[records[i][namedKey]] = records[i];
    }
    stickobjGlobal[key] = recordHash;
    return recordHash;
}

/**
 * 
 * @param {Object}
 *        returnField The field whose value we want to return. Can be name, id,
 *        scriptid
 * @param {Object}
 *        searchField The field where search is performed. Can be name, id,
 *        scriptid
 * @param {Object}
 *        value
 */
function stickGetRecordXByY(returnField, searchField, value) {
    // var logger = new stickobjLogger(arguments);
    if (stickHasNoValue(returnField)) {
        throw 'returnField has no value';
    }
    if (stickHasNoValue(searchField)) {
        throw 'searchField has no value';
    }

    var hash = stickGetRecordTypesHashByKey(searchField);
    if (stickHasValue(hash[value])) {
        var returnValue = hash[value][returnField];
        return returnValue;
    } else {
        return null;
    }
}

/**
 * 
 * @param {String}
 *        scriptId
 */
function stickGetRecordIdbyScriptId(scriptId) {
    return stickGetRecordIdByScriptId(scriptId);
}

function stickGetRecordIdByScriptId(scriptId) {
    scriptId = scriptId.toLowerCase();
    return stickGetRecordXByY('id', 'scriptid', scriptId);
}

/**
 * Gets the numeric id given the record name. Result of the record name and id
 * mapping will be saved in a named array and will be used for future use
 * (duration of the call) to avoid the SSS_INSTRUCTION_COUNT_EXCEEDED error
 * 
 * @param {string}
 *        recordName
 * @return {integer}
 */
function stickGetRecordIdByName(recordName) {
    return stickGetRecordXByY('id', 'name', recordName);
}

function stickGetRecordScriptIdById(recordInternalId) {
    return stickGetRecordXByY('scriptid', 'id', recordInternalId);
}

/**
 * returns the script id (lower case) given the name
 * 
 * @param {string}
 *        recordName Such as Case
 * @return {string} Script Id such as supportcase
 */
function stickGetRecordScriptIdByName(recordName) {
    return stickGetRecordXByY('scriptid', 'name', recordName);
}

function stickGetRecordNameByScriptId(scriptId) {
    return stickGetRecordXByY('name', 'scriptid', scriptId);
}

/**
 * Returns the content of a file
 * 
 * @param {Object}
 *        fileName File name (excludes directory)
 */
function stickGetFileHtmlCode(fileName) {
    var logger = new stickobjLogger(arguments);
    var fileId = null;
    var file = null;
    if (fileName.indexOf('/') > -1) {
        // full file path so load it
        file = nlapiLoadFile(fileName);
        fileId = file.getId();
    } else {
        // file name only, so search it first
        var results = nlapiSearchRecord("file", null, [ 'name', 'is', fileName ]);
        if (results === null) {
            throw 'results === null; fileName=' + fileName;
        }
        if (results.length > 1) {
            throw 'results.length > 1; fileName=' + fileName;
        }
        // we expect only 1 file
        fileId = results[0].getId();

    }
    var url = nlapiResolveURL('mediaitem', fileId);
    var htmlCode = '';
    if (fileName.indexOf('.css') > -1) {
        htmlCode = '<link type="text/css" rel="stylesheet" href="' + url + '" />';
    }

    if (fileName.indexOf('.js') > -1) {
        htmlCode = '<script src="' + url + '"></script>';
    }
    if (fileName.indexOf('.html') > -1) {
        if (file === null) {
            file = nlapiLoadFile(fileId);
        }
        htmlCode = file.getValue();
    }
    logger.end();
    return htmlCode;
}

/**
 * Returns the content of a file
 * 
 * @param {Object}
 *        fileName File name (excludes directory)
 */
function stickGetFileContent(fileName) {
    var results = nlapiSearchRecord("file", null, [ 'name', 'is', fileName ]);
    if (results === null) {
        throw 'results === null; fileName=' + fileName;
    }
    if (results.length > 1) {
        throw 'results.length > 1; fileName=' + fileName;
    }
    // we expect only 1 file
    var file = nlapiLoadFile(results[0].getId());
    return file.getValue();
}

/**
 * Returns the File Id of the filename.
 * 
 * @param fileName
 */
function stickGetFileId(fileName) {
    var logger = new stickobjLogger(arguments);
    var fileId = null;
    var file = null;
    if (fileName.indexOf('/') > -1) {
        // full file path so load it
        logger.log('nlapiLoadFile() fileName=' + fileName);
        file = nlapiLoadFile(fileName);
        fileId = file.getId();
    } else {
        logger.log('file name only, so search it first');
        // file name only, so search it first
        var results = nlapiSearchRecord("file", null, [ 'name', 'is', fileName ]);
        if (results === null) {
            throw 'results === null; fileName=' + fileName;
        }
        if (results.length > 1) {
            throw 'results.length > 1; fileName=' + fileName;
        }
        // we expect only 1 file
        fileId = results[0].getId();
    }
    logger.log('fileId=' + fileId);
    return fileId;
}

/**
 * Returns the url of a file
 * 
 * @param {Object}
 *        fileName File name or full file path
 */
function stickGetFileUrl(fileName) {
    var logger = new stickobjLogger(arguments);
    var fileId = null;
    var file = null;
    if (fileName.indexOf('/') > -1) {
        // full file path so load it
        file = nlapiLoadFile(fileName);
        fileId = file.getId();
    } else {
        // file name only, so search it first
        var results = nlapiSearchRecord("file", null, [ 'name', 'is', fileName ]);
        if (results === null) {
            throw 'results === null; fileName=' + fileName;
        }
        if (results.length > 1) {
            throw 'results.length > 1; fileName=' + fileName;
        }
        // we expect only 1 file
        fileId = results[0].getId();

    }
    var url = nlapiResolveURL('mediaitem', fileId);
    logger.end();
    return url;
}

/**
 * Saves a set of parameters in the queue for handling of the scheduled script queue handler.
 * @param {object} params
 *        JSON object that contains the parameters. It should have a 'command'
 *        property which specifies the type of action to be performed
 */
function stickQueue(params)
{
    // create queue record
    var record = nlapiCreateRecord('customrecord_stick_sched_script_queue');
    record.setFieldValue('custrecord_stick_ssq_command', JSON.stringify(params));
    nlapiSubmitRecord(record);
    var resp = nlapiScheduleScript('customscript_stick_sched_script_queue_ha');
    if (resp === null)
    {
        nlapiLogExecution('DEBUG', 'stickQueue', 'stickQueue resp === null');
    }
}

/**
 * Generates a GUID-like string via nlapiEncrypt, and making use of a key string
 * and a random number/string.
 * 
 * @param {String}
 *        pKey [optional] - secret key string to use
 * @returns {String} guid
 */
function stickGenerateGuid(pKey) {
    // check if key is not given, then set to empty string
    if (stickHasNoValue(pKey)) {
        pKey = "";
    }

    // generate guid
    var random = (new Date()).getTime() + Math.floor((Math.random() * 1000) + 1);
    return nlapiEncrypt(random + "_" + pKey, null, pKey);
}

/**
 * Returns the role name (i.e. Sales Person) of the current user.
 */
function stickGetCurrentRoleName() {
    // if Administrator or Full Access, return hard-coded role name.
    // they are not returned in the Roles search just as they don't appear in the Manage Roles page.
    var roleId = nlapiGetContext().getRole(); // role's internalid
    if (roleId == '3') {
        return 'Administrator';
    } else if (roleId == '18') {
        return 'Full Access';
    }
    
    // get role's scriptid; it will be returned when role is not found
    var roleName = nlapiGetContext().getRoleId();
    // do search
    var filters = [ 'internalid', 'anyof', roleId ];
    var columns = [ new nlobjSearchColumn('name') ];
    var results = nlapiSearchRecord('Role', null, filters, columns);
    if (stickHasValue(results)) {
        roleName = results[0].getValue('name');
    }
    return roleName;
}
