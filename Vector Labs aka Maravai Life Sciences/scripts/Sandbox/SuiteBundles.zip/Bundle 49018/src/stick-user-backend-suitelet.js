/**
* � 2015 NetSuite Inc.  User may not copy, modify, distribute, or re-bundle or otherwise make available this code. 
*/

// object for storing global variables
var stickGlobal = stickGlobal || {};

function process(request, response)
{
    // do not use suitesocial.Helper.logger for request and response as it cause
    // unexpected error
    var logger = new stickobjLogger(arguments);

    var datain = JSON.parse(request.getBody());

    if (stickHasNoValue(datain.action))
    {
        response.write(JSON.stringify('ERROR: stickHasNoValue(datain.action'));
        return;
    }

    if (stickHasNoValue(datain.values))
    {
        response.write(JSON.stringify('ERROR: stickHasNoValue(datain.values'));
        return;
    }
    if (stickHasNoValue(datain.values))
    {
        nlapiCreateError('SETUP_ASSISTANT', 'stickHasNoValue(datain.values');
        response.write(JSON.stringify('stickHasNoValue(datain.values'));
        return;
    }
    logger.log('action=' + datain.action);
    logger.log('datain.values=' + JSON.stringify(datain.values));

    switch (datain.action)
    {
        case 'updateUserPreference':
            var param = {};
            param.hideSticky = datain.values.hideSticky;
            param.noteSize = datain.values.noteSize;
            param.fontSize = datain.values.fontSize;
            param.kbShortcut = datain.values.kbShortcut;

            stickUpdateUserPreference(param);
            response.write(JSON.stringify('ok'));
            break;
            
        case 'showOrHideNotes':
            var hideSticky = datain.values;
            stickShowOrHideNotes(hideSticky);
            response.write(JSON.stringify('ok'));
            break;

        case 'suppressHelp':

            var suppressHelp = datain.values;
            stickSuppressHelp(suppressHelp);
            response.write(JSON.stringify('ok'));
            break;

        case 'suppressWhatsNewHelp':

            var suppressHelp = datain.values;

            stickSuppressBoardHelp(suppressHelp);

            response.write(JSON.stringify('ok'));

            break;

        case 'getUserPreference':

            // param1 - note size id
            // param2 - font size id
            var paramUserPref = {};
            paramUserPref.noteSizeId = stickGetUserNoteSizeId();
            paramUserPref.fontSizeId = stickGetUserFontSizeId();

            var pref = nlapiLoadConfiguration('userpreferences');
            paramUserPref.hideNotes = pref.getFieldValue('custscript_stick_initially_hide_sticky_n') === 'T' ? 'checked' : '';
            paramUserPref.suppressHelpInRecord = pref.getFieldValue('custscript_stick_suppress_help');
            paramUserPref.enableStickOnRecord = pref.getFieldValue('custscript_stick_enable_record_page');
            response.write(JSON.stringify(paramUserPref));
            break;

        default:
            logger.log('ERROR: action not found: ' + datain.action);
            throw 'action not found: ' + datain.action;
    }
    logger.log('END');
}

function stickShowOrHideNotes(hideSticky) {
    var pref = nlapiLoadConfiguration('userpreferences');
    pref.setFieldValue('custscript_stick_initially_hide_sticky_n', hideSticky);
    nlapiSubmitConfiguration(pref);
}

function stickSuppressHelp(isSuppressHelp) {
    var pref = nlapiLoadConfiguration('userpreferences');
    pref.setFieldValue('custscript_stick_suppress_help', isSuppressHelp);
    nlapiSubmitConfiguration(pref);
}

function stickSuppressBoardHelp(isSuppressHelp) {
    var pref = nlapiLoadConfiguration('userpreferences');
    pref.setFieldValue('custscript_stick_suppress_board_help', isSuppressHelp);
    nlapiSubmitConfiguration(pref);
}

function stickGetUserNoteSizeId() {
    var logger = new stickobjLogger(arguments);
    // get user's note size preference
    var pref = nlapiLoadConfiguration('userpreferences');
    var noteSizeId = pref.getFieldValue('custscript_stick_note_size');
    // logger.ok('noteSizeId=' + noteSizeId);
    return noteSizeId;

    // The code below won't work since a non-admin has no access to the
    // stickynotes custom records
    //
    // if (stickHasNoValue(noteSizeId)) {
    // var filters = [];
    // filters.push([ 'name', 'is', 'Medium' ]);
    // var noteSize = nlapiSearchRecord('customrecord_stick_note_size', null,
    // filters);
    // noteSizeId = noteSize[0].getId();
    // }
    //
    // return noteSizeId;
}

function stickGetUserFontSizeId() {
    // get user's font size preference
    var pref = nlapiLoadConfiguration('userpreferences');
    var fontSizeId = pref.getFieldValue('custscript_stick_font_size');
    return fontSizeId;
    // The code below won't work since a non-admin has no access to the
    // stickynotes custom records
    // if (stickHasNoValue(fontSizeId)) {
    // var filters = [];
    // filters.push([ 'name', 'is', 'Normal' ]);
    // var fontSize = nlapiSearchRecord('customrecord_stick_font_size', null,
    // filters);
    // fontSizeId = fontSize[0].getId();
    // }

}





function stickUpdateUserPreference(param)
{
    var pref = nlapiLoadConfiguration('userpreferences');
    pref.setFieldValue('custscript_stick_initially_hide_sticky_n', param.hideSticky);
    pref.setFieldValue('custscript_stick_note_size', param.noteSize);
    pref.setFieldValue('custscript_stick_font_size', param.fontSize);
    pref.setFieldValue("custscript_stick_submit_keyboardshortcut", param.kbShortcut == "1" || param.kbShortcut == "2" ? param.kbShortcut : "");
    nlapiSubmitConfiguration(pref);
}
