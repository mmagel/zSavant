// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:CLI_Selection_Window.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:18-Sep-2017
    Description: This script is used to trigger the suitelet which selects lot number for assembly item.
	Script Modification Log:
	-- Date --			-- Modified By --				--Requested By--				-- Description --
	27-09-2017          Vinod P                          Anuradha K                     Script code changes to add deployment for workordercompletion record           
	28-09-2017          Vinod P                          Anuradha K                     Script code changes to add deployment for Inventory transfer record
	29-09-2017          Vinod P                          Anuradha K                     Script code changes to add deployment for Inventory Adjustment record
	05-10-2017          Vinod P                          Anuradha K                     Script changes for sending body location for search instead of line level location array.
	09-10-2017          Vinod P                          Anuradha K                     Added code to parse expiry date for lot number & set custbody_expiry_dates on text field.
	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================

// BEGIN FIELD CHANGED ==============================================

function fieldChanged_openWindow(type, name, linenum)
{
		//Getting the record type
	var s_recordType = nlapiGetRecordType();

//If record type is workorder / workordercompletion / inventorytransfer or inventoryadjustment 
if(s_recordType == 'workorder' || s_recordType == 'workordercompletion' || s_recordType == 'inventorytransfer' || s_recordType == 'inventoryadjustment')
{
	//If field name is custbody_select_lot_number	
	if(name == 'custbody_select_lot_number')	
	{
		//Get item line count
		if(s_recordType == 'workorder')
		{
			var i_line_count = nlapiGetLineItemCount('item');
		}
		else if(s_recordType == 'workordercompletion')
		{
			var i_line_count = nlapiGetLineItemCount('component');
		}
		else if(s_recordType == 'inventorytransfer' || s_recordType == 'inventoryadjustment')
		{
			var i_line_count = nlapiGetLineItemCount('inventory');
		}

		//If recordtype is not inventoryadjustment then we have to take location id = location
		if(s_recordType != 'inventoryadjustment')
		{
			//Get the location
			var i_location = nlapiGetFieldValue('location');
		}
		//If recordtype is inventoryadjustment then we have to take location id = adjlocation
		else
		{
			var i_location = nlapiGetFieldValue('adjlocation');
		}
		//Declare item array & location array
		var item_array = new Array();
		//var location_array = new Array();

	
		//Loop through line count of item 
		for(var k=1;k<=i_line_count;k++)
		{
			//If record type is workorder then get item id by type = item
			if(s_recordType == 'workorder')
			{
				var i_item = nlapiGetLineItemValue('item','item',k);
			}
			//If record type is workordercompletion then get item id by type = component
			else if(s_recordType == 'workordercompletion')
			{
				var i_item = nlapiGetLineItemValue('component','item',k);
			}
			//If record type is inventorytransfer then get item id by type = inventory
			else if(s_recordType == 'inventorytransfer')
			{
				var i_item = nlapiGetLineItemValue('inventory','item',k);
			}
			//If record type is inventoryadjustment then get item id by type = inventory
			else if(s_recordType == 'inventoryadjustment')
			{
				var i_item = nlapiGetLineItemValue('inventory','item',k);	
			}

			//Push item id in item array
			item_array.push(i_item);
		
		}
		//Get the isCheck value for Select Lot No checkbox
		var isCheck = nlapiGetFieldValue('custbody_select_lot_number');

	//	alert('item_array' + item_array);
	//If Select Lot number field is true then the suitelet will be called.
		if(isCheck == 'T'){
			//Check logValidation for item and location OR item and line location 
			if(_logValidation(i_item) && _logValidation(i_location))  
			{
				//Get url of suitelet
				 var linkURL = nlapiResolveURL('SUITELET', 'customscript_sut_component_lot_no_window', 'customdeploy1', null);   
				 //window.open(linkURL, 'name', "width=700,location=no,menubar=no,height=500,scrollbars=no,resizable=no,fullscreen=no");
				//If record type is inventoryadjustment then add item array and location to url	
					
					//Add item array and location to the url
					 linkURL = linkURL + '&item_array=' + item_array + '&i_location=' + i_location; 
			
				 //Open suitelet in window
				 nlExtOpenWindow(linkURL, '', 700, 500, '', false, "Serial/Lot Number List");
			}
			//If Item is not selected then alert to select the item & make Select Lot No checkbox to false
			else if(_nullValidation(i_item))
			{
				alert('Please select the Item');
				nlapiSetFieldValue('custbody_select_lot_number','F',false,false);
				return false;
			}
			//If location is not selected then alert to select the item & make Select Lot No checkbox to false
			else if(_nullValidation(i_location) || _nullValidation(i_line_location))
			{
				alert('Please select the Location');
				nlapiSetFieldValue('custbody_select_lot_number','F',false,false);
				return false;
			}
	}
		return true;
	}	
}

}//function fieldChanged_openWindow(type, name, linenum)

// END FIELD CHANGED ================================================


//************************************ START getData () to set values on line level of transaction *********************************

//function getData(item_id_array,lot_no_array,i_qty_array)
function getData(data)
{
	//Check for logValidation for data
if(_logValidation(data))
{
//Split the input data by # to get each item details  
a_value = data.split('#');
//alert('a_value length = ' + a_value.length)
	//closePopup();
	var string_date_array = new Array();

	//Check for logValidation for a_value
	if(_logValidation(a_value))
	{
		
		//Loop through a_value array length -1 As last array is undefined array
		for(var i=0;i<a_value.length-1;i++)
		{
			//Split the a_value array by @ to get the values for each item, lot no , qty and index from a single set of item
 			var split_value = a_value[i].split('@');

			//Get Item id
			var i_item = split_value[0];
			//Get lot number array
			var f_lot_no = split_value[1];
			//Get quantity array
			var i_qty_enter = split_value[2];

			//Get exp date array
			var d_exp_date = split_value[3];
			//alert(d_exp_date);
			if(d_exp_date != null || d_exp_date!= undefined)
			{
				string_date_array.push(d_exp_date);
			}
			

			//Get index value
			var i_index = split_value[4];
			
			//Split f_lot_no string by , to get different lot no for single item
			var f_lot_array = f_lot_no.split(',');
			//Split f_qty_array string by , to get different lot no qty for single item
			var f_qty_array = i_qty_enter.split(',');


			//Create lot_qty_arr to store both lot no and qty
			var lot_qty_arr = new Array();
			//alert('f_lot_array.length = ' + f_lot_array.length);

			//if only 1 lot no is present in array then just push the LOt number only into lot_qty_array
			if(f_lot_array.length == 1)
			{
				//Place only lot no. value 
				lot_qty_arr.push(f_lot_array[0]);
			}
			else
			{
			//If more than one 1 lot no are present for single item then loop through each lot no and qty and concatinate them and push to lot_qty_array
				for(var k=0;k<f_lot_array.length;k++)
				{
				//Concatinate f_lot_array element with f_qty_array element and push into lot_qty_arr
					lot_qty_arr.push(f_lot_array[k] + '('+ f_qty_array[k] +')');
					
				}
			}

			//alert(lot_qty_arr);

		//Check logValidation for item id f_lot_array, f_qty_array and Lot_qty_Arr
		if(_logValidation(i_item) && _logValidation (f_lot_array) && _logValidation(f_qty_array) && _logValidation(lot_qty_arr)){
			//If record type is workorder then get/set item line level details by type = item  
			if(nlapiGetRecordType() == 'workorder'){	
			//Get line no of item id
			var line_no = nlapiFindLineItemValue('item','item',i_item);	
				//If line is present
				if(line_no!=-1){
					//Select the item line
					nlapiSelectLineItem('item',line_no);
					//alert('line_no ' + line_no);
					// set the serial number with quantity array values on the currently selected line
					nlapiSetCurrentLineItemValues('item', 'serialnumbers', lot_qty_arr, true, true);
					// commit the line to the database
					nlapiCommitLineItem('item');
				}
			}
			//If record type is workordercompletion then get/set item line level details by type = component  
			else if(nlapiGetRecordType() == 'workordercompletion')
			{
		
			//Get line no of item id
			var line_no = nlapiFindLineItemValue('component','item',i_item);	
				//If line is present
				if(line_no!=-1){
					//Select the component line
					nlapiSelectLineItem('component',line_no);
					//alert('line_no ' + line_no);
					// set the serial number with quantity array values on the currently selected line
					//alert('lot_qty_arr while setting = ' + lot_qty_arr);
					nlapiLogExecution('debug','lot_qty_arr',lot_qty_arr);

					var final_lot = lot_qty_arr.toString();
					final_lot = final_lot.replace(',',' ');
					//alert('final_lot in string = ' + final_lot);

					nlapiSetCurrentLineItemValue('component', 'componentnumbers', final_lot, true, true);
					// commit the line to the database
					nlapiCommitLineItem('component');
				}
			
			}//End of else if(nlapiGetRecordType() == 'workordercompletion')
			//If record type is InventoryTransfer or inventoryadjustment then get/set item line level details by type = inventory  
			else if(nlapiGetRecordType() == 'inventorytransfer' || nlapiGetRecordType() == 'inventoryadjustment')
			{	
			//Get line no of item id
			var line_no = nlapiFindLineItemValue('inventory','item',i_item);	
				//If line is present
				if(line_no!=-1){
					//Select the component line
					nlapiSelectLineItem('inventory',line_no);
					//alert('line_no ' + line_no);
					// set the serial number with quantity array values on the currently selected line
					//alert('lot_qty_arr while setting = ' + lot_qty_arr);
					nlapiLogExecution('debug','lot_qty_arr',lot_qty_arr);

					var final_lot = lot_qty_arr.toString();
					final_lot = final_lot.replace(',',' ');
					//alert('final_lot in string = ' + final_lot);

					nlapiSetCurrentLineItemValue('inventory', 'serialnumbers', final_lot, true, true);
					// commit the line to the database
					nlapiCommitLineItem('inventory');
				}
			
			}//End of else if(nlapiGetRecordType() == 'inventorytransfer')

			}//End of if(_logValidation(i_item) && _logValidation (f_lot_array) && _logValidation(f_qty_array) && _logValidation(lot_qty_arr))
		} //End of for(var i=0;i<a_value.length-1;i++)


		//Convert array of date into String 
		string_date_array = string_date_array.toString();
		//Removing all the preceding and succeding commas using regex 
		string_date_array = string_date_array.replace(/(^\s*,)|(,\s*$)/g, '');
		//alert('string_date_array= ' + string_date_array);
		
		//Set expiry date string array on custom field 
		nlapiSetFieldValue('custbody_expiry_dates',string_date_array);


	}//End of if(_logValidation(a_value))
	//alert(values);
	closePopup();
	//self.close();
	 //window.top.close();
	//nlapiSetCurrentLineItemValue('expense','custcol_per_diem_rate',f_perdiemRate)
}
}//End of function getData(data)

//************************************ END getData () to set values on line level of transaction *********************************


//******************************************************START SAVE RECORD function to check qty **********************************
function saveRecord_checkQty()
{
	//Get sublist count
	 var sublist_count = nlapiGetLineItemCount('custpage_assembly_sublist');
	 //Loop through sublist count
	 for(var i=1;i<=sublist_count;i++){
	 	//Get the enter qty
	 	var qty_enter = nlapiGetLineItemValue('custpage_assembly_sublist','custpage_enter_qty',i);
	 	//Get available quantity
	 	var qty_available = nlapiGetLineItemValue('custpage_assembly_sublist','custpage_qty_available',i);
	 	//If enter qty > available qty then alert and do not allow to save.
	 	if(parseFloat(qty_enter) > parseFloat(qty_available))
	 	{
	 		alert('Please correct the Quantity on line level');
	 		return false;
	 	}
	 }
	 return true;
}//End of function saveRecord_checkQty()

//******************************************************END SAVE RECORD function to check qty **********************************

function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}



function _nullValidation(val){
    if (val == null || val == undefined || val == '') {
        return true;
    }
    else {
        return false;
    }
    
}


