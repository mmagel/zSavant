function fldChange_setCheckBox(type,name)
{
  //	alert("In Client Script Function");
  	if(name =='location')
    {
      	alert("on Location Change:- "+name);
		nlapiSetFieldValue('memo', 'A',true,true);
      	alert("WIP VALUE "+memo);
    }
  return true;
}