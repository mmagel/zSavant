function pageInit_disableCheckBox(type)
{
	alert("In Page Init Function");
	nlapiDisableField('iswip',true);
}