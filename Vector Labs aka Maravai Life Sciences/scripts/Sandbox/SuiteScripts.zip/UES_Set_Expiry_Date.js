// BEGIN SCRIPT DESCRIPTION BLOCK  ==================================
{
/*
   	Script Name:UES_Set_Expiry_Date.js
	Author:Vinod Pandit
	Company:Inspirria Cloudtech Pvt Ltd.
	Date:11-Oct-2017
    Description: This script is used to get the component expiry dates and set on a custom field for setting the earliest Expiration Date on Work Order Completion.
	Script Modification Log:
	-- Date --			-- Modified By --				--Requested By--				-- Description --
	
	Below is a summary of the process controls enforced by this script file.  The control logic is described
	more fully, below, in the appropriate function headers and code blocks.

*/
}
// END SCRIPT DESCRIPTION BLOCK  ====================================

function beforeSubmit_setExpiryDates()
{
	var i_location = nlapiGetFieldValue('location');
	var item_array = new Array()
	var line_count = nlapiGetLineItemCount('component');
	for(var i=1;i<=line_count;i++)
	{
		var i_item = nlapiGetLineItemValue('component','item',i);
		item_array.push(i_item);
	}
	
	nlapiLogExecution('debug','debug',item_array);
	 //Add filters for on hand qty, location and items
    var filter = new Array(); 
    filter [0] = new nlobjSearchFilter('isonhand','inventorynumber','is','T')
    filter [1] = new nlobjSearchFilter('location','inventorynumber','anyof',i_location)
    filter [2] = new nlobjSearchFilter('internalid',null,'anyof',item_array)
    //Add columns for item iternal id , name by group, expiry date by group, location by group and quantity on hand SUM 
    var column = new Array();
   column [0] =  new nlobjSearchColumn("internalid",null,"GROUP"), 
   column [1] = new nlobjSearchColumn("itemid",null,"GROUP").setSort(false), 
   column [2] = new nlobjSearchColumn("inventorynumber","inventoryNumber","GROUP"), 
   column [3] = new nlobjSearchColumn("expirationdate","inventoryNumber","GROUP").setSort(false), 
   column [4] = new nlobjSearchColumn("location","inventoryNumber","GROUP"), 
   column [5] = new nlobjSearchColumn("quantityonhand","inventoryNumber","SUM")
//Search on item record with the given filter
   var itemSearch = nlapiSearchRecord("item",null,filter,column);
   
	if(_logValidation(itemSearch))
	{
		
		var arr_expiryDates = new Array();
	  //Loop through the itemSearch length 
	    for(var i=0;i<itemSearch.length;i++)
	    {
	       var i_item = itemSearch[i].getValue(column[1]);
	      
	       var i_Exp_Dt = itemSearch[i].getValue(column[3]);
	       if(i_Exp_Dt!= null || i_Exp_Dt != undefined)
	       {
	       		arr_expiryDates.push(i_Exp_Dt);
	       }

	    }
	    nlapiSetFieldValue('custbody_expiry_dates',arr_expiryDates);
	}
}


function _logValidation(value){
    if (value != null && value != undefined && value != '' && value != 'undefined') {
        return true;
    }
    else {
        return false;
    }
    
}