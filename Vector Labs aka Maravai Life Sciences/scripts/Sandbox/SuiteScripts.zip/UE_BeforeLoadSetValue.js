function beforeSubmitSetValue(type)
{	
	if(type== 'create' && type=='edit')
	{
		//var oldLoc = nlapiGetOldRecord('location');
		nlapiSetFieldValue('memo','T');
	}
}