function beforeSubmitSetValue(type)
{
  /*This User Event Script Function is used to set "WIP" CheckBox Value as True.
  	This Function is work only in create and edit mode
  */
	if(type== 'create'  || type=='edit')
	{
      	nlapiLogExecution('DEBUG','Inside BeforeSubmit In Function');
		var old = nlapiGetOldRecord();//api is used to get the old record i.e beforeLoad.
		var oldLoc = old.getFieldValue('location');//using old object we can get 'location'field value beforeLoad.
		var newLoc = nlapiGetFieldValue('location');//api used to get location value beforeSubmit.
		if(oldLoc != newLoc)
		{
         	//enter in this block if both old and new value are not equal
          	nlapiLogExecution('DEBUG','Inside BeforeSubmit In If Block');
			nlapiSetFieldValue('iswip','T');//api is used to set CheckBox value
		}
	}
}

function beforeLoadDemo(type,form)
{
  //nlapiLogExecution('DEBUG','obj '+obj);
 // var obj = form.getField('iswip');
	nlapiLogExecution('DEBUG','Inside BeforeLoad');
 // obj.setDisplayType('hidden');
  
  
}