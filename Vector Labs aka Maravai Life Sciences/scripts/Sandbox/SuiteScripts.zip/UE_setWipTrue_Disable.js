function beforeSubmit_SetCustWIP(type)
{
	var custobj = form.getField('custbody_iswip');
	var stdobj = form.getField('iswip');
	if(type == 'create' || type == 'edit')
	{	
		stdobj.setDisplayType('hidden'); 
		if(orderstatus=='released')
		{
			custobj.setDisplayType('readonly');
			
		}
		custobj.setDisplayType('normal');   
	}
}

function beforeLoad_showWIP(type,form)
{	
	var custobj = form.getField('custbody_iswip');
	custobj.setDisplayType('hidden');  
/*	if(type == 'view')
	{
		var stdobj = form.getField('iswip');
		nlapiLogExecution('DEBUG','obj '+obj);
		stdobj.setDisplayType('readonly');
	}*/
}


