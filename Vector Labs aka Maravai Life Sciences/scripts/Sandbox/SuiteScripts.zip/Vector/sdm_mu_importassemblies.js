/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       28 Aug 2016     smarasigan
 *
 */

/**
 * @param {String} recType Record type internal id
 * @param {Number} recId Record internal id
 * @returns {Void}
 */
function massUpdate(recType, recId) {
	try{
		var update_fields=nlapiLookupField(recType,recId,['custrecord_importassemblies_date','custrecord_importassemblies_memo','custrecord_importassemblies_item','custrecord_importassemblies_qty','custrecord_importassemblies_lot']);
		var record = nlapiCreateRecord('assemblybuild');
		record.setFieldValue('subsidiary',3);
		record.setFieldValue('location',1);
		record.setFieldValue('item',update_fields.custrecord_importassemblies_item);
		record.setFieldValue('quantity',update_fields.custrecord_importassemblies_qty);
		record.setFieldValue('trandate',update_fields.custrecord_importassemblies_date);
		record.setFieldValue('serialnumbers',update_fields.custrecord_importassemblies_lot);	
		record.setFieldValue('memo',update_fields.custrecord_importassemblies_memo);
		id = nlapiSubmitRecord(record, true); 
	}
	
	catch(e){
		nlapiLogExecution('ERROR','update fulf error',recId+' '+e.message);
	}
}
