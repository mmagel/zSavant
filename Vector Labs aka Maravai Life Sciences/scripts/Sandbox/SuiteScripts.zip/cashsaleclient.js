function cash_sales_onload(type){
//  nlapiSendEmail(13,13,'test','test '+type);
	if (type=='copy'){
		var iid=nlapiGetFieldValue('createdfrom');
		
		if (iid!=''&&iid!=null){
			var results=nlapiSearchRecord('salesorder','customsearch_auth',new nlobjSearchFilter('internalid',null,'anyof',iid));
			for (var i=0; results!=null&&i<results.length; i++){
				var cols=results[i].getAllColumns();
				var auth=results[i].getValue(cols[1]);
				var meth=nlapiGetFieldValue('paymentmethod');
				nlapiSetFieldValue('paymentmethod','',true,true);
				nlapiSetFieldValue('paymentmethod',meth,true,true);
				nlapiSetFieldValue('pnrefnum',auth);
				break;
			}
		}
	}
}