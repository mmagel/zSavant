function contact_after_submit(type){
	try {
	var eid=nlapiGetFieldValue('entityid');
	nlapiSubmitField('contact',nlapiGetRecordId(),'externalid',eid+'_con');
	}
	catch(e){
		nlapiLogExecution('ERROR',nlapiGetRecordId(),e.message)
	}
}