function cr_bs(type){
	if (type=='create'||type=='edit'){
		var name=nlapiGetFieldValue('name');
		var results=nlapiSearchRecord('item',null,new nlobjSearchFilter('itemid',null,'startswith',name),new nlobjSearchColumn('internalid'));
		var arr=new Array();
		for (var i=0; results!=null&&i<results.length; i++){
			arr.push(results[i].getValue('internalid'));
		}
		nlapiSetFieldValue('custrecord_items',arr);
	}
}