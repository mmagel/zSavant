function discount(){
	var results=nlapiSearchRecord('salesorder','customsearch259');
	for (var i=0; i<results.length-1; i++){
		var diff=results[i+1].getValue('custbody_mag_order_number')-results[i].getValue('custbody_mag_order_number');
		nlapiLogExecution('ERROR',results[i].getValue('custbody_mag_order_number'),diff);
	}
	
	
}