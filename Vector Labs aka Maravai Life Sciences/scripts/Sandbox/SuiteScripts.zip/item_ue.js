function lnii_before_submit(type)
{
	//if (type=='edit'&&nlapiGetContext().getExecutionContext()=='userinterface'){
	//	nlapiLogExecution('ERROR','test','test');
		//var id=nlapiGetFieldValue('custitem_magid');
  var id='1030';
		nlapiSetFieldValue('externalid',id);
		nlapiSubmitField(nlapiGetRecordType(),nlapiGetRecordId(),'externalid',id)
	//}
}