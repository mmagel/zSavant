function setexid(type){
	nlapiLogExecution('ERROR','id',nlapiGetRecordId());
	var item=nlapiLoadRecord('lotnumberedassemblyitem',nlapiGetFieldValue('custrecord_item'));
	item.setFieldValue('externalid',nlapiGetFieldValue('custrecord_mag_id'));
	nlapiSubmitRecord(item);
}
function item_upload_asa(type){
	if (type=='create'||type=='edit'){
		var sku=nlapiGetFieldValue('custrecord_magento_sku');
		var id=nlapiGetFieldValue('custrecord_mag_id');
		var item=nlapiSearchRecord('lotnumberedassemblyitem',null,new nlobjSearchFilter('itemid',null,'is',sku),new nlobjSearchColumn('internalid'));
		var quantity=nlapiGetFieldValue('custrecord_quantity');
		try{
		if (item!=null){
			item=nlapiLoadRecord('lotnumberedassemblyitem',item[0].getValue('internalid'));
			item.setFieldValue('externalid',id);
			item.setFieldValue('custitem_upload',nlapiGetRecordId());
			item=nlapiSubmitRecord(item);
		var adj=nlapiCreateRecord('inventoryadjustment',{recordmode:'dynamic'});
		adj.setFieldValue('subsidiary',3);
		adj.setFieldValue('account',127);
		
		adj.setFieldValue('trandate',nlapiDateToString(new Date()));
		adj.selectNewLineItem('inventory');
		adj.setCurrentLineItemValue('inventory','item',item);
		adj.setCurrentLineItemValue('inventory','location',1);
		adj.setCurrentLineItemValue('inventory','adjustqtyby',quantity);
		adj.setCurrentLineItemValue('inventory','serialnumbers',1);
		adj.commitLineItem('inventory');
		nlapiSubmitRecord(adj);
		nlapiSubmitField(nlapiGetRecordType(),nlapiGetRecordId(),'custrecord_item',item);
		
		}
		else {
			nlapiLogExecution('ERROR','failure: sku '+sku+' not found.',id);
			item=nlapiCreateRecord('lotnumberedassemblyitem',{recordmode:'dynamic'});
			item.setFieldValue('itemid',sku);
			item.setFieldValue('subsidiary',3);
			item.setFieldValue('externalid',id);
			item.setFieldText('taxschedule','CA');
			item.setFieldValue('cogsaccount',127);
			item.setFieldValue('assetaccount',145);
			item.setFieldValue('incomeaccount',54);
			item.selectNewLineItem('member');
			item.setCurrentLineItemValue('member','item',3816);
			item.setCurrentLineItemValue('member','quantity',1);
			item.commitLineItem('member');
			item.setFieldValue('custitem_upload',nlapiGetRecordId());
			item=nlapiSubmitRecord(item);
			var adj=nlapiCreateRecord('inventoryadjustment',{recordmode:'dynamic'});
		adj.setFieldValue('subsidiary',3);
		adj.setFieldValue('account',127);
		
		adj.setFieldValue('trandate',nlapiDateToString(new Date()));
		adj.selectNewLineItem('inventory');
		adj.setCurrentLineItemValue('inventory','item',item);
		adj.setCurrentLineItemValue('inventory','location',1);
		adj.setCurrentLineItemValue('inventory','adjustqtyby',quantity);
		adj.setCurrentLineItemValue('inventory','serialnumbers',1);
		adj.commitLineItem('inventory');
		nlapiSubmitRecord(adj);
		nlapiSubmitField(nlapiGetRecordType(),nlapiGetRecordId(),'custrecord_item',item);
			nlapiLogExecution('ERROR','create success: sku '+sku+' found.',id);
		}
		}
		catch(e){
			nlapiLogExecution('ERROR',id,e.message);
		}
	}
}
function item_upload_set_fields(type){
	var item=nlapiLoadRecord('lotnumberedassemblyitem',nlapiGetFieldValue('custrecord_item'));
	var unitsize=nlapiGetFieldValue('custrecord_unit_size');
	var type=nlapiGetFieldValue('custrecord_prod_type_id');
	item.setFieldValue('custitem_usize',unitsize);	
	item.setFieldText('custitem_mag_prod_type',type);
	nlapiSubmitRecord(item);
}
function item_upload_set_price(type){
	var price=nlapiGetFieldValue('custrecord_price');
	var item=nlapiLoadRecord('lotnumberedassemblyitem',nlapiGetFieldValue('custrecord_item'));
 
// You must select, set, and then commit the sublist line you want to change.
item.selectLineItem('price', 1); 
item.setCurrentLineItemMatrixValue('price', 'price', 1, price);
item.commitLineItem('price');
nlapiSubmitRecord(item);
}
function item_upload_set_attributes(type){
	//var shortdescription=nlapiGetFieldValue('custrecord_short_description');
	//var description=nlapiGetFieldValue('custrecord_description_ws');
	//var keywords=nlapiGetFieldValue('custrecord_keywords');
	//var category=nlapiGetFieldValue('custrecord_categories');
//	category=category.split(',');
	//var categories=new Array();
//for (var i=0;i<category.length;i++){
//	var catrecord=nlapiSearchRecord('customrecord_prod_category',null,new nlobjSearchFilter('custrecord_pc_mag_id',null,'is',category[i]),new nlobjSearchColumn('internalid'));
//	if (catrecord!=null){
	//	categories.push(catrecord[0].getValue('internalid'));
	//}
//}
if (type=='delete'){return;}
	var sites=nlapiGetFieldValue('custrecord_websites');
	sites=sites.split(',');
	var sitesarr=new Array();
	if (typeof sites=='string'){
		sitesarr.push(sites);
		sites=sitesarr;
	}
	var unitsize=nlapiGetFieldValue('custrecord_unit_size');
	var att_set=nlapiGetFieldValue('custrecord_attribute_set');
	var price=nlapiGetFieldValue('custrecord_price');
	var conjugate=nlapiGetFieldValue('custrecord_conjugate');
	var host_species=nlapiGetFieldValue('custrecord_host_species');
	var detection_target=nlapiGetFieldValue('custrecord_detection_target');
	var species_reactivity=nlapiGetFieldValue('custrecord_spec_reactivity');
	var tax_group=nlapiGetFieldValue('custrecord_tax_class');
	var callforprice=nlapiGetFieldValue('custrecord_call_for_price');
	var cemarked=nlapiGetFieldValue('custrecord_ce_marked');
	var featured=nlapiGetFieldValue('custrecord_featured');
	var format=nlapiGetFieldValue('custrecord_format');
	var fluor=nlapiGetFieldValue('custrecord_color_of_fluorescense');
	var enzyme=nlapiGetFieldValue('custrecord_enzyme');	
	var applications=get_multi_array('custrecord_applications');
	var technology=get_multi_array('custrecord_technology');
	var sugspec=get_multi_array('custrecord_sugar_specificity');	
	var blockingaction=get_multi_array('custrecord_blocking_action');
	var rxncolor=get_multi_array('custrecord_color_of_rxn_product');
	var microscopy=get_multi_array('custrecord_microscopy');
	var addprops=get_multi_array('custrecord_add_properties');
	var subrxn=nlapiGetFieldValue('custrecord_reaction_product');	
	var transdir=nlapiGetFieldValue('custrecord_detection_of_transport');
	var detmeth=get_multi_array('custrecord_detection_method');
	var taggroup=nlapiGetFieldValue('custrecord_tag_group_incorporated');
	var custitem_req_reactive_group=nlapiGetFieldValue('custrecord_required_reactive_group');
	var target=get_multi_array('custrecord_target');
	var cellstain=get_multi_array('custrecord_cell_stain');
	var mounting=get_multi_array('custrecord_mounting');
	var antifade=nlapiGetFieldValue('custrecord_antifade');
	var counterstains=nlapiGetFieldValue('custrecord_counterstains');
	var fpt=nlapiGetFieldValue('custrecord_fusion_protein_gag');
	var matcon=nlapiGetFieldValue('custrecord_matrix_conjugate');
	var item=nlapiLoadRecord('lotnumberedassemblyitem',nlapiGetFieldValue('custrecord_item'));
	
	item.setFieldText('custitem_sdm_itemattribute',att_set);
	item.setFieldTexts('custitem_websites',sites);
	item.setFieldText('custitem_usize',unitsize);
	nlapiLogExecution('ERROR','apps',applications);
	if (applications!='')
		item.setFieldTexts('custitem_applications',applications);
	item.setFieldText('custitem_conjugate',conjugate);
	item.setFieldText('custitem_hostspecies',host_species);	
	item.setFieldText('custitem_detection_target',detection_target);
	item.setFieldText('custitem_species_reactivity',species_reactivity);		
	item.setFieldText('custitem_mag_tax_group',tax_group);
	item.setFieldText('custitem_callforprice',callforprice);
	item.setFieldText('custitem_ce_marked',cemarked);
	item.setFieldText('custitem_feat_product',featured);
	if (technology!='')
		item.setFieldTexts('custitem_technology',technology);
	if (sugspec!='')
		item.setFieldTexts('custitem_sugarspec',sugspec);
	item.setFieldText('custitem_format',format);
	item.setFieldText('custitem_fluor_color',fluor);
	item.setFieldText('custitem_detenzyme',enzyme);
	if (blockingaction!='')
		item.setFieldTexts('custitem_blockingaction',blockingaction);
	if (rxncolor!='')
		item.setFieldTexts('custitem_color_of_rxn_product',rxncolor);	
	if (microscopy!='')
		item.setFieldTexts('custitem_microscopy',microscopy);
	if (addprops!='')
		item.setFieldTexts('custitem_addprops',addprops);
	item.setFieldText('custitem_transportdir',transdir);
	item.setFieldText('custitem_subrxnprod',subrxn);
	item.setFieldText('custitem_antifade',antifade);
	item.setFieldText('custitem_counterstains',counterstains);
	item.setFieldText('custitem_tag_group_incorporated',taggroup);
	item.setFieldText('custitem_req_reactive_group',custitem_req_reactive_group);
	if (detmeth!='')
		item.setFieldTexts('custitem_detmeth',detmeth);
	if (target!='')
		item.setFieldTexts('custitem_target',target);
	if (cellstain!='')
		item.setFieldTexts('custitem_cellstains',cellstain);
	if (mounting!='')
		item.setFieldTexts('custitem_mounting',mounting);
	item.setFieldText('custitem_fusion_protein_tag',fpt);	
	item.setFieldText('custitem_mat_conj',matcon);
	nlapiSubmitRecord(item);
	//item.setFieldValue('isonline','T');
	//item.setFieldValues('custitem_mag_prod_category',categories);
	//item.setFieldValue('storedescription',shortdescription);
	//item.setFieldValue('storedetaileddescription',description);
	//item.setFieldValue('searchkeywords',keywords);
}
function get_multi_array(field){
	
	var val=nlapiGetFieldValue(field);
	if (val==null){
		return '';
	}
	val=val.split(' , ');
	var valarr=new Array();
	if (typeof val=='string'){
		valarr.push(val);
		val=valarr;
	}
	return val;
}



function item_upload_image(type){
var small=nlapiGetFieldValue('custrecord_small_image');
var img=nlapiGetFieldValue('custrecord_image');	
var thumb=nlapiGetFieldValue('custrecord_thumbnail');	
var url='https://vectorlabs.com/media/catalog/product';
var fullurl=url+small;
file=nlapiRequestURL(fullurl);
var file = nlapiCreateFile(small.split('/')[small.split('/').length-1], 'JPGIMAGE', file.getBody());
file.setFolder(-4);
var fileId = nlapiSubmitFile(file);
var imgfile;
if (img==small){
	imgfile=fileId;
}
else {
	fullurl=url+img;
	file=nlapiRequestURL(fullurl);
	var file = nlapiCreateFile(img.split('/')[img.split('/').length-1], 'JPGIMAGE', file.getBody());
	file.setFolder(-4);
	imgfile= nlapiSubmitFile(file);
}
var thumbfile;
if (thumb==small){
	thumbfile=fileId
}
else if (thumb==img){
	thumbfile=imgfile;
}
else {
	fullurl=url+thumb;
	file=nlapiRequestURL(fullurl);
	var file = nlapiCreateFile(thumb.split('/')[thumb.split('/').length-1], 'JPGIMAGE', file.getBody());
	file.setFolder(-4);
	thumbfile= nlapiSubmitFile(file);
}
var item=nlapiLoadRecord('lotnumberedassemblyitem',nlapiGetFieldValue('custrecord_item'));
item.setFieldValue('storedisplayimage',imgfile);
item.setFieldValue('storedisplaythumbnail',thumbfile);
item.setFieldValue('custitem_small_image',fileId);
nlapiSubmitRecord(item);
}