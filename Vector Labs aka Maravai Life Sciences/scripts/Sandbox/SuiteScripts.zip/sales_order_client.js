function so_validate_field(type,name,linenum)
{
	
	if (name=='otherrefnum'&&nlapiGetFieldValue('otherrefnum')!=''&&nlapiGetFieldValue('otherrefnum')!=null){
		var num=nlapiGetFieldValue('otherrefnum');
		var entity=nlapiGetFieldValue('entity');
		if (entity!=''&&entity!=null){
			var so=nlapiSearchRecord('salesorder',null,[new nlobjSearchFilter('poastext',null,'is',num),new nlobjSearchFilter('entity',null,'anyof',entity) , new nlobjSearchFilter('mainline',null,'is','T')],new nlobjSearchColumn('internalid'));
			if (so!=null){
				alert('po number '+num+' is already in use. Please re-enter the PO#');
              	nlapiSetFieldValue('otherrefnum','');
				return false;
			}
		}
	}
	return true;
}
function so_field_changed_tax(type,name){
  //
	  if (name=='entity'){
		nlapiSetFieldValue('otherrefnum','');	
	  }
	  if (name=='shipaddress'){
		  //alert(nlapiGetFieldValue('shipaddress'));
			//alert(nlapiGetFieldValue('shipstate'));
			var shipstate=nlapiGetFieldValue('shipstate');
			var entity=nlapiGetFieldValue('entity');
       		 
			var exempt=false;
			var taxable=false;
			if (entity!=''&&entity!=null){
				var ex=nlapiLookupField('customer',entity,'custentity_taxexempt');
              var taxab=nlapiLookupField('customer',entity,'taxable');
				if (ex=='T'){
					exempt=true;
				}
				if (taxab=='T'){
					taxable=true;
				}
			}
			if (shipstate!='CA'&&shipstate!='California'){
				//not taxable
				nlapiSetFieldValue('istaxable','F');
				//nlapiSetFieldValue('taxitem','');
				//nlapiSetFieldValue('taxrate','');
			}
			else if (exempt==true){
				nlapiSetFieldValue('istaxable','F');
				//nlapiSetFieldValue('taxitem','');
				//nlapiSetFieldValue('taxrate','');
			}
			
       		if( taxable&&!exempt&&(shipstate=='CA'||shipstate=='California')) {
          
          		nlapiSetFieldValue('istaxable','T');
       		 }	
	  }
  //}
}