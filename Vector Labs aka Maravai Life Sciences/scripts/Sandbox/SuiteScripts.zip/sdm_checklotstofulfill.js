// runs on clicking save on the item fulfillment record.
// on save record check for lot control item then return T/F if it has a lot
//
function onfulfillsave(type, name){

    var lines = nlapiGetLineItemCount('item');

    for (var i=1;i<=lines;i++){
        nlapiSelectLineItem('item',i);
        var itemserials = nlapiGetLineItemValue('item','serialnumbers',i);
        var itemid = nlapiGetLineItemValue('item','item',i);
        var rectype = nlapiLookupField('item', itemid, 'recordtype');

        if (rectype.indexOf('lot') > -1 ){
            if (itemserials == '' || itemserials == null){
                console.log('yeah, you need to entter a serial/inventory numbers');
                alert('Please enter in a Lot Number for line item #'+i);
                return false;
            } else {
                return true;
            }
        } else {return true;}


    }
    //fulfillbtn = document.getElementById('process');

    //fulfillbtn.onclick( itwasclicked() );

    //function itwasclicked(){
    //    console.log("u clicked the fulfill btn"); 
    //    return false;
    //}

    //var itemid = 1234;
    //nlapiLookupField('item', itemid, 'recordtype');    // will return string containing "lot"

    //trigger when the lot field is changed/submitted = sublist event of 


}
