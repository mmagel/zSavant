function PageInit(type)
{
	var formnum = nlapiGetFieldValue('customform');
var role = nlapiGetContext();
	var dept = role.getDepartment();

	var currentform = nlapiGetFieldValue('customform');
	
	switch(dept){
		case 1:
		case 2:
		case 3:
			var x = 111;
			break;
		case 4:
		case 5:
		case 6:
		case 8:
			var x = 110;
			break;			
		case 7:
			var x = 105;
			break;			
	}	

	if(formnum != x){
		try{
		nlapiSetFieldValue('customform',x,false,true);
		var y = nlapiGetFieldValue('customform',x);

		nlapiLogExecution('DEBUG','update jour error',x+' '+dept+ ' ' + formnum+ ' ' + y);

		}
		catch(e){
		nlapiLogExecution('ERROR','update jour error');
	}	


	}
}
