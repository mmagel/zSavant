function so_bs_check_po_duplicate(type)
{
	if ((type=='create'||type=='edit'||type=='xedit')&&nlapiGetContext().getExecutionContext()!='webservices'){
		if (nlapiGetFieldValue('otherrefnum')!=''&&nlapiGetFieldValue('otherrefnum')!=null){
			var num=nlapiGetFieldValue('otherrefnum');
			var cust=nlapiGetFieldValue('entity');
			var so=nlapiSearchRecord('salesorder',null,[new nlobjSearchFilter('entity',null,'anyof',cust) ,new nlobjSearchFilter('poastext',null,'is',num) , new nlobjSearchFilter('mainline',null,'is','T')],new nlobjSearchColumn('internalid'));
			if (so!=null){
				if (type=='create'){
					throw 'po number '+num+' is already in use. Sales Order not saved.';
				}
				else {
					for (var i=0; i<so.length; i++){
						if (so[i].getValue('internalid')!=nlapiGetRecordId()){
							throw 'po number '+num+' is already in use. Sales Order not saved.';
						}
					}
				}
			}
		}
	}
}